
import { GoogleGenAI } from "@google/genai";
import type { Asset } from '../types';

const API_KEY = process.env.API_KEY;

const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

if (!ai) {
    console.warn("Gemini API key not found. AI features will be disabled. Please set the API_KEY environment variable.");
}

export const generateTroubleshootingSteps = async (
  workOrderDescription: string,
  asset: Asset
): Promise<string> => {
  if (!ai) {
    return "Error: AI feature is disabled. Please configure the Gemini API key in your environment.";
  }

  const prompt = `
    You are an expert maintenance technician assistant.
    An asset has a problem. Based on the asset information and the problem description, provide a set of numbered, prioritized troubleshooting steps.
    Be concise and practical.

    **Asset Information:**
    - Name: ${asset.name}
    - Type: ${asset.type}
    - Manufacturer: ${asset.manufacturer}
    - Model: ${asset.model}

    **Problem Description:**
    "${workOrderDescription}"

    **Troubleshooting Steps:**
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.5,
        maxOutputTokens: 500,
        thinkingConfig: { thinkingBudget: 100 },
      }
    });

    if (!response.text) {
        return "Error: The AI model did not provide a response. This could be due to safety settings or an issue with the prompt. Please try rephrasing your request.";
    }

    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);

    let errorMessage = "An unexpected error occurred while contacting the AI service. Please check your network connection and try again.";
    
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            errorMessage = "The configured Gemini API key is not valid. Please check your environment configuration.";
        } else if (error.message.includes('fetch failed') || error.message.includes('NetworkError')) {
             errorMessage = "A network error occurred. Please check your internet connection and try again.";
        }
    }
    
    return `Error: ${errorMessage}`;
  }
};