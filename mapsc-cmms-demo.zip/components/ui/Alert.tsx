
import React from 'react';

interface AlertProps {
  type: 'error' | 'warning' | 'info' | 'success';
  title?: string;
  children: React.ReactNode;
}

const icons = {
  error: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
    </svg>
  ),
  warning: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 3.001-1.742 3.001H4.42c-1.53 0-2.493-1.667-1.743-3.001l5.58-9.92zM10 13a1 1 0 110-2 1 1 0 010 2zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
    </svg>
  ),
  info: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
    </svg>
  ),
  success: (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
    </svg>
  ),
};

const colors = {
    error: {
        bg: 'bg-red-50 dark:bg-red-900/20',
        icon: 'text-red-400',
        title: 'text-red-800 dark:text-red-200',
        text: 'text-red-700 dark:text-red-300',
    },
    warning: {
        bg: 'bg-yellow-50 dark:bg-yellow-900/20',
        icon: 'text-yellow-400',
        title: 'text-yellow-800 dark:text-yellow-200',
        text: 'text-yellow-700 dark:text-yellow-300',
    },
    info: {
        bg: 'bg-blue-50 dark:bg-blue-900/20',
        icon: 'text-blue-400',
        title: 'text-blue-800 dark:text-blue-200',
        text: 'text-blue-700 dark:text-blue-300',
    },
    success: {
        bg: 'bg-green-50 dark:bg-green-900/20',
        icon: 'text-green-400',
        title: 'text-green-800 dark:text-green-200',
        text: 'text-green-700 dark:text-green-300',
    },
};

export const Alert: React.FC<AlertProps> = ({ type, title, children }) => {
    const theme = colors[type];
    const icon = icons[type];
    
    if (!theme) {
        console.error(`Alert type "${type}" is not supported.`);
        return null;
    }
    
    return (
        <div className={`rounded-md p-4 ${theme.bg}`}>
            <div className="flex">
                <div className={`flex-shrink-0 ${theme.icon}`}>
                    {icon}
                </div>
                <div className="ml-3">
                    {title && <h3 className={`text-sm font-medium ${theme.title}`}>{title}</h3>}
                    <div className={`text-sm ${theme.text} ${title ? 'mt-2' : ''}`}>
                        {children}
                    </div>
                </div>
            </div>
        </div>
    );
};
