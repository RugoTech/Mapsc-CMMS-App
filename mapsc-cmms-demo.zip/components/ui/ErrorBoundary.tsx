import React, { Component, type ErrorInfo, type ReactNode } from 'react';
import { Card } from './Card';
import { Button } from './Button';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  constructor(props: Props) {
    super(props);
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  public render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="flex items-center justify-center h-full p-6">
          <Card title="Something went wrong" className="max-w-lg w-full bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800">
            <div className="text-center space-y-4">
              <div className="text-red-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Access Error or System Glitch</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                The application encountered an unexpected error. This is often caused by trying to access data you do not have permission to view, or a temporary system issue.
              </p>
              {this.state.error && (
                  <div className="text-xs text-left bg-white dark:bg-gray-800 p-2 rounded border border-red-100 dark:border-red-900 overflow-auto max-h-32">
                      {this.state.error.toString()}
                  </div>
              )}
              <div className="pt-2">
                <Button onClick={() => window.location.href = '/'} variant="secondary">
                  Reload Application
                </Button>
              </div>
            </div>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}
