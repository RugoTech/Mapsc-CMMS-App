

import React from 'react';

interface Column<T> {
  header: string;
  accessor: keyof T | ((item: T) => React.ReactNode);
}

interface TableProps<T> {
  columns: Column<T>[];
  data: T[];
  renderRowActions?: (item: T) => React.ReactNode;
  isSelectable?: boolean;
  selection?: (string | number)[];
  setSelection?: React.Dispatch<React.SetStateAction<(string | number)[]>>;
  footer?: React.ReactNode;
}

export const Table = <T extends { id: string | number }>(
  { columns, data, renderRowActions, isSelectable, selection, setSelection, footer }: TableProps<T>
) => {

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelection?.(data.map(item => item.id));
    } else {
      setSelection?.([]);
    }
  };

  const handleSelectRow = (id: string | number) => {
    setSelection?.(prev => {
      if (prev.includes(id)) {
        return prev.filter(selectedId => selectedId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const isAllSelected = selection && data.length > 0 && selection.length === data.length;
  const isIndeterminate = selection && selection.length > 0 && selection.length < data.length;

  return (
    <div className="overflow-x-auto bg-white dark:bg-gray-800 shadow-md rounded-lg">
      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead className="bg-gray-50 dark:bg-gray-700">
          <tr>
            {isSelectable && setSelection && (
              <th scope="col" className="px-6 py-3 no-print">
                 <input
                  type="checkbox"
                  className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  checked={!!isAllSelected}
// FIX: The ref callback should not return a value. Wrapped in a function body.
                  ref={el => { if (el) { el.indeterminate = !!isIndeterminate; }}}
                  onChange={handleSelectAll}
                />
              </th>
            )}
            {columns.map((col, index) => (
              <th
                key={index}
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"
              >
                {col.header}
              </th>
            ))}
            {renderRowActions && (
              <th scope="col" className="relative px-6 py-3 no-print">
                <span className="sr-only">Actions</span>
              </th>
            )}
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          {data.map((item) => (
            <tr key={item.id} className={`hover:bg-gray-50 dark:hover:bg-gray-700 ${selection?.includes(item.id) ? 'bg-indigo-50 dark:bg-indigo-900/20' : ''}`}>
              {isSelectable && setSelection && (
                <td className="px-6 py-4 whitespace-nowrap no-print">
                   <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    checked={selection?.includes(item.id)}
                    onChange={() => handleSelectRow(item.id)}
                  />
                </td>
              )}
              {columns.map((col, index) => (
                <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                  {typeof col.accessor === 'function'
                    ? col.accessor(item)
                    : (item[col.accessor] as React.ReactNode)}
                </td>
              ))}
              {renderRowActions && (
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium no-print">
                  {renderRowActions(item)}
                </td>
              )}
            </tr>
          ))}
        </tbody>
        {footer && (
            <tfoot className="bg-gray-100 dark:bg-gray-700 border-t-2 border-gray-200 dark:border-gray-600">
                {footer}
            </tfoot>
        )}
      </table>
    </div>
  );
};
