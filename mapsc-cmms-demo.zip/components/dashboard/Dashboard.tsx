
import React, { useContext, useMemo } from 'react';
import { Card } from '../ui/Card';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderStatus, AssetStatus, WorkRequestStatus, WorkOrderType } from '../../types';
import type { View, User, LaborLog } from '../../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, LabelList } from 'recharts';
import { useCurrencyConverter } from '../../hooks/useCurrencyConverter';
import { useSettings } from '../../contexts/SettingsContext';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { useDateFormatter } from '../../hooks/useDateFormatter';

// Helper to calculate true downtime by merging overlapping intervals
const calculateEffectiveDowntime = (logs: LaborLog[]): number => {
    if (logs.length === 0) return 0;

    const intervals = logs.map(log => ({
        start: new Date(log.startTime).getTime(),
        end: new Date(log.endTime).getTime()
    })).sort((a, b) => a.start - b.start);

    let totalTime = 0;
    let currentStart = intervals[0].start;
    let currentEnd = intervals[0].end;

    for (let i = 1; i < intervals.length; i++) {
        const nextStart = intervals[i].start;
        const nextEnd = intervals[i].end;

        if (nextStart < currentEnd) {
            currentEnd = Math.max(currentEnd, nextEnd);
        } else {
            totalTime += (currentEnd - currentStart);
            currentStart = nextStart;
            currentEnd = nextEnd;
        }
    }
    totalTime += (currentEnd - currentStart);
    return totalTime / (1000 * 60 * 60); // Convert ms to hours
};

const KPICard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; onClick?: () => void }> = ({ title, value, icon, onClick }) => (
    <Card className={onClick ? "cursor-pointer hover:shadow-lg transition-all duration-200" : ""}>
        <div className="flex items-start justify-between" onClick={onClick}>
            <div>
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">{title}</p>
                <p className="mt-1 text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white">{value}</p>
            </div>
            <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
                {icon}
            </div>
        </div>
    </Card>
);

interface DashboardProps {
  onNavigate: (view: View) => void;
  onNavigateToReport: (reportName: string) => void;
  currentUser: User | null;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate, onNavigateToReport, currentUser }) => {
  const context = useContext(DataContext);
  const { settings } = useSettings();
  const { convertAndFormat: formatCurrency } = useCurrencyConverter({ maximumFractionDigits: 0, minimumFractionDigits: 0 });
  const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
  const formatDate = useDateFormatter();


  if (!context || !currentUser) {
    return <div>Loading...</div>;
  }
  
  const { data } = context;

  const dashboardMetrics = useMemo(() => {
    const { workOrders, assets, parts, preventiveMaintenances, workRequests, meters, zones, users, laborLogs, messages, auditLog } = data;

    // --- Filtered Data based on User Access ---
    const accessibleAssets = assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
    const accessibleAssetIds = new Set(accessibleAssets.map(a => a.id));

    // Get user's planner group ID if applicable
    const userPlannerGroup = context.data.plannerGroups.find(pg => pg.userIds.includes(currentUser.id));

    const accessibleWorkOrders = workOrders.filter(wo => {
        let hasAccess = false;
        
        // 1. Check direct Asset/Zone access
        if (wo.assetId) {
             hasAccess = accessibleAssetIds.has(wo.assetId);
        } else if (wo.zoneId) {
             hasAccess = canSeeAllZones || accessibleZoneIds.includes(wo.zoneId);
        } else {
             hasAccess = canSeeAllZones;
        }
        
        // 2. Override: If assigned to user's Planner Group, they must see it (e.g., cross-zone assignment)
        if (!hasAccess && userPlannerGroup && wo.planningGroupId === userPlannerGroup.id) {
            hasAccess = true;
        }
        
        return hasAccess;
    });

    const accessibleParts = parts.filter(p => {
         const asset = p.assetId ? assets.find(a => a.id === p.assetId) : null;
         const partZoneId = asset?.zoneId;
         return canSeeAllZones || !partZoneId || accessibleZoneIds.includes(partZoneId);
    });

    // --- Time Period Definitions ---
    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const daysElapsed = today.getDate();
    const todayStr = today.toISOString().split('T')[0];

    // --- KPI Calculations ---
    const openWorkOrders = accessibleWorkOrders.filter(wo => wo.status === WorkOrderStatus.Open || wo.status === WorkOrderStatus.InProgress).length;
    
    const overdueWorkOrders = accessibleWorkOrders.filter(wo => 
        (wo.status === WorkOrderStatus.Open || wo.status === WorkOrderStatus.InProgress) &&
        wo.dueDate < todayStr
    ).length;

    // Updated logic: Count ALL low stock parts that are ACTIVE, regardless of procurement status.
    // This ensures consistency with the Inventory Alerts list.
    const lowStockParts = accessibleParts.filter(p => 
        (p.isActive ?? true) && p.quantity <= p.reorderPoint
    ).length;

    // Pending Work Requests filtering
    const pendingWorkRequests = workRequests.filter(wr => {
        if (wr.status !== WorkRequestStatus.Pending) return false;

        const asset = wr.assetId ? assets.find(a => a.id === wr.assetId) : null;
        
        // 1. Universal Access (Admin, Factory Manager, or Requester)
        if (canSeeAllZones || wr.requesterId === currentUser.id) {
            return true;
        }

        // 2. Planner Specific Logic
        if (currentUser.role === 'Planner') {
             const userPlannerGroups = context.data.plannerGroups
                .filter(pg => pg.userIds.includes(currentUser.id))
                .map(pg => pg.id);
             
             // A. Claimed by my group? Visible.
             if (wr.plannerGroupId && userPlannerGroups.includes(wr.plannerGroupId)) {
                 return true;
             }
             
             // B. Unclaimed?
             if (!wr.plannerGroupId) {
                 // Visible if in my zone OR if it has no asset (Location-based/Pool)
                 const isInAccessibleZone = asset ? accessibleZoneIds.includes(asset.zoneId) : false;
                 if (isInAccessibleZone || !wr.assetId) {
                     return true;
                 }
             }
             return false;
        }

        // 3. Standard Zone Access (for other restricted roles)
        if (asset && accessibleZoneIds.includes(asset.zoneId)) {
            return true;
        }

        return false;
    }).length;

    // Filter PMs based on accessible assets AND active status
    // Rule: PM must be Active, Asset must be Operational, and User must have access to Asset
    const accessiblePMs = preventiveMaintenances.filter(pm => {
        if (!accessibleAssetIds.has(pm.assetId)) return false;
        if (pm.isActive === false) return false; // Exclude paused PMs
        const asset = assets.find(a => a.id === pm.assetId);
        if (asset && asset.status !== AssetStatus.Operational) return false; // Exclude PMs on non-operational assets
        return true;
    });

    const calendarBasedUpcoming = accessiblePMs.filter(pm => {
      if (pm.triggerType !== 'Calendar' || !pm.nextDueDate) return false;
      const dueDate = new Date(pm.nextDueDate);
      const thirtyDaysFromNow = new Date();
      thirtyDaysFromNow.setDate(today.getDate() + 30);
      // Include today's due PMs AND Overdue PMs (dueDate <= 30 days from now covers past dates too)
      return dueDate <= thirtyDaysFromNow;
    }).length;

    const meterBasedUpcoming = accessiblePMs.filter(pm => {
      if (pm.triggerType !== 'Meter' || !pm.meterId || !pm.meterTriggerValue) return false;
      const meter = meters.find(m => m.id === pm.meterId);
      
      // Check if meter exists and is active. Inactive meters should not trigger alerts.
      if (!meter || meter.isActive === false) return false;
      
      const lastTrigger = pm.lastTriggerReading || 0;
      const nextTrigger = lastTrigger + pm.meterTriggerValue;
      const threshold = nextTrigger - (pm.meterTriggerValue * 0.1); // within 10%
      
      // Include anything approaching OR already past trigger (Overdue)
      return meter.lastReading >= threshold;
    }).length;
    const upcomingPMs = calendarBasedUpcoming + meterBasedUpcoming;
    
    // --- Current Month Calculations for Availability, MTBF, MTTR, and Downtime ---
    const relevantAssets = accessibleAssets.filter(a => a.status !== AssetStatus.Decommissioned);
    const totalRelevantAssets = relevantAssets.length;
    const plannedTime = totalRelevantAssets * daysElapsed * 24;
    
    // Downtime WOs (Breakdowns) this month, only for accessible assets
    const downtimeWOsCurrentMonth = accessibleWorkOrders.filter(wo =>
        wo.workOrderType === WorkOrderType.Breakdown &&
        wo.assetId && // CRITICAL: Only consider WOs linked to an Asset for availability metrics
        new Date(wo.createdDate) >= startOfMonth
    );
    
    // Calculate total downtime (effective clock time)
    const downtimeWOIds = new Set(downtimeWOsCurrentMonth.map(wo => wo.id));
    const downtimeLogs = laborLogs.filter(log => downtimeWOIds.has(log.workOrderId));
    const downtimeCurrentMonth = calculateEffectiveDowntime(downtimeLogs);
    
    // Machine Availability
    const runTime = Math.max(0, plannedTime - downtimeCurrentMonth);
    const availabilityPercentage = plannedTime > 0 ? (runTime / plannedTime) * 100 : 100;
    const machineAvailability = `${availabilityPercentage.toFixed(0)}%`;

    // MTBF (Current Month) - Only calculate based on COMPLETED failures to avoid skewing with open tickets (0 downtime)
    const completedDowntimeWOs = downtimeWOsCurrentMonth.filter(
        wo => wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived
    );
    const completedDowntimeWOIds = new Set(completedDowntimeWOs.map(wo => wo.id));
    const completedDowntimeLogs = laborLogs.filter(log => completedDowntimeWOIds.has(log.workOrderId));
    const completedDowntimeDuration = calculateEffectiveDowntime(completedDowntimeLogs);

    const totalUptimeForMTBF = plannedTime - completedDowntimeDuration;
    const failureCountForMTBF = completedDowntimeWOs.length;
    const mtbfValue = failureCountForMTBF > 0 ? totalUptimeForMTBF / failureCountForMTBF : null;
    const mtbf = mtbfValue !== null ? `${mtbfValue.toLocaleString('en-US', {maximumFractionDigits: 0})} Hrs` : 'N/A';

    // MTTR (Current Month) - Only calculate based on COMPLETED repairs
    const completedRepairWOs = accessibleWorkOrders.filter(
        wo => (wo.workOrderType === WorkOrderType.Breakdown || wo.workOrderType === WorkOrderType.Corrective) &&
              wo.assetId && // CRITICAL: Only consider WOs linked to an Asset for MTTR
              new Date(wo.createdDate) >= startOfMonth &&
              (wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived)
    );
    
    const repairWOIdsCurrentMonth = new Set(completedRepairWOs.map(wo => wo.id));
    
    // For MTTR, we typically care about total man-hours spent fixing, OR effective downtime depending on KPI definition.
    // Usually MTTR = Total Downtime Time / Number of Failures. 
    // Let's stick to effective time (how long the machine was down/being fixed) for consistency with MTBF.
    const repairLogs = laborLogs.filter(log => repairWOIdsCurrentMonth.has(log.workOrderId));
    const totalRepairTimeCurrentMonth = calculateEffectiveDowntime(repairLogs);
    
    const totalRepairsCurrentMonth = completedRepairWOs.length;
    const mttr = totalRepairsCurrentMonth > 0 ? `${(totalRepairTimeCurrentMonth / totalRepairsCurrentMonth).toFixed(1)} Hrs` : 'N/A';

    // --- Chart Data Aggregation ---
    
    // Workload (Current Month) - This remains Man-Hours
    // Filter labor logs to only include those on accessible work orders to show relevant workload
    const accessibleWOIds = new Set(accessibleWorkOrders.map(wo => wo.id));
    // We also filter to logs created this month
    const laborLogsThisMonth = laborLogs.filter(log => new Date(log.startTime) >= startOfMonth && accessibleWOIds.has(log.workOrderId));
    
    // Updated: Calculate hours by the *User's* Work Center to show actual resource utilization/workload
    const hoursByWorkCenter = laborLogsThisMonth.reduce((acc, log) => {
        const user = users.find(u => u.id === log.userId);
        const userWorkCenter = user?.workCenter || 'Unassigned';
        
        // Map user work center names to IDs if possible for consistency, or just use name
        // For the chart, we'll aggregate by Name directly since that's what we display.
        
        const duration = (new Date(log.endTime).getTime() - new Date(log.startTime).getTime()) / (1000 * 60 * 60);
        acc[userWorkCenter] = (acc[userWorkCenter] || 0) + duration;
        
        return acc;
    }, {} as Record<string, number>);

    // Filter visible work centers based on what the current user should see
    // If the user can see all zones, they see all work centers.
    // If restricted, they only see work centers relevant to their zones/role.
    // However, for "Active Workload", we should show where the work is happening.
    
    const workloadData = Object.entries(hoursByWorkCenter).map(([name, hours]) => ({
        name,
        'Labor Hours': Number((hours as number).toFixed(1))
    }));
    
    // --- Asset Meters by Zone ---
    const metersByZone: { [zoneName: string]: { automatic: number; manual: number } } = {};
    // Filter meters by accessible assets
    const accessibleMeters = meters.filter(m => accessibleAssetIds.has(m.assetId));
    
    accessibleMeters.forEach(meter => {
      const asset = assets.find(a => a.id === meter.assetId);
      const zoneId = asset?.zoneId;
      const zoneName = zoneId ? zones.find(z => z.id === zoneId)?.name || 'Unassigned' : 'Unassigned';
      
      if (!metersByZone[zoneName]) {
        metersByZone[zoneName] = { automatic: 0, manual: 0 };
      }
      
      if (meter.type === 'Automatic') {
        metersByZone[zoneName].automatic += 1;
      } else {
        metersByZone[zoneName].manual += 1;
      }
    });

    const meterZoneData = Object.entries(metersByZone).map(([name, counts]) => ({ name, ...counts }));

    // --- Recently Active Users (Factual based on Logs) ---
    const userLastActiveMap = new Map<string, number>();
    
    // Check Audit Logs
    auditLog.forEach(log => {
        const time = new Date(log.timestamp).getTime();
        if (time > (userLastActiveMap.get(log.userId) || 0)) {
            userLastActiveMap.set(log.userId, time);
        }
    });
    // Check Labor Logs
    laborLogs.forEach(log => {
        const time = new Date(log.startTime).getTime(); // Use start time as activity point
        if (time > (userLastActiveMap.get(log.userId) || 0)) {
            userLastActiveMap.set(log.userId, time);
        }
    });

    const activeUsers = users
        .filter(u => userLastActiveMap.has(u.id) && (u.isActive ?? true))
        .sort((a, b) => (userLastActiveMap.get(b.id) || 0) - (userLastActiveMap.get(a.id) || 0))
        .slice(0, 5);

    // --- Recent Messages ---
    const recentMessages = messages
        .filter(m => m.recipientId === currentUser.id)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 5);

    return {
      openWorkOrders, overdueWorkOrders, downtimeCurrentMonth, lowStockParts, pendingWorkRequests,
      upcomingPMs,
      mtbf, mttr, machineAvailability, workloadData,
      meterZoneData, activeUsers, recentMessages
    };
  }, [data, settings.laborRatePerHour, accessibleZoneIds, canSeeAllZones, currentUser]);

  const {
    openWorkOrders, overdueWorkOrders, downtimeCurrentMonth, lowStockParts, pendingWorkRequests,
    upcomingPMs,
    mtbf, mttr, machineAvailability, workloadData,
    meterZoneData, activeUsers, recentMessages
  } = dashboardMetrics;

  const getInitials = (name: string) => {
    const names = name.split(' ');
    let initials = names[0].substring(0, 1);
    if (names.length > 1) {
        initials += names[names.length - 1].substring(0, 1);
    }
    return initials.toUpperCase();
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div onClick={() => onNavigate('Work Orders')}>
            <KPICard title="Open Work Orders" value={openWorkOrders} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>} onClick={() => onNavigate('Work Orders')} />
        </div>
        <div onClick={() => onNavigate('Work Orders')}>
            <KPICard title="Overdue Work Orders" value={overdueWorkOrders} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} onClick={() => onNavigate('Work Orders')} />
        </div>
        <div onClick={() => onNavigateToReport('Asset Downtime Report')}>
            <KPICard title="Downtime (Current Month)" value={`${downtimeCurrentMonth.toFixed(1)} Hrs`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-orange-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>} onClick={() => onNavigateToReport('Asset Downtime Report')} />
        </div>
        <div onClick={() => onNavigate('Work Requests')}>
            <KPICard title="Pending Work Requests" value={pendingWorkRequests} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>} onClick={() => onNavigate('Work Requests')} />
        </div>
        <div onClick={() => onNavigate('Inventory Alerts')}>
            <KPICard title="Critical Low Stock" value={lowStockParts} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-1.414 1.414a1 1 0 01-1.414 0l-1.414-1.414A1 1 0 009.586 13H4" /></svg>} onClick={() => onNavigate('Inventory Alerts')} />
        </div>
        
        <div onClick={() => onNavigateToReport('MTBF')}>
            <KPICard title="MTBF (Current Month)" value={mtbf} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} onClick={() => onNavigateToReport('MTBF')} />
        </div>
        <div onClick={() => onNavigateToReport('MTTR')}>
            <KPICard title="MTTR (Current Month)" value={mttr} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} onClick={() => onNavigateToReport('MTTR')} />
        </div>
        <div onClick={() => onNavigateToReport('Machine Availability')}>
            <KPICard title="Machine Availability" value={machineAvailability} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-teal-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 20.417l5.5-5.5a3 3 0 014.242 0l5.5 5.5a12.02 12.02 0 00-2.882-11.417z" /></svg>} onClick={() => onNavigateToReport('Machine Availability')} />
        </div>
        <div onClick={() => onNavigate('Preventive Maintenance')}>
            <KPICard title="Due & Upcoming PMs" value={upcomingPMs} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>} onClick={() => onNavigate('Preventive Maintenance')} />
        </div>

        <Card title="Workload by Work Center (Current Month)" className="md:col-span-2">
             <div className="h-72 w-full min-w-0 relative">
                 <ResponsiveContainer width="100%" height="100%" minWidth={0} debounce={50}>
                    <BarChart data={workloadData} margin={{ top: 20, right: 20, left: -10, bottom: 20 }}>
                        <XAxis dataKey="name" interval={0} tick={{ fontSize: 12 }} />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="Labor Hours" fill="#4f46e5">
                            <LabelList dataKey="Labor Hours" position="top" />
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </Card>
        
        <Card title="Asset Meters by Zone" className="md:col-span-2">
            <div className="space-y-3 max-h-64 overflow-y-auto">
                {meterZoneData.sort((a,b) => a.name.localeCompare(b.name)).map(zone => (
                    <div key={zone.name} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <p className="font-semibold text-gray-800 dark:text-gray-200">{zone.name}</p>
                        <div className="flex justify-between items-center mt-1 text-sm">
                            <div className="flex items-center text-gray-600 dark:text-gray-400">
                                <span className="w-2.5 h-2.5 bg-blue-500 rounded-full mr-2"></span>
                                Automatic
                            </div>
                            <span className="font-bold">{zone.automatic}</span>
                        </div>
                        <div className="flex justify-between items-center mt-1 text-sm">
                            <div className="flex items-center text-gray-600 dark:text-gray-400">
                                <span className="w-2.5 h-2.5 bg-gray-400 rounded-full mr-2"></span>
                                Manual
                            </div>
                            <span className="font-bold">{zone.manual}</span>
                        </div>
                    </div>
                ))}
            </div>
        </Card>

        <Card title="Recent Messages" className="md:col-span-2">
            <div className="space-y-3 max-h-64 overflow-y-auto">
                {recentMessages.length > 0 ? (
                    recentMessages.map(msg => (
                        <div 
                            key={msg.id} 
                            className={`p-3 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 ${!msg.read ? 'bg-indigo-50 dark:bg-indigo-900/20 border-l-4 border-indigo-500' : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700'}`}
                            onClick={() => onNavigate('Messages')}
                        >
                            <div className="flex justify-between items-start">
                                <p className={`text-sm font-semibold ${!msg.read ? 'text-indigo-800 dark:text-indigo-200' : 'text-gray-800 dark:text-gray-200'}`}>
                                    {msg.title}
                                </p>
                                <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap ml-2">
                                    {formatDate(msg.date)}
                                </span>
                            </div>
                            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1 truncate">From: {msg.sender}</p>
                        </div>
                    ))
                ) : (
                    <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">No recent messages.</p>
                )}
            </div>
        </Card>

        <Card title="Recently Active Users" className="md:col-span-2">
            <div className="space-y-4 max-h-64 overflow-y-auto">
                {activeUsers.map(user => (
                    <div key={user.id} className="flex items-center">
                        <div className="relative">
                            {user.profilePictureUrl ? (
                                <img className="h-10 w-10 rounded-full" src={user.profilePictureUrl} alt={user.name} />
                            ) : (
                                <div className="h-10 w-10 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold">
                                    {getInitials(user.name)}
                                </div>
                            )}
                            <span className="absolute bottom-0 right-0 block h-2.5 w-2.5 rounded-full bg-green-400 ring-2 ring-white dark:ring-gray-800"></span>
                        </div>
                        <div className="ml-3">
                            <p className="text-sm font-medium text-gray-900 dark:text-white">{user.name}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{user.role}</p>
                        </div>
                    </div>
                ))}
                {activeUsers.length === 0 && (
                    <p className="text-sm text-gray-500 text-center py-2">No recent activity detected.</p>
                )}
            </div>
        </Card>
    </div>
  );
};
