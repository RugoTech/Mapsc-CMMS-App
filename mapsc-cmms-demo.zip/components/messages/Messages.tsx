
import React, { useContext, useState, useEffect, useMemo } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import type { Message, User } from '../../types';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { Alert } from '../ui/Alert';
import { useDateFormatter } from '../../hooks/useDateFormatter';

const ComposeMessageModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSend: (recipientId: string, title: string, body: string) => void;
    currentUser: User;
    initialRecipientId?: string;
    initialTitle?: string;
}> = ({ isOpen, onClose, onSend, currentUser, initialRecipientId = '', initialTitle = '' }) => {
    const context = useContext(DataContext);
    const [recipientId, setRecipientId] = useState(initialRecipientId);
    const [title, setTitle] = useState(initialTitle);
    const [body, setBody] = useState('');

    // Memoize users to prevent the array reference from changing on every render,
    // which was causing the useEffect to fire repeatedly and clear the form inputs.
    const users = useMemo(() => {
        return context?.data.users.filter(u => u.id !== currentUser.id && (u.isActive ?? true)) || [];
    }, [context?.data.users, currentUser.id]);

    useEffect(() => {
        if (isOpen) {
            setRecipientId(initialRecipientId); 
            setTitle(initialTitle);
            setBody('');
        }
    }, [isOpen, initialRecipientId, initialTitle]);

    const handleSend = () => {
        if (recipientId && title.trim() && body.trim()) {
            onSend(recipientId, title, body);
            onClose();
        } else {
            alert('Please fill out all fields.');
        }
    };

    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSend}>Send Message</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="New Message" footer={modalFooter}>
            <div className="space-y-4">
                <div>
                    <label htmlFor="recipientId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">To:</label>
                    <select id="recipientId" value={recipientId} onChange={e => setRecipientId(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                        <option value="">Select a recipient...</option>
                        {users.map(user => (
                            <option key={user.id} value={user.id}>{user.name} ({user.role})</option>
                        ))}
                    </select>
                </div>
                <Input id="title" label="Title" value={title} onChange={e => setTitle(e.target.value)} required />
                <div>
                    <label htmlFor="body" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Body:</label>
                    <textarea id="body" value={body} onChange={e => setBody(e.target.value)} rows={6} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required />
                </div>
            </div>
        </Modal>
    );
};


export const Messages: React.FC<{ currentUser: User | null }> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const [activeTab, setActiveTab] = useState<'inbox' | 'sent'>('inbox');
    const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
    const [isComposeOpen, setIsComposeOpen] = useState(false);
    const [replyData, setReplyData] = useState<{ recipientId: string; title: string }>({ recipientId: '', title: '' });
    const [messageToDelete, setMessageToDelete] = useState<Message | null>(null);
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    const [isBulkDeleteConfirmOpen, setIsBulkDeleteConfirmOpen] = useState(false);
    const formatDate = useDateFormatter();
    
    if (!context || !currentUser) return <div>Loading...</div>;
    
    const { data, setData } = context;

    const messages = useMemo(() => {
        return data.messages
            .filter(m => {
                if (activeTab === 'inbox') {
                    return m.recipientId === currentUser.id;
                } else {
                    return m.sender === currentUser.name;
                }
            })
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [data.messages, currentUser.id, currentUser.name, activeTab]);
        
    const unreadCount = useMemo(() => {
        return data.messages.filter(m => m.recipientId === currentUser.id && !m.read).length;
    }, [data.messages, currentUser.id]);

    // Auto-select first message logic when tab changes or messages list updates (e.g. mount)
    useEffect(() => {
        if (messages.length > 0) {
            // Auto-select if no selection or if current selection is not in the new list (e.g. after tab switch)
            if (!selectedMessage || !messages.find(m => m.id === selectedMessage.id)) {
                 setSelectedMessage(messages[0]);
            }
        } else {
            setSelectedMessage(null);
        }
        setSelectedIds([]); // Clear bulk selection when tab/list changes
    }, [activeTab, messages]);

    const handleSelectMessage = (message: Message) => {
        setSelectedMessage(message);
        // Mark as read when selected in Inbox
        if (activeTab === 'inbox' && !message.read) {
            handleMarkAsRead(message.id);
        }
    };
    
    const handleMarkAsRead = (messageId: string) => {
        setData(prevData => ({
            ...prevData,
            messages: prevData.messages.map(m =>
                m.id === messageId ? { ...m, read: true } : m
            ),
        }));
    };
    
    const handleDeleteClick = (message: Message) => {
        setMessageToDelete(message);
    };

    const handleToggleSelect = (id: string) => {
        setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };

    const handleBulkDelete = () => {
        setIsBulkDeleteConfirmOpen(true);
    };

    const confirmBulkDelete = () => {
        setData(prev => ({
            ...prev,
            messages: prev.messages.filter(m => !selectedIds.includes(m.id))
        }));
        
        // If selected message was deleted, clear selection
        if (selectedMessage && selectedIds.includes(selectedMessage.id)) {
            setSelectedMessage(null);
        }
        
        setSelectedIds([]);
        setIsBulkDeleteConfirmOpen(false);
    };

    const confirmDeleteMessage = () => {
        if (!messageToDelete) return;
        
        setData(prevData => ({
            ...prevData,
            messages: prevData.messages.filter(m => m.id !== messageToDelete.id),
        }));
        if(selectedMessage?.id === messageToDelete.id) {
            setSelectedMessage(null);
        }
        setMessageToDelete(null);
    };
    
    const handleSendMessage = (recipientId: string, title: string, body: string) => {
        setData(prevData => {
            const newMessage: Message = {
                id: `MSG-${String(prevData.messages.length + 1).padStart(3, '0')}`,
                sender: currentUser.name,
                recipientId,
                title,
                body,
                date: new Date().toISOString(),
                read: false,
            };
            return {
                ...prevData,
                messages: [newMessage, ...prevData.messages],
            };
        });
    };

    const handleReply = (message: Message) => {
        // Find user by name since sender is stored as name in Message type
        const senderUser = data.users.find(u => u.name === message.sender);
        if (senderUser) {
            setReplyData({
                recipientId: senderUser.id,
                title: `Re: ${message.title}`
            });
            setIsComposeOpen(true);
        } else {
            console.error("Could not find user ID for sender:", message.sender);
        }
    };

    const handleOpenCompose = () => {
        setReplyData({ recipientId: '', title: '' });
        setIsComposeOpen(true);
    };

    const getUserName = (id: string) => {
        return data.users.find(u => u.id === id)?.name || id;
    };

    return (
        <>
            <Card 
                title={activeTab === 'inbox' ? `Inbox (${unreadCount} unread)` : 'Sent Messages'} 
                actions={
                    <div className="flex space-x-2">
                        {selectedIds.length > 0 && (
                            <Button variant="danger" onClick={handleBulkDelete}>
                                Delete Selected ({selectedIds.length})
                            </Button>
                        )}
                        <Button onClick={handleOpenCompose}>New Message</Button>
                    </div>
                }
            >
                
                {/* Tabs */}
                <div className="flex justify-between items-center mb-4">
                    <div className="flex space-x-1 bg-gray-100 dark:bg-gray-700/50 p-1 rounded-lg w-fit">
                        <button
                            onClick={() => { setActiveTab('inbox'); }}
                            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'inbox' ? 'bg-white dark:bg-gray-600 shadow text-indigo-600 dark:text-indigo-300' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                        >
                            Inbox
                        </button>
                        <button
                            onClick={() => { setActiveTab('sent'); }}
                            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'sent' ? 'bg-white dark:bg-gray-600 shadow text-indigo-600 dark:text-indigo-300' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                        >
                            Sent
                        </button>
                    </div>
                </div>
                
                <div className="mb-4">
                    <Alert type="info">Messages and notifications are automatically deleted after 6 months.</Alert>
                </div>

                <div className="flex flex-col md:flex-row gap-4 h-[calc(100vh-340px)]">
                    {/* Message List */}
                    <div className="w-full md:w-1/3 border-r dark:border-gray-700 overflow-y-auto pr-2">
                        <ul className="divide-y dark:divide-gray-700">
                            {messages.length > 0 ? messages.map(message => (
                                <li
                                    key={message.id}
                                    onClick={() => handleSelectMessage(message)}
                                    className={`p-3 cursor-pointer rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors mb-1 ${!message.read && activeTab === 'inbox' ? 'font-bold bg-blue-50 dark:bg-blue-900/10' : ''} ${selectedMessage?.id === message.id ? 'bg-indigo-100 dark:bg-indigo-900 ring-1 ring-indigo-300' : ''}`}
                                >
                                    <div className="flex items-start">
                                        <input
                                            type="checkbox"
                                            checked={selectedIds.includes(message.id)}
                                            onClick={(e) => e.stopPropagation()}
                                            onChange={() => handleToggleSelect(message.id)}
                                            className="mr-3 h-4 w-4 mt-1 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                        />
                                        <div className="flex-1 min-w-0">
                                            <div className="flex justify-between text-sm mb-1">
                                                <span className="truncate font-medium">
                                                    {activeTab === 'inbox' ? message.sender : `To: ${getUserName(message.recipientId)}`}
                                                </span>
                                                <span className="text-xs text-gray-500 whitespace-nowrap ml-1">{formatDate(message.date)}</span>
                                            </div>
                                            <p className="truncate text-sm text-gray-600 dark:text-gray-400">{message.title}</p>
                                        </div>
                                    </div>
                                </li>
                            )) : (
                                <div className="text-center py-8 text-gray-500">No messages found.</div>
                            )}
                        </ul>
                    </div>

                    {/* Message Detail */}
                    <div className="w-full md:w-2/3 p-4 flex flex-col bg-gray-50 dark:bg-gray-800 rounded-lg border dark:border-gray-700">
                        {selectedMessage ? (
                            <>
                                <div className="border-b dark:border-gray-700 pb-4 mb-4">
                                    <h2 className="text-xl font-semibold mb-2">{selectedMessage.title}</h2>
                                    <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
                                        <div>
                                            <span className="block">From: <span className="font-medium text-gray-900 dark:text-gray-200">{selectedMessage.sender}</span></span>
                                            <span className="block">To: <span className="font-medium text-gray-900 dark:text-gray-200">{getUserName(selectedMessage.recipientId)}</span></span>
                                        </div>
                                        <span>{formatDate(selectedMessage.date)} {new Date(selectedMessage.date).toLocaleTimeString()}</span>
                                    </div>
                                </div>
                                <div className="flex-grow overflow-y-auto whitespace-pre-wrap">
                                    <p className="text-gray-800 dark:text-gray-300 leading-relaxed">{selectedMessage.body}</p>
                                </div>
                                <div className="mt-4 pt-4 border-t dark:border-gray-700 flex justify-end space-x-2">
                                    {/* Reply Button: Only show if sender is not System and in Inbox */}
                                    {activeTab === 'inbox' && selectedMessage.sender !== 'System' && (
                                        <Button variant="primary" onClick={() => handleReply(selectedMessage)}>Reply</Button>
                                    )}
                                    <Button variant="danger" onClick={() => handleDeleteClick(selectedMessage)}>Delete</Button>
                                </div>
                            </>
                        ) : (
                            <div className="flex-grow flex flex-col items-center justify-center text-gray-400">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 00-2-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                                <p>Select a message to read</p>
                            </div>
                        )}
                    </div>
                </div>
            </Card>
            <ComposeMessageModal
                isOpen={isComposeOpen}
                onClose={() => setIsComposeOpen(false)}
                onSend={handleSendMessage}
                currentUser={currentUser}
                initialRecipientId={replyData.recipientId}
                initialTitle={replyData.title}
            />
            
            {messageToDelete && (
                <ConfirmationModal
                    isOpen={!!messageToDelete}
                    onClose={() => setMessageToDelete(null)}
                    onConfirm={confirmDeleteMessage}
                    title="Delete Message"
                    confirmText="Delete"
                    confirmButtonVariant="danger"
                >
                    <p>Are you sure you want to delete this message? This action cannot be undone.</p>
                </ConfirmationModal>
            )}

            {isBulkDeleteConfirmOpen && (
                <ConfirmationModal
                    isOpen={isBulkDeleteConfirmOpen}
                    onClose={() => setIsBulkDeleteConfirmOpen(false)}
                    onConfirm={confirmBulkDelete}
                    title="Delete Selected Messages"
                    confirmText="Delete All"
                    confirmButtonVariant="danger"
                >
                    <p>Are you sure you want to delete {selectedIds.length} selected message(s)? This action is irreversible.</p>
                </ConfirmationModal>
            )}
        </>
    );
};
