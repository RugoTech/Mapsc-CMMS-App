
import React, { useState, useEffect, useContext, useCallback, useMemo } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { WorkInstruction, WorkInstructionOperation, User } from '../../types';

interface WorkInstructionFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: WorkInstruction) => void;
  itemToEdit: WorkInstruction | null;
  currentUser: User | null;
}

export const WorkInstructionForm: React.FC<WorkInstructionFormProps> = ({ isOpen, onClose, onSave, itemToEdit, currentUser }) => {
    const context = useContext(DataContext);
    const getInitialState = useCallback((): Omit<WorkInstruction, 'id'> => ({
        assetId: '', // Forces manual selection
        description: '',
        createdDate: new Date().toISOString().split('T')[0],
        createdBy: currentUser?.id || '',
        operations: [{ opNo: '001', description: '', duration: 0 }],
        totalDuration: 0,
        remarks: ''
    }), [currentUser]);
    
    const [formData, setFormData] = useState(getInitialState());

    const availableAssets = useMemo(() => {
        if (!context || !currentUser) return [];
        const { assets, zones, plannerGroups } = context.data;

        // Allow admins to see all
        if (currentUser.role === 'Administrator') return assets;

        // Check if user is part of a Planner Group
        const userPlannerGroup = plannerGroups.find(pg => pg.userIds.includes(currentUser.id));

        // Requirement: "Let users under the 'Planning Group' group ... be able to ONLY select those assets that belong to the zones they are linked to"
        if (userPlannerGroup) {
            // Find zones where planningGroupId matches the user's group ID
            const allowedZoneIds = zones
                .filter(z => z.planningGroupId === userPlannerGroup.id)
                .map(z => z.id);
            
            return assets.filter(a => allowedZoneIds.includes(a.zoneId));
        }

        // For other users (e.g. Engineers not in a specific planner group constraint in this context, or fallbacks)
        return assets;
    }, [context, currentUser]);

    useEffect(() => {
        if (isOpen) {
            setFormData(itemToEdit ? itemToEdit : getInitialState());
        }
    }, [isOpen, itemToEdit, getInitialState]);
    
    useEffect(() => {
        const total = formData.operations.reduce((sum, op) => sum + (Number(op.duration) || 0), 0);
        setFormData(prev => ({ ...prev, totalDuration: total }));
    }, [formData.operations]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleOperationChange = (index: number, field: keyof WorkInstructionOperation, value: string | number) => {
        const newOps = [...formData.operations];
        if (field === 'duration') {
             newOps[index] = { ...newOps[index], duration: Math.max(0, Number(value)) };
        } else {
             newOps[index] = { ...newOps[index], [field]: value };
        }
        setFormData(prev => ({...prev, operations: newOps}));
    };
    
    const addOperation = () => {
        const newOpNo = String(formData.operations.length + 1).padStart(3, '0');
        setFormData(prev => ({...prev, operations: [...prev.operations, { opNo: newOpNo, description: '', duration: 0 }]}));
    };

    const removeOperation = (index: number) => {
        if (formData.operations.length <= 1) return;
        setFormData(prev => ({...prev, operations: prev.operations.filter((_, i) => i !== index)}));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.assetId) {
            alert("Please select an asset.");
            return;
        }
        onSave(formData as WorkInstruction);
    };

    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="wi-form">{itemToEdit ? 'Save Changes' : 'Save'}</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={itemToEdit ? 'Edit Work Instruction' : 'New Work Instruction'} footer={modalFooter}>
            <form id="wi-form" onSubmit={handleSubmit} className="space-y-4">
                <Input id="description" label="Description" name="description" value={formData.description} onChange={handleChange} required maxLength={106} />
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="assetId" className="block text-sm font-medium">Asset</label>
                        <select id="assetId" name="assetId" value={formData.assetId} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" required>
                            <option value="" disabled>Select Asset...</option>
                            {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                        </select>
                    </div>
                    <Input id="totalDuration" label="Total Duration (Hrs)" name="totalDuration" type="number" value={formData.totalDuration} disabled />
                </div>
                
                <div className="border-t pt-4">
                    <h4 className="font-semibold mb-2">Operations</h4>
                    <div className="space-y-2">
                        {formData.operations.map((op, index) => (
                            <div key={index} className="flex items-center space-x-2">
                                <Input id={`opNo-${index}`} label="Op. #" name="opNo" value={op.opNo} onChange={e => handleOperationChange(index, 'opNo', e.target.value)} className="w-20" />
                                <div className="flex-grow">
                                  <Input id={`opDesc-${index}`} label="Description" name="description" value={op.description} onChange={e => handleOperationChange(index, 'description', e.target.value)} />
                                </div>
                                <Input id={`opDur-${index}`} label="Duration (Hrs)" name="duration" type="number" step="0.1" min="0" value={op.duration} onChange={e => handleOperationChange(index, 'duration', e.target.value)} className="w-24" />
                                <Button type="button" variant="danger" size="sm" onClick={() => removeOperation(index)} className="mt-6" disabled={formData.operations.length <= 1}>X</Button>
                            </div>
                        ))}
                    </div>
                    <Button type="button" variant="secondary" size="sm" onClick={addOperation} className="mt-2">Add Operation</Button>
                </div>
                
                <div>
                    <label htmlFor="remarks" className="block text-sm font-medium">Remarks</label>
                    <textarea id="remarks" name="remarks" rows={3} value={formData.remarks} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
                </div>
            </form>
        </Modal>
    );
};
