
import React, { useState, useContext, useMemo, useCallback, useRef, useEffect } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderStatus, Priority, WorkOrderType } from '../../types';
import type { WorkOrder, Asset, User, AuditLogEntry, SafetyInstruction, WorkInstruction, SOP } from '../../types';
import { Alert } from '../ui/Alert';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { useDateFormatter } from '../../hooks/useDateFormatter';
import { PrintableWorkOrderDocument } from './PrintableWorkOrderDocument';

interface WorkOrderListProps {
    onViewWorkOrder: (workOrderId: string) => void;
    currentUser: User | null;
}

const statusColors: Record<WorkOrderStatus, 'blue' | 'yellow' | 'green' | 'gray' | 'red'> = {
    [WorkOrderStatus.Open]: 'blue',
    [WorkOrderStatus.InProgress]: 'yellow',
    [WorkOrderStatus.Completed]: 'green',
    [WorkOrderStatus.Archived]: 'gray',
    [WorkOrderStatus.Cancelled]: 'red',
};

const priorityColors: Record<Priority, 'blue' | 'yellow' | 'red'> = {
    [Priority.Low]: 'blue',
    [Priority.Medium]: 'yellow',
    [Priority.High]: 'red',
    [Priority.Critical]: 'red',
};

const typeColors: Record<WorkOrderType, 'red' | 'yellow' | 'blue' | 'green'> = {
    [WorkOrderType.Breakdown]: 'red',
    [WorkOrderType.Corrective]: 'yellow',
    [WorkOrderType.Preventive]: 'blue',
    [WorkOrderType.Project]: 'green',
};

const cancelReasons = [
    "Cancelled-Production Priority(asset needed for production, maintenance postponed)",
    "Cancelled-Resources Constraints(labor or spare parts unavailable)",
    "Cancelled-Plan Optimization(task merged into another PM or rescheduled)",
    "Cancelled-Equipment Decommissioned(asset retired or replaced)",
    "Cancelled-Incorrect Plan(PM Plan was set up incorrectly)",
    "Cancelled-Others(User to type manually)"
];

const CancelWorkOrderModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (reason: string) => void;
    woId: string;
}> = ({ isOpen, onClose, onConfirm, woId }) => {
    const [selectedReason, setSelectedReason] = useState('');
    const [customReason, setCustomReason] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        if (isOpen) {
            setSelectedReason('');
            setCustomReason('');
            setError('');
        }
    }, [isOpen]);

    const handleConfirm = () => {
        if (!selectedReason) {
            setError('Please select a reason.');
            return;
        }
        let finalReason = selectedReason;
        if (selectedReason.startsWith("Cancelled-Others")) {
            if (!customReason.trim()) {
                setError('Please type the reason manually.');
                return;
            }
            finalReason = `Cancelled-Others: ${customReason}`;
        }
        onConfirm(finalReason);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`Cancel Work Order: ${woId}`}>
            <div className="space-y-4">
                {error && <Alert type="error">{error}</Alert>}
                <div>
                    <label htmlFor="reason" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Reason for PM (WO) Cancel:</label>
                    <select
                        id="reason"
                        value={selectedReason}
                        onChange={(e) => setSelectedReason(e.target.value)}
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                    >
                        <option value="">Select a reason...</option>
                        {cancelReasons.map((reason, idx) => (
                            <option key={idx} value={reason}>{reason}</option>
                        ))}
                    </select>
                </div>
                {selectedReason.startsWith("Cancelled-Others") && (
                    <Input
                        id="customReason"
                        label="Enter Reason"
                        value={customReason}
                        onChange={(e) => setCustomReason(e.target.value)}
                        placeholder="Type manual reason..."
                    />
                )}
                <div className="flex justify-end space-x-2 mt-4">
                    <Button variant="secondary" onClick={onClose}>Close</Button>
                    <Button variant="danger" onClick={handleConfirm}>Confirm Cancel</Button>
                </div>
            </div>
        </Modal>
    );
};


const NewWorkOrderForm: React.FC<{ isOpen: boolean; onClose: () => void; onSave: (wo: WorkOrder) => void, currentUser: User | null }> = ({ isOpen, onClose, onSave, currentUser }) => {
    const context = useContext(DataContext);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    const availableAssets = useMemo(() => {
        if (!context) return [];
        return context.data.assets.filter(a => {
            const hasAccess = canSeeAllZones || accessibleZoneIds.includes(a.zoneId);
            return hasAccess;
        });
    }, [context, accessibleZoneIds, canSeeAllZones]);

    const availableControllerGroups = useMemo(() => {
        if (!context || !currentUser) return [];

        // Check if current user belongs to a planner group
        const userPlannerGroup = context.data.plannerGroups.find(pg => pg.userIds.includes(currentUser.id));

        if (userPlannerGroup) {
            // Filter Maintenance Controllers linked to this Planner Group
            return context.data.maintenanceControllers.filter(cg => cg.plannerGroupId === userPlannerGroup.id);
        }
        
        // If not in a planner group (e.g. Admin or Manager), show all
        return context.data.maintenanceControllers;
    }, [context, currentUser]);

    const availableWorkCenters = useMemo(() => {
        if (!context || !currentUser) return [];
        
        // Filter Work Centers based on the available Controller Groups
        const allowedControllerGroupIds = availableControllerGroups.map(cg => cg.id);
        
        return context.data.workCenters.filter(wc => allowedControllerGroupIds.includes(wc.controllerGroupId));
    }, [context, availableControllerGroups]);
    
    const availableParentWOs = useMemo(() => {
        if (!context) return [];
        return context.data.workOrders.filter(wo => {
            const asset = wo.assetId ? context.data.assets.find(a => a.id === wo.assetId) : null;
            const woZoneId = asset ? asset.zoneId : wo.zoneId;
            const hasAccess = canSeeAllZones || (woZoneId && accessibleZoneIds.includes(woZoneId));
            return hasAccess;
        });
    }, [context, accessibleZoneIds, canSeeAllZones]);

    const [description, setDescription] = useState('');
    const [assetId, setAssetId] = useState('');
    const [priority, setPriority] = useState<Priority>(Priority.Medium);
    const [workOrderType, setWorkOrderType] = useState<WorkOrderType>(WorkOrderType.Corrective);
    const [parentWorkOrderId, setParentWorkOrderId] = useState('');
    const [estimatedDuration, setEstimatedDuration] = useState(0);
    const [controllerGroupId, setControllerGroupId] = useState('');
    const [workCenterId, setWorkCenterId] = useState('');
    const [assignedUserIds, setAssignedUserIds] = useState<string[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [dueDate, setDueDate] = useState('');

    useEffect(() => {
        if (isOpen && context) {
            setDescription('');
            setAssetId('');
            setPriority(Priority.Medium);
            setWorkOrderType(WorkOrderType.Corrective);
            setParentWorkOrderId('');
            setEstimatedDuration(0);
            setControllerGroupId('');
            setWorkCenterId('');
            setAssignedUserIds([]);
            setError(null);
            
            // Default Due Date to 7 days from now
            const nextWeek = new Date();
            nextWeek.setDate(nextWeek.getDate() + 7);
            setDueDate(nextWeek.toISOString().split('T')[0]);
        }
    }, [isOpen, context, availableControllerGroups]);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);

        if (!context || !currentUser) return;
        
        if (!description.trim()) {
            setError('Description cannot be empty.');
            return;
        }
        if (!assetId) {
            setError('Please select an asset.');
            return;
        }
        if (!controllerGroupId) {
            setError('Please select a Controller Group.');
            return;
        }
        if (assignedUserIds.length === 0) {
            setError('You must assign at least one person to the work order.');
            return;
        }

        if (workOrderType === WorkOrderType.Corrective && !parentWorkOrderId.trim()) {
            setError('A Parent Work Order is required for Corrective work orders.');
            return;
        }

        // Determine Planning Group
        // Priority 1: Asset Custodian
        // Priority 2: Current User's Planner Group (if they are a planner)
        const asset = context.data.assets.find(a => a.id === assetId);
        let planningGroupId = asset?.custodianId;

        if (!planningGroupId) {
            const plannerGroup = context.data.plannerGroups.find(pg => pg.userIds.includes(currentUser.id));
            planningGroupId = plannerGroup?.id;
        }

        let plantCostCodeId: string | undefined = undefined;
        let zoneCostCodeId: string | undefined = undefined;
        let zoneId: string | undefined = undefined;
        
        if (asset) {
            zoneId = asset.zoneId; // Ensure Zone is set from Asset
            const plant = context.data.plants.find(p => p.id === asset.plantId);
            if (plant) {
                plantCostCodeId = context.data.plantCostCodes.find(pcc => pcc.name === plant.name)?.id;
            }
            const zone = context.data.zones.find(z => z.id === asset.zoneId);
            if (zone) {
                zoneCostCodeId = context.data.zoneCostCodes.find(zcc => zcc.name === zone.name)?.id;
            }
        }

        const newWorkOrder: WorkOrder = {
            id: `WO-${String(context.data.workOrders.length + 1).padStart(3, '0')}`,
            description,
            assetId,
            priority,
            workOrderType,
            status: WorkOrderStatus.Open,
            dueDate: dueDate, // Use the editable state
            createdDate: new Date().toISOString().split('T')[0],
            createdBy: currentUser.id,
            partsUsed: [],
            estimatedDuration,
            laborHours: 0,
            assignedUserIds: assignedUserIds, // Explicitly pass the current state
            workCenterId: workCenterId || undefined,
            controllerGroupId,
            procedureIds: [],
            planningGroupId,
            plantCostCodeId,
            zoneCostCodeId,
            zoneId, // Ensure zoneId is set explicitly if available
            parentWorkOrderId: workOrderType === WorkOrderType.Corrective ? parentWorkOrderId : undefined,
        };
        onSave(newWorkOrder);
        onClose();
    };
    
    const footer = (
      <>
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button type="submit" form="wo-form">Create Work Order</Button>
      </>
    );

    if (!context) return null;

    const availableTechnicians = workCenterId
        ? context.data.workCenters.find(wc => wc.id === workCenterId)?.userIds
            .map(userId => context.data.users.find(u => u.id === userId))
            .filter((u): u is User => u !== undefined && (u.isActive ?? true))
        : [];

    const handleWorkCenterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setWorkCenterId(e.target.value);
        setAssignedUserIds([]); // Reset assigned users when WC changes
    };

    const selectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md";

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Create New Work Order" footer={footer} size="3xl">
            <form id="wo-form" onSubmit={handleSubmit} className="space-y-4">
                {error && <Alert type="error">{error}</Alert>}
                <Input id="description" label="Description" value={description} onChange={e => setDescription(e.target.value)} required maxLength={84} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="assetId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Asset</label>
                        <select id="assetId" value={assetId} onChange={e => setAssetId(e.target.value)} className={selectClasses} required>
                            <option value="">-- Select Asset --</option>
                            {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name} ({a.id})</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Priority</label>
                        <select id="priority" value={priority} onChange={e => setPriority(e.target.value as Priority)} className={selectClasses}>
                            {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="workOrderType" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Work Order Type</label>
                        <select id="workOrderType" value={workOrderType} onChange={e => setWorkOrderType(e.target.value as WorkOrderType)} className={selectClasses}>
                            <option value={WorkOrderType.Corrective}>{WorkOrderType.Corrective}</option>
                            <option value={WorkOrderType.Breakdown}>{WorkOrderType.Breakdown}</option>
                        </select>
                    </div>
                    <Input 
                        id="dueDate" 
                        label="Due Date" 
                        type="date" 
                        value={dueDate} 
                        onChange={e => setDueDate(e.target.value)} 
                        min={new Date().toISOString().split('T')[0]}
                        required 
                    />
                    <Input id="estimatedDuration" label="Estimated Duration (Hours)" type="number" step="0.01" min="0" value={estimatedDuration} onChange={e => setEstimatedDuration(Number(e.target.value))} required />
                    
                    {workOrderType === WorkOrderType.Corrective && (
                        <div className="">
                            <label htmlFor="parentWorkOrderId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Parent Work Order (Search or Type ID)</label>
                            <input 
                                list="parent-wos" 
                                id="parentWorkOrderId"
                                value={parentWorkOrderId} 
                                onChange={e => setParentWorkOrderId(e.target.value)} 
                                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                placeholder="Search or type WO ID..."
                                required
                            />
                            <datalist id="parent-wos">
                                {availableParentWOs.map(wo => (
                                    <option key={wo.id} value={wo.id}>{wo.id} - {wo.description}</option>
                                ))}
                            </datalist>
                        </div>
                    )}

                    <div className="md:col-span-2">
                        <label htmlFor="controllerGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Controller Group</label>
                        <select id="controllerGroupId" value={controllerGroupId} onChange={e => setControllerGroupId(e.target.value)} className={selectClasses} required>
                             <option value="">Select...</option>
                            {availableControllerGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                        </select>
                        {availableControllerGroups.length === 0 && <p className="text-xs text-red-500 mt-1">No controller groups available for your planning group.</p>}
                    </div>
                    <div className="md:col-span-2">
                        <label htmlFor="workCenterId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Work Center</label>
                        <select id="workCenterId" value={workCenterId} onChange={handleWorkCenterChange} className={selectClasses} disabled={!controllerGroupId}>
                            <option value="">Select a Work Center...</option>
                            {availableWorkCenters.map(wc => <option key={wc.id} value={wc.id}>{wc.name}</option>)}
                        </select>
                    </div>

                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Assigned Personnel</label>
                        <div className={`border border-gray-300 dark:border-gray-600 rounded-md overflow-y-auto h-32 bg-white dark:bg-gray-700 ${!workCenterId ? 'opacity-50 cursor-not-allowed' : ''}`}>
                            {availableTechnicians.length > 0 ? (
                                <div className="divide-y dark:divide-gray-600">
                                    {availableTechnicians.map(user => (
                                        <div 
                                            key={user.id} 
                                            className={`flex items-center p-2 hover:bg-gray-50 dark:hover:bg-gray-600 cursor-pointer ${assignedUserIds.includes(user.id) ? 'bg-indigo-50 dark:bg-indigo-900/30' : ''}`}
                                            onClick={() => {
                                                if (!workCenterId) return;
                                                setAssignedUserIds(prev => 
                                                    prev.includes(user.id) 
                                                    ? prev.filter(id => id !== user.id) 
                                                    : [...prev, user.id]
                                                );
                                            }}
                                        >
                                            <input
                                                type="checkbox"
                                                checked={assignedUserIds.includes(user.id)}
                                                onChange={() => {}}
                                                className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                                disabled={!workCenterId}
                                            />
                                            <span className="ml-2 text-sm text-gray-900 dark:text-white">{user.name}</span>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-sm text-gray-500 dark:text-gray-400 p-4 text-center">Select a Work Center to see available personnel.</p>
                            )}
                        </div>
                        <p className="mt-1 text-xs text-gray-500">Click rows to select multiple personnel.</p>
                    </div>
                </div>
            </form>
        </Modal>
    );
};


export const WorkOrderList: React.FC<WorkOrderListProps> = ({ onViewWorkOrder, currentUser }) => {
    const context = useContext(DataContext);
    const [isNewWOModalOpen, setIsNewWOModalOpen] = useState(false);
    const [cancelModalOpen, setCancelModalOpen] = useState(false);
    const [woToCancel, setWoToCancel] = useState<string | null>(null);
    const [isBatchPrintOpen, setIsBatchPrintOpen] = useState(false);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
    const formatDate = useDateFormatter();
    
    // Initialize filters from sessionStorage to persist state across navigation
    const [filters, setFilters] = useState(() => {
        const savedFilters = sessionStorage.getItem('woListFilters');
        return savedFilters ? JSON.parse(savedFilters) : {
            id: '',
            type: '',
            asset: '',
            status: '',
            zone: '',
            dueDate: '',
        };
    });

    const printRef = useRef<HTMLDivElement>(null);
    
    const userPlannerGroup = useMemo(() => {
        if (currentUser?.role !== 'Planner' || !context) return null;
        return context.data.plannerGroups.find(pg => pg.userIds.includes(currentUser.id));
    }, [context, currentUser]);

    // Persist filters to sessionStorage whenever they change
    useEffect(() => {
        sessionStorage.setItem('woListFilters', JSON.stringify(filters));
    }, [filters]);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { workOrders, assets, zones, plants, plannerGroups, safetyInstructions, workInstructions, sops } = data;

    const getAssetName = useCallback((assetId?: string) => {
        return assets.find(a => a.id === assetId)?.name || 'N/A';
    }, [assets]);
    
    const getZoneName = useCallback((workOrder: WorkOrder) => {
        const woZoneId = workOrder.assetId ? assets.find(a => a.id === workOrder.assetId)?.zoneId : workOrder.zoneId;
        if (woZoneId) {
            return zones.find(z => z.id === woZoneId)?.name || 'N/A';
        }
        return 'N/A';
    }, [assets, zones]);

    const filteredWorkOrders = useMemo(() => {
        return workOrders.filter(wo => {
            const asset = wo.assetId ? assets.find(a => a.id === wo.assetId) : null;
            const woZoneId = asset ? asset.zoneId : wo.zoneId;

            const zoneAccessMatch = canSeeAllZones || (woZoneId && accessibleZoneIds.includes(woZoneId));
            
            // VISIBILITY RULE:
            // 1. Standard Zone Access
            // 2. OR if the WO is assigned to the current user's Planner Group (allows seeing WOs created from 'pool' WRs without asset/zone)
            let hasAccess = zoneAccessMatch;
            if (!hasAccess && userPlannerGroup && wo.planningGroupId === userPlannerGroup.id) {
                hasAccess = true;
            }
            
            if (!hasAccess) return false;

            const idMatch = filters.id ? wo.id.toLowerCase().includes(filters.id.toLowerCase()) : true;
            const typeMatch = filters.type ? wo.workOrderType === filters.type : true;
            const assetMatch = filters.asset ? getAssetName(wo.assetId).toLowerCase().includes(filters.asset.toLowerCase()) : true;
            const statusMatch = filters.status ? wo.status === filters.status : true;
            const zoneFilterMatch = filters.zone ? woZoneId === filters.zone : true;
            const dueDateMatch = filters.dueDate ? wo.dueDate === filters.dueDate : true;

            return idMatch && typeMatch && assetMatch && statusMatch && zoneFilterMatch && dueDateMatch;
        });
    }, [workOrders, filters, getAssetName, assets, accessibleZoneIds, canSeeAllZones, userPlannerGroup]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({ id: '', type: '', asset: '', status: '', zone: '', dueDate: '' });
    };

    const removeFilter = (key: keyof typeof filters) => {
        setFilters(prev => ({ ...prev, [key]: '' }));
    };

    const handleSaveWorkOrder = (newWorkOrder: WorkOrder) => {
        const logEntry: AuditLogEntry = {
            id: `LOG-${String(data.auditLog.length + 1).padStart(3, '0')}`,
            timestamp: new Date().toISOString(),
            userId: currentUser!.id,
            action: 'CREATE',
            entityType: 'WorkOrder',
            entityId: newWorkOrder.id,
            details: `Created new work order '${newWorkOrder.description}' (${newWorkOrder.id}).`,
            status: 'Success'
        };
        // Ensure zoneId is populated if not already present, but assetId exists
        let woToSave = { ...newWorkOrder };
        if (!woToSave.zoneId && woToSave.assetId) {
             const asset = data.assets.find(a => a.id === woToSave.assetId);
             if (asset) {
                 woToSave.zoneId = asset.zoneId;
             }
        }

        setData(prevData => ({
            ...prevData,
            workOrders: [...prevData.workOrders, woToSave],
            auditLog: [logEntry, ...prevData.auditLog]
        }));
        alert(`Work Order ${newWorkOrder.id} created successfully!`);
    };
    
    const handlePrintList = () => {
        if (printRef.current) {
            const printContent = printRef.current.innerHTML;
            const printWindow = window.open('', '', 'height=800,width=1000');
            if (printWindow) {
                printWindow.document.write('<html><head><title>Work Orders</title>');
                printWindow.document.write(`
                    <style>
                        body { font-family: sans-serif; margin: 2rem; }
                        table { width: 100%; border-collapse: collapse; font-size: 12px; }
                        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        tr:nth-child(even) { background-color: #f9f9f9; }
                        tfoot { font-weight: bold; }
                        h1 { font-size: 24px; margin-bottom: 1rem; }
                        .no-print { display: none; }
                        /* Badge styles for printing */
                        span { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                        span[class*="bg-blue-100"] { background-color: #DBEAFE !important; color: #1E40AF !important; }
                        span[class*="bg-green-100"] { background-color: #D1FAE5 !important; color: #065F46 !important; }
                        span[class*="bg-yellow-100"] { background-color: #FEF3C7 !important; color: #92400E !important; }
                        span[class*="bg-red-100"] { background-color: #FEE2E2 !important; color: #991B1B !important; }
                        span[class*="bg-gray-100"] { background-color: #F3F4F6 !important; color: #1F2937 !important; }
                    </style>
                `);
                printWindow.document.write('</head><body>');
                printWindow.document.write('<h1>Work Orders</h1>');
                printWindow.document.write(printContent);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 500);
            }
        }
    };

    const handleBatchPrintConfirm = () => {
        setIsBatchPrintOpen(false);
        setTimeout(() => {
            window.print();
        }, 200);
    };

    const handleCancelClick = (wo: WorkOrder) => {
        // 1. Parts Check
        if (wo.partsUsed && wo.partsUsed.length > 0) {
            alert("Cannot cancel Work Order: Parts are attached (planned or issued). Remove parts from the Work Order before cancelling.");
            return;
        }

        // 2. Labor Check
        const hasLabor = data.laborLogs.some(log => log.workOrderId === wo.id);
        if (hasLabor) {
            alert("Cannot cancel Work Order: Labor hours have been logged. Remove labor entries before cancelling.");
            return;
        }

        // 3. External Costs Check (Linked PRs)
        const hasPRs = data.purchaseRequisitions.some(pr => pr.workOrderId === wo.id);
        if (hasPRs) {
            alert("Cannot cancel Work Order: External costs (Purchase Requisitions) are linked. Cancel or delete linked PRs before cancelling the Work Order.");
            return;
        }

        setWoToCancel(wo.id);
        setCancelModalOpen(true);
    };

    const handleCancelWorkOrder = (reason: string) => {
        if (!woToCancel) return;
        
        const logEntry: AuditLogEntry = {
            id: `LOG-${String(data.auditLog.length + 1).padStart(3, '0')}`,
            timestamp: new Date().toISOString(),
            userId: currentUser!.id,
            action: 'UPDATE',
            entityType: 'WorkOrder',
            entityId: woToCancel,
            details: `Work Order ${woToCancel} cancelled. Reason: ${reason}`,
            status: 'Success'
        };

        setData(prevData => ({
            ...prevData,
            workOrders: prevData.workOrders.map(wo => 
                wo.id === woToCancel 
                ? { ...wo, status: WorkOrderStatus.Cancelled, cancellationReason: reason }
                : wo
            ),
            auditLog: [logEntry, ...prevData.auditLog]
        }));
        setCancelModalOpen(false);
        setWoToCancel(null);
    };

    const totalEstimatedDuration = useMemo(() => {
        return filteredWorkOrders.reduce((sum, wo) => sum + wo.estimatedDuration, 0);
    }, [filteredWorkOrders]);

    const tableFooter = (
        <tr>
            <td colSpan={8} className="px-6 py-3 text-right text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                Total Estimated Duration
            </td>
            <td className="px-6 py-3 text-left text-sm font-bold text-gray-900 dark:text-white">
                {totalEstimatedDuration.toFixed(2)} Hrs
            </td>
            <td></td> {/* For Actions column */}
        </tr>
    );

    const columns = [
        { header: 'WO ID', accessor: 'id' as keyof WorkOrder },
        { 
            header: 'Description', 
            accessor: (item: WorkOrder) => (
                <span title={item.description}>
                    {item.description.length > 42 
                        ? `${item.description.substring(0, 42)}...` 
                        : item.description}
                </span>
            ) 
        },
        { 
            header: 'Type', 
            accessor: (item: WorkOrder) => <Badge color={typeColors[item.workOrderType]}>{item.workOrderType}</Badge> 
        },
        { header: 'Asset', accessor: (item: WorkOrder) => getAssetName(item.assetId) },
        { header: 'Zone', accessor: (item: WorkOrder) => getZoneName(item) },
        { header: 'Priority', accessor: (item: WorkOrder) => <Badge color={priorityColors[item.priority]}>{item.priority}</Badge> },
        { header: 'Status', accessor: (item: WorkOrder) => <Badge color={statusColors[item.status]}>{item.status}</Badge> },
        { header: 'Due Date', accessor: (item: WorkOrder) => formatDate(item.dueDate) },
        { header: 'Est. Duration (Hrs)', accessor: 'estimatedDuration' as keyof WorkOrder },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    // Helper for friendly filter key names
    const filterLabels: Record<string, string> = {
        id: 'WO ID',
        type: 'Type',
        asset: 'Asset',
        status: 'Status',
        zone: 'Zone',
        dueDate: 'Due Date'
    };

    const activeFilters = Object.entries(filters).filter(([key, value]) => value !== '');

    const allProcedures = [...safetyInstructions, ...workInstructions, ...sops];

    return (
        <>
            <Card
                title="Work Orders"
                actions={
                    <div className="flex space-x-2">
                         <Button variant="secondary" onClick={() => setIsBatchPrintOpen(true)}>Batch Print</Button>
                         <Button variant="secondary" onClick={handlePrintList}>Print List</Button>
                        {currentUser?.role === 'Planner' && (
                            <Button onClick={() => setIsNewWOModalOpen(true)}>
                                New Work Order
                            </Button>
                        )}
                    </div>
                }
            >
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                        <label htmlFor="id-filter" className={filterLabelClasses}>WO ID</label>
                        <input type="text" id="id-filter" name="id" value={filters.id} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search ID..."/>
                    </div>
                     <div>
                        <label htmlFor="type-filter" className={filterLabelClasses}>Type</label>
                        <select id="type-filter" name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Types</option>
                            {Object.values(WorkOrderType).map(type => <option key={type} value={type}>{type}</option>)}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="asset-filter" className={filterLabelClasses}>Asset</label>
                        <input type="text" id="asset-filter" name="asset" value={filters.asset} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search asset name..."/>
                    </div>
                     <div>
                        <label htmlFor="status-filter" className={filterLabelClasses}>Status</label>
                        <select id="status-filter" name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Statuses</option>
                            {Object.values(WorkOrderStatus).map(status => <option key={status} value={status}>{status}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="zone-filter" className={filterLabelClasses}>Zone</label>
                        <select id="zone-filter" name="zone" value={filters.zone} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Zones</option>
                            {zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id)).map(zone => <option key={zone.id} value={zone.id}>{zone.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="dueDate-filter" className={filterLabelClasses}>Due Date</label>
                        <input type="date" id="dueDate-filter" name="dueDate" value={filters.dueDate} onChange={handleFilterChange} className={filterInputClasses}/>
                    </div>
                    <div className="flex items-end">
                        <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                    </div>
                </div>

                {activeFilters.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4 px-4 items-center">
                        <span className="text-xs text-gray-500 font-medium">Active Filters:</span>
                        {activeFilters.map(([key, value]) => (
                            <span key={key} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200">
                                {filterLabels[key] || key}: {value}
                                <button 
                                    type="button" 
                                    onClick={() => removeFilter(key as keyof typeof filters)}
                                    className="ml-1 inline-flex text-indigo-500 hover:text-indigo-900 dark:text-indigo-300 dark:hover:text-white focus:outline-none"
                                >
                                    <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                                </button>
                            </span>
                        ))}
                        <button onClick={clearFilters} className="text-xs text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 underline ml-2">Clear All</button>
                    </div>
                )}

                <div ref={printRef}>
                    <Table<WorkOrder>
                        columns={columns}
                        data={filteredWorkOrders}
                        footer={tableFooter}
                        renderRowActions={(wo) => (
                            <div className="space-x-2 flex items-center">
                                <Button variant="secondary" size="sm" onClick={() => onViewWorkOrder(wo.id)}>
                                    Details
                                </Button>
                                {currentUser?.role === 'Planner' && wo.workOrderType === WorkOrderType.Preventive && wo.status !== WorkOrderStatus.Cancelled && wo.status !== WorkOrderStatus.Completed && wo.status !== WorkOrderStatus.Archived && (
                                    <Button variant="danger" size="sm" onClick={() => handleCancelClick(wo)}>
                                        Cancel
                                    </Button>
                                )}
                            </div>
                        )}
                    />
                </div>
            </Card>

            <NewWorkOrderForm 
                isOpen={isNewWOModalOpen} 
                onClose={() => setIsNewWOModalOpen(false)} 
                onSave={handleSaveWorkOrder} 
                currentUser={currentUser}
            />
            
            <CancelWorkOrderModal 
                isOpen={cancelModalOpen} 
                onClose={() => setCancelModalOpen(false)} 
                onConfirm={handleCancelWorkOrder}
                woId={woToCancel || ''}
            />

            {/* Batch Print Preview Modal */}
            {isBatchPrintOpen && (
                <Modal
                    isOpen={isBatchPrintOpen}
                    onClose={() => setIsBatchPrintOpen(false)}
                    title={`Batch Print Preview: ${filteredWorkOrders.length} Work Orders`}
                    size="5xl"
                    footer={
                        <div className="flex justify-between w-full">
                            <Button variant="secondary" onClick={() => setIsBatchPrintOpen(false)}>Cancel</Button>
                            <Button variant="primary" onClick={handleBatchPrintConfirm}>Confirm Print</Button>
                        </div>
                    }
                >
                    <div className="bg-gray-100 dark:bg-gray-900 p-4 overflow-auto flex justify-center max-h-[70vh]">
                        <div className="transform scale-100 origin-top w-full max-w-[8.5in]">
                            {filteredWorkOrders.map((wo, index) => {
                                const asset = wo.assetId ? assets.find(a => a.id === wo.assetId) : undefined;
                                const effectiveZoneId = asset ? asset.zoneId : wo.zoneId;
                                const zone = effectiveZoneId ? zones.find(z => z.id === effectiveZoneId) : undefined;
                                const effectivePlantId = asset ? asset.plantId : zone?.plantId;
                                const plant = effectivePlantId ? plants.find(p => p.id === effectivePlantId) : undefined;
                                const effectivePlannerGroupId = wo.planningGroupId || asset?.custodianId;
                                const plannerGroup = effectivePlannerGroupId ? plannerGroups.find(pg => pg.id === effectivePlannerGroupId) : undefined;
                                const linkedProcedures = wo.procedureIds
                                    .map(pid => allProcedures.find(p => p.id === pid))
                                    .filter(Boolean) as (SafetyInstruction | WorkInstruction | SOP)[];

                                return (
                                    <div key={wo.id} style={{ pageBreakAfter: 'always' }} className="mb-8 print:mb-0">
                                        <PrintableWorkOrderDocument
                                            wo={wo}
                                            asset={asset}
                                            plant={plant}
                                            zone={zone}
                                            plannerGroup={plannerGroup}
                                            linkedProcedures={linkedProcedures}
                                            data={data}
                                        />
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </Modal>
            )}

            {/* Hidden Printable Content for Batch Printing */}
            <div className="hidden print:block">
                {filteredWorkOrders.map((wo, index) => {
                    const asset = wo.assetId ? assets.find(a => a.id === wo.assetId) : undefined;
                    const effectiveZoneId = asset ? asset.zoneId : wo.zoneId;
                    const zone = effectiveZoneId ? zones.find(z => z.id === effectiveZoneId) : undefined;
                    const effectivePlantId = asset ? asset.plantId : zone?.plantId;
                    const plant = effectivePlantId ? plants.find(p => p.id === effectivePlantId) : undefined;
                    const effectivePlannerGroupId = wo.planningGroupId || asset?.custodianId;
                    const plannerGroup = effectivePlannerGroupId ? plannerGroups.find(pg => pg.id === effectivePlannerGroupId) : undefined;
                    const linkedProcedures = wo.procedureIds
                        .map(pid => allProcedures.find(p => p.id === pid))
                        .filter(Boolean) as (SafetyInstruction | WorkInstruction | SOP)[];

                    return (
                        <div key={wo.id} style={{ pageBreakAfter: 'always' }}>
                            <PrintableWorkOrderDocument
                                wo={wo}
                                asset={asset}
                                plant={plant}
                                zone={zone}
                                plannerGroup={plannerGroup}
                                linkedProcedures={linkedProcedures}
                                data={data}
                            />
                        </div>
                    );
                })}
            </div>
        </>
    );
};
