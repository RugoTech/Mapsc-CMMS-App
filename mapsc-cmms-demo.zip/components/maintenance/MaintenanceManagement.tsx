import React from 'react';
import { Card } from '../ui/Card';

export const MaintenanceManagement: React.FC = () => {
  return (
    <Card title="Maintenance Management">
      <div className="text-center p-8">
        <h2 className="text-2xl font-semibold text-gray-700 dark:text-gray-200">Coming Soon</h2>
        <p className="text-gray-500 dark:text-gray-400 mt-2">This module is under construction.</p>
      </div>
    </Card>
  );
};
