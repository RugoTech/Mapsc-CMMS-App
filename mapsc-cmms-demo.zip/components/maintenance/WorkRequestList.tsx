
import React, { useContext, useState, useMemo, useEffect, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { WorkRequestStatus, Priority, WorkOrderStatus, WorkOrderType } from '../../types';
import type { WorkRequest, WorkOrder, User, AuditLogEntry, Message } from '../../types';
import { WorkRequestForm } from './WorkRequestForm';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { Alert } from '../ui/Alert';

const statusColors: Record<WorkRequestStatus, 'blue' | 'green' | 'red' | 'gray'> = {
    [WorkRequestStatus.Pending]: 'blue',
    [WorkRequestStatus.Approved]: 'green',
    [WorkRequestStatus.Rejected]: 'red',
    [WorkRequestStatus.ConvertedToWO]: 'gray',
};

const priorityColors: Record<Priority, 'blue' | 'yellow' | 'red'> = {
    [Priority.Low]: 'blue',
    [Priority.Medium]: 'yellow',
    [Priority.High]: 'red',
    [Priority.Critical]: 'red',
};

const WorkRequestDetailModal: React.FC<{ wr: WorkRequest | null, onClose: () => void }> = ({ wr, onClose }) => {
    const context = useContext(DataContext);
    if (!wr || !context) return null;

    const { assets, users, plannerGroups } = context.data;
    const assetName = wr.assetId ? assets.find(a => a.id === wr.assetId)?.name : 'N/A';
    const requester = users.find(u => u.id === wr.requesterId);
    const requesterName = requester ? requester.name : 'Unknown';
    const plannerGroup = wr.plannerGroupId ? plannerGroups.find(p => p.id === wr.plannerGroupId)?.name : 'Unassigned';

    return (
        <Modal isOpen={!!wr} onClose={onClose} title={`Details for ${wr.id}`}>
            <div className="space-y-4 text-sm">
                 {wr.status === WorkRequestStatus.Rejected && wr.rejectionReason && (
                    <Alert type="error" title="Reason for Rejection">
                        {wr.rejectionReason}
                    </Alert>
                )}
                <div><strong className="block text-gray-500 dark:text-gray-400">Status</strong> <Badge color={statusColors[wr.status]}>{wr.status}</Badge></div>
                <div><strong className="block text-gray-500 dark:text-gray-400">Description</strong> {wr.description}</div>
                <div><strong className="block text-gray-500 dark:text-gray-400">Asset</strong> {assetName} ({wr.assetId})</div>
                {wr.locationDescription && <div><strong className="block text-gray-500 dark:text-gray-400">Location</strong> {wr.locationDescription}</div>}
                <div><strong className="block text-gray-500 dark:text-gray-400">Priority</strong> <Badge color={priorityColors[wr.priority]}>{wr.priority}</Badge></div>
                <div><strong className="block text-gray-500 dark:text-gray-400">Requester</strong> {requesterName}</div>
                {wr.requesterContact && <div><strong className="block text-gray-500 dark:text-gray-400">Contact</strong> {wr.requesterContact}</div>}
                <div><strong className="block text-gray-500 dark:text-gray-400">Request Date</strong> {wr.requestDate}</div>
                <div><strong className="block text-gray-500 dark:text-gray-400">Planner Group</strong> {plannerGroup}</div>
                {wr.attachments && wr.attachments.length > 0 && (
                    <div>
                        <strong className="block text-gray-500 dark:text-gray-400">Attachments</strong>
                        <ul className="list-disc pl-5">
                            {wr.attachments.map((att, index) => (
                                <li key={index}>{att.name}</li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        </Modal>
    );
};

interface WorkRequestListProps {
    currentUser: User | null;
}

export const WorkRequestList: React.FC<WorkRequestListProps> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const [isRequestFormOpen, setIsRequestFormOpen] = useState(false);
    const [selectedWR, setSelectedWR] = useState<WorkRequest | null>(null);
    const [rejectingWR, setRejectingWR] = useState<WorkRequest | null>(null);
    const [rejectionReason, setRejectionReason] = useState('');
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    const [filters, setFilters] = useState({
        status: '',
        priority: '',
        asset: '',
    });

    const userPlannerGroup = useMemo(() => {
        if (currentUser?.role !== 'Planner' || !context) return null;
        return context.data.plannerGroups.find(pg => pg.userIds.includes(currentUser.id));
    }, [context, currentUser]);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { workRequests, assets, users, plannerGroups } = data;

    const getAssetName = (assetId?: string) => assets.find(a => a.id === assetId)?.name || 'N/A';
    const getUserName = (userId: string) => users.find(u => u.id === userId)?.name || userId;
    
    const getPlannerGroupName = (groupId?: string) => {
        if (!groupId) return 'Unassigned';
        return plannerGroups.find(pg => pg.id === groupId)?.name || 'Unknown Group';
    };

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({ status: '', priority: '', asset: '' });
    };

    const filteredRequests = useMemo(() => {
        return workRequests.filter(wr => {
            // Zone Access Check
            const asset = wr.assetId ? assets.find(a => a.id === wr.assetId) : null;
            const wrZoneId = asset?.zoneId; 
            
            let hasAccess = false;
            
            // Admins (canSeeAllZones) and Engineers can see all requests
            if (canSeeAllZones || currentUser.role === 'Engineer') {
                hasAccess = true;
            } else if (wr.requesterId === currentUser.id) {
                // Requester always sees their own
                hasAccess = true;
            } else {
                const isInAccessibleZone = wrZoneId ? accessibleZoneIds.includes(wrZoneId) : false;
                
                if (currentUser.role === 'Planner') {
                    // Planners Logic:
                    if (wr.plannerGroupId) {
                        // 1. Claimed Requests: ONLY visible if assigned to THIS planner's group
                        // This ensures that once claimed, it is hidden from other planner groups
                        if (userPlannerGroup && wr.plannerGroupId === userPlannerGroup.id) {
                            hasAccess = true;
                        }
                    } else {
                        // 2. Unclaimed Requests: Visible if in their Zone OR if no asset assigned (pool)
                        if (isInAccessibleZone || !wr.assetId) {
                            hasAccess = true;
                        }
                    }
                } else {
                    // Other roles restricted strictly by zone presence
                    if (isInAccessibleZone) {
                        hasAccess = true;
                    }
                }
            }

            if (!hasAccess) return false;

            const statusMatch = filters.status ? wr.status === filters.status : true;
            const priorityMatch = filters.priority ? wr.priority === filters.priority : true;
            const assetMatch = filters.asset ? getAssetName(wr.assetId).toLowerCase().includes(filters.asset.toLowerCase()) : true;

            return statusMatch && priorityMatch && assetMatch;
        });
    }, [workRequests, filters, accessibleZoneIds, canSeeAllZones, currentUser, assets, userPlannerGroup]);

    const handleSaveRequest = (newRequest: WorkRequest) => {
        setData(prevData => ({
            ...prevData,
            workRequests: [newRequest, ...prevData.workRequests],
             // Add log
             auditLog: [{
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: 'CREATE',
                entityType: 'WorkRequest',
                entityId: newRequest.id,
                details: `Created Work Request ${newRequest.id}`,
                status: 'Success'
            }, ...prevData.auditLog]
        }));
        setIsRequestFormOpen(false);
    };

    const handleApprove = (wr: WorkRequest) => {
         setData(prevData => {
             const updatedWRs = prevData.workRequests.map(r => r.id === wr.id ? { ...r, status: WorkRequestStatus.Approved } : r);
             
             const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: 'UPDATE',
                entityType: 'WorkRequest',
                entityId: wr.id,
                details: `Approved Work Request ${wr.id}`,
                status: 'Success'
            };
            
            let newMessages = [...prevData.messages];

            // Notify requester only if they are not the current user
            if (currentUser.id !== wr.requesterId) {
                const message: Message = {
                    id: `MSG-${String(prevData.messages.length + 1).padStart(3, '0')}`,
                    sender: 'System',
                    recipientId: wr.requesterId,
                    title: `Work Request Approved`,
                    body: `Your work request ${wr.id} has been approved.`,
                    date: new Date().toISOString(),
                    read: false
                };
                newMessages = [message, ...prevData.messages];
            }

             return {
                 ...prevData,
                 workRequests: updatedWRs,
                 auditLog: [logEntry, ...prevData.auditLog],
                 messages: newMessages
             }
         });
    };

    const handleReject = () => {
        if (!rejectingWR) return;
        setData(prevData => {
             const updatedWRs = prevData.workRequests.map(r => r.id === rejectingWR.id ? { ...r, status: WorkRequestStatus.Rejected, rejectionReason } : r);
             
             const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: 'UPDATE',
                entityType: 'WorkRequest',
                entityId: rejectingWR.id,
                details: `Rejected Work Request ${rejectingWR.id}. Reason: ${rejectionReason}`,
                status: 'Success'
            };

            let newMessages = [...prevData.messages];

             // Notify requester only if they are not the current user
            if (currentUser.id !== rejectingWR.requesterId) {
                const message: Message = {
                    id: `MSG-${String(prevData.messages.length + 1).padStart(3, '0')}`,
                    sender: 'System',
                    recipientId: rejectingWR.requesterId,
                    title: `Work Request Rejected`,
                    body: `Your work request ${rejectingWR.id} has been rejected. Reason: ${rejectionReason}`,
                    date: new Date().toISOString(),
                    read: false
                };
                newMessages = [message, ...prevData.messages];
            }

             return {
                 ...prevData,
                 workRequests: updatedWRs,
                 auditLog: [logEntry, ...prevData.auditLog],
                 messages: newMessages
             }
         });
         setRejectingWR(null);
         setRejectionReason('');
    };

    const handleConvertToWO = (wr: WorkRequest) => {
         setData(prevData => {
            // Determine cost centers based on asset/zone
            let plantCostCodeId: string | undefined = undefined;
            let zoneCostCodeId: string | undefined = undefined;
            const asset = prevData.assets.find(a => a.id === wr.assetId);
            
            if (asset) {
                const plant = prevData.plants.find(p => p.id === asset.plantId);
                if (plant) {
                    plantCostCodeId = prevData.plantCostCodes.find(pcc => pcc.name === plant.name)?.id;
                }
                const zone = prevData.zones.find(z => z.id === asset.zoneId);
                if (zone) {
                    zoneCostCodeId = prevData.zoneCostCodes.find(zcc => zcc.name === zone.name)?.id;
                }
            }

            // Ensure it's assigned to the current planner's group if not already assigned to one
            const targetPlannerGroupId = wr.plannerGroupId || userPlannerGroup?.id;

             // Create new WO
             const newWO: WorkOrder = {
                 id: `WO-${String(prevData.workOrders.length + 1).padStart(3, '0')}`,
                 description: wr.description,
                 assetId: wr.assetId,
                 priority: wr.priority,
                 status: WorkOrderStatus.Open,
                 dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                 createdDate: new Date().toISOString().split('T')[0],
                 createdBy: currentUser.id,
                 partsUsed: [],
                 estimatedDuration: 0, // Needs planning
                 laborHours: 0,
                 workOrderType: WorkOrderType.Corrective, // Automatically Corrective
                 workRequestId: wr.id,
                 assignedUserIds: [],
                 procedureIds: [],
                 planningGroupId: targetPlannerGroupId,
                 plantCostCodeId,
                 zoneCostCodeId
             };

             const updatedWRs = prevData.workRequests.map(r => r.id === wr.id ? { ...r, status: WorkRequestStatus.ConvertedToWO, plannerGroupId: targetPlannerGroupId } : r);

             const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: 'CREATE',
                entityType: 'WorkOrder',
                entityId: newWO.id,
                details: `Converted Work Request ${wr.id} to Corrective Work Order ${newWO.id}`,
                status: 'Success'
            };

            let newMessages = [...prevData.messages];

             // Notify requester only if they are not the current user
            if (currentUser.id !== wr.requesterId) {
                const message: Message = {
                    id: `MSG-${String(prevData.messages.length + 1).padStart(3, '0')}`,
                    sender: 'System',
                    recipientId: wr.requesterId,
                    title: `Work Order Created`,
                    body: `Work Order ${newWO.id} has been created from your request ${wr.id}.`,
                    date: new Date().toISOString(),
                    read: false
                };
                newMessages = [message, ...prevData.messages];
            }

             return {
                 ...prevData,
                 workOrders: [...prevData.workOrders, newWO],
                 workRequests: updatedWRs,
                 auditLog: [logEntry, ...prevData.auditLog],
                 messages: newMessages
             };
         });
         alert('Work Order created successfully.');
    };

    const handleClaim = (wr: WorkRequest) => {
        if (!userPlannerGroup) return;
        
        setData(prevData => {
             const updatedWRs = prevData.workRequests.map(r => 
                r.id === wr.id ? { ...r, plannerGroupId: userPlannerGroup.id } : r
             );
             
             const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: 'UPDATE',
                entityType: 'WorkRequest',
                entityId: wr.id,
                details: `Planner ${currentUser.name} claimed Work Request ${wr.id}.`,
                status: 'Success'
            };

             return {
                 ...prevData,
                 workRequests: updatedWRs,
                 auditLog: [logEntry, ...prevData.auditLog],
             }
         });
         alert('Work Request claimed successfully.');
    };

    const columns = [
        { header: 'WR ID', accessor: 'id' as keyof WorkRequest },
        { 
            header: 'Description', 
            accessor: (item: WorkRequest) => (
                <span title={item.description}>
                    {item.description.length > 42 
                        ? `${item.description.substring(0, 42)}...` 
                        : item.description}
                </span>
            )
        },
        { header: 'Asset', accessor: (item: WorkRequest) => getAssetName(item.assetId) },
        { header: 'Priority', accessor: (item: WorkRequest) => <Badge color={priorityColors[item.priority]}>{item.priority}</Badge> },
        { header: 'Status', accessor: (item: WorkRequest) => <Badge color={statusColors[item.status]}>{item.status}</Badge> },
        { header: 'Requester', accessor: (item: WorkRequest) => getUserName(item.requesterId) },
        { header: 'Planning Group', accessor: (item: WorkRequest) => getPlannerGroupName(item.plannerGroupId) },
        { header: 'Date', accessor: 'requestDate' as keyof WorkRequest },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <>
            <Card 
                title="Work Requests" 
                actions={currentUser.role !== 'Planner' && <Button onClick={() => setIsRequestFormOpen(true)}>New Request</Button>}
            >
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                        <label htmlFor="status-filter" className={filterLabelClasses}>Status</label>
                        <select id="status-filter" name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Statuses</option>
                            {Object.values(WorkRequestStatus).map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="priority-filter" className={filterLabelClasses}>Priority</label>
                         <select id="priority-filter" name="priority" value={filters.priority} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Priorities</option>
                            {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="asset-filter" className={filterLabelClasses}>Asset</label>
                        <input type="text" id="asset-filter" name="asset" value={filters.asset} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search asset..." />
                    </div>
                    <div className="flex items-end">
                        <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                    </div>
                </div>
                <Table<WorkRequest>
                    columns={columns}
                    data={filteredRequests}
                    renderRowActions={(wr) => (
                        <div className="flex space-x-2 justify-end">
                            <Button variant="secondary" size="sm" onClick={() => setSelectedWR(wr)}>Details</Button>
                            {/* Actions for Planner */}
                            {currentUser.role === 'Planner' && (
                                <>
                                    {wr.status === WorkRequestStatus.Pending && (
                                        <>
                                            {/* RULE: Planners can ONLY approve/reject if the request is assigned to THEIR group (created for them or claimed) */}
                                            {wr.plannerGroupId === userPlannerGroup?.id ? (
                                                <>
                                                    <Button variant="primary" size="sm" onClick={() => handleApprove(wr)}>Approve</Button>
                                                    <Button variant="danger" size="sm" onClick={() => setRejectingWR(wr)}>Reject</Button>
                                                </>
                                            ) : (
                                                // If not assigned to any group (or user not in the assigned group), allow claiming if it's unassigned
                                                !wr.plannerGroupId && (
                                                    <Button variant="secondary" size="sm" onClick={() => handleClaim(wr)}>Claim</Button>
                                                )
                                            )}
                                        </>
                                    )}
                                    {/* Allow converting approved requests if assigned to user's group (or generally if planner has access, but usually implies ownership) */}
                                    {wr.status === WorkRequestStatus.Approved && (
                                         <Button variant="primary" size="sm" onClick={() => handleConvertToWO(wr)}>Convert to WO</Button>
                                    )}
                                </>
                            )}
                        </div>
                    )}
                />
            </Card>

            <WorkRequestForm
                isOpen={isRequestFormOpen}
                onClose={() => setIsRequestFormOpen(false)}
                onSave={handleSaveRequest}
                currentUser={currentUser}
            />
            
            <WorkRequestDetailModal 
                wr={selectedWR} 
                onClose={() => setSelectedWR(null)} 
            />
            
             <ConfirmationModal
                isOpen={!!rejectingWR}
                onClose={() => { setRejectingWR(null); setRejectionReason(''); }}
                onConfirm={handleReject}
                title="Reject Work Request"
                confirmText="Reject"
                confirmButtonVariant="danger"
            >
                <p>Please provide a reason for rejecting this work request.</p>
                <Input 
                    label="Reason" 
                    id="rejectionReason" 
                    value={rejectionReason} 
                    onChange={e => setRejectionReason(e.target.value)} 
                    required
                />
            </ConfirmationModal>
        </>
    );
};
