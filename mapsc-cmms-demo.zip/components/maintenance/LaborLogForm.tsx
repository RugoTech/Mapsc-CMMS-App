
import React, { useState, useContext, useEffect, useMemo } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { User, LaborLog } from '../../types';

interface LaborLogFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (logData: { userId: string, startTime: string, endTime: string, notes: string }) => void;
  workCenterId?: string;
  currentUser: User | null;
  logToEdit?: LaborLog | null;
}

const getIsoStringWithoutSeconds = (date: Date) => {
    // Format to 'YYYY-MM-DDTHH:mm' which is what datetime-local input expects
    const pad = (num: number) => num.toString().padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
};

export const LaborLogForm: React.FC<LaborLogFormProps> = ({ isOpen, onClose, onSave, workCenterId, currentUser, logToEdit }) => {
    const context = useContext(DataContext);
    const [userId, setUserId] = useState('');
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    const [notes, setNotes] = useState('');

    const availableUsers = useMemo(() => {
        if (!context || !currentUser) return [];

        const { workCenters, users, plannerGroups, maintenanceClerks } = context.data;

        // If editing, we must include the user already on the log, even if they moved work centers
        if (logToEdit) {
             // We return all users to ensure the ID resolves, but in a real app you might optimize this. 
             // For filtering consistency, we'll try to stick to the work center logic but fallback to finding the specific user.
             const existingUser = users.find(u => u.id === logToEdit.userId);
             // If we can find the user, we ensure they are in the list or just return all valid users for simplicity in edit mode 
             // or strict adherence to current WC. Let's stick to current WC logic + the existing user.
        }

        if (currentUser.role === 'Planner' || currentUser.role === 'Clerk') {
            let keyword: 'PKG' | 'UTLS' | null = null;
            
            // Check planner groups
            const isPackagingPlanner = plannerGroups.find(pg => pg.name === 'Packaging Planner')?.userIds.includes(currentUser.id);
            const isUtilitiesPlanner = plannerGroups.find(pg => pg.name === 'Utilities Planner')?.userIds.includes(currentUser.id);
            
            if (isPackagingPlanner) keyword = 'PKG';
            if (isUtilitiesPlanner) keyword = 'UTLS';

            // Check clerk groups if not identified as a planner
            if (!keyword && currentUser.role === 'Clerk') {
                const isPackagingClerk = maintenanceClerks.find(mc => mc.name === 'Packaging Clerk')?.userIds.includes(currentUser.id);
                const isUtilitiesClerk = maintenanceClerks.find(mc => mc.name === 'Utilities Clerk')?.userIds.includes(currentUser.id);
                
                if (isPackagingClerk) keyword = 'PKG';
                if (isUtilitiesClerk) keyword = 'UTLS';
            }

            if (keyword) {
                const relevantWorkCenters = workCenters.filter(wc => wc.name.includes(keyword!));
                const userIds = new Set(relevantWorkCenters.flatMap(wc => wc.userIds));
                let filteredUsers = users.filter(user => userIds.has(user.id) && (user.isActive ?? true));
                
                // Ensure the user on the log is included if editing
                if (logToEdit && !userIds.has(logToEdit.userId)) {
                    const logUser = users.find(u => u.id === logToEdit.userId);
                    if (logUser) filteredUsers = [...filteredUsers, logUser];
                }
                return filteredUsers;
            }
        }

        // Fallback for non-planners/clerks or those without a specific domain
        if (workCenterId) {
            const workCenter = workCenters.find(wc => wc.id === workCenterId);
            if (!workCenter) return [];

            const userIdsInWorkCenter = new Set(workCenter.userIds);
            let filteredUsers = users.filter(user => userIdsInWorkCenter.has(user.id) && (user.isActive ?? true));

            // Ensure the user on the log is included if editing
            if (logToEdit && !userIdsInWorkCenter.has(logToEdit.userId)) {
                const logUser = users.find(u => u.id === logToEdit.userId);
                if (logUser) filteredUsers = [...filteredUsers, logUser];
            }
            return filteredUsers;
        }
        
        return [];

    }, [context, workCenterId, currentUser, logToEdit]);


    useEffect(() => {
        if (isOpen) {
            if (logToEdit) {
                setUserId(logToEdit.userId);
                // Slice to remove seconds/milliseconds for datetime-local input compatibility
                setStartTime(logToEdit.startTime.slice(0, 16));
                setEndTime(logToEdit.endTime.slice(0, 16));
                setNotes(logToEdit.notes);
            } else {
                // Reset form on open
                setUserId(availableUsers.length > 0 ? availableUsers[0].id : '');
                const now = new Date();
                const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
                setStartTime(getIsoStringWithoutSeconds(oneHourAgo));
                setEndTime(getIsoStringWithoutSeconds(now));
                setNotes('');
            }
        }
    }, [isOpen, availableUsers, logToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (new Date(endTime) <= new Date(startTime)) {
            alert('End time must be after start time.');
            return;
        }
        if (!userId) {
            alert('A user must be selected. Ensure a Work Center is assigned to this Work Order.');
            return;
        }
        onSave({ userId, startTime, endTime, notes });
    };
    
    if (!context) return null;

    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="labor-log-form">{logToEdit ? 'Save Changes' : 'Log Labor'}</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={logToEdit ? 'Edit Labor Log' : 'Log Labor'} footer={modalFooter}>
            <form id="labor-log-form" onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="userId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">User</label>
                    <select
                        id="userId"
                        value={userId}
                        onChange={(e) => setUserId(e.target.value)}
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                        disabled={availableUsers.length === 0}
                    >
                        {availableUsers.length > 0 ? (
                            availableUsers.map(user => (
                                <option key={user.id} value={user.id}>{user.name}</option>
                            ))
                        ) : (
                             <option value="">No users found in assigned Work Center</option>
                        )}
                    </select>
                </div>
                <Input
                    id="startTime"
                    label="Start Time"
                    type="datetime-local"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    required
                />
                <Input
                    id="endTime"
                    label="End Time"
                    type="datetime-local"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    required
                />
                <div>
                    <label htmlFor="notes" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Notes</label>
                    <textarea
                        id="notes"
                        rows={3}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        required
                    />
                </div>
            </form>
        </Modal>
    );
};
