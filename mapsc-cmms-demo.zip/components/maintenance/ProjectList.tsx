
import React, { useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { ProjectStatus, WorkOrderStatus, WorkOrderType, Priority, User, AuditLogEntry } from '../../types';
import type { Project, WorkOrder } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ProjectForm } from './ProjectForm';
import { useCurrencyConverter } from '../../hooks/useCurrencyConverter';
import { useCurrencyFormatter } from '../../hooks/useCurrency';

const statusColors: Record<ProjectStatus, 'blue' | 'yellow' | 'gray' | 'green'> = {
    [ProjectStatus.Planning]: 'blue',
    [ProjectStatus.InProgress]: 'yellow',
    [ProjectStatus.OnHold]: 'gray',
    [ProjectStatus.Completed]: 'green',
};

const ProjectDetailModal: React.FC<{ project: Project | null, onClose: () => void }> = ({ project, onClose }) => {
    const context = useContext(DataContext);
    const formatCurrency = useCurrencyFormatter();

    if (!project || !context) return null;

    const createdByUser = context.data.users.find(u => u.id === project.createdBy)?.name || project.createdBy;
    
    return (
        <Modal isOpen={true} onClose={onClose} title={`Details for ${project.name}`}>
            <div className="space-y-2 text-sm">
                <div><strong className="block text-gray-500">Description</strong> {project.description}</div>
                <div><strong className="block text-gray-500">Status</strong> <Badge color={statusColors[project.status]}>{project.status}</Badge></div>
                <div><strong className="block text-gray-500">Start Date</strong> {project.startDate}</div>
                <div><strong className="block text-gray-500">End Date</strong> {project.endDate}</div>
                <div><strong className="block text-gray-500">Budget</strong> {formatCurrency(project.budget)}</div>
                <div><strong className="block text-gray-500">Created By</strong> {createdByUser} on {project.createdDate}</div>
            </div>
        </Modal>
    );
};

const GenerateWOForm: React.FC<{
  project: Project;
  isOpen: boolean;
  onClose: () => void;
  onSave: (details: { description: string; priority: Priority; assetId?: string; zoneId?: string; planningGroupId?: string; estimatedDuration: number; }) => void;
  currentUser: User | null;
}> = ({ project, isOpen, onClose, onSave, currentUser }) => {
    const context = useContext(DataContext);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
    const [description, setDescription] = useState('');
    const [priority, setPriority] = useState<Priority>(Priority.Medium);
    const [assetId, setAssetId] = useState<string>('');
    const [zoneId, setZoneId] = useState<string>('');
    const [planningGroupId, setPlanningGroupId] = useState<string>('');
    const [estimatedDuration, setEstimatedDuration] = useState(8);
    const [isZoneDisabled, setIsZoneDisabled] = useState(false);
    
    const availableAssets = useMemo(() => {
        if (!context) return [];
        return context.data.assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
    }, [context, accessibleZoneIds, canSeeAllZones]);

    useEffect(() => {
        if (isOpen && context) {
            setDescription('');
            setPriority(Priority.Medium);
            setAssetId('');
            setZoneId('');
            
            // Auto-select planner group based on current user
            let defaultGroupId = '';
            if (currentUser) {
                const userPlannerGroup = context.data.plannerGroups.find(pg => pg.userIds.includes(currentUser.id));
                if (userPlannerGroup) {
                    defaultGroupId = userPlannerGroup.id;
                } else {
                    defaultGroupId = context.data.plannerGroups[0]?.id || '';
                }
            } else {
                defaultGroupId = context.data.plannerGroups[0]?.id || '';
            }

            setPlanningGroupId(defaultGroupId);
            setEstimatedDuration(8);
            setIsZoneDisabled(false);
        }
    }, [isOpen, context, availableAssets, currentUser]);

    useEffect(() => {
        if (assetId && context) {
            const selectedAsset = context.data.assets.find(a => a.id === assetId);
            if (selectedAsset) {
                setZoneId(selectedAsset.zoneId);
                setPlanningGroupId(selectedAsset.custodianId);
                setIsZoneDisabled(true);
            }
        } else {
            setZoneId('');
            setIsZoneDisabled(false);
        }
    }, [assetId, context]);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ 
            description, 
            priority, 
            assetId: assetId || undefined, 
            zoneId: zoneId || undefined, 
            planningGroupId: planningGroupId || undefined,
            estimatedDuration,
        });
        onClose();
    };
    
    if (!context) return null;
    const { zones, plannerGroups } = context.data;
    const selectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md disabled:bg-gray-100 dark:disabled:bg-gray-800";

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title={`Generate WO for: ${project.name}`}
            footer={
                <>
                    <Button variant="secondary" onClick={onClose}>Cancel</Button>
                    <Button type="submit" form="generate-wo-form">Generate</Button>
                </>
            }
        >
            <form id="generate-wo-form" onSubmit={handleSubmit} className="space-y-4">
                <Input
                    id="description"
                    label="Work Order Task Description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                    placeholder="e.g., Install new pump foundation"
                />
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Priority</label>
                        <select id="priority" value={priority} onChange={(e) => setPriority(e.target.value as Priority)} className={selectClasses}>
                            {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                        </select>
                    </div>
                    <Input
                        id="estimatedDuration"
                        label="Est. Duration (Hrs)"
                        type="number"
                        min="0"
                        step="0.01"
                        value={estimatedDuration}
                        onChange={e => setEstimatedDuration(Number(e.target.value))}
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="assetId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Asset (Optional)</label>
                    <select id="assetId" value={assetId} onChange={e => setAssetId(e.target.value)} className={selectClasses}>
                        <option value="">No specific asset</option>
                        {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                </div>
                 <div>
                    <label htmlFor="zoneId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Zone</label>
                    <select id="zoneId" value={zoneId} onChange={e => setZoneId(e.target.value)} disabled={isZoneDisabled} className={selectClasses}>
                        <option value="">Select a zone...</option>
                        {zones
                            .filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id))
                            .map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="planningGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Planning Group</label>
                    <select id="planningGroupId" value={planningGroupId} onChange={e => setPlanningGroupId(e.target.value)} required className={selectClasses}>
                        {plannerGroups.map(pg => <option key={pg.id} value={pg.id}>{pg.name}</option>)}
                    </select>
                </div>
            </form>
        </Modal>
    );
};

export const ProjectList: React.FC<{ currentUser: User | null }> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [projectToEdit, setProjectToEdit] = useState<Project | null>(null);
    const [selectedProject, setSelectedProject] = useState<Project | null>(null);
    const [projectToGenerateFrom, setProjectToGenerateFrom] = useState<Project | null>(null);
    const [filters, setFilters] = useState({
        id: '',
        name: '',
        createdDate: '',
    });
    
    const formatCurrency = useCurrencyFormatter(); // Uses default settings currency directly

    if (!context) return <div>Loading...</div>;

    const { data, setData } = context;
    const { projects, users, workOrders } = data;

    const handleOpenForm = (project: Project | null) => {
        setProjectToEdit(project);
        setIsFormOpen(true);
    };

    const handleCloseForm = () => {
        setProjectToEdit(null);
        setIsFormOpen(false);
    };

    const handleSave = (project: Project) => {
        setData(prev => {
            const isEditing = prev.projects.some(p => p.id === project.id);
            let savedProject: Project;
            let newProjects: Project[];
            const logAction: 'CREATE' | 'UPDATE' = isEditing ? 'UPDATE' : 'CREATE';

            if (isEditing) {
                savedProject = project;
                newProjects = prev.projects.map(p => p.id === project.id ? project : p);
            } else {
                savedProject = { ...project, id: `PROJ-${String(prev.projects.length + 1).padStart(3, '0')}` };
                newProjects = [...prev.projects, savedProject];
            }

            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: logAction,
                entityType: 'Project',
                entityId: savedProject.id,
                details: `${logAction === 'CREATE' ? 'Created' : 'Updated'} project '${savedProject.name}' (${savedProject.id}).`,
                status: 'Success'
            };

            return { 
                ...prev, 
                projects: newProjects,
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        handleCloseForm();
    };
    
    const handleGenerateWorkOrder = (details: { description: string; priority: Priority; assetId?: string; zoneId?: string; planningGroupId?: string; estimatedDuration: number; }) => {
        if (!projectToGenerateFrom) return;

        setData(prevData => {
            const { assets, zones, plants, plantCostCodes, zoneCostCodes } = prevData;
            let plantCostCodeId: string | undefined = undefined;
            let zoneCostCodeId: string | undefined = undefined;
            
            const finalZoneId = details.assetId ? assets.find(a => a.id === details.assetId)?.zoneId : details.zoneId;

            if (finalZoneId) {
                const zone = zones.find(z => z.id === finalZoneId);
                if (zone) {
                    zoneCostCodeId = zoneCostCodes.find(zcc => zcc.name === zone.name)?.id;
                    const plant = plants.find(p => p.id === zone.plantId);
                    if (plant) {
                        plantCostCodeId = plantCostCodes.find(pcc => pcc.name === plant.name)?.id;
                    }
                }
            }

            const newWorkOrder: WorkOrder = {
                id: `WO-${String(prevData.workOrders.length + 1).padStart(3, '0')}`,
                description: details.description,
                assetId: details.assetId,
                priority: details.priority,
                status: WorkOrderStatus.Open,
                dueDate: projectToGenerateFrom.endDate, // Set Due Date to Project End Date
                createdDate: new Date().toISOString().split('T')[0],
                createdBy: currentUser!.id,
                partsUsed: [],
                estimatedDuration: details.estimatedDuration,
                laborHours: 0,
                workOrderType: WorkOrderType.Project,
                projectId: projectToGenerateFrom.id,
                planningGroupId: details.planningGroupId,
                zoneId: details.zoneId,
                assignedUserIds: [],
                procedureIds: [],
                plantCostCodeId,
                zoneCostCodeId,
            };

            const updatedProjects = prevData.projects.map(p => 
                p.id === projectToGenerateFrom.id 
                ? { ...p, status: ProjectStatus.InProgress } 
                : p
            );
            
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'CREATE',
                entityType: 'WorkOrder',
                entityId: newWorkOrder.id,
                details: `Generated Project WO ${newWorkOrder.id} from project '${projectToGenerateFrom.name}' (${projectToGenerateFrom.id}).`,
                status: 'Success'
            };

            return {
                ...prevData,
                workOrders: [...prevData.workOrders, newWorkOrder],
                projects: updatedProjects,
                auditLog: [logEntry, ...prevData.auditLog],
            };
        });
        alert(`Work Order generated for project "${projectToGenerateFrom.name}".`);
    };
    
    const getUserName = useCallback((userId: string) => users.find(u => u.id === userId)?.name || 'N/A', [users]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({ id: '', name: '', createdDate: '' });
    };

    const filteredProjects = useMemo(() => {
        return projects.filter(project => {
            const idMatch = filters.id ? project.id.toLowerCase().includes(filters.id.toLowerCase()) : true;
            const nameMatch = filters.name ? project.name.toLowerCase().includes(filters.name.toLowerCase()) : true;
            const dateMatch = filters.createdDate ? project.createdDate === filters.createdDate : true;

            return idMatch && nameMatch && dateMatch;
        });
    }, [projects, filters]);

    const columns = [
        { header: 'Project ID', accessor: 'id' as keyof Project },
        { header: 'Project Name', accessor: 'name' as keyof Project },
        {
            header: 'Status',
            accessor: (item: Project) => (
                <Badge color={statusColors[item.status]}>{item.status}</Badge>
            ),
        },
        { header: 'End Date', accessor: 'endDate' as keyof Project },
        { header: 'Date Created', accessor: 'createdDate' as keyof Project },
        {
            header: 'Budget',
            accessor: (item: Project) => formatCurrency(item.budget) // Use formatCurrency (no conversion)
        },
        { header: 'Created By', accessor: (item: Project) => getUserName(item.createdBy) },
    ];
    
    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <>
            <Card
                title="Projects"
                actions={currentUser?.role === 'Planner' && <Button onClick={() => handleOpenForm(null)}>New Project</Button>}
            >
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                        <label htmlFor="id-filter" className={filterLabelClasses}>Project ID</label>
                        <input type="text" id="id-filter" name="id" value={filters.id} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search ID..."/>
                    </div>
                    <div>
                        <label htmlFor="name-filter" className={filterLabelClasses}>Project Name</label>
                        <input type="text" id="name-filter" name="name" value={filters.name} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search name..."/>
                    </div>
                    <div>
                        <label htmlFor="createdDate-filter" className={filterLabelClasses}>Date Created</label>
                        <input type="date" id="createdDate-filter" name="createdDate" value={filters.createdDate} onChange={handleFilterChange} className={filterInputClasses}/>
                    </div>
                    <div className="flex items-end">
                        <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                    </div>
                </div>

                <Table<Project>
                    columns={columns}
                    data={filteredProjects}
                    renderRowActions={(proj) => {
                        const woExistsForProject = workOrders.some(wo => wo.projectId === proj.id);
                        const isPlanning = proj.status === ProjectStatus.Planning;
                        
                        return (
                            <div className="flex space-x-2 justify-end">
                                <Button variant="secondary" size="sm" onClick={() => setSelectedProject(proj)}>
                                    View Details
                                </Button>
                                {currentUser?.role === 'Planner' && (
                                    <>
                                        <Button
                                            variant="secondary"
                                            size="sm"
                                            onClick={() => handleOpenForm(proj)}
                                            disabled={!isPlanning}
                                            title={!isPlanning ? "Cannot edit a project that is in progress or completed" : "Edit project details"}
                                        >
                                            Edit
                                        </Button>
                                        <Button
                                            variant="secondary"
                                            size="sm"
                                            onClick={() => setProjectToGenerateFrom(proj)}
                                            disabled={!isPlanning}
                                            title={
                                                !isPlanning
                                                ? "A Work Order has already been generated for this project"
                                                : "Generate a new Work Order for this project"
                                            }
                                        >
                                            {woExistsForProject ? 'WO Generated' : 'Generate WO'}
                                        </Button>
                                    </>
                                )}
                            </div>
                        );
                    }}
                />
            </Card>
            <ProjectForm isOpen={isFormOpen} onClose={handleCloseForm} onSave={handleSave} projectToEdit={projectToEdit} currentUser={currentUser} />
            <ProjectDetailModal project={selectedProject} onClose={() => setSelectedProject(null)} />
            {projectToGenerateFrom && (
                <GenerateWOForm
                    isOpen={!!projectToGenerateFrom}
                    onClose={() => setProjectToGenerateFrom(null)}
                    project={projectToGenerateFrom}
                    onSave={handleGenerateWorkOrder}
                    currentUser={currentUser}
                />
            )}
        </>
    );
};
