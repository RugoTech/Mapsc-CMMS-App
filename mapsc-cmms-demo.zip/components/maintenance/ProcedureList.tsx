import React, { useState, useContext, useMemo } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import type { SafetyInstruction, WorkInstruction, SOP, MockData, User, AuditLogEntry } from '../../types';
import { SafetyInstructionForm } from './SafetyInstructionForm';
import { WorkInstructionForm } from './WorkInstructionForm';
import { SOPForm } from './SOPForm';

type Tab = 'Safety Instructions' | 'Work Instructions' | 'SOPs';
type ProcedureItem = SafetyInstruction | WorkInstruction | SOP;

interface ProcedureListProps {
    currentUser: User | null;
}

export const ProcedureList: React.FC<ProcedureListProps> = ({ currentUser }) => {
    const [activeTab, setActiveTab] = useState<Tab>('Safety Instructions');
    const context = useContext(DataContext);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<ProcedureItem | null>(null);
    const [itemToDelete, setItemToDelete] = useState<ProcedureItem | null>(null);

    const canEdit = useMemo(() => {
        if (!currentUser) return false;
        return currentUser.role === 'Planner' || currentUser.role === 'Engineer';
    }, [currentUser]);

    if (!context) return <div>Loading...</div>;

    const { data, setData } = context;

    const handleOpenAdd = () => {
        setEditingItem(null);
        setIsModalOpen(true);
    };

    const handleOpenEdit = (item: ProcedureItem) => {
        setEditingItem(item);
        setIsModalOpen(true);
    };
    
    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingItem(null);
    };

    const handleSave = (item: ProcedureItem) => {
        setData(prevData => {
            let listKey: keyof MockData | null = null;
            let prefix = '';
            let isEditing = !!item.id;

            switch(activeTab) {
                case 'Safety Instructions': listKey = 'safetyInstructions'; prefix = 'SI'; break;
                case 'Work Instructions': listKey = 'workInstructions'; prefix = 'WI'; break;
                case 'SOPs': listKey = 'sops'; prefix = 'SP'; break;
            }

            if (!listKey) return prevData;

            const itemArray = prevData[listKey as keyof MockData] as ProcedureItem[];
            
            let savedItem: ProcedureItem;
            let logAction: 'CREATE' | 'UPDATE';
            let updatedArray: ProcedureItem[];
            
            if (isEditing) {
                logAction = 'UPDATE';
                savedItem = item;
                updatedArray = itemArray.map(i => i.id === item.id ? item : i);
            } else {
                logAction = 'CREATE';
                const newId = `${prefix}-${String(itemArray.length + 1).padStart(2, '0')}`;
                savedItem = { ...item, id: newId };
                updatedArray = [...itemArray, savedItem];
            }

            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: logAction,
                entityType: 'Procedure',
                entityId: savedItem.id,
                details: `${logAction === 'CREATE' ? 'Created' : 'Updated'} procedure '${savedItem.description}' (${savedItem.id}).`,
                status: 'Success'
            };

            return {
                ...prevData,
                [listKey]: updatedArray,
                auditLog: [logEntry, ...prevData.auditLog]
            };
        });
        handleCloseModal();
    };
    
    const handleDelete = () => {
        if (!itemToDelete) return;

        setData(prevData => {
            let listKey: keyof MockData | null = null;
            switch(activeTab) {
                case 'Safety Instructions': listKey = 'safetyInstructions'; break;
                case 'Work Instructions': listKey = 'workInstructions'; break;
                case 'SOPs': listKey = 'sops'; break;
            }
            if (!listKey) return prevData;

            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'DELETE',
                entityType: 'Procedure',
                entityId: itemToDelete.id,
                details: `Deleted procedure '${itemToDelete.description}' (${itemToDelete.id}).`,
                status: 'Success'
            };

            const itemArray = prevData[listKey as keyof MockData] as ProcedureItem[];
            const updatedArray = itemArray.filter(i => i.id !== itemToDelete.id);
          
            return {
                ...prevData,
                [listKey]: updatedArray,
                auditLog: [logEntry, ...prevData.auditLog]
            };
        });
        setItemToDelete(null);
    };


    const renderTable = () => {
        let columns: any[] = [];
        let tableData: any[] = [];
        
        const baseColumns = [
            { header: 'ID', accessor: 'id' },
            { header: 'Description', accessor: 'description' },
        ];
        
        switch (activeTab) {
            case 'Safety Instructions':
                columns = [...baseColumns];
                tableData = data.safetyInstructions;
                break;
            case 'Work Instructions':
                columns = [
                    ...baseColumns,
                    { header: 'Asset', accessor: (item: WorkInstruction) => data.assets.find(a => a.id === item.assetId)?.name || 'N/A' },
                    { header: 'Total Duration (Hrs)', accessor: 'totalDuration' }
                ];
                tableData = data.workInstructions;
                break;
            case 'SOPs':
                 columns = [
                    ...baseColumns,
                    { header: 'Asset', accessor: (item: SOP) => item.assetId ? (data.assets.find(a => a.id === item.assetId)?.name || 'N/A') : 'N/A' },
                ];
                tableData = data.sops;
                break;
        }

        return (
             <Table
                columns={columns}
                data={tableData}
                renderRowActions={(item) => (
                    canEdit && (
                        <div className="space-x-2">
                            <Button variant="secondary" size="sm" onClick={() => handleOpenEdit(item)}>Edit</Button>
                            <Button variant="danger" size="sm" onClick={() => setItemToDelete(item)}>Delete</Button>
                        </div>
                    )
                )}
            />
        )
    }

    const renderModal = () => {
        if (!isModalOpen) return null;
        switch (activeTab) {
            case 'Safety Instructions':
                return <SafetyInstructionForm isOpen={isModalOpen} onClose={handleCloseModal} onSave={handleSave as (item: SafetyInstruction) => void} itemToEdit={editingItem as SafetyInstruction | null} currentUser={currentUser} />;
            case 'Work Instructions':
                return <WorkInstructionForm isOpen={isModalOpen} onClose={handleCloseModal} onSave={handleSave as (item: WorkInstruction) => void} itemToEdit={editingItem as WorkInstruction | null} currentUser={currentUser} />;
            case 'SOPs':
                return <SOPForm isOpen={isModalOpen} onClose={handleCloseModal} onSave={handleSave as (item: SOP) => void} itemToEdit={editingItem as SOP | null} currentUser={currentUser} />;
        }
    };

    const tabs: Tab[] = ['Safety Instructions', 'Work Instructions', 'SOPs'];
    const title = `${activeTab} Register`;
    const buttonText = `New ${activeTab.slice(0, -1)}`;

    return (
        <div className="space-y-6">
            <div>
                <div className="border-b border-gray-200 dark:border-gray-700">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        {tabs.map((tab) => (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab)}
                                className={`${
                                    activeTab === tab
                                    ? 'border-indigo-500 text-indigo-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                            >
                            {tab}
                            </button>
                        ))}
                    </nav>
                </div>
                <div className="mt-6">
                    <Card title={title} actions={canEdit && <Button onClick={handleOpenAdd}>{buttonText}</Button>}>
                        {renderTable()}
                    </Card>
                </div>
            </div>
            {renderModal()}
            {itemToDelete && (
                <ConfirmationModal
                    isOpen={!!itemToDelete}
                    onClose={() => setItemToDelete(null)}
                    onConfirm={handleDelete}
                    title="Confirm Deletion"
                    confirmText="Delete"
                    confirmButtonVariant="danger"
                >
                    <p>Are you sure you want to delete the procedure <span className="font-bold">{itemToDelete.description}</span>?</p>
                    <p className="text-sm text-gray-500 mt-2">This action cannot be undone.</p>
                </ConfirmationModal>
            )}
        </div>
    );
};