
import React, { useState, useEffect, useContext, useCallback } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { Project, User } from '../../types';
import { ProjectStatus } from '../../types';
import { useSettings } from '../../contexts/SettingsContext';


interface ProjectFormProps { 
    isOpen: boolean, 
    onClose: () => void, 
    onSave: (p: Project) => void,
    projectToEdit: Project | null,
    currentUser: User | null;
}

export const ProjectForm: React.FC<ProjectFormProps> = ({ isOpen, onClose, onSave, projectToEdit, currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    
    const getInitialState = useCallback((): Omit<Project, 'id'> => ({ 
        name: '', 
        description: '', 
        status: ProjectStatus.Planning, 
        startDate: '', 
        endDate: '', 
        budget: 0,
        createdDate: new Date().toISOString().split('T')[0],
        createdBy: currentUser?.id || '',
    }), [currentUser]);

    const [formData, setFormData] = useState(getInitialState());

    useEffect(() => {
        if (isOpen) {
            if (projectToEdit) {
                setFormData(projectToEdit);
            } else {
                setFormData(getInitialState());
            }
        }
    }, [isOpen, projectToEdit, getInitialState]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({...prev, [name]: name === 'budget' ? Number(value) : value}));
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData as Project);
    };

    if (!context) return null;
    const createdByUser = context.data.users.find(u => u.id === formData.createdBy)?.name || formData.createdBy;
    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="proj-form">{projectToEdit ? "Save Changes" : "Save"}</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={projectToEdit ? "Edit Project" : "Add New Project"} footer={modalFooter}>
            <form id="proj-form" onSubmit={handleSubmit} className="space-y-4">
                <Input id="name" label="Project Name" name="name" value={formData.name} onChange={handleChange} required />
                <Input id="description" label="Description" name="description" value={formData.description} onChange={handleChange} required maxLength={106} />
                <Input id="startDate" label="Start Date" name="startDate" type="date" value={formData.startDate} onChange={handleChange} required />
                <Input id="endDate" label="End Date" name="endDate" type="date" value={formData.endDate} onChange={handleChange} required />
                <Input id="budget" label={`Budget (${settings.currency})`} name="budget" type="number" value={formData.budget} onChange={handleChange} required />
                <div>
                  <label htmlFor="status" className="block text-sm font-medium">Status</label>
                  <select name="status" value={formData.status} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                      {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                {projectToEdit && (
                     <div className="grid grid-cols-2 gap-4 border-t pt-4 mt-4">
                        <Input id="createdBy" label="Created By" value={createdByUser} disabled />
                        <Input id="createdDate" label="Date Created" type="date" value={formData.createdDate} disabled />
                    </div>
                )}
            </form>
        </Modal>
    );
};
