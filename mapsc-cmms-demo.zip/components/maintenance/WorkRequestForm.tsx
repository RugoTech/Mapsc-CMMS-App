
import React, { useState, useContext, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { Priority, WorkRequestStatus } from '../../types';
import type { WorkRequest, User } from '../../types';

interface WorkRequestFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (request: WorkRequest) => void;
  currentUser: User | null;
}

type FormState = Omit<WorkRequest, 'id' | 'status' | 'requestDate'>;

const getInitialFormState = (context: any, currentUser: User | null): FormState => {
    if (!context || !currentUser) return { description: '', requesterId: '', priority: Priority.Medium };
    return {
        description: '',
        assetId: '',
        locationDescription: '',
        requesterId: currentUser.id,
        requesterContact: '',
        priority: Priority.Medium,
        attachments: [],
        plannerGroupId: '',
    };
};


export const WorkRequestForm: React.FC<WorkRequestFormProps> = ({ isOpen, onClose, onSave, currentUser }) => {
  const context = useContext(DataContext);
  const [formData, setFormData] = useState<FormState>(getInitialFormState(context, currentUser));
  const [requesterDept, setRequesterDept] = useState('');
  const [assetOrLocation, setAssetOrLocation] = useState<'asset' | 'location'>('asset');
  const [attachments, setAttachments] = useState<File[]>([]);

  useEffect(() => {
    if (isOpen && context) {
      // Reset form on open
      const initialState = getInitialFormState(context, currentUser);
      setFormData(initialState);
      setAssetOrLocation('asset');
      setAttachments([]);

      const requester = context.data.users.find(u => u.id === initialState.requesterId);
      setRequesterDept(requester?.workCenter || '');
    }
  }, [isOpen, context, currentUser]);

  useEffect(() => {
      if (context) {
        const requester = context.data.users.find(u => u.id === formData.requesterId);
        setRequesterDept(requester?.workCenter || '');
      }
  }, [formData.requesterId, context]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
        setAttachments(Array.from(e.target.files));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!context) return;

    const finalAttachments = attachments.map(file => ({
        name: file.name,
        size: file.size,
        type: file.type,
    }));

    let plannerGroupId: string | undefined = undefined;
    if (assetOrLocation === 'asset' && formData.assetId) {
        const selectedAsset = context.data.assets.find(a => a.id === formData.assetId);
        if (selectedAsset) {
            plannerGroupId = selectedAsset.custodianId;
        }
    }

    const newRequest: WorkRequest = {
        id: `WR-${String(context.data.workRequests.length + 1).padStart(3, '0')}`,
        status: WorkRequestStatus.Pending,
        requestDate: new Date().toISOString().split('T')[0],
        ...formData,
        assetId: assetOrLocation === 'asset' ? formData.assetId : undefined,
        locationDescription: assetOrLocation === 'location' ? formData.locationDescription : undefined,
        attachments: finalAttachments,
        plannerGroupId: plannerGroupId,
    };
    onSave(newRequest);
    onClose();
  };

  const modalFooter = (
    <>
      <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
      <Button type="submit" form="work-request-form">Submit Request</Button>
    </>
  );

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Submit Work Request" footer={modalFooter}>
      <form onSubmit={handleSubmit} id="work-request-form" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input id="requesterName" label="Your Name" value={currentUser?.name || ''} disabled />
            <Input id="department" name="department" label="Department" value={requesterDept} disabled />
        </div>
        <Input id="requesterContact" name="requesterContact" label="Contact Info (Phone/Ext.)" value={formData.requesterContact} onChange={handleChange} />
        
        <div className="border-t pt-4">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Affected Asset/Location</label>
            <div className="flex items-center space-x-4 mt-2">
                <label className="flex items-center">
                    <input type="radio" name="assetOrLocation" value="asset" checked={assetOrLocation === 'asset'} onChange={() => setAssetOrLocation('asset')} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300" />
                    <span className="ml-2 text-sm">Select Existing Asset</span>
                </label>
                 <label className="flex items-center">
                    <input type="radio" name="assetOrLocation" value="location" checked={assetOrLocation === 'location'} onChange={() => setAssetOrLocation('location')} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300" />
                    <span className="ml-2 text-sm">Describe Location</span>
                </label>
            </div>
             <div className="mt-2">
                {assetOrLocation === 'asset' ? (
                    <select id="assetId" name="assetId" value={formData.assetId} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                        <option value="">Select Asset...</option>
                        {context?.data.assets.map(asset => <option key={asset.id} value={asset.id}>{asset.name}</option>)}
                    </select>
                ) : (
                    <Input id="locationDescription" name="locationDescription" label="Location Description" value={formData.locationDescription} onChange={handleChange} placeholder="e.g. Building B, 2nd Floor, Room 201" required />
                )}
            </div>
        </div>

        <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description of Issue</label>
            <textarea 
                id="description" 
                name="description" 
                rows={4} 
                value={formData.description} 
                onChange={handleChange} 
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" 
                required
                maxLength={84}
            ></textarea>
        </div>
        <div>
            <label htmlFor="priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Urgency / Priority</label>
            <select id="priority" name="priority" value={formData.priority} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                {Object.values(Priority).map(p => <option key={p}>{p}</option>)}
            </select>
        </div>
        <div>
            <label htmlFor="attachments" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Attach Photos/Documents</label>
            <input id="attachments" name="attachments" type="file" multiple onChange={handleFileChange} className="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-900/50 file:text-indigo-700 dark:file:text-indigo-300 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-900" />
            {attachments.length > 0 && (
                <ul className="mt-2 text-sm text-gray-500 list-disc pl-5">
                    {attachments.map((file, index) => <li key={index}>{file.name}</li>)}
                </ul>
            )}
        </div>
      </form>
    </Modal>
  );
};
