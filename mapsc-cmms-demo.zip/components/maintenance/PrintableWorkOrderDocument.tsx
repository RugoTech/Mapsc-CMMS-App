
import React from 'react';
import type { WorkOrder, Asset, Plant, Zone, PlannerGroup, SafetyInstruction, WorkInstruction, SOP, MockData } from '../../types';
import { WorkOrderType } from '../../types';

interface PrintableWorkOrderDocumentProps {
    wo: WorkOrder;
    asset?: Asset;
    plant?: Plant;
    zone?: Zone;
    plannerGroup?: PlannerGroup;
    linkedProcedures: (SafetyInstruction | WorkInstruction | SOP)[];
    data: MockData;
}

export const PrintableWorkOrderDocument: React.FC<PrintableWorkOrderDocumentProps> = ({ wo, asset, plant, zone, plannerGroup, linkedProcedures, data }) => {
     // Logic: If count is 0 or 1 (just incremented), it is the Original. 
     // Subsequent prints (count > 1) are Reprinted.
     const isOriginal = (wo.printCount || 0) <= 1;
     
     const controllerGroupName = data.maintenanceControllers.find(c => c.id === wo.controllerGroupId)?.name || 'N/A';

     return (
        <div className="font-sans text-black bg-white p-8 border-2 border-black min-h-[11in] flex flex-col box-border relative">
            {/* Header */}
            <div className="flex justify-between items-center pb-4 border-b-2 border-black mb-4">
                <div className="flex items-center">
                    {/* Placeholder Logo */}
                    <div className="w-16 h-16 border border-black flex items-center justify-center mr-4 font-bold text-xs">LOGO</div>
                    <div>
                        <h1 className="text-2xl font-bold uppercase">Work Order</h1>
                        <p className="text-sm">Maintenance Department</p>
                    </div>
                </div>
                <div className="text-right">
                    <h2 className="text-xl font-bold">{wo.id}</h2>
                    <p className="text-sm font-mono">Printed: {new Date().toLocaleString()}</p>
                </div>
            </div>

            {/* Main Details Grid */}
            <div className="grid grid-cols-2 gap-x-8 gap-y-2 mb-6 text-sm border-b pb-4">
                <div><span className="font-bold">Description:</span> <span className="block mt-1">{wo.description}</span></div>
                <div className="text-right"><span className="font-bold">Status:</span> {wo.status}</div>
                
                <div><span className="font-bold">Asset:</span> {asset ? `${asset.name} (${asset.id})` : 'N/A'}</div>
                <div><span className="font-bold">Location:</span> {plant?.name} / {zone?.name} / {asset?.areaId}</div>
                
                <div><span className="font-bold">Type:</span> {wo.workOrderType}</div>
                <div><span className="font-bold">Priority:</span> {wo.priority}</div>
                
                <div><span className="font-bold">Controller Group:</span> {controllerGroupName}</div>
                
                {wo.workOrderType === WorkOrderType.Preventive && (
                    <div><span className="font-bold">PM Plan ID:</span> {wo.pmPlanId || 'N/A'}</div>
                )}

                {wo.workOrderType === WorkOrderType.Project && (
                    <div><span className="font-bold">Project ID:</span> {wo.projectId || 'N/A'}</div>
                )}

                {wo.workOrderType === WorkOrderType.Corrective && wo.workRequestId && (
                    <div><span className="font-bold">Work Request ID:</span> {wo.workRequestId}</div>
                )}
                
                <div><span className="font-bold">Planner Group:</span> {plannerGroup?.name}</div>
                <div><span className="font-bold">Work Center:</span> {data.workCenters.find(wc => wc.id === wo.workCenterId)?.name || 'N/A'}</div>
                
                <div><span className="font-bold">Due Date:</span> {wo.dueDate}</div>
                <div><span className="font-bold">Est. Duration:</span> {wo.estimatedDuration} Hrs</div>
                {wo.parentWorkOrderId && <div><span className="font-bold">Parent WO:</span> {wo.parentWorkOrderId}</div>}
                {wo.cancellationReason && <div className="col-span-2"><span className="font-bold text-red-600">Cancellation Reason:</span> {wo.cancellationReason}</div>}
            </div>

            {/* Resources: Procedures */}
            <div className="mb-6">
                <h3 className="font-bold border-b border-black mb-2 uppercase text-sm">Procedures / Safety Instructions</h3>
                {linkedProcedures.length > 0 ? (
                    <div className="space-y-6 mt-2">
                        {linkedProcedures.map(proc => {
                            const hasDuration = 'totalDuration' in proc;
                            return (
                                <div key={proc.id} className="break-inside-avoid">
                                    <div className="font-bold text-sm mb-1">{proc.id} - {proc.description}</div>
                                    {proc.remarks && <p className="text-xs italic mb-2">{proc.remarks}</p>}
                                    
                                    <table className="w-full text-xs border-collapse border border-black">
                                        <thead>
                                            <tr className="bg-gray-100">
                                                <th className="border border-black p-1 w-12 text-center">Op #</th>
                                                <th className="border border-black p-1 text-left">Description</th>
                                                {hasDuration && <th className="border border-black p-1 w-16 text-right">Est. Hrs</th>}
                                                <th className="border border-black p-1 w-12 text-center">Done</th>
                                                <th className="border border-black p-1 w-24 text-center">Initials</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {proc.operations.map((op: any, idx: number) => (
                                                <tr key={idx}>
                                                    <td className="border border-black p-1 text-center">{op.opNo}</td>
                                                    <td className="border border-black p-1">{op.description}</td>
                                                    {hasDuration && (
                                                        <td className="border border-black p-1 text-right">
                                                            {op.duration !== undefined ? op.duration : '-'}
                                                        </td>
                                                    )}
                                                    <td className="border border-black p-1"></td>
                                                    <td className="border border-black p-1"></td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            );
                        })}
                    </div>
                ) : <p className="text-sm italic">No specific procedures linked.</p>}
            </div>

            {/* Resources: Parts */}
            <div className="mb-6 break-inside-avoid">
                <h3 className="font-bold border-b border-black mb-2 uppercase text-sm">Parts Required</h3>
                {wo.partsUsed.length > 0 ? (
                    <table className="w-full text-sm border-collapse border border-black">
                        <thead>
                            <tr className="bg-gray-100">
                                <th className="border border-black p-1 text-left">Part #</th>
                                <th className="border border-black p-1 text-left">Description</th>
                                <th className="border border-black p-1 text-right w-20">Qty</th>
                                <th className="border border-black p-1 text-center w-20">Check</th>
                            </tr>
                        </thead>
                        <tbody>
                            {wo.partsUsed.map(partUsed => {
                                const part = data.parts.find(p => p.id === partUsed.partId);
                                return (
                                    <tr key={partUsed.partId}>
                                        <td className="border border-black p-1">{part?.partNumber}</td>
                                        <td className="border border-black p-1">{part?.name}</td>
                                        <td className="border border-black p-1 text-right">{partUsed.quantity}</td>
                                        <td className="border border-black p-1"></td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                ) : <p className="text-sm italic">No parts required.</p>}
            </div>
            
            {/* Personnel */}
            <div className="mb-6 break-inside-avoid">
                 <h3 className="font-bold border-b border-black mb-2 uppercase text-sm">Assigned Personnel</h3>
                 <p className="text-sm">{wo.assignedUserIds.map(uid => data.users.find(u => u.id === uid)?.name).join(', ') || 'None Assigned'}</p>
            </div>

            {wo.workOrderType === WorkOrderType.Breakdown && wo.rca && (
                <div className="mb-6 break-inside-avoid">
                    <h3 className="font-bold border-b border-black mb-2 uppercase text-sm">Root Cause Analysis</h3>
                    <div className="space-y-1 text-sm">
                        <p><strong>Component:</strong> {data.parts.find(p => p.id === data.bomItems.find(b => b.id === wo.rca!.componentAffectedId)?.partId)?.name || wo.rca.componentAffectedCustom || 'N/A'}</p>
                        <p><strong>Problem:</strong> {wo.rca.problemStatement}</p>
                        <p><strong>Action Taken:</strong> {wo.rca.immediateActionTaken}</p>
                    </div>
                </div>
            )}

            {/* Feedback Section (Manual Entry) */}
            <div className="flex-grow break-inside-avoid">
                <h3 className="font-bold border-b border-black mb-2 uppercase text-sm">Execution Feedback (To be filled by Technician)</h3>
                <table className="w-full text-sm border-collapse border border-black">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="border border-black p-2 text-left w-1/4">Name / Emp ID</th>
                            <th className="border border-black p-2 text-center w-24">Start Time</th>
                            <th className="border border-black p-2 text-center w-24">End Time</th>
                            <th className="border border-black p-2 text-left">Comments / Work Done</th>
                        </tr>
                    </thead>
                    <tbody>
                        {/* 4 Empty Rows for manual entry */}
                        {[1, 2, 3, 4].map(i => (
                            <tr key={i} className="h-12">
                                <td className="border border-black p-2"></td>
                                <td className="border border-black p-2"></td>
                                <td className="border border-black p-2"></td>
                                <td className="border border-black p-2"></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Footer */}
            <div className="mt-auto pt-4 text-xs flex justify-between border-t-2 border-black">
                <span className="font-bold uppercase">
                    {isOriginal ? 'ORIGINAL COPY' : 'REPRINTED COPY'}
                </span>
                <span>Page 1 of 1</span>
            </div>
        </div>
     );
};
