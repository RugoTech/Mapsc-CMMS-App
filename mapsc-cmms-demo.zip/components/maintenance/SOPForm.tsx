
import React, { useState, useEffect, useContext, useCallback } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { SOP, SOPOperation, User } from '../../types';

interface SOPFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: SOP) => void;
  itemToEdit: SOP | null;
  currentUser: User | null;
}

export const SOPForm: React.FC<SOPFormProps> = ({ isOpen, onClose, onSave, itemToEdit, currentUser }) => {
    const context = useContext(DataContext);
    const getInitialState = useCallback((): Omit<SOP, 'id'> => ({
        assetId: '',
        description: '',
        createdDate: new Date().toISOString().split('T')[0],
        createdBy: currentUser?.id || '',
        operations: [{ opNo: '001', description: '' }],
        remarks: ''
    }), [currentUser]);
    
    const [formData, setFormData] = useState(getInitialState());

    useEffect(() => {
        if (isOpen) {
            setFormData(itemToEdit ? itemToEdit : getInitialState());
        }
    }, [isOpen, itemToEdit, getInitialState]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleOperationChange = (index: number, field: keyof SOPOperation, value: string) => {
        const newOps = [...formData.operations];
        newOps[index] = { ...newOps[index], [field]: value };
        setFormData(prev => ({...prev, operations: newOps}));
    };
    
    const addOperation = () => {
        const newOpNo = String(formData.operations.length + 1).padStart(3, '0');
        setFormData(prev => ({...prev, operations: [...prev.operations, { opNo: newOpNo, description: '' }]}));
    };

    const removeOperation = (index: number) => {
        if (formData.operations.length <= 1) return;
        setFormData(prev => ({...prev, operations: prev.operations.filter((_, i) => i !== index)}));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData as SOP);
    };

    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="sop-form">{itemToEdit ? 'Save Changes' : 'Save'}</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={itemToEdit ? 'Edit SOP' : 'New SOP'} footer={modalFooter}>
            <form id="sop-form" onSubmit={handleSubmit} className="space-y-4">
                <Input id="description" label="Description" name="description" value={formData.description} onChange={handleChange} required maxLength={106} />
                 <div>
                    <label htmlFor="assetId" className="block text-sm font-medium">Asset (Optional)</label>
                    <select id="assetId" name="assetId" value={formData.assetId} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                        <option value="">None</option>
                        {context?.data.assets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                </div>
                
                <div className="border-t pt-4">
                    <h4 className="font-semibold mb-2">Operations</h4>
                    <div className="space-y-2">
                        {formData.operations.map((op, index) => (
                            <div key={index} className="flex items-center space-x-2">
                                <Input id={`opNo-${index}`} label="Op. #" name="opNo" value={op.opNo} onChange={e => handleOperationChange(index, 'opNo', e.target.value)} className="w-20" />
                                <div className="flex-grow">
                                  <Input id={`opDesc-${index}`} label="Description" name="description" value={op.description} onChange={e => handleOperationChange(index, 'description', e.target.value)} />
                                </div>
                                <Button type="button" variant="danger" size="sm" onClick={() => removeOperation(index)} className="mt-6" disabled={formData.operations.length <= 1}>X</Button>
                            </div>
                        ))}
                    </div>
                    <Button type="button" variant="secondary" size="sm" onClick={addOperation} className="mt-2">Add Operation</Button>
                </div>
                
                <div>
                    <label htmlFor="remarks" className="block text-sm font-medium">Remarks</label>
                    <textarea id="remarks" name="remarks" rows={3} value={formData.remarks} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
                </div>
            </form>
        </Modal>
    );
};
