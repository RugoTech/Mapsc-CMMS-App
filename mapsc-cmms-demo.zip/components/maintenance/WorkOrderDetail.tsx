
// ... existing imports ...
import React, { useState, useContext, useEffect, useMemo, useCallback } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Table } from '../ui/Table';
import { Input } from '../ui/Input';
import { Modal } from '../ui/Modal';
import { LaborLogForm } from './LaborLogForm';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { useSettings } from '../../contexts/SettingsContext';
import { generateTroubleshootingSteps } from '../../services/geminiService';
import { Alert } from '../ui/Alert';
import { InitialMPRForm } from '../inventory/InitialMPRForm';
import { ManualPRForm } from '../inventory/ManualPRForm';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { PrintableWorkOrderDocument } from './PrintableWorkOrderDocument';
import type {
  WorkOrder,
  User,
  PartUsed,
  LaborLog,
  SafetyInstruction,
  WorkInstruction,
  SOP,
  InventoryTransaction,
  RootCauseAnalysis,
  AuditLogEntry,
  PurchaseRequisition,
  Vendor,
  RFQ,
  PurchaseOrder,
  Asset,
  Plant,
  Zone,
  PlannerGroup,
  MockData
} from '../../types';
import { WorkOrderStatus, Priority, WorkOrderType, TransactionType, ProjectStatus, PRType, PRStatus, PRItemType, POStatus } from '../../types';

// ... (existing interfaces, colors, PartSelectorModal, ProcedureSelectorModal, ResourcePlanningTab... NO changes until WorkOrderDetail component definition) ...

interface WorkOrderDetailProps {
  workOrderId: string;
  onBack: () => void;
  currentUser: User | null;
  setUnsavedChanges: (state: { isDirty: boolean; onSave: () => Promise<boolean> }) => void;
}

type Tab = 'Resource Planning' | 'Feedback' | 'Costs' | 'Root Cause Analysis';

const statusColors: Record<WorkOrderStatus, 'blue' | 'yellow' | 'green' | 'gray' | 'red'> = {
    [WorkOrderStatus.Open]: 'blue',
    [WorkOrderStatus.InProgress]: 'yellow',
    [WorkOrderStatus.Completed]: 'green',
    [WorkOrderStatus.Archived]: 'gray',
    [WorkOrderStatus.Cancelled]: 'red',
};

const poStatusColors: Record<POStatus, 'gray' | 'blue' | 'yellow' | 'green' | 'red'> = {
    [POStatus.Draft]: 'gray',
    [POStatus.PendingApproval]: 'blue',
    [POStatus.PendingHighValueApproval]: 'blue',
    [POStatus.Approved]: 'green',
    [POStatus.Rejected]: 'red',
    [POStatus.AddMoreInfo]: 'blue',
    [POStatus.Submitted]: 'yellow',
    [POStatus.PartiallyReceived]: 'yellow',
    [POStatus.Received]: 'green',
    [POStatus.Closed]: 'gray',
};

const prStatusColors: Record<PRStatus, 'blue' | 'green' | 'red' | 'gray' | 'yellow'> = {
    [PRStatus.Draft]: 'gray',
    [PRStatus.Pending]: 'blue',
    [PRStatus.Approved]: 'green',
    [PRStatus.Rejected]: 'red',
    [PRStatus.RFQCreated]: 'yellow',
};

// ... (PartSelectorModal implementation) ...
const PartSelectorModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (selections: { partId: string; quantity: number }[]) => void;
}> = ({ isOpen, onClose, onSave }) => {
    const context = useContext(DataContext);
    const [selections, setSelections] = useState<Record<string, number>>({});
    const [searchQuery, setSearchQuery] = useState('');

    const filteredParts = context ? context.data.parts.filter(part => 
        part.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        part.partNumber.toLowerCase().includes(searchQuery.toLowerCase())
    ) : [];

    useEffect(() => {
        if (isOpen) {
            setSelections({});
            setSearchQuery('');
        }
    }, [isOpen]);

    const togglePart = (partId: string) => {
        setSelections(prev => {
            const next = { ...prev };
            if (next[partId]) {
                delete next[partId];
            } else {
                next[partId] = 1; // Default quantity
            }
            return next;
        });
    };

    const updateQuantity = (partId: string, qty: number) => {
        if (qty < 1) return;
        setSelections(prev => ({
            ...prev,
            [partId]: qty
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const result = Object.entries(selections).map(([partId, quantity]) => ({ partId, quantity }));
        if (result.length > 0) {
            onSave(result);
        }
    };

    const selectionCount = Object.keys(selections).length;

    if (!context) return null;

    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="part-selector-form" disabled={selectionCount === 0}>Add Selected ({selectionCount})</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Add Parts to Work Order" footer={modalFooter} size="xl">
            <form id="part-selector-form" onSubmit={handleSubmit} className="space-y-4">
                 <Input
                    id="part-search"
                    label="Search Parts"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by name or number..."
                />
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Available Parts</label>
                    <div className="border border-gray-300 dark:border-gray-600 rounded-md overflow-y-auto h-96 bg-white dark:bg-gray-700">
                        {filteredParts.length > 0 ? (
                            <div className="divide-y dark:divide-gray-600">
                                {filteredParts.map(part => (
                                    <div 
                                        key={part.id} 
                                        className={`flex items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-600 cursor-pointer ${selections[part.id] ? 'bg-indigo-50 dark:bg-indigo-900/30' : ''}`}
                                        onClick={() => togglePart(part.id)}
                                    >
                                        <input 
                                            type="checkbox" 
                                            checked={!!selections[part.id]} 
                                            onChange={() => {}} // Handled by parent div click
                                            className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                        />
                                        <div className="ml-3 flex-1">
                                            <div className="text-sm font-medium text-gray-900 dark:text-white">{part.name}</div>
                                            <div className="text-xs text-gray-500 dark:text-gray-400">
                                                #{part.partNumber} | On Hand: <span className={part.quantity <= part.reorderPoint ? 'text-red-500 font-bold' : ''}>{part.quantity}</span> | {part.location}
                                            </div>
                                        </div>
                                        {selections[part.id] && (
                                            <div className="flex items-center" onClick={(e) => e.stopPropagation()}>
                                                <span className="text-xs mr-2 text-gray-500 dark:text-gray-400">Qty:</span>
                                                <input
                                                    type="number" 
                                                    min="1" 
                                                    value={selections[part.id]} 
                                                    onChange={(e) => updateQuantity(part.id, parseInt(e.target.value) || 1)}
                                                    className="w-20 text-center border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-800 dark:text-white"
                                                />
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="p-4 text-center text-gray-500 dark:text-gray-400">No parts found matching your search.</div>
                        )}
                    </div>
                    <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                        Click rows to select parts. Specify quantity for selected items.
                    </p>
                </div>
            </form>
        </Modal>
    );
};

// ... (ProcedureSelectorModal implementation) ...
const ProcedureSelectorModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (selection: string[]) => void;
    alreadyLinkedIds: string[];
}> = ({ isOpen, onClose, onSave, alreadyLinkedIds }) => {
    const context = useContext(DataContext);
    const [selectedProcedureIds, setSelectedProcedureIds] = useState<string[]>([]);
    const [searchQuery, setSearchQuery] = useState('');

    if (!context) return null;

    const { safetyInstructions, workInstructions, sops } = context.data;
    const allProcedures = [...safetyInstructions, ...workInstructions, ...sops];

    const availableProcedures = allProcedures.filter(proc =>
        !alreadyLinkedIds.includes(proc.id) &&
        (proc.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
         proc.id.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    useEffect(() => {
        if (isOpen) {
            setSelectedProcedureIds([]);
            setSearchQuery('');
        }
    }, [isOpen]);

    const toggleSelection = (id: string) => {
        setSelectedProcedureIds(prev =>
            prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
        );
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (selectedProcedureIds.length > 0) {
            onSave(selectedProcedureIds);
        }
    };

    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="procedure-selector-form" disabled={selectedProcedureIds.length === 0}>Add Selected ({selectedProcedureIds.length})</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Add Procedures to Work Order" footer={modalFooter}>
            <form id="procedure-selector-form" onSubmit={handleSubmit} className="space-y-4">
                <Input
                    id="procedure-search"
                    label="Search Procedures"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by ID or description..."
                />
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Available Procedures</label>
                    <div className="border border-gray-300 dark:border-gray-600 rounded-md overflow-y-auto h-64 bg-white dark:bg-gray-700">
                        {availableProcedures.length > 0 ? (
                            <div className="divide-y dark:divide-gray-600">
                                {availableProcedures.map(proc => (
                                    <div 
                                        key={proc.id} 
                                        className={`flex items-start p-2 hover:bg-gray-50 dark:hover:bg-gray-600 cursor-pointer ${selectedProcedureIds.includes(proc.id) ? 'bg-indigo-50 dark:bg-indigo-900/30' : ''}`}
                                        onClick={() => toggleSelection(proc.id)}
                                    >
                                        <input
                                            type="checkbox"
                                            checked={selectedProcedureIds.includes(proc.id)}
                                            onChange={() => {}} // Handled by parent div click
                                            className="mt-1 h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                        />
                                        <div className="ml-2 text-sm text-gray-700 dark:text-gray-300 flex-1">
                                            <span className="font-semibold">{proc.id}</span> - {proc.description}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-sm text-gray-500 dark:text-gray-400 p-4 text-center">No matching procedures found.</p>
                        )}
                    </div>
                    <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                        Click rows to select multiple procedures.
                    </p>
                </div>
            </form>
        </Modal>
    );
};

// ... (ResourcePlanningTab implementation) ...
const ResourcePlanningTab: React.FC<{
    editableWO: WorkOrder;
    handleFieldChange: (updates: Partial<WorkOrder>) => void;
    isLocked: boolean;
    currentUser: User | null;
    setIsProcedureModalOpen: (isOpen: boolean) => void;
    setIsPartModalOpen: (isOpen: boolean) => void;
    handleRemoveProcedure: (procedureId: string) => void;
    handleRemovePart: (partId: string) => void;
    linkedProcedures: (SafetyInstruction | WorkInstruction | SOP)[];
}> = ({
    editableWO,
    handleFieldChange,
    isLocked,
    currentUser,
    setIsProcedureModalOpen,
    setIsPartModalOpen,
    handleRemoveProcedure,
    handleRemovePart,
    linkedProcedures,
}) => {
    // ... (No changes here) ...
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const formatCurrency = useCurrencyFormatter();

    if (!context) return null;
    const { data } = context;

    const issuedParts = useMemo(() => {
        return data.inventoryTransactions.filter(
            t => t.workOrderId === editableWO.id && t.type === TransactionType.Issue
        );
    }, [data.inventoryTransactions, editableWO.id]);

    const availableControllerGroups = useMemo(() => {
        if (!context || !currentUser) return [];
        const { maintenanceControllers, plannerGroups } = context.data;

        const userPlannerGroup = plannerGroups.find(pg => pg.userIds.includes(currentUser.id));

        if (userPlannerGroup) {
            return maintenanceControllers.filter(cg => cg.plannerGroupId === userPlannerGroup.id);
        }

        const isUtilitiesPlanner = currentUser.id === 'USER-006';
        const isPackagingPlanner = currentUser.id === 'USER-013';
        if (isUtilitiesPlanner) { return maintenanceControllers.filter(cg => cg.name.includes('UTLS')); }
        if (isPackagingPlanner) { return maintenanceControllers.filter(cg => cg.name.includes('PKG')); }
        
        return maintenanceControllers;
    }, [context, currentUser]);

    const availableWorkCenters = useMemo(() => {
        if (!context || !currentUser) return [];
        const { workCenters, maintenanceControllers, plannerGroups } = context.data;
        
        let allowedControllerGroupIds: string[] = [];
        const userPlannerGroup = plannerGroups.find(pg => pg.userIds.includes(currentUser.id));

        if (userPlannerGroup) {
             allowedControllerGroupIds = maintenanceControllers
                .filter(cg => cg.plannerGroupId === userPlannerGroup.id)
                .map(cg => cg.id);
        } else {
            const isUtilitiesPlanner = currentUser.id === 'USER-006';
            const isPackagingPlanner = currentUser.id === 'USER-013';
            if (isUtilitiesPlanner) { 
                allowedControllerGroupIds = maintenanceControllers.filter(cg => cg.name.includes('UTLS')).map(cg => cg.id);
            } else if (isPackagingPlanner) { 
                allowedControllerGroupIds = maintenanceControllers.filter(cg => cg.name.includes('PKG')).map(cg => cg.id); 
            } else {
                allowedControllerGroupIds = maintenanceControllers.map(cg => cg.id);
            }
        }

        let wcs = workCenters.filter(wc => allowedControllerGroupIds.includes(wc.controllerGroupId));

        if (editableWO.controllerGroupId) {
            wcs = wcs.filter(wc => wc.controllerGroupId === editableWO.controllerGroupId);
        }

        return wcs;
    }, [context, currentUser, editableWO.controllerGroupId]);

    const partsInWO = editableWO.partsUsed.map(pu => {
        const partDetails = data.parts.find(p => p.id === pu.partId);
        return {
            ...pu,
            id: pu.partId,
            name: partDetails?.name || 'N/A',
            partNumber: partDetails?.partNumber || 'N/A',
        };
    });

    const partsColumns = [
        { header: 'Part #', accessor: 'partNumber' as keyof typeof partsInWO[0] },
        { header: 'Description', accessor: 'name' as keyof typeof partsInWO[0] },
        { header: 'Qty Required', accessor: 'quantity' as keyof typeof partsInWO[0] },
    ];

    const procedureColumns = [
        { header: 'Procedure ID', accessor: 'id' as keyof (SafetyInstruction | WorkInstruction | SOP) },
        { header: 'Description', accessor: 'description' as keyof (SafetyInstruction | WorkInstruction | SOP) },
    ];
    
    const handleWorkCenterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newWorkCenterId = e.target.value;
        handleFieldChange({
            workCenterId: newWorkCenterId,
            assignedUserIds: [], 
        });
    };

    const handleUserToggle = (userId: string) => {
        const currentIds = editableWO.assignedUserIds || [];
        const newIds = currentIds.includes(userId)
            ? currentIds.filter(id => id !== userId)
            : [...currentIds, userId];
        handleFieldChange({ assignedUserIds: newIds });
    };

    const availableTechnicians = editableWO.workCenterId
        ? data.workCenters.find(wc => wc.id === editableWO.workCenterId)?.userIds
            .map(userId => data.users.find(u => u.id === userId))
            .filter((u): u is User => u !== undefined)
        : [];

    const partsCost = editableWO.partsUsed.reduce((acc, partUsed) => {
        const partInfo = data.parts.find(p => p.id === partUsed.partId);
        return acc + (partInfo ? (partInfo.unitCost * partUsed.quantity) : 0);
    }, 0);
    
    const personnelCount = Math.max(editableWO.assignedUserIds.length, 1);
    const laborCost = editableWO.estimatedDuration * settings.laborRatePerHour * personnelCount;
    const totalCost = partsCost + laborCost;

    return (
        <Card>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                    <h4 className="font-semibold text-lg border-b pb-2">Execution & Resources</h4>
                    <div>
                        <label htmlFor="controllerGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Controller Group</label>
                        <select id="controllerGroupId" value={editableWO.controllerGroupId} onChange={e => handleFieldChange({ controllerGroupId: e.target.value })} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" disabled={isLocked}>
                            <option value="">Select...</option>
                            {availableControllerGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="workCenterId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Work Center</label>
                        <select
                            id="workCenterId"
                            value={editableWO.workCenterId || ''}
                            onChange={handleWorkCenterChange}
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                            disabled={isLocked}
                        >
                            <option value="">Select a Work Center...</option>
                            {availableWorkCenters.map(wc => <option key={wc.id} value={wc.id}>{wc.name}</option>)}
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Assigned Personnel</label>
                        <div className={`border border-gray-300 dark:border-gray-600 rounded-md overflow-y-auto h-40 bg-white dark:bg-gray-700 ${isLocked || !editableWO.workCenterId ? 'opacity-50 cursor-not-allowed' : ''}`}>
                            {availableTechnicians.length > 0 ? (
                                <div className="divide-y dark:divide-gray-600">
                                    {availableTechnicians.map(user => (
                                        <div 
                                            key={user.id} 
                                            className={`flex items-center p-2 hover:bg-gray-50 dark:hover:bg-gray-600 cursor-pointer ${editableWO.assignedUserIds.includes(user.id) ? 'bg-indigo-50 dark:bg-indigo-900/30' : ''}`}
                                            onClick={() => !isLocked && editableWO.workCenterId && handleUserToggle(user.id)}
                                        >
                                            <input
                                                type="checkbox"
                                                checked={editableWO.assignedUserIds.includes(user.id)}
                                                onChange={() => {}} 
                                                disabled={isLocked || !editableWO.workCenterId}
                                                className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                            />
                                            <div className="ml-3">
                                                <div className="text-sm text-gray-700 dark:text-gray-300 font-medium">{user.name}</div>
                                                <div className="text-xs text-gray-500">{user.role}</div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-sm text-gray-500 dark:text-gray-400 p-4 text-center">Select a Work Center to see available personnel.</p>
                            )}
                        </div>
                        <p className="mt-1 text-xs text-gray-500">Click rows to toggle personnel assignment.</p>
                    </div>

                    <Input id="estimatedDuration" label="Estimated Duration (Hours)" type="number" step="0.01" min="0" value={editableWO.estimatedDuration} onChange={e => handleFieldChange({ estimatedDuration: Number(e.target.value)})} disabled={isLocked} />
                </div>
                <div className="space-y-6">
                    <div>
                        <h4 className="font-semibold text-lg border-b pb-2 flex justify-between items-center">
                            <span>Procedures</span>
                            {!isLocked && (
                                <Button size="sm" variant="secondary" onClick={() => setIsProcedureModalOpen(true)}>Add Procedure</Button>
                            )}
                        </h4>
                        <div className="mt-2">
                            {linkedProcedures.length > 0 ? (
                                <Table<(typeof linkedProcedures)[0]>
                                    columns={procedureColumns}
                                    data={linkedProcedures}
                                    renderRowActions={(item) => (
                                        !isLocked && (
                                            <Button variant="danger" size="sm" onClick={() => handleRemoveProcedure(item.id)}>Remove</Button>
                                        )
                                    )}
                                />
                            ) : (
                                <p className="text-sm text-gray-500">No procedures linked.</p>
                            )}
                        </div>
                    </div>
                    <div>
                        <h4 className="font-semibold text-lg border-b pb-2 flex justify-between items-center">
                            <span>Parts Required</span>
                             {!isLocked && (
                                <div className="flex flex-col items-end">
                                    <Button
                                        size="sm"
                                        variant="secondary"
                                        onClick={() => setIsPartModalOpen(true)}
                                        disabled={settings.inventoryLocked}
                                    >
                                        Add Part
                                    </Button>
                                    {settings.inventoryLocked && (
                                        <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
                                            Disabled during inventory count.
                                        </p>
                                    )}
                                </div>
                            )}
                        </h4>
                        <div className="mt-2">
                             {partsInWO.length > 0 ? (
                                <Table<(typeof partsInWO)[0]>
                                    columns={partsColumns}
                                    data={partsInWO}
                                    renderRowActions={(item) => {
                                        const isIssued = issuedParts.some(p => p.partId === item.partId);
                                        return !isLocked && (
                                            <Button 
                                                variant="danger" 
                                                size="sm" 
                                                onClick={() => handleRemovePart(item.partId)}
                                                disabled={isIssued}
                                                title={isIssued ? "This part has been issued and cannot be removed." : "Remove part"}
                                            >
                                                Remove
                                            </Button>
                                        )
                                    }}
                                />
                            ) : (
                                <p className="text-sm text-gray-500">No parts required.</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
            <div className="border-t dark:border-gray-700 pt-4 mt-6">
                <h5 className="font-semibold text-gray-800 dark:text-gray-200">Cost Estimate</h5>
                <div className="grid grid-cols-3 gap-2 mt-2 text-sm">
                    <div>
                        <span className="text-gray-500 dark:text-gray-400">Parts</span>
                        <p className="font-medium text-gray-900 dark:text-white">{formatCurrency(partsCost)}</p>
                    </div>
                    <div>
                        <span className="text-gray-500 dark:text-gray-400">Labor {personnelCount > 1 ? `(x${personnelCount})` : ''}</span>
                        <p className="font-medium text-gray-900 dark:text-white">{formatCurrency(laborCost)}</p>
                    </div>
                    <div>
                        <span className="font-bold text-base text-indigo-600 dark:text-indigo-400">Total</span>
                        <p className="font-bold text-base text-indigo-600 dark:text-indigo-400">{formatCurrency(totalCost)}</p>
                    </div>
                </div>
            </div>
        </Card>
    );
};

export const WorkOrderDetail: React.FC<WorkOrderDetailProps> = ({ workOrderId, onBack, currentUser, setUnsavedChanges }) => {
    // ... (rest of the component, updating prepareSaveData) ...
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [activeTab, setActiveTab] = useState<Tab>('Resource Planning');
    const formatCurrency = useCurrencyFormatter();
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
    
    // ... (convertToDefault, originalWO, changes, useEffect remain unchanged) ...
    const convertToDefault = useCallback((value: number, fromCurrency: string): number => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
    }, [settings.currency, settings.exchangeRate]);

    const originalWO = useMemo(() => 
        context?.data.workOrders.find(wo => wo.id === workOrderId), 
    [context?.data.workOrders, workOrderId]);

    const [changes, setChanges] = useState<Partial<WorkOrder>>({});

    useEffect(() => {
        setChanges({});
    }, [originalWO]);

    const [isPartModalOpen, setIsPartModalOpen] = useState(false);
    const [isLaborLogModalOpen, setIsLaborLogModalOpen] = useState(false);
    const [isProcedureModalOpen, setIsProcedureModalOpen] = useState(false);
    const [isArchiveConfirmOpen, setIsArchiveConfirmOpen] = useState(false);
    const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
    const [isPrintPreviewOpen, setIsPrintPreviewOpen] = useState(false);
    const [infoModalContent, setInfoModalContent] = useState<{ title: string; content: React.ReactNode } | null>(null);
    const [isInitialPRFormOpen, setIsInitialPRFormOpen] = useState(false);
    const [manualPRData, setManualPRData] = useState<PurchaseRequisition | null>(null);
    const [troubleshooting, setTroubleshooting] = useState<{ loading: boolean; content: string | null; error: string | null }>({
        loading: false, content: null, error: null,
    });
    const [laborLogToEdit, setLaborLogToEdit] = useState<LaborLog | null>(null);
    const [laborLogToDelete, setLaborLogToDelete] = useState<LaborLog | null>(null);
  
    if (!context || !currentUser) return <div>Loading...</div>;
    const { data, setData } = context;
  
    if (!originalWO) {
        return (
        <div>
            <p>Work Order not found.</p>
            <Button onClick={onBack}>Back to List</Button>
        </div>
        );
    }
  
    const { vendors } = data;
    const getVendorName = (vendorId: string) => vendors.find(v => v.id === vendorId)?.name || 'N/A';

    // ... (externalCosts calculation, calculatePOTotal, calculateReceivedCost, renderCostsTab remain unchanged) ...
    const externalCosts = useMemo(() => {
        const { purchaseRequisitions, rfqs, purchaseOrders } = data;

        const linkedPRs = purchaseRequisitions.filter(pr => pr.workOrderId === workOrderId);
        const linkedPRIds = new Set(linkedPRs.map(pr => pr.id));

        const linkedRFQs = rfqs.filter(rfq => linkedPRIds.has(rfq.prId));
        const linkedRFQIds = new Set(linkedRFQs.map(rfq => rfq.id));

        const linkedPOs = purchaseOrders.filter(po =>
            linkedRFQIds.has(po.rfqId) &&
            [POStatus.Approved, POStatus.Submitted, POStatus.PartiallyReceived, POStatus.Received, POStatus.Closed].includes(po.status)
        );

        const calculateReceivedCostLocal = (po: PurchaseOrder): number => {
            const receivedSubtotal = po.items.reduce((sum, item) => sum + item.quantityReceived * item.unitCost, 0);
            return receivedSubtotal * (1 + po.taxRate);
        };

        const totalReceived = linkedPOs.reduce((sum, po) => {
            const costInPoCurrency = calculateReceivedCostLocal(po);
            return sum + convertToDefault(costInPoCurrency, po.currency);
        }, 0);

        return { totalReceived, pos: linkedPOs, prs: linkedPRs };
    }, [data, workOrderId, convertToDefault]);

    const calculatePOTotal = (po: PurchaseOrder): number => {
        const subtotal = po.items.reduce((sum, item) => sum + item.quantity * item.unitCost, 0);
        return subtotal * (1 + po.taxRate);
    };

    const calculateReceivedCost = (po: PurchaseOrder): number => {
        const receivedSubtotal = po.items.reduce((sum, item) => sum + item.quantityReceived * item.unitCost, 0);
        return receivedSubtotal * (1 + po.taxRate);
    };

    const renderCostsTab = () => {
         // ... (implementation same as before) ...
        const { laborLogs, inventoryTransactions, parts } = data;
        const getUserName = (id: string) => data.users.find(u => u.id === id)?.name || id;
        const { totalReceived, pos: externalPOs, prs: linkedPRs } = externalCosts;
    
        const calculateDuration = (start: string, end: string) => {
            return (new Date(end).getTime() - new Date(start).getTime()) / (1000 * 60 * 60);
        };
    
        const issuedPartsTransactions = inventoryTransactions.filter(
            t => t.workOrderId === workOrderId && t.type === TransactionType.Issue
        );
        
        const actualPartsCost = issuedPartsTransactions.reduce((acc, transaction) => {
            const partInfo = parts.find(p => p.id === transaction.partId);
            return acc + (partInfo ? (partInfo.unitCost * transaction.quantity) : 0);
        }, 0);
    
        const woLaborLogs = laborLogs.filter(l => l.workOrderId === workOrderId);
        const actualLaborCost = woLaborLogs.reduce((acc, log) => {
            const duration = calculateDuration(log.startTime, log.endTime);
            return acc + (duration * settings.laborRatePerHour);
        }, 0);
    
        const actualTotalCost = actualPartsCost + actualLaborCost + totalReceived;
    
        const partsIssuedColumns = [
            { header: 'Part #', accessor: (item: InventoryTransaction) => parts.find(p => p.id === item.partId)?.partNumber || 'N/A' },
            { header: 'Description', accessor: (item: InventoryTransaction) => parts.find(p => p.id === item.partId)?.name || 'N/A' },
            { header: 'Qty Issued', accessor: 'quantity' as keyof InventoryTransaction },
            { header: 'Unit Cost', accessor: (item: InventoryTransaction) => formatCurrency(parts.find(p => p.id === item.partId)?.unitCost || 0) },
            { header: 'Line Total', accessor: (item: InventoryTransaction) => {
                const part = parts.find(p => p.id === item.partId);
                const total = part ? (part.unitCost * item.quantity) : 0;
                return formatCurrency(total);
            }},
            { header: 'Date Issued', accessor: 'date' as keyof InventoryTransaction },
        ];
        
        const laborColumns = [
            { header: 'Personnel', accessor: (item: LaborLog) => getUserName(item.userId) },
            { header: 'Start Time', accessor: (item: LaborLog) => new Date(item.startTime).toLocaleString() },
            { header: 'End Time', accessor: (item: LaborLog) => new Date(item.endTime).toLocaleString() },
            { header: 'Duration (Hrs)', accessor: (item: LaborLog) => calculateDuration(item.startTime, item.endTime).toFixed(2) },
            { header: 'Cost', accessor: (item: LaborLog) => formatCurrency(calculateDuration(item.startTime, item.endTime) * settings.laborRatePerHour) },
        ];
        
        return (
            <div className="space-y-6">
                <Card title="Parts Issued (from Stock)">
                    {issuedPartsTransactions.length > 0 ? (
                        <Table<InventoryTransaction>
                            columns={partsIssuedColumns}
                            data={issuedPartsTransactions}
                        />
                    ) : <p>No parts have been issued against this work order yet.</p>}
                </Card>
                
                {/* Linked Purchase Requisitions Table */}
                <Card title="Linked Purchase Requisitions (Manual PRs)">
                    <div className="mb-4 text-sm text-gray-600 dark:text-gray-300">
                        Use this table to track Manual Purchase Requisitions created specifically for this Work Order.
                    </div>
                    {linkedPRs.length > 0 ? (
                        <Table<PurchaseRequisition>
                            columns={[
                                { header: 'PR ID', accessor: 'id' as keyof PurchaseRequisition },
                                { header: 'Type', accessor: (pr: PurchaseRequisition) => (
                                    <Badge color={pr.type === PRType.Manual ? 'yellow' : 'gray'}>{pr.type}</Badge>
                                )},
                                { header: 'Description', accessor: 'description' as keyof PurchaseRequisition },
                                { header: 'Status', accessor: (pr: PurchaseRequisition) => <Badge color={prStatusColors[pr.status]}>{pr.status}</Badge> },
                                { header: 'Est. Cost', accessor: (pr: PurchaseRequisition) => typeof pr.estimatedCost === 'number' ? formatCurrency(pr.estimatedCost) : pr.estimatedCost }
                            ]}
                            data={linkedPRs}
                        />
                    ) : <p className="text-gray-500 dark:text-gray-400">No linked Purchase Requisitions found.</p>}
                </Card>
    
                <Card title="External Costs / Purchase Orders">
                    {externalPOs.length > 0 ? (
                        <Table<PurchaseOrder>
                            columns={[
                                { header: 'PO ID', accessor: 'id' as keyof PurchaseOrder },
                                { header: 'Vendor', accessor: (po: PurchaseOrder) => getVendorName(po.vendorId) },
                                { header: 'Status', accessor: (po: PurchaseOrder) => <Badge color={poStatusColors[po.status]}>{po.status}</Badge> },
                                { 
                                    header: 'Total PO Value', 
                                    accessor: (po: PurchaseOrder) => formatCurrency(convertToDefault(calculatePOTotal(po), po.currency)) 
                                },
                                { 
                                    header: 'Received Cost', 
                                    accessor: (po: PurchaseOrder) => formatCurrency(convertToDefault(calculateReceivedCost(po), po.currency)) 
                                }
                            ]}
                            data={externalPOs}
                        />
                    ) : <p className="text-gray-500 dark:text-gray-400">No external purchases have been made for this work order yet.</p>}
                </Card>
                 <Card title="Labor Costs">
                     {woLaborLogs.length > 0 ? (
                         <Table<LaborLog>
                            columns={laborColumns}
                            data={woLaborLogs}
                        />
                     ) : <p>No labor logged.</p>}
                </Card>
                 <Card>
                    <h4 className="font-semibold text-lg">Actual Cost Summary</h4>
                     <div className="grid grid-cols-4 gap-4 mt-2 text-center">
                        <div>
                            <p className="text-sm text-gray-500">Total Parts (Issued)</p>
                            <p className="text-2xl font-bold">{formatCurrency(actualPartsCost)}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">Total External</p>
                            <p className="text-2xl font-bold">{formatCurrency(totalReceived)}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">Total Labor</p>
                            <p className="text-2xl font-bold">{formatCurrency(actualLaborCost)}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">Grand Total</p>
                            <p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{formatCurrency(actualTotalCost)}</p>
                        </div>
                     </div>
                </Card>
            </div>
        );
    };

    const editableWO: WorkOrder = { ...originalWO, ...changes };
    const isDirty = Object.keys(changes).length > 0;

    const isLockedByStatus = originalWO.status === WorkOrderStatus.Completed || originalWO.status === WorkOrderStatus.Archived || originalWO.status === WorkOrderStatus.Cancelled;
    const isArchived = originalWO.status === WorkOrderStatus.Archived;
    const isClerk = currentUser?.role === 'Clerk';
    const isRestrictedUser = useMemo(() => {
        if (!currentUser) return false;
        return ['Engineer', 'Manager', 'Factory Manager'].includes(currentUser.role);
    }, [currentUser]);

    const isFieldLocked = isLockedByStatus || isClerk || isRestrictedUser;
    const isSaveDisabled = isLockedByStatus || !isDirty || isRestrictedUser;
    const isCompleteDisabled = isLockedByStatus || isRestrictedUser;
    const isArchiveDisabled = isLockedByStatus || isClerk || isRestrictedUser;
  
    const hasFeedback = useMemo(() => data.laborLogs.some(log => log.workOrderId === workOrderId), [data.laborLogs, workOrderId]);
    const hasCosts = useMemo(() => data.inventoryTransactions.some(t => t.workOrderId === workOrderId && t.type === TransactionType.Issue), [data.inventoryTransactions, workOrderId]);

    const [isDeleteDisabled, deleteButtonTitle] = useMemo(() => {
        const hasLinkedPR = data.purchaseRequisitions.some(pr => pr.workOrderId === workOrderId);
        if (hasLinkedPR) return [true, "Cannot delete: This WO has a Purchase Requisition attached."];
        if (hasFeedback || hasCosts) return [true, "Cannot delete: This WO has costs or labor logged. Please archive it instead."];
        if (currentUser?.role !== 'Administrator') return [true, "Only an Administrator can delete a work order."];
        if (isArchived) return [true, "This work order cannot be deleted as it is archived."];
        return [false, "Delete this work order permanently"];
    }, [currentUser, hasFeedback, hasCosts, isArchived, data.purchaseRequisitions, workOrderId]);

    const handleFieldChange = (updates: Partial<WorkOrder>) => setChanges(prev => ({ ...prev, ...updates }));
    
    // ... (event handlers: handleAddParts, handleRemovePart, handleSaveLaborLog, handleConfirmDeleteLog, handleAddProcedures, handleRemoveProcedure) ...
    const handleAddParts = (selections: { partId: string; quantity: number }[]) => {
        let updatedParts = [...editableWO.partsUsed];
        selections.forEach(({ partId, quantity }) => {
            const existingIndex = updatedParts.findIndex(p => p.partId === partId);
            if (existingIndex >= 0) {
                updatedParts[existingIndex] = { ...updatedParts[existingIndex], quantity: updatedParts[existingIndex].quantity + quantity };
            } else {
                updatedParts.push({ partId, quantity });
            }
        });
        handleFieldChange({ partsUsed: updatedParts });
        setIsPartModalOpen(false);
    };
    const handleRemovePart = (partIdToRemove: string) => handleFieldChange({ partsUsed: editableWO.partsUsed.filter(p => p.partId !== partIdToRemove) });
    const recalculateTotalLaborHours = (logs: LaborLog[]) => logs.reduce((total, log) => total + ((new Date(log.endTime).getTime() - new Date(log.startTime).getTime()) / (1000 * 60 * 60)), 0);

    const handleSaveLaborLog = (logData: { userId: string, startTime: string, endTime: string, notes: string }) => {
        const duration = (new Date(logData.endTime).getTime() - new Date(logData.startTime).getTime()) / (1000 * 60 * 60);
        setData(prevData => {
            let updatedLogs;
            let logAction: 'CREATE' | 'UPDATE';
            let logId;
            if (laborLogToEdit) {
                 logAction = 'UPDATE';
                 logId = laborLogToEdit.id;
                 updatedLogs = prevData.laborLogs.map(l => l.id === laborLogToEdit.id ? { ...l, ...logData } : l);
            } else {
                 logAction = 'CREATE';
                 logId = `LL-${String(prevData.laborLogs.length + 1).padStart(3, '0')}`;
                 updatedLogs = [...prevData.laborLogs, { id: logId, workOrderId: workOrderId, ...logData }];
            }
            const auditEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: logAction,
                entityType: 'LaborLog',
                entityId: logId,
                details: `Logged ${duration.toFixed(2)} hours for user ${logData.userId}.`,
                status: 'Success'
            };
            const woLogs = updatedLogs.filter(l => l.workOrderId === workOrderId);
            handleFieldChange({ laborHours: recalculateTotalLaborHours(woLogs) });
            return { ...prevData, laborLogs: updatedLogs, auditLog: [auditEntry, ...prevData.auditLog] };
        });
        setIsLaborLogModalOpen(false);
        setLaborLogToEdit(null);
    };

    const handleConfirmDeleteLog = () => {
        if (!laborLogToDelete) return;
        setData(prevData => {
            const updatedLogs = prevData.laborLogs.filter(l => l.id !== laborLogToDelete.id);
             const auditEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'DELETE',
                entityType: 'LaborLog',
                entityId: laborLogToDelete.id,
                details: `Deleted labor log ${laborLogToDelete.id}.`,
                status: 'Success'
            };
            const woLogs = updatedLogs.filter(l => l.workOrderId === workOrderId);
            handleFieldChange({ laborHours: recalculateTotalLaborHours(woLogs) });
            return { ...prevData, laborLogs: updatedLogs, auditLog: [auditEntry, ...prevData.auditLog] };
        });
        setLaborLogToDelete(null);
    }

    const handleAddProcedures = (procedureIds: string[]) => {
        const newProcedureIds = [...new Set([...editableWO.procedureIds, ...procedureIds])];
        handleFieldChange({ procedureIds: newProcedureIds });
        setIsProcedureModalOpen(false);
    };
    const handleRemoveProcedure = (procedureIdToRemove: string) => handleFieldChange({ procedureIds: editableWO.procedureIds.filter(id => id !== procedureIdToRemove) });

    const persistChanges = (woToSave: WorkOrder, alertMessage: string, actionDetail: string, shouldAlert: boolean = true) => {
        const logEntry: AuditLogEntry = {
            id: `LOG-${String(data.auditLog.length + 1).padStart(3, '0')}`,
            timestamp: new Date().toISOString(),
            userId: currentUser!.id,
            action: 'UPDATE',
            entityType: 'WorkOrder',
            entityId: workOrderId,
            details: actionDetail,
            status: 'Success'
        };
        setData(prevData => {
            const updatedWorkOrders = prevData.workOrders.map(wo => wo.id === workOrderId ? woToSave : wo);
            let updatedProjects = prevData.projects;
            if (woToSave.status === WorkOrderStatus.Completed && woToSave.projectId) {
                const projectWOs = prevData.workOrders.filter(wo => wo.projectId === woToSave.projectId);
                const allWOsForProjectAreDone = projectWOs.every(wo => {
                    if (wo.id === woToSave.id) return true;
                    return wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived;
                });
                if (allWOsForProjectAreDone) {
                    updatedProjects = prevData.projects.map(p => p.id === woToSave.projectId ? { ...p, status: ProjectStatus.Completed } : p);
                }
            }
            return { ...prevData, workOrders: updatedWorkOrders, projects: updatedProjects, auditLog: [logEntry, ...prevData.auditLog] };
        });
        if (shouldAlert) alert(alertMessage);
    };

    const prepareSaveData = () => {
        if (!originalWO) return null;
        let woToSave = { ...editableWO };
        let actionDetail = `Updated details for WO ${workOrderId}.`;
        let alertMessage = 'Changes saved successfully!';

        if (originalWO.status === WorkOrderStatus.Open && !isClerk) {
             const missingFields = [];
             if (!woToSave.controllerGroupId) missingFields.push('Controller Group');
             if (!woToSave.estimatedDuration || woToSave.estimatedDuration <= 0) missingFields.push('Estimated Duration');
             
             // Updated logic: Work Order can move to 'In Progress' if:
             // 1. Controller Group is assigned (Team identified)
             // 2. Duration is estimated (Scope defined)
             // 3. EITHER Personnel are assigned OR Parts are planned (Resources identified)
             const hasLaborPlan = (woToSave.assignedUserIds && woToSave.assignedUserIds.length > 0);
             const hasPartsPlan = (woToSave.partsUsed && woToSave.partsUsed.length > 0);
             
             if (!hasLaborPlan && !hasPartsPlan) {
                 missingFields.push('Assigned Personnel or Parts');
             }

             const linkedAsset = woToSave.assetId ? data.assets.find(a => a.id === woToSave.assetId) : null;
             const hasZone = woToSave.zoneId || linkedAsset?.zoneId;
             if (!hasZone) missingFields.push('Zone');
             
             if (missingFields.length > 0) {
                 // Do not change status, just save changes
                 alertMessage = `Changes saved. To advance to 'In Progress', please complete: ${missingFields.join(', ')}`;
             } else {
                 woToSave = { ...woToSave, status: WorkOrderStatus.InProgress };
                 alertMessage = "Work Order automatically moved to 'In Progress'.";
                 actionDetail += " Status changed to 'In Progress'.";
             }
        }
        return { woToSave, actionDetail, alertMessage };
    };

    const handleSaveChanges = () => { if (isDirty) { const data = prepareSaveData(); if (data) persistChanges(data.woToSave, data.alertMessage, data.actionDetail); } };
    const handleExternalSave = async (): Promise<boolean> => { if (!isDirty) return true; const data = prepareSaveData(); if (data) { persistChanges(data.woToSave, data.alertMessage, data.actionDetail, false); return true; } return false; };

    // ... (rest of the component) ...
    useEffect(() => { setUnsavedChanges({ isDirty, onSave: handleExternalSave }); return () => { setUnsavedChanges({ isDirty: false, onSave: async () => true }); } }, [isDirty, editableWO]);

    const handleCompleteWorkOrder = () => {
        if (!originalWO) return;
        const { purchaseRequisitions, rfqs, purchaseOrders, laborLogs, inventoryTransactions, parts } = data;
        
        // PO check
        const linkedPRIds = new Set(purchaseRequisitions.filter(pr => pr.workOrderId === workOrderId).map(pr => pr.id));
        const linkedRFQIds = new Set(rfqs.filter(rfq => linkedPRIds.has(rfq.prId)).map(rfq => rfq.id));
        const incompletePOs = purchaseOrders.filter(po => linkedRFQIds.has(po.rfqId) && po.status !== POStatus.Received && po.status !== POStatus.Closed);
        if (incompletePOs.length > 0) {
            setInfoModalContent({ title: "Cannot Complete", content: <p>Pending Purchase Orders exist.</p> });
            return;
        }
        // Labor check
        if (!laborLogs.some(log => log.workOrderId === workOrderId)) {
            setInfoModalContent({ title: "Cannot Complete", content: <p>Log labor first.</p> });
            return;
        }
        // Parts check
        const issuedQtys = inventoryTransactions.filter(t => t.workOrderId === workOrderId && t.type === TransactionType.Issue).reduce((acc, t) => { acc[t.partId] = (acc[t.partId] || 0) + t.quantity; return acc; }, {} as Record<string, number>);
        const unissued = editableWO.partsUsed.filter(p => (issuedQtys[p.partId] || 0) < p.quantity);
        if (unissued.length > 0) {
             setInfoModalContent({ title: "Cannot Complete", content: <p>Not all parts issued.</p> });
             return;
        }
        
        const finalWO = { ...editableWO, status: WorkOrderStatus.Completed };
        persistChanges(finalWO, "Work order Completed.", `Completed work order ${workOrderId}.`);
    };
    
    // ... (rest of the functions: handleConfirmDelete, handleArchiveClick, etc. same as provided code) ...
    const handleConfirmDelete = () => {
        const logEntry: AuditLogEntry = { id: `LOG-${Date.now()}`, timestamp: new Date().toISOString(), userId: currentUser!.id, action: 'DELETE', entityType: 'WorkOrder', entityId: workOrderId, details: `Deleted WO ${workOrderId}.`, status: 'Success' };
        setData(prev => ({ ...prev, workOrders: prev.workOrders.filter(wo => wo.id !== workOrderId), laborLogs: prev.laborLogs.filter(l => l.workOrderId !== workOrderId), auditLog: [logEntry, ...prev.auditLog] }));
        alert(`Deleted ${workOrderId}`); onBack();
    };

    const handleArchiveClick = () => {
        setIsArchiveConfirmOpen(true);
    }
    const handleConfirmArchive = () => {
        persistChanges({ ...editableWO, status: WorkOrderStatus.Archived }, "Archived.", `Archived ${workOrderId}.`);
    }

    const handlePrint = () => setIsPrintPreviewOpen(true);
    const handleConfirmPrint = () => { setIsPrintPreviewOpen(false); setTimeout(() => window.print(), 200); };
    const asset = editableWO.assetId ? data.assets.find(a => a.id === editableWO.assetId) : undefined;
    const handleAiTroubleshoot = async () => { 
        if(!asset) return;
        setTroubleshooting({ loading: true, content: null, error: null });
        const result = await generateTroubleshootingSteps(editableWO.description, asset);
        setTroubleshooting({ loading: false, content: result, error: null });
    };
    const handleInitialProceed = (d: any) => { 
        // Sequential ID generation for Manual PRs
        const nextMprId = `MPR-${String(data.purchaseRequisitions.filter(pr => pr.type === PRType.Manual).length + 1).padStart(3, '0')}`;
        setManualPRData({ id: nextMprId, type: PRType.Manual, requestDate: new Date().toISOString().split('T')[0], status: PRStatus.Draft, requesterId: currentUser.id, workOrderId: workOrderId, budgetCode: '', ...d });
        setIsInitialPRFormOpen(false);
    };
    const handleSaveManualPR = (pr: PurchaseRequisition) => { 
        setData(prev => ({ ...prev, purchaseRequisitions: [...prev.purchaseRequisitions, pr] })); 
        setManualPRData(null); 
    };
    const handleRcaChange = (e: any) => { handleFieldChange({ rca: { ...(editableWO.rca || {} as RootCauseAnalysis), [e.target.name]: e.target.value } }); };
    const handleRcaSelectChange = (e: any) => { handleFieldChange({ rca: { ...(editableWO.rca || {} as RootCauseAnalysis), [e.target.name]: e.target.value } }); };

    const effectiveZoneId = asset ? asset.zoneId : editableWO.zoneId;
    const zone = effectiveZoneId ? data.zones.find(z => z.id === effectiveZoneId) : undefined;
    const effectivePlantId = asset ? asset.plantId : zone?.plantId;
    const plant = effectivePlantId ? data.plants.find(p => p.id === effectivePlantId) : undefined;
    const effectivePlannerGroupId = editableWO.planningGroupId || asset?.custodianId;
    const plannerGroup = effectivePlannerGroupId ? data.plannerGroups.find(pg => pg.id === effectivePlannerGroupId) : undefined;
    const { safetyInstructions, workInstructions, sops } = data;
    const allProcedures = [...safetyInstructions, ...workInstructions, ...sops];
    const linkedProcedures = editableWO.procedureIds.map(pid => allProcedures.find(p => p.id === pid)).filter(Boolean) as (SafetyInstruction | WorkInstruction | SOP)[];

    const availableAssets = useMemo(() => data.assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId)), [data.assets, canSeeAllZones, accessibleZoneIds]);
    const availableZones = useMemo(() => data.zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id)), [data.zones, canSeeAllZones, accessibleZoneIds]);
    
    const handleAssetChange = (e: React.ChangeEvent<HTMLSelectElement>) => { handleFieldChange({ assetId: e.target.value }); };
    const handleZoneChange = (e: React.ChangeEvent<HTMLSelectElement>) => { handleFieldChange({ zoneId: e.target.value }); };

    const renderFeedbackTab = () => {
        const woLogs = data.laborLogs.filter(l => l.workOrderId === workOrderId);
        return (
            <Card title="Feedback & Labor">
                <div className="space-y-4">
                    <div className="flex justify-between items-center">
                        <h4 className="font-semibold">Labor Logs</h4>
                        {!isLockedByStatus && (
                            <Button size="sm" onClick={() => { setLaborLogToEdit(null); setIsLaborLogModalOpen(true); }}>Add Labor</Button>
                        )}
                    </div>
                    {woLogs.length > 0 ? (
                        <Table<LaborLog>
                            columns={[
                                { header: 'User', accessor: (l) => data.users.find(u => u.id === l.userId)?.name || l.userId },
                                { header: 'Start', accessor: (l) => new Date(l.startTime).toLocaleString() },
                                { header: 'End', accessor: (l) => new Date(l.endTime).toLocaleString() },
                                { header: 'Duration (Hrs)', accessor: (l) => ((new Date(l.endTime).getTime() - new Date(l.startTime).getTime()) / 3600000).toFixed(2) },
                                { header: 'Notes', accessor: 'notes' }
                            ]}
                            data={woLogs}
                            renderRowActions={(log) => !isLockedByStatus && (
                                <div className="flex space-x-2">
                                    <Button size="sm" variant="secondary" onClick={() => { setLaborLogToEdit(log); setIsLaborLogModalOpen(true); }}>Edit</Button>
                                    <Button size="sm" variant="danger" onClick={() => setLaborLogToDelete(log)}>Delete</Button>
                                </div>
                            )}
                        />
                    ) : <p className="text-sm text-gray-500">No labor logged.</p>}
                </div>
            </Card>
        );
    };

    const renderRcaTab = () => (
        <Card title="Root Cause Analysis">
            <div className="space-y-4">
                <p className="text-sm text-gray-500">Required for Breakdown Work Orders before closing.</p>
                <div className="grid grid-cols-1 gap-4">
                    <div>
                        <label className="block text-sm font-medium">Component Affected</label>
                        <select name="componentAffectedId" value={editableWO.rca?.componentAffectedId || ''} onChange={handleRcaSelectChange} className="border p-2 w-full rounded" disabled={isFieldLocked}>
                            <option value="">Select component...</option>
                            {data.bomItems.filter(b => b.assetId === editableWO.assetId).map(b => (
                                <option key={b.id} value={b.id}>{data.parts.find(p => p.id === b.partId)?.name || b.id}</option>
                            ))}
                        </select>
                        <input type="text" name="componentAffectedCustom" value={editableWO.rca?.componentAffectedCustom || ''} onChange={handleRcaChange} placeholder="Or type component name..." className="border p-2 w-full rounded mt-2" disabled={isFieldLocked} />
                    </div>
                    <Input label="Problem Statement" name="problemStatement" value={editableWO.rca?.problemStatement || ''} onChange={handleRcaChange} disabled={isFieldLocked} />
                    <Input label="Immediate Action" name="immediateActionTaken" value={editableWO.rca?.immediateActionTaken || ''} onChange={handleRcaChange} disabled={isFieldLocked} />
                    <div>
                        <label className="block text-sm font-medium">5-Why Analysis</label>
                        <textarea name="fiveWhyAnalysis" value={editableWO.rca?.fiveWhyAnalysis || ''} onChange={handleRcaChange} rows={3} className="w-full border p-2 rounded" disabled={isFieldLocked} />
                    </div>
                    <Input label="Root Cause" name="rootCauses" value={editableWO.rca?.rootCauses || ''} onChange={handleRcaChange} disabled={isFieldLocked} />
                    <Input label="Corrective Action" name="correctiveActions" value={editableWO.rca?.correctiveActions || ''} onChange={handleRcaChange} disabled={isFieldLocked} />
                    <Input label="Verification Plan" name="verificationPlan" value={editableWO.rca?.verificationPlan || ''} onChange={handleRcaChange} disabled={isFieldLocked} />
                </div>
            </div>
        </Card>
    );

    const renderTabContent = () => {
        switch (activeTab) {
          case 'Resource Planning':
            return <ResourcePlanningTab
                editableWO={editableWO}
                handleFieldChange={handleFieldChange}
                isLocked={isFieldLocked}
                currentUser={currentUser}
                setIsProcedureModalOpen={setIsProcedureModalOpen}
                setIsPartModalOpen={setIsPartModalOpen}
                handleRemoveProcedure={handleRemoveProcedure}
                handleRemovePart={handleRemovePart}
                linkedProcedures={linkedProcedures}
            />;
          case 'Feedback': return renderFeedbackTab();
          case 'Costs': return renderCostsTab();
          case 'Root Cause Analysis': return renderRcaTab();
          default: return null;
        }
    };

    const tabs: Tab[] = ['Resource Planning', 'Feedback', 'Costs'];
    if (originalWO.workOrderType === WorkOrderType.Breakdown) tabs.push('Root Cause Analysis');

    return (
        <>
            <div className="space-y-6 print:hidden">
                <div className="flex justify-between items-center flex-wrap gap-4">
                    <Button onClick={onBack} variant="secondary">Back</Button>
                    <div className="flex space-x-2">
                        {currentUser?.role === 'Planner' && !isLockedByStatus && (
                            <Button variant="secondary" onClick={() => setIsInitialPRFormOpen(true)}>Create Manual PR</Button>
                        )}
                        <Button variant="secondary" onClick={handlePrint}>Print</Button>
                        {!isLockedByStatus && !isRestrictedUser && (
                            <Button variant="danger" onClick={handleConfirmDelete} disabled={isDeleteDisabled} title={deleteButtonTitle}>Delete</Button>
                        )}
                        {originalWO.status === WorkOrderStatus.Completed && !isRestrictedUser && !isClerk && (
                            <Button variant="secondary" onClick={handleArchiveClick}>Archive</Button>
                        )}
                        {!isLockedByStatus && (
                             <Button variant="primary" onClick={handleCompleteWorkOrder} disabled={isCompleteDisabled}>Complete</Button>
                        )}
                        <Button onClick={handleSaveChanges} disabled={isSaveDisabled}>Save</Button>
                    </div>
                </div>

                <Card>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                        <div className="space-y-4">
                            <h4 className="font-semibold text-lg border-b pb-2">Identification</h4>
                            <div><strong className="block text-gray-500 dark:text-gray-400">Asset</strong>{(!editableWO.assetId && !isFieldLocked) ? <select value={editableWO.assetId || ''} onChange={handleAssetChange} className="border p-1 rounded w-full dark:bg-gray-700 dark:border-gray-600"><option value="">Select...</option>{availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select> : asset?.name || 'N/A'}</div>
                            <div><strong className="block text-gray-500 dark:text-gray-400">Zone</strong>{(!editableWO.assetId && !isFieldLocked) ? <select value={editableWO.zoneId || ''} onChange={handleZoneChange} className="border p-1 rounded w-full dark:bg-gray-700 dark:border-gray-600"><option value="">Select...</option>{availableZones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}</select> : zone?.name || 'N/A'}</div>
                            <div><strong className="block text-gray-500 dark:text-gray-400">WO Type</strong><Badge color={editableWO.workOrderType === WorkOrderType.Breakdown ? 'red' : 'blue'}>{editableWO.workOrderType}</Badge></div>
                            <div><strong className="block text-gray-500 dark:text-gray-400">Priority</strong><Badge color={editableWO.priority === Priority.Critical ? 'red' : 'blue'}>{editableWO.priority}</Badge></div>
                            <div><strong className="block text-gray-500 dark:text-gray-400">Status</strong><Badge color={statusColors[editableWO.status]}>{editableWO.status}</Badge></div>
                        </div>
                        <div className="space-y-4">
                            <h4 className="font-semibold text-lg border-b pb-2">Schedule & Planning</h4>
                            <div><strong className="block text-gray-500 dark:text-gray-400">Created Date</strong>{editableWO.createdDate}</div>
                            <div><strong className="block text-gray-500 dark:text-gray-400">Due Date</strong>{editableWO.dueDate}</div>
                            <div><strong className="block text-gray-500 dark:text-gray-400">Planning Group</strong>{plannerGroup?.name || 'N/A'}</div>
                            {editableWO.pmPlanId && <div><strong className="block text-gray-500 dark:text-gray-400">PM Plan</strong>{editableWO.pmPlanId}</div>}
                            {editableWO.workRequestId && <div><strong className="block text-gray-500 dark:text-gray-400">Origin WR</strong>{editableWO.workRequestId}</div>}
                        </div>
                        <div className="md:col-span-2 space-y-4">
                             <h4 className="font-semibold text-lg border-b pb-2">Work Order Details</h4>
                             <textarea value={editableWO.description} onChange={e => handleFieldChange({description: e.target.value})} className="w-full border p-2 rounded dark:bg-gray-700 dark:border-gray-600" disabled={isFieldLocked} rows={3} />
                             
                             {asset && (
                                <div className="mt-4 p-4 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg">
                                    <div className="flex justify-between items-center mb-2">
                                        <h5 className="font-semibold text-indigo-700 dark:text-indigo-300">AI Assistant</h5>
                                        <Button size="sm" variant="secondary" onClick={handleAiTroubleshoot} disabled={troubleshooting.loading}>
                                            {troubleshooting.loading ? 'Thinking...' : 'Generate Troubleshooting Steps'}
                                        </Button>
                                    </div>
                                    {troubleshooting.content && (
                                        <div className="text-sm bg-white dark:bg-gray-800 p-3 rounded border dark:border-gray-600 max-h-60 overflow-y-auto">
                                            <pre className="whitespace-pre-wrap font-sans">{troubleshooting.content}</pre>
                                        </div>
                                    )}
                                    {troubleshooting.error && (
                                        <p className="text-sm text-red-500">{troubleshooting.error}</p>
                                    )}
                                </div>
                             )}
                        </div>
                    </div>
                </Card>

                <div className="border-b border-gray-200 dark:border-gray-700">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        {tabs.map((tab) => (
                            <button key={tab} onClick={() => setActiveTab(tab)} className={`${activeTab === tab ? 'border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}>{tab}</button>
                        ))}
                    </nav>
                </div>
                <div className="mt-6">{renderTabContent()}</div>
            </div>
            
            <PartSelectorModal isOpen={isPartModalOpen} onClose={() => setIsPartModalOpen(false)} onSave={handleAddParts} />
            <LaborLogForm isOpen={isLaborLogModalOpen} onClose={() => { setIsLaborLogModalOpen(false); setLaborLogToEdit(null); }} onSave={handleSaveLaborLog} workCenterId={editableWO.workCenterId} currentUser={currentUser} logToEdit={laborLogToEdit} />
            <ProcedureSelectorModal isOpen={isProcedureModalOpen} onClose={() => setIsProcedureModalOpen(false)} onSave={handleAddProcedures} alreadyLinkedIds={editableWO.procedureIds} />
            
            <ConfirmationModal isOpen={isArchiveConfirmOpen} onClose={() => setIsArchiveConfirmOpen(false)} onConfirm={handleConfirmArchive} title="Confirm Archive" confirmText="Archive">
                <p>Are you sure you want to archive this work order? It will be moved to historical records.</p>
            </ConfirmationModal>

            <ConfirmationModal isOpen={isDeleteConfirmOpen} onClose={() => setIsDeleteConfirmOpen(false)} onConfirm={handleConfirmDelete} title="Confirm Delete" confirmText="Delete" confirmButtonVariant="danger">
                <p>Are you sure you want to permanently delete this work order? This action cannot be undone.</p>
            </ConfirmationModal>

            {infoModalContent && <Modal isOpen={!!infoModalContent} onClose={() => setInfoModalContent(null)} title={infoModalContent.title} footer={<Button onClick={() => setInfoModalContent(null)}>OK</Button>}>{infoModalContent.content}</Modal>}
            
            <InitialMPRForm isOpen={isInitialPRFormOpen} onClose={() => setIsInitialPRFormOpen(false)} onProceed={handleInitialProceed} />
            {manualPRData && <ManualPRForm isOpen={!!manualPRData} onClose={() => setManualPRData(null)} onSave={handleSaveManualPR} pr={manualPRData} />}
            
            {laborLogToDelete && <ConfirmationModal isOpen={!!laborLogToDelete} onClose={() => setLaborLogToDelete(null)} onConfirm={handleConfirmDeleteLog} title="Delete Labor Log" confirmText="Delete" confirmButtonVariant="danger"><p>Delete this labor entry?</p></ConfirmationModal>}

            {isPrintPreviewOpen && (
                <Modal isOpen={isPrintPreviewOpen} onClose={() => setIsPrintPreviewOpen(false)} title={`Print Preview: ${workOrderId}`} size="5xl" footer={<div className="flex justify-between w-full"><Button variant="secondary" onClick={() => setIsPrintPreviewOpen(false)}>Cancel</Button><Button variant="primary" onClick={handleConfirmPrint}>Confirm Print</Button></div>}>
                    <div className="bg-gray-100 dark:bg-gray-900 p-4 overflow-auto flex justify-center max-h-[70vh]">
                        <div className="transform scale-100 origin-top w-full max-w-[8.5in]">
                            <PrintableWorkOrderDocument wo={editableWO} asset={asset} plant={plant} zone={zone} plannerGroup={plannerGroup} linkedProcedures={linkedProcedures} data={data} />
                        </div>
                    </div>
                </Modal>
            )}
            <div className="hidden print:block">
                <PrintableWorkOrderDocument wo={editableWO} asset={asset} plant={plant} zone={zone} plannerGroup={plannerGroup} linkedProcedures={linkedProcedures} data={data} />
            </div>
        </>
    );
};
