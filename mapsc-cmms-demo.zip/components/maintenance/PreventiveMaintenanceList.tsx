import React, { useContext, useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { PreventiveMaintenance, WorkOrder, PMFrequency, User, AuditLogEntry } from '../../types';
import { WorkOrderType, WorkOrderStatus, Priority, AssetStatus } from '../../types';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { useSettings } from '../../contexts/SettingsContext';
import { Badge } from '../ui/Badge';

const PMDetailModal: React.FC<{ pm: PreventiveMaintenance | null, assetName: string, procNames: string[], createdBy: string, onClose: () => void }> = ({ pm, assetName, procNames, createdBy, onClose }) => {
    if (!pm) return null;
    return (
        <Modal isOpen={true} onClose={onClose} title={`Details for ${pm.name}`}>
            <div className="space-y-2 text-sm">
                <div><strong className="block text-gray-500">Asset</strong> {assetName}</div>
                <div>
                    <strong className="block text-gray-500">Procedures</strong>
                    <ul className="list-disc pl-5">
                        {procNames.length > 0 ? procNames.map((name, index) => (
                            <li key={index}>{name}</li>
                        )) : <li>No procedures linked</li>}
                    </ul>
                </div>
                <div><strong className="block text-gray-500">Duration</strong> {pm.duration} Hours</div>
                <div><strong className="block text-gray-500">Trigger Type</strong> {pm.triggerType}</div>
                {pm.triggerType === 'Calendar' ? (
                    <>
                        <div><strong className="block text-gray-500">Frequency</strong> {pm.frequency}</div>
                        <div><strong className="block text-gray-500">Next Due Date</strong> {pm.nextDueDate}</div>
                    </>
                ) : (
                    <>
                         <div><strong className="block text-gray-500">Meter</strong> {pm.meterId}</div>
                         <div><strong className="block text-gray-500">Trigger Interval</strong> Every {pm.meterTriggerValue}</div>
                         <div><strong className="block text-gray-500">Last Triggered At</strong> {pm.lastTriggerReading || 'N/A'}</div>
                    </>
                )}
                <div><strong className="block text-gray-500">Status</strong> {pm.isActive === false ? 'Paused' : 'Active'}</div>
                <div><strong className="block text-gray-500">Created By</strong> {createdBy}</div>
                <div><strong className="block text-gray-500">Date Created</strong> {pm.createdDate}</div>
            </div>
        </Modal>
    );
};

const PMForm: React.FC<{ 
    isOpen: boolean, 
    onClose: () => void, 
    onSave: (pm: PreventiveMaintenance) => void, 
    pmToEdit: PreventiveMaintenance | null,
    currentUser: User | null
}> = ({ isOpen, onClose, onSave, pmToEdit, currentUser }) => {
    const context = useContext(DataContext);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    const availableAssets = useMemo(() => {
        if (!context) return [];
        return context.data.assets.filter(a => 
            (canSeeAllZones || accessibleZoneIds.includes(a.zoneId)) &&
            a.status === AssetStatus.Operational
        );
    }, [context, accessibleZoneIds, canSeeAllZones]);

    const allProcedures = useMemo(() => {
        if (!context) return [];
        const { safetyInstructions, workInstructions, sops } = context.data;
        return [...safetyInstructions, ...workInstructions, ...sops];
    }, [context?.data]);
    
    const getInitialState = useCallback((): Omit<PreventiveMaintenance, 'id'> => ({
        name: '', 
        assetId: '', // Forces manual selection
        procedureIds: [], // Forces manual selection
        duration: 0,
        createdDate: new Date().toISOString().split('T')[0],
        createdBy: currentUser?.id || '',
        triggerType: 'Calendar',
        frequency: undefined, // Forces manual selection
        nextDueDate: '',
        meterId: '',
        meterTriggerValue: 0,
        lastTriggerReading: 0,
        isActive: true,
    }), [currentUser]);

    const [formData, setFormData] = useState(getInitialState());

    useEffect(() => {
        if(isOpen) {
            if (pmToEdit) {
                setFormData(pmToEdit);
            } else {
                setFormData(getInitialState());
            }
        }
    }, [isOpen, pmToEdit, getInitialState]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        let processedValue: string | number | 'Calendar' | 'Meter' | PMFrequency | boolean | undefined = value;
        if (type === 'number') {
            processedValue = Number(value);
        }
        if (value === '') {
             processedValue = undefined;
        }
        setFormData(prev => ({...prev, [name]: processedValue}));
    };
    
    const handleProcedureToggle = (procedureId: string) => {
        setFormData(prev => {
            const currentIds = prev.procedureIds || [];
            let newIds: string[];
            if (currentIds.includes(procedureId)) {
                newIds = currentIds.filter(id => id !== procedureId);
            } else {
                newIds = [...currentIds, procedureId];
            }

            let newDuration = prev.duration;

            if (context) {
                const { workInstructions } = context.data;
                
                const calculateWiDuration = (ids: string[]) => {
                    return ids.reduce((sum, id) => {
                        const wi = workInstructions.find(w => w.id === id);
                        return sum + (wi?.totalDuration || 0);
                    }, 0);
                };

                const currentWiDuration = calculateWiDuration(currentIds);
                const newWiDuration = calculateWiDuration(newIds);

                // If the duration contribution from Work Instructions has changed, update total duration.
                // This implies a Work Instruction was selected or deselected.
                if (currentWiDuration !== newWiDuration) {
                    newDuration = newWiDuration;
                }
            }

            return { ...prev, procedureIds: newIds, duration: newDuration };
        });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.assetId) {
            alert('Please select an asset.');
            return;
        }
        if (!formData.procedureIds || formData.procedureIds.length === 0) {
            alert('Please select at least one procedure.');
            return;
        }
        if (formData.triggerType === 'Calendar' && !formData.frequency) {
            alert('Please select a frequency.');
            return;
        }
        onSave(formData as PreventiveMaintenance);
    };
    
    if (!context) return null;
    const createdByUser = context.data.users.find(u => u.id === formData.createdBy)?.name || formData.createdBy;
    const assetMeters = context.data.meters.filter(m => m.assetId === formData.assetId);


    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="pm-form">{pmToEdit ? "Save Changes" : "Save"}</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={pmToEdit ? "Edit PM Schedule" : "Add New PM Schedule"} footer={modalFooter}>
            <form id="pm-form" onSubmit={handleSubmit} className="space-y-4">
                <Input id="name" label="PM Name" name="name" value={formData.name} onChange={handleChange} required maxLength={106} />
                <Input label="Duration (Hrs)" name="duration" type="number" step="0.01" min="0" value={formData.duration} onChange={handleChange} required />
                <div>
                  <label htmlFor="assetId" className="block text-sm font-medium">Asset</label>
                  <select name="assetId" value={formData.assetId} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" required>
                      <option value="" disabled>Select Asset...</option>
                      {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                  </select>
                </div>
                
                <div>
                    <label className="block text-sm font-medium mb-2">Procedures</label>
                    <div className="border border-gray-300 dark:border-gray-600 rounded-md p-2 h-40 overflow-y-auto bg-white dark:bg-gray-700">
                        {allProcedures.map(p => (
                            <div key={p.id} className="flex items-start mb-2">
                                <input 
                                    type="checkbox" 
                                    id={`proc-${p.id}`} 
                                    checked={formData.procedureIds?.includes(p.id)} 
                                    onChange={() => handleProcedureToggle(p.id)}
                                    className="mt-1 h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                />
                                <label htmlFor={`proc-${p.id}`} className="ml-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer select-none">
                                    <span className="font-semibold">{p.id}</span> - {p.description}
                                </label>
                            </div>
                        ))}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Select one or more procedures.</p>
                </div>
                
                <div className="border-t pt-4">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Trigger Type</label>
                    <div className="flex items-center space-x-4 mt-2">
                        <label className="flex items-center">
                            <input type="radio" name="triggerType" value="Calendar" checked={formData.triggerType === 'Calendar'} onChange={handleChange} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300" />
                            <span className="ml-2 text-sm">Calendar</span>
                        </label>
                        <label className="flex items-center">
                            <input type="radio" name="triggerType" value="Meter" checked={formData.triggerType === 'Meter'} onChange={handleChange} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300" />
                            <span className="ml-2 text-sm">Meter</span>
                        </label>
                    </div>
                </div>

                {formData.triggerType === 'Calendar' && (
                    <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                        <div>
                            <label htmlFor="frequency" className="block text-sm font-medium">Frequency</label>
                            <select name="frequency" value={formData.frequency || ''} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                <option value="" disabled>Select Frequency...</option>
                                <option value="Weekly">Weekly</option>
                                <option value="Bi-Weekly">Bi-Weekly</option>
                                <option value="Monthly">Monthly</option>
                                <option value="3-Monthly">3-Monthly</option>
                                <option value="6-Monthly">6-Monthly</option>
                                <option value="Annually">Annually</option>
                            </select>
                        </div>
                        <Input label="Next Due Date" name="nextDueDate" type="date" value={formData.nextDueDate || ''} onChange={handleChange} required />
                    </div>
                )}
                
                {formData.triggerType === 'Meter' && (
                    <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                        <div>
                            <label htmlFor="meterId" className="block text-sm font-medium">Meter</label>
                            <select name="meterId" value={formData.meterId || ''} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" disabled={assetMeters.length === 0}>
                                <option value="">Select a meter...</option>
                                {assetMeters.map(m => <option key={m.id} value={m.id}>{m.name} ({m.unitOfMeasure})</option>)}
                            </select>
                            {assetMeters.length === 0 && <p className="text-xs text-red-500 mt-1">No meters found for the selected asset.</p>}
                        </div>
                        <Input label="Trigger Interval" name="meterTriggerValue" type="number" min="1" value={formData.meterTriggerValue || ''} onChange={handleChange} required />
                        <Input label="Last Triggered Reading" name="lastTriggerReading" type="number" min="0" value={formData.lastTriggerReading || '0'} onChange={handleChange} helperText="The meter reading when the last PM was done. Set to 0 for the first time."/>
                    </div>
                )}

                {pmToEdit && (
                    <div className="grid grid-cols-2 gap-4 border-t pt-4 mt-4">
                        <Input label="Created By" value={createdByUser} disabled />
                        <Input label="Date Created" type="date" value={formData.createdDate} disabled />
                    </div>
                )}
            </form>
        </Modal>
    );
};

export const PreventiveMaintenanceList: React.FC<{ currentUser: User | null }> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [selectedPM, setSelectedPM] = useState<PreventiveMaintenance | null>(null);
    const [pmToEdit, setPmToEdit] = useState<PreventiveMaintenance | null>(null);
    const [pmToGenerate, setPmToGenerate] = useState<PreventiveMaintenance | null>(null);
    const [pmToToggle, setPmToToggle] = useState<PreventiveMaintenance | null>(null);
    
    // Deletion state
    const [pmToDelete, setPmToDelete] = useState<PreventiveMaintenance | null>(null);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
    const [filters, setFilters] = useState({
        id: '',
        asset: '',
        triggerType: '',
        dueDate: '',
    });
    const printRef = useRef<HTMLDivElement>(null);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { preventiveMaintenances, assets, safetyInstructions, workInstructions, sops, users, meters, workOrders } = data;

    const allProcedures = useMemo(() => [...safetyInstructions, ...workInstructions, ...sops], [safetyInstructions, workInstructions, sops]);
    
    const getAssetName = useCallback((assetId: string) => assets.find(a => a.id === assetId)?.name || 'N/A', [assets]);
    const getUserName = useCallback((userId: string) => users.find(u => u.id === userId)?.name || 'N/A', [users]);
    const getProcedureNames = useCallback((procIds: string[]) => {
        if (!procIds || procIds.length === 0) return ['N/A'];
        return procIds.map(id => allProcedures.find(p => p.id === id)?.description || id);
    }, [allProcedures]);
    
    const isPmDue = useCallback((pm: PreventiveMaintenance): boolean => {
        if (pm.triggerType === 'Calendar' && pm.nextDueDate) {
            const today = new Date();
            today.setUTCHours(0, 0, 0, 0);
            const dueDate = new Date(pm.nextDueDate);
            return dueDate <= today;
        } else if (pm.triggerType === 'Meter' && pm.meterId && pm.meterTriggerValue) {
            const meter = meters.find(m => m.id === pm.meterId);
            if (meter) {
                const lastTrigger = pm.lastTriggerReading || 0;
                const nextTriggerPoint = lastTrigger + pm.meterTriggerValue;
                return meter.lastReading >= nextTriggerPoint;
            }
        }
        return false;
    }, [meters]);

    const hasOpenWoForPm = useCallback((pmId: string): boolean => {
        return workOrders.some(wo => 
            wo.pmPlanId === pmId && 
            (wo.status === WorkOrderStatus.Open || wo.status === WorkOrderStatus.InProgress)
        );
    }, [workOrders]);
    
    const handleOpenForm = (pm: PreventiveMaintenance | null) => {
        setPmToEdit(pm);
        setIsFormOpen(true);
    };

    const handleCloseForm = () => {
        setPmToEdit(null);
        setIsFormOpen(false);
    };

    const handleSave = (pm: PreventiveMaintenance) => {
        setData(prev => {
            const isEditing = prev.preventiveMaintenances.some(p => p.id === pm.id);
            let savedPM: PreventiveMaintenance;
            let newPMsArray: PreventiveMaintenance[];
            const logAction: 'CREATE' | 'UPDATE' = isEditing ? 'UPDATE' : 'CREATE';
            
            if (isEditing) {
                savedPM = pm;
                newPMsArray = prev.preventiveMaintenances.map(p => p.id === pm.id ? pm : p);
            } else {
                savedPM = { ...pm, id: `PM-${String(prev.preventiveMaintenances.length + 1).padStart(3, '0')}`, isActive: true };
                newPMsArray = [...prev.preventiveMaintenances, savedPM];
            }

            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: logAction,
                entityType: 'PreventiveMaintenance',
                entityId: savedPM.id,
                details: `${logAction === 'CREATE' ? 'Created' : 'Updated'} PM schedule '${savedPM.name}' (${savedPM.id}).`,
                status: 'Success'
            };

            return { 
                ...prev, 
                preventiveMaintenances: newPMsArray,
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        handleCloseForm();
    };
    
    const handleOpenDelete = (pm: PreventiveMaintenance) => {
        // Check for history
        const hasHistory = workOrders.some(wo => wo.pmPlanId === pm.id);
        if (hasHistory) {
            alert("Cannot delete this PM Plan because Work Orders have already been generated from it.");
            return;
        }
        setPmToDelete(pm);
        setIsDeleteModalOpen(true);
    };

    const handleDelete = () => {
        if (!pmToDelete) return;

        setData(prevData => {
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'DELETE',
                entityType: 'PreventiveMaintenance',
                entityId: pmToDelete.id,
                details: `Deleted PM schedule '${pmToDelete.name}' (${pmToDelete.id}).`,
                status: 'Success'
            };

            return {
                ...prevData,
                preventiveMaintenances: prevData.preventiveMaintenances.filter(pm => pm.id !== pmToDelete.id),
                auditLog: [logEntry, ...prevData.auditLog]
            };
        });
        setIsDeleteModalOpen(false);
        setPmToDelete(null);
    };

    const calculateNextDueDate = (currentDueDate: string, frequency: PMFrequency): string => {
        const date = new Date(currentDueDate);
        date.setUTCHours(12, 0, 0, 0);

        switch(frequency) {
            case 'Weekly':
                date.setDate(date.getDate() + 7);
                break;
            case 'Bi-Weekly':
                date.setDate(date.getDate() + 14);
                break;
            case 'Monthly':
                date.setMonth(date.getMonth() + 1);
                break;
            case '3-Monthly':
                date.setMonth(date.getMonth() + 3);
                break;
            case '6-Monthly':
                date.setMonth(date.getMonth() + 6);
                break;
            case 'Annually':
                date.setFullYear(date.getFullYear() + 1);
                break;
        }
        return date.toISOString().split('T')[0];
    };

    const generateWorkOrderFromPM = (pm: PreventiveMaintenance, currentWOCount: number, currentUser: User | null): { wo: WorkOrder | null, log: AuditLogEntry | null, reason?: string } => {
        // 1. Check if PM is Manually Paused
        if (pm.isActive === false) {
            return { wo: null, log: null, reason: "PM Plan is Paused" };
        }

        const asset = data.assets.find(a => a.id === pm.assetId);
        
        // 2. Check Asset Status
        if (!asset || asset.status !== AssetStatus.Operational) {
            return { wo: null, log: null, reason: `Asset is ${asset ? asset.status : 'Missing'}` };
        }

        // 3. Check Meter Status (if applicable)
        if (pm.triggerType === 'Meter') {
            const meter = data.meters.find(m => m.id === pm.meterId);
            if (!meter || meter.isActive === false) {
                return { wo: null, log: null, reason: "Linked Meter is Inactive" };
            }
        }

        let plantCostCodeId: string | undefined = undefined;
        let zoneCostCodeId: string | undefined = undefined;

        if (asset) {
            const plant = data.plants.find(p => p.id === asset.plantId);
            if (plant) {
                plantCostCodeId = data.plantCostCodes.find(pcc => pcc.name === plant.name)?.id;
            }
            const zone = data.zones.find(z => z.id === asset.zoneId);
            if (zone) {
                zoneCostCodeId = data.zoneCostCodes.find(zcc => zcc.name === zone.name)?.id;
            }
        }
        
        const estimatedDuration = pm.duration;

        const newWorkOrder: WorkOrder = {
            id: `WO-${String(currentWOCount + 1).padStart(3, '0')}`,
            description: pm.name,
            assetId: pm.assetId,
            priority: settings.defaultWorkOrderPriorities[WorkOrderType.Preventive] || Priority.Medium,
            status: WorkOrderStatus.Open,
            dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            createdDate: new Date().toISOString().split('T')[0],
            createdBy: currentUser!.id,
            partsUsed: [],
            estimatedDuration,
            laborHours: 0,
            workOrderType: WorkOrderType.Preventive,
            pmPlanId: pm.id,
            assignedUserIds: [],
            procedureIds: pm.procedureIds,
            planningGroupId: asset?.custodianId,
            plantCostCodeId,
            zoneCostCodeId,
        };
        
        const logEntry: AuditLogEntry = {
            id: `LOG-TEMP`,
            timestamp: new Date().toISOString(),
            userId: currentUser!.id,
            action: 'CREATE',
            entityType: 'WorkOrder',
            entityId: newWorkOrder.id,
            details: `Generated WO '${newWorkOrder.description}' from PM schedule ${pm.id}.`,
            status: 'Success'
        };

        return { wo: newWorkOrder, log: logEntry };
    };

    const handleGenerateDueWorkOrders = () => {
        const today = new Date();
        today.setUTCHours(0, 0, 0, 0);

        const duePMs = data.preventiveMaintenances.filter(pm => pm.triggerType === 'Calendar' && pm.nextDueDate && new Date(pm.nextDueDate) <= today);

        if (duePMs.length === 0) {
            alert('No calendar-based PMs are currently due for work order generation.');
            return;
        }

        let newWorkOrders = [...data.workOrders];
        const newLogs: AuditLogEntry[] = [];
        let skippedCount = 0;

        const updatedPMs = data.preventiveMaintenances.map(pm => {
            if (duePMs.some(duePM => duePM.id === pm.id)) {
                const { wo, log } = generateWorkOrderFromPM(pm, newWorkOrders.length, currentUser);
                
                if (wo && log) {
                    newWorkOrders.push(wo);
                    newLogs.push(log);
                    
                    let newDueDate = pm.nextDueDate!;
                    while (new Date(newDueDate) <= today) {
                        newDueDate = calculateNextDueDate(newDueDate, pm.frequency!);
                    }
                    return { ...pm, nextDueDate: newDueDate };
                } else {
                    skippedCount++;
                    // Logic to skip this generation cycle or keep it due? 
                    // Usually, if paused/blocked, we DON'T advance the due date so it generates immediately when unblocked.
                    // So we return pm unchanged.
                    return pm;
                }
            }
            return pm;
        });

        setData(prevData => ({
            ...prevData,
            workOrders: newWorkOrders,
            preventiveMaintenances: updatedPMs,
            auditLog: [...newLogs.map((l, i) => ({...l, id: `LOG-${String(prevData.auditLog.length + i + 1).padStart(3, '0')}`})), ...prevData.auditLog]
        }));
        
        const generatedCount = newLogs.length;
        let msg = `${generatedCount} work order(s) generated.`;
        if (skippedCount > 0) {
            msg += ` ${skippedCount} PMs were skipped due to being paused or asset/meter status.`;
        }
        alert(msg);
    };

    const handleManualGenerateWorkOrder = () => {
        if (!pmToGenerate) return;
        const pm = data.preventiveMaintenances.find(p => p.id === pmToGenerate.id);
        if (!pm) return;
        
        const { wo: newWO, log: logEntry, reason } = generateWorkOrderFromPM(pm, data.workOrders.length, currentUser);
        
        if (!newWO || !logEntry) {
            alert(`Cannot generate Work Order: ${reason}`);
            setPmToGenerate(null);
            return;
        }
        
        let updatedPM: PreventiveMaintenance = { ...pm };
        if (pm.triggerType === 'Calendar' && pm.nextDueDate && pm.frequency) {
             updatedPM.nextDueDate = calculateNextDueDate(pm.nextDueDate, pm.frequency);
        } else if (pm.triggerType === 'Meter' && pm.meterId && pm.meterTriggerValue) {
            const meter = meters.find(m => m.id === pm.meterId);
            if (meter) {
                 updatedPM.lastTriggerReading = meter.lastReading;
            }
        }

        setData(prevData => ({
            ...prevData,
            workOrders: [...prevData.workOrders, newWO],
            preventiveMaintenances: prevData.preventiveMaintenances.map(p =>
                p.id === pm.id ? updatedPM : p
            ),
            auditLog: [{...logEntry, id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`}, ...prevData.auditLog]
        }));
        alert(`Work Order ${newWO.id} has been generated.`);
        setPmToGenerate(null);
    };
    
    const handleToggleStatus = () => {
        if (!pmToToggle) return;
        
        setData(prevData => {
             const newStatus = !(pmToToggle.isActive ?? true);
             const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'UPDATE',
                entityType: 'PreventiveMaintenance',
                entityId: pmToToggle.id,
                details: `${newStatus ? 'Resumed' : 'Paused'} PM schedule '${pmToToggle.name}' (${pmToToggle.id}).`,
                status: 'Success'
            };
            return {
                ...prevData,
                preventiveMaintenances: prevData.preventiveMaintenances.map(p => 
                    p.id === pmToToggle.id ? { ...p, isActive: newStatus } : p
                ),
                auditLog: [logEntry, ...prevData.auditLog]
            }
        });
        setPmToToggle(null);
    };
    
    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({ id: '', asset: '', triggerType: '', dueDate: '' });
    };

    const handlePrint = () => {
        if (printRef.current) {
            const printContent = printRef.current.innerHTML;
            const printWindow = window.open('', '', 'height=800,width=1000');
            if (printWindow) {
                printWindow.document.write('<html><head><title>Preventive Maintenance Schedule</title>');
                printWindow.document.write(`
                    <style>
                        body { font-family: sans-serif; margin: 2rem; }
                        table { width: 100%; border-collapse: collapse; font-size: 12px; }
                        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        tr:nth-child(even) { background-color: #f9f9f9; }
                        tfoot { font-weight: bold; }
                        h1 { font-size: 24px; margin-bottom: 1rem; }
                        .no-print { display: none; }
                        /* Badge styles for printing */
                        span { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                        span[class*="bg-green-100"] { background-color: #D1FAE5 !important; color: #065F46 !important; }
                        span[class*="bg-yellow-100"] { background-color: #FEF3C7 !important; color: #92400E !important; }
                        span[class*="bg-red-100"] { background-color: #FEE2E2 !important; color: #991B1B !important; }
                        span[class*="bg-gray-100"] { background-color: #F3F4F6 !important; color: #1F2937 !important; }
                    </style>
                `);
                printWindow.document.write('</head><body>');
                printWindow.document.write('<h1>Preventive Maintenance Schedule</h1>');
                printWindow.document.write(printContent);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 500);
            }
        }
    };

    const filteredPMs = useMemo(() => {
        return preventiveMaintenances.filter(pm => {
            const asset = assets.find(a => a.id === pm.assetId);
            if (!asset) return false;
            
            const zoneAccessMatch = canSeeAllZones || accessibleZoneIds.includes(asset.zoneId);
            if (!zoneAccessMatch) return false;
            
            const idMatch = filters.id ? pm.id.toLowerCase().includes(filters.id.toLowerCase()) : true;
            
            const assetName = getAssetName(pm.assetId);
            const assetMatch = filters.asset
                ? assetName.toLowerCase().includes(filters.asset.toLowerCase()) || pm.assetId.toLowerCase().includes(filters.asset.toLowerCase())
                : true;

            const triggerMatch = filters.triggerType ? pm.triggerType === filters.triggerType : true;

            const dateMatch = filters.dueDate
                ? pm.triggerType === 'Calendar' && pm.nextDueDate && new Date(pm.nextDueDate) <= new Date(filters.dueDate)
                : true;

            return idMatch && assetMatch && triggerMatch && dateMatch;
        });
    }, [preventiveMaintenances, filters, getAssetName, assets, accessibleZoneIds, canSeeAllZones]);

    const totalDuration = useMemo(() => {
        return filteredPMs.reduce((sum, pm) => sum + pm.duration, 0);
    }, [filteredPMs]);

    const columns = [
        { header: 'PM ID', accessor: 'id' as keyof PreventiveMaintenance },
        { header: 'PM Name', accessor: 'name' as keyof PreventiveMaintenance },
        { header: 'Asset', accessor: (item: PreventiveMaintenance) => getAssetName(item.assetId) },
        { header: 'Trigger Type', accessor: 'triggerType' as keyof PreventiveMaintenance },
        { header: 'Duration (Hrs)', accessor: 'duration' as keyof PreventiveMaintenance },
        {
            header: 'Status',
            accessor: (item: PreventiveMaintenance) => {
                // Determine effective status
                const asset = assets.find(a => a.id === item.assetId);
                const meter = meters.find(m => m.id === item.meterId);
                
                if (item.isActive === false) return <Badge color="gray">Paused (Manual)</Badge>;
                if (asset?.status !== AssetStatus.Operational) return <Badge color="red">Blocked (Asset)</Badge>;
                if (item.triggerType === 'Meter' && meter?.isActive === false) return <Badge color="red">Blocked (Meter)</Badge>;
                
                return <Badge color="green">Active</Badge>;
            }
        },
        {
            header: 'Next Due',
            accessor: (item: PreventiveMaintenance) => {
                if (item.triggerType === 'Meter') {
                    const meter = meters.find(m => m.id === item.meterId);
                    const nextTrigger = (item.lastTriggerReading || 0) + (item.meterTriggerValue || 0);
                    return `At ${nextTrigger} ${meter?.unitOfMeasure || ''}`;
                }
                return item.nextDueDate || 'N/A';
            }
        },
    ];

    const tableFooter = (
        <tr>
            <td colSpan={4} className="px-6 py-3 text-right text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                Total Duration
            </td>
            <td className="px-6 py-3 text-left text-sm font-bold text-gray-900 dark:text-white">
                {totalDuration.toFixed(2)} Hrs
            </td>
            <td colSpan={3}></td> {/* For Status, Next Due and Actions columns */}
        </tr>
    );

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    const canDeletePM = currentUser?.role === 'Administrator';

    return (
        <>
            <Card
                title="Preventive Maintenance Scheduling"
                actions={
                    <div className="flex space-x-2">
                         <Button variant="secondary" onClick={handlePrint}>Print List</Button>
                        {currentUser?.role === 'Planner' && (
                            <>
                                <Button variant="secondary" onClick={handleGenerateDueWorkOrders}>Generate Due WOs</Button>
                                <Button onClick={() => handleOpenForm(null)}>New PM Schedule</Button>
                            </>
                        )}
                    </div>
                }
            >
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                        <label htmlFor="id-filter" className={filterLabelClasses}>PM ID</label>
                        <input type="text" id="id-filter" name="id" value={filters.id} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search ID..."/>
                    </div>
                     <div>
                        <label htmlFor="asset-filter" className={filterLabelClasses}>Asset</label>
                        <input type="text" id="asset-filter" name="asset" value={filters.asset} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search asset name or ID..."/>
                    </div>
                    <div>
                        <label htmlFor="triggerType-filter" className={filterLabelClasses}>Trigger Type</label>
                        <select id="triggerType-filter" name="triggerType" value={filters.triggerType} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Types</option>
                            <option value="Calendar">Calendar</option>
                            <option value="Meter">Meter</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="dueDate-filter" className={filterLabelClasses}>Due On Or Before</label>
                        <input type="date" id="dueDate-filter" name="dueDate" value={filters.dueDate} onChange={handleFilterChange} className={filterInputClasses} />
                    </div>
                    <div className="flex items-end">
                        <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                    </div>
                </div>

                <div ref={printRef}>
                    <Table<PreventiveMaintenance>
                        columns={columns}
                        data={filteredPMs}
                        footer={tableFooter}
                        renderRowActions={(pm) => {
                            const isDue = isPmDue(pm);
                            const hasOpenWO = hasOpenWoForPm(pm.id);
                            
                            // Check blockers
                            const asset = assets.find(a => a.id === pm.assetId);
                            const isAssetDown = asset?.status !== AssetStatus.Operational;
                            const linkedMeter = meters.find(m => m.id === pm.meterId);
                            const isMeterInactive = pm.triggerType === 'Meter' && linkedMeter?.isActive === false;
                            const isPaused = pm.isActive === false;

                            const isBlocked = isPaused || isAssetDown || isMeterInactive;
                            const isDisabled = !isDue || hasOpenWO || isBlocked;
                            
                            let buttonTitle = "Generate Work Order";
                            if (isPaused) buttonTitle = "PM Plan is paused.";
                            else if (isAssetDown) buttonTitle = "Asset is not operational.";
                            else if (isMeterInactive) buttonTitle = "Linked meter is inactive.";
                            else if (hasOpenWO) buttonTitle = "An open Work Order already exists for this PM.";
                            else if (!isDue) buttonTitle = "This PM is not yet due.";
                            
                            return (
                                <div className="flex space-x-2 justify-end">
                                    <Button variant="secondary" size="sm" onClick={() => setSelectedPM(pm)}>
                                        Details
                                    </Button>
                                    {currentUser?.role === 'Planner' && (
                                        <>
                                            <Button variant="secondary" size="sm" onClick={() => handleOpenForm(pm)}>
                                                Edit
                                            </Button>
                                             <Button 
                                                variant={pm.isActive === false ? "primary" : "secondary"} 
                                                size="sm" 
                                                onClick={() => setPmToToggle(pm)}
                                                title={pm.isActive === false ? "Resume PM generation" : "Pause PM generation"}
                                            >
                                                {pm.isActive === false ? "Resume" : "Pause"}
                                            </Button>
                                            <Button
                                                variant="secondary"
                                                size="sm"
                                                onClick={() => setPmToGenerate(pm)}
                                                disabled={isDisabled}
                                                title={buttonTitle}
                                            >
                                                Generate WO
                                            </Button>
                                        </>
                                    )}
                                    {canDeletePM && (
                                        <Button variant="danger" size="sm" onClick={() => handleOpenDelete(pm)}>Delete</Button>
                                    )}
                                </div>
                            );
                        }}
                    />
                </div>
            </Card>
            <PMForm isOpen={isFormOpen} onClose={handleCloseForm} onSave={handleSave} pmToEdit={pmToEdit} currentUser={currentUser} />
            <PMDetailModal 
                pm={selectedPM} 
                onClose={() => setSelectedPM(null)}
                assetName={getAssetName(selectedPM?.assetId || '')}
                procNames={getProcedureNames(selectedPM?.procedureIds || [])}
                createdBy={getUserName(selectedPM?.createdBy || '')}
            />
            {pmToGenerate && (
                <ConfirmationModal
                    isOpen={!!pmToGenerate}
                    onClose={() => setPmToGenerate(null)}
                    onConfirm={handleManualGenerateWorkOrder}
                    title="Confirm Work Order Generation"
                    confirmText="Generate"
                >
                    <p>Are you sure you want to generate a work order for <span className="font-bold">{pmToGenerate.name}</span>?</p>
                    <p className="mt-2 text-sm text-gray-500">This action will also advance the next due date or meter reading for this PM schedule.</p>
                </ConfirmationModal>
            )}
            {pmToToggle && (
                <ConfirmationModal
                    isOpen={!!pmToToggle}
                    onClose={() => setPmToToggle(null)}
                    onConfirm={handleToggleStatus}
                    title={`Confirm ${pmToToggle.isActive === false ? 'Resume' : 'Pause'}`}
                    confirmText={pmToToggle.isActive === false ? "Resume" : "Pause"}
                    confirmButtonVariant={pmToToggle.isActive === false ? "primary" : "secondary"}
                >
                    <p>Are you sure you want to {pmToToggle.isActive === false ? 'resume' : 'pause'} the PM schedule <span className="font-bold">{pmToToggle.name}</span>?</p>
                    <p className="text-sm text-gray-500 mt-2">
                        {pmToToggle.isActive === false 
                            ? "Work Orders will be generated when due." 
                            : "Work Orders will NOT be generated even if due."}
                    </p>
                </ConfirmationModal>
            )}
            
            {isDeleteModalOpen && pmToDelete && (
                <ConfirmationModal
                    isOpen={isDeleteModalOpen}
                    onClose={() => setIsDeleteModalOpen(false)}
                    onConfirm={handleDelete}
                    title="Confirm PM Deletion"
                    confirmText="Delete"
                    confirmButtonVariant="danger"
                >
                    <p>Are you sure you want to delete the PM schedule <span className="font-bold">{pmToDelete.name}</span>?</p>
                    <p className="mt-2 text-sm text-gray-500">This action cannot be undone.</p>
                </ConfirmationModal>
            )}
        </>
    );
};
