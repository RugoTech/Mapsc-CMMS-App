
import React, { useContext, useMemo } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { useSettings } from '../../contexts/SettingsContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { WorkOrderStatus, type User } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

// Define the shape of the data for each row in our table.
type LaborDataRow = {
    id: string; // user id
    name: string;
    workCenter: string;
    assignedWOCount: number;
    totalHoursAssigned: number;
};

// A self-contained component for rendering the workload bar.
// It now accepts capacity as a prop to be dynamic.
const UtilizationBar: React.FC<{ hours: number; capacity: number }> = ({ hours, capacity }) => {
    const utilization = capacity > 0 ? (hours / capacity) * 100 : 0;
    // Cap the visual bar at 100% to prevent it from overflowing its container.
    const displayPercentage = Math.min(utilization, 100);
    
    // Determine bar color based on utilization percentage.
    let barColor = 'bg-green-500';
    if (utilization > 100) {
        barColor = 'bg-red-500';
    } else if (utilization > 80) {
        barColor = 'bg-yellow-500';
    }

    return (
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-5 relative">
            <div
                className={`${barColor} h-5 rounded-full transition-all duration-500`}
                style={{ width: `${displayPercentage}%` }}
            />
            <span className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-white dark:text-gray-100 mix-blend-difference dark:mix-blend-normal">
                {hours.toFixed(1)} hrs ({utilization.toFixed(0)}%)
            </span>
        </div>
    );
};

interface LaborAllocationProps {
    currentUser: User | null;
}

export const LaborAllocation: React.FC<LaborAllocationProps> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const WEEKLY_CAPACITY = settings.workWeekHours;
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    // This calculation is memoized and will only re-run when the underlying data changes,
    // ensuring the view is always up-to-date and performant.
    const laborData: LaborDataRow[] = useMemo(() => {
        if (!context || !currentUser) return [];

        const { workOrders, users, workCenters, zones, plannerGroups, maintenanceControllers } = context.data;
        
        let visibleWorkCenters = workCenters;

        if (!canSeeAllZones) {
            // Hierarchy Check: Planner Group -> Maintenance Controller -> Work Center
            const userPlannerGroup = plannerGroups.find(pg => pg.userIds.includes(currentUser.id));

            if (userPlannerGroup) {
                // 1. Find Controller Groups linked to this Planner Group
                const linkedControllerGroups = maintenanceControllers.filter(cg => cg.plannerGroupId === userPlannerGroup.id);
                const linkedControllerGroupIds = new Set(linkedControllerGroups.map(cg => cg.id));

                // 2. Find Work Centers linked to these Controller Groups
                visibleWorkCenters = workCenters.filter(wc => linkedControllerGroupIds.has(wc.controllerGroupId));
            } else {
                // Fallback for non-planner roles (e.g. Zone-based Managers/Engineers)
                const zoneNameMap: Record<string, string> = {
                    'packaging': 'pkg',
                    'utilities': 'utls',
                };

                const accessibleKeywords = accessibleZoneIds
                    .map(zoneId => zones.find(z => z.id === zoneId)?.name.toLowerCase())
                    .filter((name): name is string => !!name)
                    .map(name => zoneNameMap[name])
                    .filter((keyword): keyword is string => !!keyword);

                if (accessibleKeywords.length > 0) {
                    visibleWorkCenters = workCenters.filter(wc => {
                        const wcNameLower = wc.name.toLowerCase();
                        return accessibleKeywords.some(keyword => wcNameLower.includes(keyword));
                    });
                } else {
                    // If a user has access to this view but no assigned zones with keywords or planner group, show them nothing.
                    visibleWorkCenters = [];
                }
            }
        }
        
        // Get a set of all technician IDs the planner can see for efficient lookup
        const technicianIds = new Set(visibleWorkCenters.flatMap(wc => wc.userIds));

        // Filter for only active work orders.
        const activeWorkOrders = workOrders.filter(wo =>
            wo.status === WorkOrderStatus.Open || wo.status === WorkOrderStatus.InProgress
        );

        // Use reduce to create the workload map for visible technicians.
        const workloadByUserId = activeWorkOrders.reduce((acc, wo) => {
            if (wo.assignedUserIds && wo.assignedUserIds.length > 0) {
                // Requirement: Each personnel gets the FULL duration, not divided.
                const hoursPerPerson = wo.estimatedDuration;
                
                wo.assignedUserIds.forEach(userId => {
                    if (technicianIds.has(userId)) {
                        const currentLoad = acc.get(userId) || { assignedWOCount: 0, totalHoursAssigned: 0 };
                        acc.set(userId, {
                            assignedWOCount: currentLoad.assignedWOCount + 1,
                            totalHoursAssigned: currentLoad.totalHoursAssigned + hoursPerPerson
                        });
                    }
                });
            }
            return acc;
        }, new Map<string, { assignedWOCount: number; totalHoursAssigned: number }>());

        // Now, build the final rows, ensuring all visible technicians are included.
        const rows: LaborDataRow[] = [];
        technicianIds.forEach(userId => {
            const user = users.find(u => u.id === userId);
            if (user) {
                const workload = workloadByUserId.get(userId) || { assignedWOCount: 0, totalHoursAssigned: 0 };
                rows.push({
                    id: user.id,
                    name: user.name,
                    workCenter: user.workCenter,
                    ...workload
                });
            }
        });

        // Sort by total hours assigned in descending order.
        return rows.sort((a, b) => b.totalHoursAssigned - a.totalHoursAssigned);

    }, [context, currentUser, accessibleZoneIds, canSeeAllZones]);

    if (!context) {
        return <Card title="Labor Allocation & Capacity Planning"><div>Loading...</div></Card>;
    }
    
    // Define the columns for the table.
    const columns = [
        { header: 'Personnel', accessor: 'name' as keyof LaborDataRow },
        { header: 'Work Center', accessor: 'workCenter' as keyof LaborDataRow },
        { header: '# of WOs', accessor: 'assignedWOCount' as keyof LaborDataRow },
        { 
            header: `Workload (vs ${WEEKLY_CAPACITY}hr Capacity)`, 
            accessor: (item: LaborDataRow) => <UtilizationBar hours={item.totalHoursAssigned} capacity={WEEKLY_CAPACITY} />
        },
    ];

    return (
        <Card title="Labor Allocation & Capacity Planning">
            <div className="mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg text-sm text-gray-600 dark:text-gray-300">
                This table shows the current workload for all technicians based on the estimated duration of their assigned work orders. Capacity is based on a {WEEKLY_CAPACITY}-hour work week.
            </div>
            <Table<LaborDataRow>
                columns={columns}
                data={laborData}
            />
        </Card>
    );
};
