
import React, { useState, useEffect, useContext } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import type { Settings, User, AuditLogEntry } from '../../types';
import { Priority } from '../../types';
import { useSettings } from '../../contexts/SettingsContext';
import { currencies } from '../../data/currencies';
import { DataContext } from '../../contexts/DataContext';

interface SystemSettingsProps {
    onBack: () => void;
    currentUser: User | null;
}

export const SystemSettings: React.FC<SystemSettingsProps> = ({ onBack, currentUser }) => {
    const { settings: globalSettings, setSettings: setGlobalSettings } = useSettings();
    const context = useContext(DataContext);
    const [settings, setSettings] = useState<Settings | null>(null);
    const [isDirty, setIsDirty] = useState(false);

    useEffect(() => {
        setSettings(JSON.parse(JSON.stringify(globalSettings)));
        setIsDirty(false);
    }, [globalSettings]);

    if (!settings) {
        return <div>Loading settings...</div>;
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        // @ts-ignore - 'checked' is a valid property for checkboxes
        const checked = e.target.checked;
        const keys = name.split('.');
        
        setIsDirty(true);

        const processedValue = type === 'checkbox' ? checked : (type === 'number' ? Number(value) : value);

        if (keys.length > 1) {
            setSettings(prev => {
                if (!prev) return null;
                // Deep copy to avoid mutation issues
                const newSettings = JSON.parse(JSON.stringify(prev));
                let currentLevel: any = newSettings;
                for (let i = 0; i < keys.length - 1; i++) {
                    currentLevel = currentLevel[keys[i]];
                }
                currentLevel[keys[keys.length - 1]] = processedValue;
                return newSettings;
            });
        } else {
            setSettings(prev => (prev ? { ...prev, [name]: processedValue } : null));
        }
    };

    const handleSave = () => {
        if (settings) {
            setGlobalSettings(settings);
            
            // Add Audit Log
            if (context && currentUser) {
                context.setData(prev => {
                    const logEntry: AuditLogEntry = {
                        id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                        timestamp: new Date().toISOString(),
                        userId: currentUser.id,
                        action: 'UPDATE',
                        entityType: 'SystemSettings',
                        entityId: 'Global',
                        details: 'Updated system settings.',
                        status: 'Success'
                    };
                    return { ...prev, auditLog: [logEntry, ...prev.auditLog] };
                });
            }
            
            setIsDirty(false);
            alert('Settings saved successfully!');
        }
    };
    
    const selectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md";

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <Button onClick={onBack} variant="secondary" leftIcon={<svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>}>
                    Back to Admin
                </Button>
                <Button onClick={handleSave} disabled={!isDirty}>
                    {isDirty ? 'Save Changes' : 'Saved'}
                </Button>
            </div>
            
            <Card title="General Settings">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label htmlFor="currency" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Default Currency</label>
                        <select id="currency" name="currency" value={settings.currency} onChange={handleChange} className={selectClasses}>
                            {currencies.map(c => <option key={c.code} value={c.code}>{c.name} ({c.code})</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="dateFormat" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Date Format</label>
                        <select id="dateFormat" name="dateFormat" value={settings.dateFormat} onChange={handleChange} className={selectClasses}>
                            <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                            <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                            <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                        </select>
                    </div>
                </div>

                <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200 mb-4">Work Week Configuration</h4>
                    <div>
                        <label htmlFor="workWeekHours" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Standard Work Week</label>
                        <select id="workWeekHours" name="workWeekHours" value={settings.workWeekHours} onChange={handleChange} className={selectClasses}>
                            <option value="40">40 Hours</option>
                            <option value="48">48 Hours</option>
                        </select>
                        <p className="mt-2 text-sm text-gray-500">This setting is used for capacity planning and utilization reports.</p>
                    </div>
                </div>

                <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200 mb-4">Exchange Rates</h4>
                     <p className="text-sm text-gray-500 mb-4">Set the value of 1 unit of your default currency against USD and EUR. This is used for converting foreign currency purchase orders.</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Input 
                            id="exchange-rate-usd" 
                            name="exchangeRate.USD" 
                            label={`1 ${settings.currency} to USD`} 
                            type="number" 
                            step="0.0001" 
                            value={settings.exchangeRate.USD} 
                            onChange={handleChange} 
                        />
                         <Input 
                            id="exchange-rate-eur" 
                            name="exchangeRate.EUR" 
                            label={`1 ${settings.currency} to EUR`} 
                            type="number" 
                            step="0.0001" 
                            value={settings.exchangeRate.EUR} 
                            onChange={handleChange} 
                        />
                    </div>
                </div>
                <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200 mb-2">System Lock for Inventory Count</h4>
                    <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div>
                            <label htmlFor="inventoryLocked" className="font-medium text-gray-800 dark:text-gray-200">Lock Inventory Transactions</label>
                            <p className="text-sm text-gray-500">Prevents inventory transactions and adding parts to WOs during a physical count.</p>
                        </div>
                        <input
                            type="checkbox"
                            id="inventoryLocked"
                            name="inventoryLocked"
                            checked={settings.inventoryLocked}
                            onChange={handleChange}
                            className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                    </div>
                </div>
            </Card>

            <Card title="Maintenance Settings">
                <div className="space-y-6">
                    <div>
                        <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200 mb-4">Default Work Order Priorities</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="wo-preventive-priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Preventive</label>
                                <select id="wo-preventive-priority" name="defaultWorkOrderPriorities.Preventive" value={settings.defaultWorkOrderPriorities.Preventive} onChange={handleChange} className={selectClasses}>
                                    {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="wo-corrective-priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Corrective</label>
                                <select id="wo-corrective-priority" name="defaultWorkOrderPriorities.Corrective" value={settings.defaultWorkOrderPriorities.Corrective} onChange={handleChange} className={selectClasses}>
                                    {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="wo-breakdown-priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Breakdown</label>
                                <select id="wo-breakdown-priority" name="defaultWorkOrderPriorities.Breakdown" value={settings.defaultWorkOrderPriorities.Breakdown} onChange={handleChange} className={selectClasses}>
                                    {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="wo-project-priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Project</label>
                                <select id="wo-project-priority" name="defaultWorkOrderPriorities.Project" value={settings.defaultWorkOrderPriorities.Project} onChange={handleChange} className={selectClasses}>
                                    {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
                        <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200 mb-4">Default Work Request Priority</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="defaultWorkRequestPriority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Default Priority</label>
                                <select id="defaultWorkRequestPriority" name="defaultWorkRequestPriority" value={settings.defaultWorkRequestPriority} onChange={handleChange} className={selectClasses}>
                                    {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
                        <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200 mb-2">Other</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                           <Input id="laborRatePerHour" name="laborRatePerHour" label={`Labor Rate per Hour (in ${settings.currency})`} type="number" min="0" value={settings.laborRatePerHour} onChange={handleChange} />
                        </div>
                    </div>
                </div>
            </Card>

            <Card title="Inventory Settings">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Input id="defaultPaymentTerms" name="defaultPaymentTerms" label="Default PO Payment Terms" value={settings.defaultPaymentTerms} onChange={handleChange} />
                    <Input 
                        id="highValuePOThreshold" 
                        name="highValuePOThreshold" 
                        label={`High-Value PO Approval Threshold (in ${settings.currency})`} 
                        type="number" 
                        min="0"
                        value={settings.highValuePOThreshold} 
                        onChange={handleChange} 
                        helperText={`POs exceeding this total value (in ${settings.currency}) will require second-level approval.`}
                    />
                </div>
                 <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-semibold text-gray-800 dark:text-gray-200 mb-2">Inventory Notifications</h4>
                    <p className="text-sm text-gray-500 mb-4">Configure email notifications for key inventory events.</p>
                    <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                            <label htmlFor="notif-stock" className="font-medium text-gray-800 dark:text-gray-200">Low Stock Alert Triggered</label>
                            <input
                                type="checkbox"
                                id="notif-stock"
                                name="notifications.lowStockAlert"
                                checked={settings.notifications.lowStockAlert}
                                onChange={handleChange}
                                className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                            <label htmlFor="notif-pr" className="font-medium text-gray-800 dark:text-gray-200">PRs notifications (approvals, rejections, etc.)</label>
                            <input
                                type="checkbox"
                                id="notif-pr"
                                name="notifications.purchaseRequisition"
                                checked={settings.notifications.purchaseRequisition}
                                onChange={handleChange}
                                className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                            <label htmlFor="notif-rfq" className="font-medium text-gray-800 dark:text-gray-200">RFQs notifications (approvals, rejections, etc.)</label>
                            <input
                                type="checkbox"
                                id="notif-rfq"
                                name="notifications.requestForQuotation"
                                checked={settings.notifications.requestForQuotation}
                                onChange={handleChange}
                                className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                            <label htmlFor="notif-po" className="font-medium text-gray-800 dark:text-gray-200">POs notifications (approvals, rejections, etc.)</label>
                            <input
                                type="checkbox"
                                id="notif-po"
                                name="notifications.purchaseOrder"
                                checked={settings.notifications.purchaseOrder}
                                onChange={handleChange}
                                className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />
                        </div>
                    </div>
                </div>
            </Card>
            
            <Card title="Maintenance Notifications">
                <p className="text-sm text-gray-500 mb-4">Configure email notifications for key events. (UI only for demo)</p>
                <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <label htmlFor="notif-wr" className="font-medium text-gray-800 dark:text-gray-200">New Work Request Submitted</label>
                        <input
                            type="checkbox"
                            id="notif-wr"
                            name="notifications.newWorkRequest"
                            checked={settings.notifications.newWorkRequest}
                            onChange={handleChange}
                            className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <label htmlFor="notif-pm" className="font-medium text-gray-800 dark:text-gray-200">PM Schedule is Due</label>
                        <input
                            type="checkbox"
                            id="notif-pm"
                            name="notifications.pmDue"
                            checked={settings.notifications.pmDue}
                            onChange={handleChange}
                            className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                    </div>
                </div>
            </Card>
        </div>
    );
};
