import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { AuditLogEntry } from '../../types';

interface AuditTrailProps {
    onBack: () => void;
}

const statusColors: Record<AuditLogEntry['status'], 'green' | 'red'> = {
    Success: 'green',
    Failure: 'red',
};

export const AuditTrail: React.FC<AuditTrailProps> = ({ onBack }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        userId: '',
        dateFrom: '',
        dateTo: '',
        search: '',
    });

    if (!context) return <div>Loading...</div>;
    
    const { auditLog, users } = context.data;

    const getUserName = (userId: string) => users.find(u => u.id === userId)?.name || userId;

    const filteredLogs = useMemo(() => {
        return auditLog.filter(log => {
            const userMatch = filters.userId ? log.userId === filters.userId : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            if (from) from.setHours(0, 0, 0, 0);
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            if (to) to.setHours(23, 59, 59, 999);

            const logDate = new Date(log.timestamp);
            const dateMatch = (!from || logDate >= from) && (!to || logDate <= to);

            const searchMatch = filters.search
                ? log.entityId.toLowerCase().includes(filters.search.toLowerCase()) ||
                  log.details.toLowerCase().includes(filters.search.toLowerCase())
                : true;

            return userMatch && dateMatch && searchMatch;
        });
    }, [auditLog, filters]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFilters(prev => ({...prev, [e.target.name]: e.target.value }));
    };

    const clearFilters = () => {
        setFilters({ userId: '', dateFrom: '', dateTo: '', search: '' });
    };

    const columns = [
        {
            header: 'Timestamp',
            accessor: (item: AuditLogEntry) => new Date(item.timestamp).toLocaleString(),
        },
        {
            header: 'User',
            accessor: (item: AuditLogEntry) => getUserName(item.userId),
        },
        {
            header: 'Action',
            accessor: 'action' as keyof AuditLogEntry,
        },
        {
            header: 'Entity',
            accessor: (item: AuditLogEntry) => `${item.entityType} (${item.entityId})`,
        },
        {
            header: 'Details',
            accessor: 'details' as keyof AuditLogEntry,
        },
        {
            header: 'Status',
            accessor: (item: AuditLogEntry) => <Badge color={statusColors[item.status]}>{item.status}</Badge>,
        },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="System Audit Trail" actions={<Button variant="secondary" onClick={onBack}>Back to Admin</Button>}>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="userId" className={filterLabelClasses}>User</label>
                    <select id="userId" name="userId" value={filters.userId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Users</option>
                        {users.map(user => <option key={user.id} value={user.id}>{user.name}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="dateFrom" className={filterLabelClasses}>From</label>
                    <input type="date" id="dateFrom" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses} />
                </div>
                <div>
                    <label htmlFor="dateTo" className={filterLabelClasses}>To</label>
                    <input type="date" id="dateTo" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses} />
                </div>
                <div>
                    <label htmlFor="search" className={filterLabelClasses}>Search Details/ID</label>
                    <input type="text" id="search" name="search" value={filters.search} onChange={handleFilterChange} className={filterInputClasses} placeholder="e.g., WO-005 or 'status'" />
                </div>
                <div className="flex items-end">
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            <Table<AuditLogEntry>
                columns={columns}
                data={filteredLogs}
            />
        </Card>
    );
};
