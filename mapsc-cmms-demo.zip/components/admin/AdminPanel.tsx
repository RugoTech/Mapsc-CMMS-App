
import React, { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import type { View, User } from '../../types';
import { DataExportModal } from './DataExportModal';
import { DataImportModal } from './DataImportModal';

interface AdminPanelProps {
  onNavigate: (view: View) => void;
  currentUser: User | null;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onNavigate, currentUser }) => {
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  return (
    <>
      <div className="space-y-6">
        <Card title="User Management">
          <p className="text-gray-500 dark:text-gray-400 mb-4">Manage users, roles, and permissions.</p>
          <div className="flex space-x-2">
            <Button onClick={() => onNavigate('Personnel Management')}>Manage Users</Button>
            <Button variant="secondary" onClick={() => onNavigate('User Rights & Permissions')}>User Roles & Rights</Button>
          </div>
        </Card>
        <Card title="Audit Trails">
          <p className="text-gray-500 dark:text-gray-400 mb-4">Track changes made to records, including procedure and project revisions.</p>
          <Button variant="secondary" onClick={() => onNavigate('Audit Trails')}>View Audit Log</Button>
        </Card>
        <Card title="System Settings">
          <p className="text-gray-500 dark:text-gray-400 mb-4">Configure system-wide settings and preferences.</p>
          <Button onClick={() => onNavigate('System Settings')}>Go to Settings</Button>
        </Card>
        <Card title="Data Import/Export">
          <p className="text-gray-500 dark:text-gray-400 mb-4">Bulk import or export system data.</p>
          <div className="flex space-x-2">
            <Button variant="secondary" onClick={() => setIsImportModalOpen(true)}>Import Data</Button>
            <Button variant="secondary" onClick={() => setIsExportModalOpen(true)}>Export Data</Button>
          </div>
        </Card>
      </div>
      <DataExportModal isOpen={isExportModalOpen} onClose={() => setIsExportModalOpen(false)} />
      <DataImportModal isOpen={isImportModalOpen} onClose={() => setIsImportModalOpen(false)} currentUser={currentUser} />
    </>
  );
};
