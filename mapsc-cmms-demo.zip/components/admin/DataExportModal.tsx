
import React, { useContext } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { useSettings } from '../../contexts/SettingsContext';
import type { MockData } from '../../types';

const escapeCSV = (field: any): string => {
    if (field === null || field === undefined) {
        return '';
    }
    const str = String(field);
    // If the string contains a comma, a double quote, or a newline, enclose it in double quotes.
    if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
        // Escape existing double quotes by doubling them up.
        const escapedStr = str.replace(/"/g, '""');
        return `"${escapedStr}"`;
    }
    return str;
};

const downloadCSV = (data: any[], filename: string) => {
    if (!data || data.length === 0) {
        alert(`No data available to export for ${filename}.`);
        return;
    }

    // Collect all unique keys from all objects to ensure comprehensive headers
    // even if the first row is missing optional fields.
    const allKeys = new Set<string>();
    data.forEach(row => {
        if (row && typeof row === 'object') {
            Object.keys(row).forEach(k => allKeys.add(k));
        }
    });
    
    // Sort keys or prioritize specific ones like 'id' if desired, but default order is usually fine
    const header = Array.from(allKeys);

    const csvRows = data.map(row => 
        header.map(fieldName => {
            const value = row[fieldName];
            if (Array.isArray(value) || (typeof value === 'object' && value !== null)) {
                return escapeCSV(JSON.stringify(value));
            }
            return escapeCSV(value);
        }).join(',')
    );
    
    const csv = [header.join(','), ...csvRows].join('\r\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
};

const formatDateForExport = (dateStr: string, format: string): string => {
    if (!dateStr || typeof dateStr !== 'string') return dateStr || '';
    
    // Check if it's potentially a date (starts with YYYY-MM-DD)
    if (!/^\d{4}-\d{2}-\d{2}/.test(dateStr)) return dateStr;

    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return dateStr;

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    let formattedDate = '';
    switch (format) {
        case 'DD/MM/YYYY':
            formattedDate = `${day}/${month}/${year}`;
            break;
        case 'MM/DD/YYYY':
            formattedDate = `${month}/${day}/${year}`;
            break;
        case 'YYYY-MM-DD':
        default:
            formattedDate = `${year}-${month}-${day}`;
            break;
    }

    // Preserve time if present
    if (dateStr.includes('T') || dateStr.includes(':')) {
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        return `${formattedDate} ${hours}:${minutes}:${seconds}`;
    }

    return formattedDate;
};


const ExportItem: React.FC<{ title: string; description: string; onExport: () => void }> = ({ title, description, onExport }) => (
    <div className="p-3 border dark:border-gray-700 rounded-lg flex justify-between items-center bg-gray-50 dark:bg-gray-700/50">
        <div>
            <h4 className="font-semibold">{title}</h4>
            <p className="text-xs text-gray-500 dark:text-gray-400">{description}</p>
        </div>
        <Button variant="secondary" size="sm" onClick={onExport}>Export to CSV</Button>
    </div>
);

interface DataExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DataExportModal: React.FC<DataExportModalProps> = ({ isOpen, onClose }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    
    if (!context) return null;

    const { data } = context;

    const exportableData: {
        title: string;
        description: string;
        key: keyof MockData;
    }[] = [
        // Asset Management
        { title: 'Asset Register', description: 'All assets in the system.', key: 'assets' },
        { title: 'Bill of Materials (BOM)', description: 'Asset component structures.', key: 'bomItems' },
        { title: 'Asset Meters', description: 'All configured asset meters.', key: 'meters' },
        { title: 'Meter Readings', description: 'Historical meter reading logs.', key: 'meterReadings' },
        { title: 'Asset Documentation', description: 'List of all linked documents.', key: 'documents' },
        
        // Maintenance
        { title: 'Work Orders', description: 'All maintenance work orders (Open & History).', key: 'workOrders' },
        { title: 'Work Requests', description: 'Submitted work requests.', key: 'workRequests' },
        { title: 'Labor Logs', description: 'Technician labor entries.', key: 'laborLogs' },
        { title: 'PM Schedules', description: 'All preventive maintenance plans.', key: 'preventiveMaintenances' },
        { title: 'Projects', description: 'Maintenance projects.', key: 'projects' },
        { title: 'Safety Instructions', description: 'All safety instruction procedures.', key: 'safetyInstructions' },
        { title: 'Work Instructions', description: 'All work instruction procedures.', key: 'workInstructions' },
        { title: 'SOPs', description: 'All standard operating procedures.', key: 'sops' },

        // Inventory & Procurement
        { title: 'Parts Catalog', description: 'Full list of inventory parts.', key: 'parts' },
        { title: 'Inventory Transactions', description: 'Stock movement logs.', key: 'inventoryTransactions' },
        { title: 'Purchase Requisitions', description: 'PRs (Manual & System).', key: 'purchaseRequisitions' },
        { title: 'RFQs', description: 'Requests for Quotation.', key: 'rfqs' },
        { title: 'Purchase Orders', description: 'Purchase Orders.', key: 'purchaseOrders' },
        { title: 'Invoices', description: 'Vendor Invoices.', key: 'invoices' },
        { title: 'Vendors', description: 'List of all approved vendors.', key: 'vendors' },
        { title: 'Cycle Counts', description: 'Physical inventory counts.', key: 'cycleCounts' },

        // Admin & Finance
        { title: 'Personnel', description: 'List of all system users.', key: 'users' },
        { title: 'Cost Centers', description: 'Financial cost centers.', key: 'costCenters' },
        { title: 'Budgets', description: 'Financial budgets.', key: 'budgets' },
        { title: 'Audit Log', description: 'System audit trail.', key: 'auditLog' },

        // Locations
        { title: 'Plants', description: 'List of all plants.', key: 'plants' },
        { title: 'Zones', description: 'List of all zones.', key: 'zones' },
        { title: 'Areas', description: 'List of all areas.', key: 'areas' },
    ];

    const dateKeys = [
        'purchaseDate', 'warrantyExpiryDate', 'createdDate', 'dateCreated', 
        'dueDate', 'requestDate', 'orderDate', 'expectedDeliveryDate', 
        'invoiceDate', 'date', 'startDate', 'endDate', 
        'timestamp', 'startTime', 'endTime', 'scheduledDate', 'lastReadingDate'
    ];

    const handleExport = (key: keyof MockData) => {
        const rawData = data[key];
        if (Array.isArray(rawData)) {
            // Process data to format dates based on settings
            const formattedData = rawData.map(row => {
                const newRow: any = { ...row };
                for (const field in newRow) {
                    if (dateKeys.includes(field)) {
                        newRow[field] = formatDateForExport(newRow[field], settings.dateFormat);
                    }
                }
                return newRow;
            });
            downloadCSV(formattedData, key);
        } else {
            alert('This data type is not exportable.');
        }
    };
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Export Data" size="2xl">
            <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                    Select a data set to download as a CSV file. Dates will be exported in <strong>{settings.dateFormat}</strong> format.
                </p>
                {exportableData.map(item => (
                    <ExportItem
                        key={item.key}
                        title={item.title}
                        description={item.description}
                        onExport={() => handleExport(item.key)}
                    />
                ))}
            </div>
        </Modal>
    );
};
