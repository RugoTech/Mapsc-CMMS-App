
import React, { useState, useContext } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { useSettings } from '../../contexts/SettingsContext';
import type { MockData, User, AuditLogEntry } from '../../types';
import { Alert } from '../ui/Alert';

// Helper to parse a single CSV line handling quotes
const parseCSVLine = (line: string): string[] => {
    const result: string[] = [];
    let currentField = '';
    let inQuotes = false;
    
    for (let j = 0; j < line.length; j++) {
        const char = line[j];
        if (char === '"') {
            if (inQuotes && line[j + 1] === '"') { // Escaped quote
                currentField += '"';
                j++; 
            } else {
                inQuotes = !inQuotes;
            }
        } else if (char === ',' && !inQuotes) {
            result.push(currentField);
            currentField = '';
        } else {
            currentField += char;
        }
    }
    result.push(currentField);
    return result;
};

const parseCSV = (csvText: string): Record<string, string>[] => {
    const lines = csvText.trim().replace(/\r/g, '').split('\n');
    if (lines.length < 2) return [];
    
    // Handle BOM (Byte Order Mark) which Excel often adds
    if (lines[0].charCodeAt(0) === 0xFEFF) {
        lines[0] = lines[0].slice(1);
    }
    
    const headerLine = lines.shift()!;
    const header = parseCSVLine(headerLine).map(h => h.trim());
    
    const result: Record<string, string>[] = [];
    
    for (const line of lines) {
        if (!line.trim()) continue;
        const values = parseCSVLine(line);
        
        if (values.length === header.length) {
            const obj: Record<string, string> = {};
            header.forEach((h, i) => {
                obj[h] = values[i];
            });
            result.push(obj);
        }
    }
    return result;
};


const convertToType = <T,>(obj: Record<string, string>, requiredFields: (keyof T)[], jsonFields: string[] = []): T | null => {
    for (const field of requiredFields) {
        // Check if field exists and is not empty string. (Zero is allowed)
        if (!obj.hasOwnProperty(field as string) || obj[field as string] === undefined || obj[field as string].trim() === '') {
            console.error(`Row skipped. Missing required field: ${String(field)}`, obj);
            return null;
        }
    }

    const typedObj: any = {};
    for (const key in obj) {
        if (!obj.hasOwnProperty(key)) continue;
        let value: any = obj[key];

        if (jsonFields.includes(key)) {
            try {
                // JSON.parse handles arrays/objects. Empty string defaults to empty array.
                // IMPORTANT: If parse fails, we must return null to skip the row, 
                // otherwise the app crashes when it tries to map over a string instead of an array.
                value = (value.trim() === '') ? [] : JSON.parse(value);
            } catch (e) {
                console.error(`Row skipped. JSON Parse error for field '${key}':`, value);
                return null; 
            }
        }
        else if (value.toLowerCase() === 'true') { value = true; } 
        else if (value.toLowerCase() === 'false') { value = false; }
        else if (!isNaN(Number(value)) && value.trim() !== '' && !key.toLowerCase().endsWith('id') && !key.toLowerCase().endsWith('number') && !key.toLowerCase().endsWith('code')) {
            value = Number(value);
        }
        
        typedObj[key] = value;
    }
    return typedObj as T;
};

// Helper to parse date from specific format to YYYY-MM-DD
const parseDateFromImport = (dateStr: string, format: string): string => {
    if (!dateStr || typeof dateStr !== 'string') return dateStr || '';
    
    // If it already looks like YYYY-MM-DD (ISO), just return it.
    if (/^\d{4}-\d{2}-\d{2}/.test(dateStr)) return dateStr;

    let day, month, year;
    const parts = dateStr.split(/[\/\-\.]/); // Split by / - or .

    if (parts.length < 3) return dateStr; // Can't parse

    if (format === 'DD/MM/YYYY') {
        day = parts[0];
        month = parts[1];
        year = parts[2];
    } else if (format === 'MM/DD/YYYY') {
        month = parts[0];
        day = parts[1];
        year = parts[2];
    } else {
        // Assume YYYY-MM-DD or unexpected format, try default
        year = parts[0];
        month = parts[1];
        day = parts[2];
    }
    
    // Basic fix for 2 digit year
    if (year && year.length === 2) year = '20' + year; 
    
    if (!day || !month || !year) return dateStr;

    // Return ISO format YYYY-MM-DD
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
};

const parseDateTimeFromImport = (dateStr: string, format: string): string => {
     if (!dateStr || typeof dateStr !== 'string') return dateStr || '';
     
     // Split date and time (handles "DD/MM/YYYY HH:mm:ss")
     const [dPart, tPart] = dateStr.split(' ');
     const isoDate = parseDateFromImport(dPart, format);
     
     if (tPart) {
         return `${isoDate}T${tPart}`; 
     }
     return isoDate;
};

interface UploadItemProps {
    title: string;
    onUpload: (file: File) => void;
}

const UploadItem: React.FC<UploadItemProps> = ({ title, onUpload }) => {
    const [file, setFile] = useState<File | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const handleUploadClick = () => {
        if (file) {
            onUpload(file);
            setFile(null); // Reset file input after upload attempt
        } else {
            alert('Please select a file first.');
        }
    };

    return (
        <div className="p-3 border dark:border-gray-700 rounded-lg flex justify-between items-center bg-gray-50 dark:bg-gray-700/50">
            <h4 className="font-semibold">{title}</h4>
            <div className="flex items-center space-x-2">
                <input
                    type="file"
                    accept=".csv"
                    onChange={handleFileChange}
                    className="text-sm text-gray-500 file:mr-4 file:py-1 file:px-3 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-900/50 file:text-indigo-700 dark:file:text-indigo-300 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-900"
                />
                <Button variant="secondary" size="sm" onClick={handleUploadClick} disabled={!file}>
                    Upload
                </Button>
            </div>
        </div>
    );
};

export const DataImportModal: React.FC<{ isOpen: boolean; onClose: () => void; currentUser: User | null }> = ({ isOpen, onClose, currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [feedback, setFeedback] = useState<{ type: 'success' | 'error', message: string } | null>(null);

    if (!context) return null;
    const { setData } = context;

    const dateKeys = [
        'purchaseDate', 'warrantyExpiryDate', 'createdDate', 'dateCreated', 
        'dueDate', 'requestDate', 'orderDate', 'expectedDeliveryDate', 
        'invoiceDate', 'date', 'startDate', 'endDate', 'scheduledDate', 'lastReadingDate'
    ];
    const dateTimeKeys = ['timestamp', 'startTime', 'endTime'];

    const handleUpload = (
        file: File, 
        dataType: keyof MockData, 
        requiredFields: any[], 
        idPrefix: string, 
        jsonFields: string[] = [],
        defaults: Record<string, any> = {} 
    ) => {
        setFeedback(null);
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const text = e.target?.result as string;
                const parsedData = parseCSV(text);
                if (parsedData.length === 0) {
                    setFeedback({ type: 'error', message: 'CSV is empty or invalid.' });
                    return;
                }

                let addedCount = 0;
                let failedCount = 0;

                setData(prevData => {
                    const existingData = prevData[dataType] as any[];
                    let lastIdNumber = existingData.length;

                    const newData = parsedData.map(row => {
                        const typedRow = convertToType(row, requiredFields, jsonFields) as Record<string, any> | null;
                        if (!typedRow) {
                            failedCount++;
                            return null;
                        }
                        
                        // Parse Dates based on settings
                        for (const key in typedRow) {
                            if (dateKeys.includes(key)) {
                                typedRow[key] = parseDateFromImport(typedRow[key], settings.dateFormat);
                            }
                            if (dateTimeKeys.includes(key)) {
                                typedRow[key] = parseDateTimeFromImport(typedRow[key], settings.dateFormat);
                            }
                        }

                        const newId = `${idPrefix}-${String(++lastIdNumber).padStart(3, '0')}`;
                        
                        // Apply defaults for any missing fields
                        const finalRow = { ...defaults, ...typedRow, id: newId };
                        
                        addedCount++;
                        return finalRow;
                    }).filter((item): item is NonNullable<typeof item> => item !== null);

                    // Special logic for linking Users to Work Centers upon import
                    let updatedWorkCenters = prevData.workCenters;
                    if (dataType === 'users') {
                        updatedWorkCenters = prevData.workCenters.map(wc => {
                            // Find all new users whose 'workCenter' string matches this group's name (case-insensitive)
                            const matchingNewUsers = newData.filter((u: any) => 
                                u.workCenter && 
                                u.workCenter.trim().toLowerCase() === wc.name.toLowerCase()
                            );
                            
                            if (matchingNewUsers.length > 0) {
                                const newIds = matchingNewUsers.map((u: any) => u.id);
                                // Merge and ensure uniqueness
                                return {
                                    ...wc,
                                    userIds: Array.from(new Set([...wc.userIds, ...newIds]))
                                };
                            }
                            return wc;
                        });
                    }
                    
                    const logEntry: AuditLogEntry = {
                        id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                        timestamp: new Date().toISOString(),
                        userId: currentUser?.id || 'SYSTEM',
                        action: 'IMPORT',
                        entityType: 'System',
                        entityId: dataType,
                        details: `Imported ${addedCount} records into ${dataType}. (${failedCount} failed).`,
                        status: 'Success'
                    };

                    return {
                        ...prevData,
                        [dataType]: [...existingData, ...newData] as any,
                        workCenters: updatedWorkCenters,
                        auditLog: [logEntry, ...prevData.auditLog],
                    };
                });
                
                let message = `${addedCount} '${dataType}' records added successfully.`;
                if (failedCount > 0) {
                    message += ` ${failedCount} records failed validation (missing required fields).`;
                }
                setFeedback({ type: 'success', message });

            } catch (error) {
                console.error("Error processing CSV:", error);
                setFeedback({ type: 'error', message: 'An error occurred while processing the file. Please ensure it is a valid CSV.' });
            }
        };
        reader.readAsText(file);
    };

    // Define defaults for various types
    const assetDefaults = {
        status: 'Operational',
        meterReading: 0,
        cost: 0,
        underWarranty: false,
        createdBy: 'USER-005',
        meterId: ''
    };

    const partDefaults = {
        maxQuantity: 0,
        leadTime: 7,
        isActive: true,
        createdBy: 'USER-005',
        vendorId: '',
        assetId: ''
    };

    const userDefaults = {
        isActive: true,
        profilePictureUrl: '',
    };

    const importableData = [
      { section: 'Asset Management', items: [
        // Enforced requirements to match system Forms
        { title: 'Assets', onUpload: (file: File) => handleUpload(file, 'assets', ['name', 'type', 'plantId', 'zoneId', 'areaId', 'purchaseDate', 'custodianId'], 'ASSET', [], assetDefaults) },
        { title: 'Meters', onUpload: (file: File) => handleUpload(file, 'meters', ['assetId', 'name', 'type', 'unitOfMeasure'], 'MTR', [], { createdBy: 'USER-005', lastReading: 0, isActive: true }) },
        { title: 'Asset Locations', onUpload: () => alert("Please upload Plants, Zones, and Areas individually.") },
        { title: 'Plants', onUpload: (file: File) => handleUpload(file, 'plants', ['name'], 'PLANT') },
        { title: 'Zones', onUpload: (file: File) => handleUpload(file, 'zones', ['name', 'plantId'], 'ZONE') },
        { title: 'Areas', onUpload: (file: File) => handleUpload(file, 'areas', ['name', 'zoneId'], 'AREA') },
      ]},
      { section: 'Maintenance', items: [
        { title: 'PM Plans', onUpload: (file: File) => handleUpload(file, 'preventiveMaintenances', ['name', 'assetId', 'procedureIds', 'triggerType', 'duration', 'frequency'], 'PM', ['procedureIds'], { createdBy: 'USER-005' }) },
      ]},
      { section: 'Inventory & Personnel', items: [
        { title: 'Parts Catalog', onUpload: (file: File) => handleUpload(file, 'parts', ['partNumber', 'name', 'location', 'unitOfMeasure', 'quantity', 'reorderPoint', 'unitCost', 'type'], 'PART', [], partDefaults) },
        { title: 'Vendors', onUpload: (file: File) => handleUpload(file, 'vendors', ['name', 'contactPerson', 'email'], 'VEND') },
        { title: 'Users', onUpload: (file: File) => handleUpload(file, 'users', ['name', 'email', 'role', 'department', 'workCenter'], 'USER', [], userDefaults) },
      ]},
    ];

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Import Data" size="3xl">
            <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
                <Alert type="info" title="Important Notes">
                    - Uploaded data will be **added** to the existing data. It will not replace or update records. <br/>
                    - Dates must match the system format setting: <strong>{settings.dateFormat}</strong>. <br/>
                    - IDs will be automatically generated to prevent conflicts. Any 'id' column in your CSV will be ignored. <br/>
                    - Please ensure your CSV file has a header row that matches the required fields exactly. <br/>
                    - For fields like `procedureIds`, use JSON array format in the CSV cell (e.g., `["WI-01", "SI-01"]`). <br/>
                    - Optional fields (like cost, meter readings) will be set to 0 or defaults if missing.
                </Alert>

                {feedback && (
                    <Alert type={feedback.type} title={feedback.type === 'success' ? 'Upload Complete' : 'Upload Failed'}>
                        {feedback.message}
                    </Alert>
                )}
                
                {importableData.map(section => (
                    <div key={section.section}>
                        <h3 className="font-semibold pt-4 border-t">{section.section}</h3>
                        <div className="mt-2 space-y-2">
                          {section.items.map(item => (
                              <UploadItem key={item.title} title={item.title} onUpload={item.onUpload} />
                          ))}
                        </div>
                    </div>
                ))}
            </div>
        </Modal>
    );
};
