
import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { standaloneRolePermissions, allViews } from '../../auth/permissions';
import type { User, View, AuditLogEntry } from '../../types';

interface UserRightsReportProps {
    onBack: () => void;
}

type UserRightsRow = {
    id: string;
    name: string;
    role: string;
    groups: { name: string, typeKey: string }[];
    permissionCount: number;
    allPermissions: View[];
};

const EditGroupPermissionsModal: React.FC<{
    groupTypeKey: string;
    groupName: string;
    onClose: () => void;
    currentPermissions: View[];
    onSave: (newPermissions: View[]) => void;
}> = ({ groupTypeKey, groupName, onClose, currentPermissions, onSave }) => {
    const [selectedPermissions, setSelectedPermissions] = useState<View[]>(currentPermissions);

    const togglePermission = (view: View) => {
        setSelectedPermissions(prev => 
            prev.includes(view) 
            ? prev.filter(p => p !== view) 
            : [...prev, view]
        );
    };

    const handleSelectAll = () => setSelectedPermissions(allViews);
    const handleDeselectAll = () => setSelectedPermissions([]);

    return (
        <Modal isOpen={true} onClose={onClose} title={`Edit Permissions for Group Type: ${groupTypeKey}`}>
            <div className="space-y-4">
                <p className="text-sm text-gray-500">
                    Modifying these permissions will affect <strong>ALL</strong> users belonging to any <strong>{groupTypeKey}</strong> (e.g., {groupName}).
                </p>
                <div className="flex space-x-2 mb-2">
                    <Button size="sm" variant="secondary" onClick={handleSelectAll}>Select All</Button>
                    <Button size="sm" variant="secondary" onClick={handleDeselectAll}>Deselect All</Button>
                </div>
                <div className="max-h-[60vh] overflow-y-auto border rounded p-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {allViews.map(view => (
                        <label key={view} className="flex items-center space-x-2 p-1 hover:bg-gray-50 dark:hover:bg-gray-700 rounded cursor-pointer">
                            <input 
                                type="checkbox" 
                                checked={selectedPermissions.includes(view)} 
                                onChange={() => togglePermission(view)}
                                className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                            />
                            <span className="text-sm text-gray-700 dark:text-gray-300">{view}</span>
                        </label>
                    ))}
                </div>
                <div className="flex justify-end space-x-2 pt-2">
                    <Button variant="secondary" onClick={onClose}>Cancel</Button>
                    <Button onClick={() => onSave(selectedPermissions)}>Save Permissions</Button>
                </div>
            </div>
        </Modal>
    );
};

export const UserRightsReport: React.FC<UserRightsReportProps> = ({ onBack }) => {
    const context = useContext(DataContext);
    const [selectedUser, setSelectedUser] = useState<UserRightsRow | null>(null);
    const [filter, setFilter] = useState('');
    const [editingGroupKey, setEditingGroupKey] = useState<{ key: string, name: string } | null>(null);

    if (!context) return <div>Loading...</div>;
    const { data, setData } = context;

    const usersWithRights: UserRightsRow[] = useMemo(() => {
        return data.users.map(user => {
            // 1. Determine Groups and their Type Keys for editing
            const userGroups: { name: string, typeKey: string }[] = [];
            
            // Map the internal data key to the permission key in data.groupPermissions
            const groupLists = [
                { list: data.systemAdmins, name: 'System Admin', typeKey: 'SystemAdmins' }, // Admin hardcoded usually, but mapped for display
                { list: data.topManagementGroups, name: 'Top Management', typeKey: 'TopManagementGroup' },
                { list: data.assetManagers, name: 'Asset Manager', typeKey: 'AssetManagers' },
                { list: data.logisticsManagers, name: 'Logistics Manager', typeKey: 'LogisticsManagers' },
                { list: data.engineers, name: 'Engineer Group', typeKey: 'Engineers' },
                { list: data.plannerGroups, name: 'Planner Group', typeKey: 'PlannerGroup' },
                { list: data.logisticsClerks, name: 'Logistics Clerk', typeKey: 'LogisticsClerks' },
                { list: data.maintenanceClerks, name: 'Maintenance Clerk', typeKey: 'MaintenanceClerks' },
                { list: data.maintenanceControllers, name: 'Maint. Controller', typeKey: 'MaintenanceControllers' },
                { list: data.logisticsControllers, name: 'Log. Controller', typeKey: 'LogisticsControllers' },
                { list: data.workCenters, name: 'Work Center', typeKey: 'WorkCenter' },
            ];

            groupLists.forEach(g => {
                const found = g.list.find(grp => grp.userIds.includes(user.id));
                if (found) {
                    userGroups.push({ name: `${g.name} (${found.name})`, typeKey: g.typeKey });
                }
            });

            // 2. Calculate Effective Permissions
            const permissionSet = new Set<View>();

            // Role Permissions
            const rolePerms = standaloneRolePermissions[user.role];
            if (rolePerms) rolePerms.forEach(p => permissionSet.add(p));

            // Group Permissions (Dynamic)
            const dynPerms = data.groupPermissions;
            
            if (data.systemAdmins.some(g => g.userIds.includes(user.id))) { allViews.forEach(p => permissionSet.add(p)); }
            if (data.topManagementGroups.some(g => g.userIds.includes(user.id))) dynPerms.TopManagementGroup?.forEach(p => permissionSet.add(p));
            if (data.assetManagers.some(g => g.userIds.includes(user.id))) dynPerms.AssetManagers?.forEach(p => permissionSet.add(p));
            if (data.logisticsManagers.some(g => g.userIds.includes(user.id))) dynPerms.LogisticsManagers?.forEach(p => permissionSet.add(p));
            if (data.engineers.some(g => g.userIds.includes(user.id))) dynPerms.Engineers?.forEach(p => permissionSet.add(p));
            if (data.plannerGroups.some(g => g.userIds.includes(user.id))) dynPerms.PlannerGroup?.forEach(p => permissionSet.add(p));
            if (data.logisticsClerks.some(g => g.userIds.includes(user.id))) dynPerms.LogisticsClerks?.forEach(p => permissionSet.add(p));
            if (data.maintenanceClerks.some(g => g.userIds.includes(user.id))) dynPerms.MaintenanceClerks?.forEach(p => permissionSet.add(p));
            if (data.maintenanceControllers.some(g => g.userIds.includes(user.id))) dynPerms.MaintenanceControllers?.forEach(p => permissionSet.add(p));
            if (data.logisticsControllers.some(g => g.userIds.includes(user.id))) dynPerms.LogisticsControllers?.forEach(p => permissionSet.add(p));
            if (data.workCenters.some(g => g.userIds.includes(user.id))) dynPerms.WorkCenter?.forEach(p => permissionSet.add(p));

            return {
                id: user.id,
                name: user.name,
                role: user.role,
                groups: userGroups,
                permissionCount: permissionSet.size,
                allPermissions: Array.from(permissionSet).sort()
            };
        });
    }, [data]);

    const filteredUsers = useMemo(() => {
        return usersWithRights.filter(u => 
            u.name.toLowerCase().includes(filter.toLowerCase()) || 
            u.role.toLowerCase().includes(filter.toLowerCase())
        );
    }, [usersWithRights, filter]);

    const handleSaveGroupPermissions = (newPermissions: View[]) => {
        if (!editingGroupKey) return;
        
        setData(prev => {
            const updatedGroupPermissions = { ...prev.groupPermissions, [editingGroupKey.key]: newPermissions };
            
            // Log update
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: 'SYSTEM', // Context currentUser is tricky here if passed from top
                action: 'UPDATE',
                entityType: 'Permissions',
                entityId: editingGroupKey.key,
                details: `Updated permissions for group type: ${editingGroupKey.key}`,
                status: 'Success'
            };

            return {
                ...prev,
                groupPermissions: updatedGroupPermissions,
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        setEditingGroupKey(null);
    };

    const columns = [
        { header: 'Name', accessor: 'name' as keyof UserRightsRow },
        { header: 'Base Role', accessor: 'role' as keyof UserRightsRow },
        { 
            header: 'Group Memberships', 
            accessor: (row: UserRightsRow) => (
                <div className="text-xs text-gray-600 dark:text-gray-400">
                    {row.groups.length > 0 ? (
                        <ul className="list-disc pl-4">
                            {row.groups.map((g, i) => <li key={i}>{g.name}</li>)}
                        </ul>
                    ) : (
                        <span className="italic">No Groups</span>
                    )}
                </div>
            ) 
        },
        { 
            header: 'Access Rights', 
            accessor: (row: UserRightsRow) => <Badge color="blue">{row.permissionCount} Modules</Badge> 
        },
    ];

    return (
        <>
            <Card title="User Rights & Permissions Report" actions={<Button variant="secondary" onClick={onBack}>Back to Admin</Button>}>
                <div className="mb-4">
                    <input 
                        type="text" 
                        placeholder="Search users..." 
                        className="w-full md:w-1/3 px-3 py-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
                        value={filter}
                        onChange={e => setFilter(e.target.value)}
                    />
                </div>
                <Table<UserRightsRow>
                    columns={columns}
                    data={filteredUsers}
                    renderRowActions={(row) => (
                        <Button size="sm" variant="secondary" onClick={() => setSelectedUser(row)}>
                            View Permissions
                        </Button>
                    )}
                />
            </Card>

            {selectedUser && (
                <Modal
                    isOpen={!!selectedUser}
                    onClose={() => setSelectedUser(null)}
                    title={`Permissions for ${selectedUser.name}`}
                    size="lg"
                >
                    <div className="space-y-4">
                        <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg grid grid-cols-2 gap-4 text-sm">
                            <div>
                                <span className="font-semibold text-gray-500 block">Base Role</span>
                                {selectedUser.role}
                            </div>
                            <div>
                                <span className="font-semibold text-gray-500 block mb-1">Group Memberships (Click to Edit Rights)</span>
                                {selectedUser.groups.length > 0 ? (
                                    <div className="flex flex-wrap gap-2">
                                        {selectedUser.groups.map((g, i) => (
                                            <button 
                                                key={i}
                                                onClick={() => {
                                                    if (g.typeKey !== 'SystemAdmins') {
                                                        setEditingGroupKey({ key: g.typeKey, name: g.name });
                                                    } else {
                                                        alert("System Admin permissions cannot be modified.");
                                                    }
                                                }}
                                                className="px-2 py-1 text-xs font-medium rounded-full bg-indigo-100 text-indigo-800 hover:bg-indigo-200 dark:bg-indigo-900 dark:text-indigo-200 dark:hover:bg-indigo-800"
                                                title="Edit permissions for this group type"
                                            >
                                                {g.name} ✎
                                            </button>
                                        ))}
                                    </div>
                                ) : 'None'}
                            </div>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2 border-b pb-1">Accessible Modules & Views</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                                {selectedUser.allPermissions.map(perm => (
                                    <div key={perm} className="flex items-center text-sm">
                                        <svg className="w-4 h-4 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path></svg>
                                        {perm}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                    <div className="mt-6 flex justify-end">
                        <Button variant="secondary" onClick={() => setSelectedUser(null)}>Close</Button>
                    </div>
                </Modal>
            )}

            {editingGroupKey && (
                <EditGroupPermissionsModal
                    groupTypeKey={editingGroupKey.key}
                    groupName={editingGroupKey.name}
                    currentPermissions={data.groupPermissions[editingGroupKey.key] || []}
                    onClose={() => setEditingGroupKey(null)}
                    onSave={handleSaveGroupPermissions}
                />
            )}
        </>
    );
};
