
import React, { useMemo, useContext } from 'react';
import { Card } from '../ui/Card';
import type { View, User } from '../../types';
import { Button } from '../ui/Button';
import { useUserPermissions } from '../../hooks/useUserPermissions';
import { DataContext } from '../../contexts/DataContext';

interface LandingPageProps {
  onNavigate: (view: View) => void;
  onLogout: () => void;
  currentUser: User | null;
}

interface LandingItemProps {
    title: string;
    icon: React.ReactNode;
    onClick: () => void;
}

const LandingItem: React.FC<LandingItemProps> = ({ title, icon, onClick }) => {
    return (
        <div onClick={onClick} className="cursor-pointer group">
            <Card className="hover:bg-indigo-600 hover:text-white dark:hover:bg-indigo-700 transition-all duration-300 transform hover:-translate-y-1">
                <div className="flex flex-col items-center justify-center h-32 text-center p-2">
                    <div className="w-10 h-10 text-indigo-500 group-hover:text-white transition-colors duration-300">
                        {icon}
                    </div>
                    <h3 className="mt-4 font-semibold text-md text-gray-800 dark:text-gray-200 group-hover:text-white transition-colors duration-300">{title}</h3>
                </div>
            </Card>
        </div>
    );
};

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, onLogout, currentUser }) => {
    const landingItems: { title: string; icon: React.ReactNode; view: View }[] = [
        { title: 'Dashboard', view: 'Dashboard', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg> },
        { title: 'Asset Management', view: 'Assets', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" /></svg> },
        { title: 'Maintenance Management', view: 'Work Orders', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 16v-2m8-8h2M4 12H2m15.364 6.364l-1.414-1.414M6.05 19.95l1.414-1.414M19.95 6.05l-1.414 1.414M6.05 6.05l1.414 1.414M12 18a6 6 0 100-12 6 6 0 000 12z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14a2 2 0 100-4 2 2 0 000 4z" /></svg> },
        { title: 'Projects', view: 'Projects', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg> },
        { title: 'Inventory Management', view: 'Parts Catalog', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg> },
        { title: 'Personnel Management', view: 'Personnel Management', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg> },
        { title: 'Reporting & Analytics', view: 'Reporting & Analytics', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg> },
        { title: 'Messages', view: 'Messages', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg> },
        { title: 'Admin & Settings', view: 'Admin & Settings', icon: <svg xmlns="http://www.w3.org/2000/svg" className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924-1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0 3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.096 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
    ];
    
    const permissions = useUserPermissions(currentUser);
    
    const accessibleLandingItems = useMemo(() => {
        return landingItems.filter(item => permissions.includes(item.view));
    }, [permissions]);

    return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-4 sm:p-8">
            <div className="max-w-7xl mx-auto">
                <div className="flex justify-between items-center mb-8">
                     <div className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                        <span className="ml-2 text-2xl font-bold text-gray-800 dark:text-white">Mapsc CMMS Portal</span>
                    </div>
                    <div className="flex items-center space-x-4">
                        {currentUser && <span className="text-sm text-gray-600 dark:text-gray-300">Welcome, <strong>{currentUser.name}</strong>!</span>}
                        <Button variant="secondary" onClick={onLogout}>Logout</Button>
                    </div>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
                    {accessibleLandingItems.map(item => (
                        <LandingItem 
                            key={item.title}
                            title={item.title}
                            icon={item.icon}
                            onClick={() => onNavigate(item.view)}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
};
