
import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { HealthLevel } from '../../hooks/useAssetHealthScore';
import type { Asset, User } from '../../types';
import { WorkOrderType, Priority, WorkOrderStatus } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface AssetHealthReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const levelColors: Record<HealthLevel, 'green' | 'blue' | 'yellow' | 'red'> = {
    Excellent: 'green',
    Good: 'blue',
    Fair: 'yellow',
    Poor: 'red',
};

type AssetWithHealth = Asset & {
    health: {
        score: number;
        level: HealthLevel;
        factors: {
            openCriticalWos: number;
            openHighWos: number;
            recentBreakdowns: number;
            overduePms: number;
        };
    };
};

export const AssetHealthScoreReport: React.FC<AssetHealthReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({ plantId: '', zoneId: '', healthLevel: '' });
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { assets, plants, zones, workOrders, preventiveMaintenances, meters } = context.data;

    const assetsWithHealth = useMemo(() => {
        return assets
            .filter(asset => canSeeAllZones || accessibleZoneIds.includes(asset.zoneId))
            .map(asset => {
                // Logic duplicated from useAssetHealthScore to process a list efficiently
                let score = 100;
                const factors = { openCriticalWos: 0, openHighWos: 0, recentBreakdowns: 0, overduePms: 0 };
                const now = new Date();
                const ninetyDaysAgo = new Date();
                ninetyDaysAgo.setDate(now.getDate() - 90);

                const assetWorkOrders = workOrders.filter(wo => wo.assetId === asset.id);
                assetWorkOrders.forEach(wo => {
                    if (wo.status === WorkOrderStatus.Open || wo.status === WorkOrderStatus.InProgress) {
                        if (wo.priority === Priority.Critical) { score -= 25; factors.openCriticalWos++; }
                        else if (wo.priority === Priority.High) { score -= 15; factors.openHighWos++; }
                        else { score -= 5; }
                    }
                    const woDate = new Date(wo.createdDate);
                    if (woDate > ninetyDaysAgo) {
                        if (wo.workOrderType === WorkOrderType.Breakdown) { score -= 20; factors.recentBreakdowns++; }
                        else if (wo.workOrderType === WorkOrderType.Corrective) { score -= 10; }
                    }
                });

                const assetPMs = preventiveMaintenances.filter(pm => pm.assetId === asset.id);
                assetPMs.forEach(pm => {
                    let isOverdue = false;
                    if (pm.triggerType === 'Calendar' && pm.nextDueDate) { if (new Date(pm.nextDueDate) < now) { isOverdue = true; } }
                    else if (pm.triggerType === 'Meter' && pm.meterId && pm.meterTriggerValue) {
                        const meter = meters.find(m => m.id === pm.meterId);
                        if (meter) {
                            const lastTrigger = pm.lastTriggerReading || 0;
                            const nextTriggerPoint = lastTrigger + pm.meterTriggerValue;
                            if (meter.lastReading >= nextTriggerPoint) { isOverdue = true; }
                        }
                    }
                    if (isOverdue) { score -= 15; factors.overduePms++; }
                });

                const finalScore = Math.max(0, Math.round(score));
                let level: HealthLevel;
                if (finalScore >= 90) level = 'Excellent';
                else if (finalScore >= 70) level = 'Good';
                else if (finalScore >= 50) level = 'Fair';
                else level = 'Poor';

                return { ...asset, health: { score: finalScore, level, factors } };
            });
    }, [assets, workOrders, preventiveMaintenances, meters, canSeeAllZones, accessibleZoneIds]);

    // Filter dropdown options
    const availableZones = useMemo(() => {
        let filtered = zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id));
        if (filters.plantId) filtered = filtered.filter(z => z.plantId === filters.plantId);
        return filtered;
    }, [zones, canSeeAllZones, accessibleZoneIds, filters.plantId]);

    const filteredAssets = useMemo(() => {
        return assetsWithHealth.filter(asset => {
            const plantMatch = filters.plantId ? asset.plantId === filters.plantId : true;
            const zoneMatch = filters.zoneId ? asset.zoneId === filters.zoneId : true;
            const healthMatch = filters.healthLevel ? asset.health.level === filters.healthLevel : true;
            return plantMatch && zoneMatch && healthMatch;
        });
    }, [assetsWithHealth, filters]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({ plantId: '', zoneId: '', healthLevel: '' });
    };

    const columns = [
        { header: 'Asset Name', accessor: 'name' as keyof AssetWithHealth },
        { header: 'Health Score', accessor: (item: AssetWithHealth) => <Badge color={levelColors[item.health.level]}>{item.health.score}</Badge> },
        { header: 'Health Level', accessor: (item: AssetWithHealth) => item.health.level },
        { header: 'Open Critical WOs', accessor: (item: AssetWithHealth) => item.health.factors.openCriticalWos },
        { header: 'Recent Breakdowns', accessor: (item: AssetWithHealth) => item.health.factors.recentBreakdowns },
        { header: 'Overdue PMs', accessor: (item: AssetWithHealth) => item.health.factors.overduePms },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Asset Health Score Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Plant</label>
                    <select name="plantId" value={filters.plantId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Plants</option>
                        {plants.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Zone</label>
                    <select name="zoneId" value={filters.zoneId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableZones.length === 0}>
                        <option value="">All Zones</option>
                        {availableZones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Health Level</label>
                    <select name="healthLevel" value={filters.healthLevel} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Levels</option>
                        <option value="Excellent">Excellent</option>
                        <option value="Good">Good</option>
                        <option value="Fair">Fair</option>
                        <option value="Poor">Poor</option>
                    </select>
                </div>
                <div className="flex items-end">
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            <Table<AssetWithHealth>
                columns={columns}
                data={filteredAssets}
            />
        </Card>
    );
};
