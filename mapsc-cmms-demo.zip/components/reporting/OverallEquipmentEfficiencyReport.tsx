
import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Table } from '../ui/Table';
import { DataContext } from '../../contexts/DataContext';
import type { Asset, User, LaborLog } from '../../types';
import { WorkOrderType } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface MachineAvailabilityReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type ReportMetrics = {
    availability: number;
    plannedTime: number;
    runTime: number;
    downtime: number;
};

type ReportRow = ReportMetrics & {
    id: string; // assetId
    assetName: string;
};

// Helper to calculate true downtime by merging overlapping intervals
const calculateEffectiveDowntime = (logs: LaborLog[]): number => {
    if (logs.length === 0) return 0;

    const intervals = logs.map(log => ({
        start: new Date(log.startTime).getTime(),
        end: new Date(log.endTime).getTime()
    })).sort((a, b) => a.start - b.start);

    let totalTime = 0;
    let currentStart = intervals[0].start;
    let currentEnd = intervals[0].end;

    for (let i = 1; i < intervals.length; i++) {
        const nextStart = intervals[i].start;
        const nextEnd = intervals[i].end;

        if (nextStart < currentEnd) {
            currentEnd = Math.max(currentEnd, nextEnd);
        } else {
            totalTime += (currentEnd - currentStart);
            currentStart = nextStart;
            currentEnd = nextEnd;
        }
    }
    totalTime += (currentEnd - currentStart);
    return totalTime / (1000 * 60 * 60); // Convert ms to hours
};

const MetricCard: React.FC<{ title: string; value: string; className?: string }> = ({ title, value, className }) => (
    <div className={`p-4 rounded-lg text-center ${className}`}>
        <p className="text-sm uppercase text-gray-500 dark:text-gray-400">{title}</p>
        <p className="text-3xl font-bold">{value}</p>
    </div>
);

export const MachineAvailabilityReport: React.FC<MachineAvailabilityReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        plantId: '',
        zoneId: '',
        assetId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<ReportRow[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { assets, workOrders, plants, zones, laborLogs } = data;
    
    // Filter options based on access
    const availableZones = useMemo(() => {
        let filtered = zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id));
        if (filters.plantId) filtered = filtered.filter(z => z.plantId === filters.plantId);
        return filtered;
    }, [zones, canSeeAllZones, accessibleZoneIds, filters.plantId]);

    const availableAssets = useMemo(() => {
        let filtered = assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
        if (filters.zoneId) filtered = filtered.filter(a => a.zoneId === filters.zoneId);
        if (filters.plantId) filtered = filtered.filter(a => a.plantId === filters.plantId);
        return filtered;
    }, [assets, canSeeAllZones, accessibleZoneIds, filters.plantId, filters.zoneId]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => {
            const newFilters = { ...prev, [name]: value };
            if (name === 'plantId') {
                newFilters.zoneId = '';
                newFilters.assetId = '';
            }
            if (name === 'zoneId') {
                newFilters.assetId = '';
            }
            return newFilters;
        });
    };

    const handleRunReport = () => {
        if ((!filters.plantId && !filters.zoneId && !filters.assetId) || !filters.dateFrom || !filters.dateTo) {
            alert('Please select a scope (Plant, Zone, or Asset) and a full date range.');
            return;
        }

        const from = new Date(filters.dateFrom);
        from.setHours(0,0,0,0);
        const to = new Date(filters.dateTo);
        if (to < from) {
            alert('The "To" date must be after the "From" date.');
            return;
        }
        to.setHours(23, 59, 59, 999);

        let assetsToProcess: Asset[] = [];
        if (filters.assetId) {
            const asset = assets.find(a => a.id === filters.assetId);
            if (asset) assetsToProcess.push(asset);
        } else if (filters.zoneId) {
            assetsToProcess = assets.filter(a => a.zoneId === filters.zoneId);
        } else if (filters.plantId) {
            assetsToProcess = assets.filter(a => a.plantId === filters.plantId);
        }

        // Apply Security Filter
        assetsToProcess = assetsToProcess.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));

        if (assetsToProcess.length === 0) {
            alert('No accessible assets found in the selected scope.');
            setReportData([]);
            return;
        }
        
        const diffTime = to.getTime() - from.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        const reportRows: ReportRow[] = assetsToProcess.map(asset => {
            const plannedTime = diffDays * 24; // Assuming 24/7 operation
            
            const downtimeWOs = workOrders
                .filter(wo =>
                    wo.assetId === asset.id &&
                    wo.workOrderType === WorkOrderType.Breakdown &&
                    new Date(wo.createdDate) >= from &&
                    new Date(wo.createdDate) <= to
                );

            const downtimeWOIds = new Set(downtimeWOs.map(wo => wo.id));
            
            // Gather all logs for breakdown WOs on this asset
            const logs = laborLogs.filter(log => downtimeWOIds.has(log.workOrderId));
            
            // Calculate effective downtime (union of intervals) to handle concurrent work properly
            const downtime = calculateEffectiveDowntime(logs);

            const runTime = Math.max(0, plannedTime - downtime);
            const availability = plannedTime > 0 ? (runTime / plannedTime) : 0;

            return {
                id: asset.id,
                assetName: asset.name,
                availability: availability * 100,
                plannedTime,
                runTime,
                downtime,
            };
        });

        setReportData(reportRows);
    };

    const clearFilters = () => {
        setFilters({ plantId: '', zoneId: '', assetId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };
    
    const getAvailabilityColor = (availability: number) => {
        if (availability >= 90) return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
        if (availability >= 80) return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
        return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
    };
    
    const summary = useMemo(() => {
        if (!reportData || reportData.length === 0) return { avgAvailability: 0, totalPlannedTime: 0, totalDowntime: 0, totalRunTime: 0 };
        const total = reportData.length;
        const sums = reportData.reduce((acc, row) => ({
            availability: acc.availability + row.availability,
            plannedTime: acc.plannedTime + row.plannedTime,
            downtime: acc.downtime + row.downtime,
            runTime: acc.runTime + row.runTime,
        }), { availability: 0, plannedTime: 0, downtime: 0, runTime: 0 });
        return {
            avgAvailability: sums.availability / total,
            totalPlannedTime: sums.plannedTime,
            totalDowntime: sums.downtime,
            totalRunTime: sums.runTime,
        };
    }, [reportData]);

    const tableColumns = [
        { header: 'Asset Name', accessor: 'assetName' as keyof ReportRow },
        { header: 'Availability', accessor: (item: ReportRow) => `${item.availability.toFixed(1)}%` },
        { header: 'Planned Time (hrs)', accessor: (item: ReportRow) => `${item.plannedTime.toFixed(1)}` },
        { header: 'Downtime (hrs)', accessor: (item: ReportRow) => `${item.downtime.toFixed(1)}` },
        { header: 'Run Time (hrs)', accessor: (item: ReportRow) => `${item.runTime.toFixed(1)}` },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    const renderReportContent = () => {
        if (reportData === null) {
            return <div className="text-center py-10"><p className="text-gray-500">Select a scope and date range, then click 'Run'.</p></div>;
        }
        if (reportData.length === 0) {
            return <div className="text-center py-10"><p className="text-gray-500">No assets found for the selected criteria.</p></div>;
        }
        if (reportData.length === 1) {
            const singleReport = reportData[0];
            return (
                <>
                    <Card className={`mb-6 ${getAvailabilityColor(singleReport.availability)}`}>
                        <div className="text-center">
                            <p className="text-sm font-semibold uppercase">Machine Availability</p>
                            <p className="text-6xl font-bold my-2">{singleReport.availability.toFixed(1)}%</p>
                            <p className="text-xs">World-class availability is 90% or higher.</p>
                        </div>
                    </Card>
                    <Card title="Availability Data">
                        <dl className="grid grid-cols-3 gap-x-4 gap-y-6 text-sm">
                            <div><dt className="font-medium text-gray-500">Planned Time</dt><dd>{singleReport.plannedTime.toFixed(1)} hrs</dd></div>
                            <div><dt className="font-medium text-gray-500">Downtime</dt><dd>{singleReport.downtime.toFixed(1)} hrs</dd></div>
                            <div><dt className="font-medium text-gray-500">Run Time</dt><dd>{singleReport.runTime.toFixed(1)} hrs</dd></div>
                        </dl>
                    </Card>
                </>
            );
        }
        return (
            <>
                <Card className={`mb-6 ${getAvailabilityColor(summary.avgAvailability)}`}>
                    <h4 className="font-semibold text-lg text-center">Scope Summary</h4>
                     <div className="grid grid-cols-4 gap-4 mt-2">
                        <MetricCard title="Average Availability" value={`${summary.avgAvailability.toFixed(1)}%`} />
                        <MetricCard title="Total Planned Time" value={`${summary.totalPlannedTime.toFixed(1)} hrs`} />
                        <MetricCard title="Total Downtime" value={`${summary.totalDowntime.toFixed(1)} hrs`} />
                        <MetricCard title="Total Run Time" value={`${summary.totalRunTime.toFixed(1)} hrs`} />
                    </div>
                </Card>
                <Card title="Asset Breakdown">
                    <Table<ReportRow> columns={tableColumns} data={reportData} />
                </Card>
            </>
        );
    };

    return (
        <Card title="Machine Availability Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Plant</label>
                    <select name="plantId" value={filters.plantId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Plants</option>
                        {plants.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                </div>
                 <div>
                    <label className={filterLabelClasses}>Zone</label>
                    <select name="zoneId" value={filters.zoneId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableZones.length === 0}>
                        <option value="">All Zones</option>
                        {availableZones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Asset</label>
                    <select name="assetId" value={filters.assetId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableAssets.length === 0}>
                        <option value="">All Assets in Scope</option>
                        {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>
            {renderReportContent()}
        </Card>
    );
};
