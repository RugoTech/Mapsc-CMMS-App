
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderType, WorkOrder, WorkOrderStatus } from '../../types';
import type { User, LaborLog } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface MTTRReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type ReportRow = {
    id: string; // Asset ID
    assetName: string;
    repairHours: number;
    repairCount: number;
    mttr: number; // Mean Time To Repair
};

// Helper to calculate true repair time by merging overlapping intervals
const calculateEffectiveRepairTime = (logs: LaborLog[]): number => {
    if (logs.length === 0) return 0;

    const intervals = logs.map(log => ({
        start: new Date(log.startTime).getTime(),
        end: new Date(log.endTime).getTime()
    })).sort((a, b) => a.start - b.start);

    let totalTime = 0;
    let currentStart = intervals[0].start;
    let currentEnd = intervals[0].end;

    for (let i = 1; i < intervals.length; i++) {
        const nextStart = intervals[i].start;
        const nextEnd = intervals[i].end;

        if (nextStart < currentEnd) {
            currentEnd = Math.max(currentEnd, nextEnd);
        } else {
            totalTime += (currentEnd - currentStart);
            currentStart = nextStart;
            currentEnd = nextEnd;
        }
    }
    totalTime += (currentEnd - currentStart);
    return totalTime / (1000 * 60 * 60); // Convert ms to hours
};

const MetricCard: React.FC<{ title: string; value: string; className?: string }> = ({ title, value, className }) => (
    <div className={`p-4 rounded-lg text-center ${className}`}>
        <p className="text-sm uppercase text-gray-500 dark:text-gray-400">{title}</p>
        <p className="text-3xl font-bold">{value}</p>
    </div>
);

export const MTTRReport: React.FC<MTTRReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        plantId: '',
        zoneId: '',
        assetId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<ReportRow[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { workOrders, assets, plants, zones, laborLogs } = data;

    // Filter options based on access
    const availableZones = useMemo(() => {
        let filtered = zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id));
        if (filters.plantId) filtered = filtered.filter(z => z.plantId === filters.plantId);
        return filtered;
    }, [zones, canSeeAllZones, accessibleZoneIds, filters.plantId]);

    const availableAssets = useMemo(() => {
        let filtered = assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
        if (filters.zoneId) filtered = filtered.filter(a => a.zoneId === filters.zoneId);
        if (filters.plantId) filtered = filtered.filter(a => a.plantId === filters.plantId);
        return filtered;
    }, [assets, canSeeAllZones, accessibleZoneIds, filters.plantId, filters.zoneId]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => {
            const newFilters = { ...prev, [name]: value };
            if (name === 'plantId') {
                newFilters.zoneId = '';
                newFilters.assetId = '';
            }
            if (name === 'zoneId') {
                newFilters.assetId = '';
            }
            return newFilters;
        });
    };

    const handleRunReport = () => {
        // Strict filtering: Only Completed or Archived repair orders
        const repairWOs = workOrders.filter(wo =>
            (wo.workOrderType === WorkOrderType.Breakdown || wo.workOrderType === WorkOrderType.Corrective) &&
            (wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived)
        );

        const filteredWOs = repairWOs.filter(wo => {
            const asset = assets.find(a => a.id === wo.assetId);
            if (!asset) return false;

            // Security Check
            if (!canSeeAllZones && !accessibleZoneIds.includes(asset.zoneId)) {
                return false;
            }

            const plantMatch = filters.plantId ? asset.plantId === filters.plantId : true;
            const zoneMatch = filters.zoneId ? asset.zoneId === filters.zoneId : true;
            const assetMatch = filters.assetId ? wo.assetId === filters.assetId : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const created = new Date(wo.createdDate);
            
            if (from && created < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (created > to) return false;
            }
            
            return plantMatch && zoneMatch && assetMatch;
        });
        
        // Group WOs by Asset to consolidate repair time properly
        const wosByAsset: Record<string, string[]> = {};
        filteredWOs.forEach(wo => {
            if (wo.assetId) {
                if (!wosByAsset[wo.assetId]) wosByAsset[wo.assetId] = [];
                wosByAsset[wo.assetId].push(wo.id);
            }
        });

        const repairsByAsset: Record<string, { totalHours: number, count: number }> = {};
        
        Object.entries(wosByAsset).forEach(([assetId, woIds]) => {
            // Calculate effective repair time for each WO individually (since repairs on different WOs are distinct events)
            let totalEffectiveHours = 0;
            
            woIds.forEach(woId => {
                const logs = laborLogs.filter(log => log.workOrderId === woId);
                totalEffectiveHours += calculateEffectiveRepairTime(logs);
            });

            repairsByAsset[assetId] = {
                totalHours: totalEffectiveHours,
                count: woIds.length
            };
        });

        const reportRows: ReportRow[] = Object.entries(repairsByAsset).map(([assetId, data]) => {
            const asset = assets.find(a => a.id === assetId);
            const mttr = data.count > 0 ? data.totalHours / data.count : 0;
            return {
                id: assetId,
                assetName: asset?.name || 'N/A',
                repairHours: data.totalHours,
                repairCount: data.count,
                mttr: mttr,
            };
        }).sort((a, b) => b.mttr - a.mttr);

        setReportData(reportRows);
    };

    const clearFilters = () => {
        setFilters({ plantId: '', zoneId: '', assetId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const summary = useMemo(() => {
        if (!reportData) return { totalRepairHours: 0, totalRepairs: 0, averageMttr: 0 };
        const totalRepairHours = reportData.reduce((sum, row) => sum + row.repairHours, 0);
        const totalRepairs = reportData.reduce((sum, row) => sum + row.repairCount, 0);
        const averageMttr = totalRepairs > 0 ? totalRepairHours / totalRepairs : 0;
        return { totalRepairHours, totalRepairs, averageMttr };
    }, [reportData]);

    const columns = [
        { header: 'Asset Name', accessor: 'assetName' as keyof ReportRow },
        { header: 'Total Repair Hours', accessor: (item: ReportRow) => item.repairHours.toFixed(2) },
        { header: 'Number of Repairs', accessor: 'repairCount' as keyof ReportRow },
        { header: 'MTTR (Hours)', accessor: (item: ReportRow) => item.mttr.toFixed(2) },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Mean Time To Repair (MTTR) Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Plant</label>
                    <select name="plantId" value={filters.plantId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Plants</option>
                        {plants.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Zone</label>
                    <select name="zoneId" value={filters.zoneId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableZones.length === 0}>
                        <option value="">All Zones</option>
                        {availableZones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Asset</label>
                    <select name="assetId" value={filters.assetId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableAssets.length === 0}>
                        <option value="">All Assets</option>
                        {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500">Select filters and click 'Run' to generate the report.</p></div>
            )}

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Report Summary</h4>
                        <div className="grid grid-cols-3 gap-4 mt-2">
                            <MetricCard title="Total Repair Hours" value={summary.totalRepairHours.toFixed(2)} />
                            <MetricCard title="Total # of Repairs" value={`${summary.totalRepairs}`} />
                            <MetricCard title="Overall MTTR (Hours)" value={summary.averageMttr.toFixed(2)} className="bg-indigo-50 dark:bg-indigo-900/30" />
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No completed repair data found for the selected criteria.</p></div>
                    ) : (
                        <Table<ReportRow> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
