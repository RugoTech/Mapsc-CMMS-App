
import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderType, WorkOrderStatus } from '../../types';
import type { WorkOrder, Asset, User, LaborLog } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface MTBFReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type ReportData = {
    mtbf: number | null; // null for infinite (no failures)
    totalUptime: number;
    totalDowntime: number;
    failureCount: number;
    failures: WorkOrder[];
};

// Helper to calculate true downtime by merging overlapping intervals
const calculateEffectiveDowntime = (logs: LaborLog[]): number => {
    if (logs.length === 0) return 0;

    const intervals = logs.map(log => ({
        start: new Date(log.startTime).getTime(),
        end: new Date(log.endTime).getTime()
    })).sort((a, b) => a.start - b.start);

    let totalTime = 0;
    let currentStart = intervals[0].start;
    let currentEnd = intervals[0].end;

    for (let i = 1; i < intervals.length; i++) {
        const nextStart = intervals[i].start;
        const nextEnd = intervals[i].end;

        if (nextStart < currentEnd) {
            currentEnd = Math.max(currentEnd, nextEnd);
        } else {
            totalTime += (currentEnd - currentStart);
            currentStart = nextStart;
            currentEnd = nextEnd;
        }
    }
    totalTime += (currentEnd - currentStart);
    return totalTime / (1000 * 60 * 60); // Convert ms to hours
};

const MetricCard: React.FC<{ title: string; value: string; className?: string }> = ({ title, value, className }) => (
    <div className={`p-4 rounded-lg text-center ${className}`}>
        <p className="text-sm uppercase text-gray-500 dark:text-gray-400">{title}</p>
        <p className="text-3xl font-bold">{value}</p>
    </div>
);

export const MTBFReport: React.FC<MTBFReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        plantId: '',
        zoneId: '',
        assetId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<ReportData | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { assets, workOrders, plants, zones, laborLogs } = data;

    // Filter options based on access
    const availableZones = useMemo(() => {
        let filtered = zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id));
        if (filters.plantId) filtered = filtered.filter(z => z.plantId === filters.plantId);
        return filtered;
    }, [zones, canSeeAllZones, accessibleZoneIds, filters.plantId]);

    const availableAssets = useMemo(() => {
        let filtered = assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
        if (filters.zoneId) filtered = filtered.filter(a => a.zoneId === filters.zoneId);
        if (filters.plantId) filtered = filtered.filter(a => a.plantId === filters.plantId);
        return filtered;
    }, [assets, canSeeAllZones, accessibleZoneIds, filters.plantId, filters.zoneId]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => {
            const newFilters = { ...prev, [name]: value };
            if (name === 'plantId') {
                newFilters.zoneId = '';
                newFilters.assetId = '';
            }
            if (name === 'zoneId') {
                newFilters.assetId = '';
            }
            return newFilters;
        });
    };

    const handleRunReport = () => {
        if ((!filters.plantId && !filters.zoneId && !filters.assetId) || !filters.dateFrom || !filters.dateTo) {
            alert('Please select a scope (Plant, Zone, or Asset) and a full date range.');
            return;
        }

        const from = new Date(filters.dateFrom);
        const to = new Date(filters.dateTo);
        to.setHours(23, 59, 59, 999);

        const totalPeriodHoursPerAsset = (to.getTime() - from.getTime()) / (1000 * 60 * 60);
        if (totalPeriodHoursPerAsset <= 0) {
            alert('The "To" date must be after the "From" date.');
            return;
        }

        let assetsInScope: Asset[] = [];
        if (filters.assetId) {
            const asset = assets.find(a => a.id === filters.assetId);
            if (asset) assetsInScope.push(asset);
        } else if (filters.zoneId) {
            assetsInScope = assets.filter(a => a.zoneId === filters.zoneId);
        } else if (filters.plantId) {
            assetsInScope = assets.filter(a => a.plantId === filters.plantId);
        }

        // Apply Security Filter
        assetsInScope = assetsInScope.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));

        if (assetsInScope.length === 0) {
            alert('No accessible assets found in the selected scope.');
            setReportData({ mtbf: null, totalUptime: 0, totalDowntime: 0, failureCount: 0, failures: [] });
            return;
        }

        const assetIdsInScope = new Set(assetsInScope.map(a => a.id));
        const totalPeriodHours = assetsInScope.length * totalPeriodHoursPerAsset;

        // Filter for Breakdown work orders.
        // NOTE: We include ALL breakdowns (Open or Closed) created in the period to accurately reflect reliability issues.
        const failures = workOrders.filter(wo =>
            wo.assetId &&
            assetIdsInScope.has(wo.assetId) &&
            wo.workOrderType === WorkOrderType.Breakdown &&
            new Date(wo.createdDate) >= from &&
            new Date(wo.createdDate) <= to
        );

        const failureWOIds = new Set(failures.map(wo => wo.id));
        const logsForFailures = laborLogs.filter(log => failureWOIds.has(log.workOrderId));
        
        // Use the interval logic to calculate true downtime (clock time) instead of man-hours
        const totalDowntime = calculateEffectiveDowntime(logsForFailures);

        const totalUptime = Math.max(0, totalPeriodHours - totalDowntime);
        const failureCount = failures.length;
        const mtbf = failureCount > 0 ? totalUptime / failureCount : null;

        setReportData({
            mtbf,
            totalUptime,
            totalDowntime,
            failureCount,
            failures,
        });
    };

    const clearFilters = () => {
        setFilters({ assetId: '', plantId: '', zoneId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const failureColumns = [
        { header: 'WO ID', accessor: 'id' as keyof WorkOrder },
        { header: 'Description', accessor: 'description' as keyof WorkOrder },
        { header: 'Date', accessor: 'createdDate' as keyof WorkOrder },
        { header: 'Status', accessor: 'status' as keyof WorkOrder },
        { header: 'Downtime (Hours)', accessor: (item: WorkOrder) => {
            const woLogs = laborLogs.filter(log => log.workOrderId === item.id);
            return calculateEffectiveDowntime(woLogs).toFixed(2);
        }},
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Mean Time Between Failures (MTBF) Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Plant</label>
                    <select name="plantId" value={filters.plantId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">Select Plant</option>
                        {plants.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Zone</label>
                    <select name="zoneId" value={filters.zoneId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableZones.length === 0}>
                        <option value="">Select Zone</option>
                        {availableZones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Asset</label>
                    <select name="assetId" value={filters.assetId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableAssets.length === 0}>
                        <option value="">All Assets in Scope</option>
                        {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500">Select a scope and date range to calculate MTBF.</p></div>
            )}

            {reportData !== null && (
                <>
                    <Card className="mb-6 bg-indigo-50 dark:bg-indigo-900/30">
                        <MetricCard
                            title="Mean Time Between Failures (MTBF)"
                            value={reportData.mtbf !== null ? `${reportData.mtbf.toFixed(2)} Hours` : 'No Failures'}
                        />
                    </Card>

                    <Card className="mb-6" title="Calculation Summary">
                        <div className="grid grid-cols-3 gap-4">
                            <MetricCard title="Total Uptime" value={`${reportData.totalUptime.toFixed(2)} hrs`} />
                            <MetricCard title="Number of Failures" value={`${reportData.failureCount}`} />
                            <MetricCard title="Total Downtime" value={`${reportData.totalDowntime.toFixed(2)} hrs`} />
                        </div>
                    </Card>
                    
                    <Card title="Failure Events Log">
                        {reportData.failures.length > 0 ? (
                            <Table<WorkOrder> columns={failureColumns} data={reportData.failures} />
                        ) : (
                            <p className="text-gray-500 dark:text-gray-400 p-4 text-center">No breakdown events recorded for the selected scope in this period.</p>
                        )}
                    </Card>
                </>
            )}
        </Card>
    );
};
