
import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderType } from '../../types';
import type { User, Asset, LaborLog } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface AssetDowntimeReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type ReportRow = {
    id: string; // Asset ID
    assetName: string;
    downtimeHours: number;
    eventCount: number;
    mttr: number; // Mean Time To Repair
};

type ComponentDowntimeRow = {
    id: string; // component name
    componentName: string;
    failureCount: number;
    downtime: number;
};

// Helper to calculate true downtime by merging overlapping intervals
const calculateEffectiveDowntime = (logs: LaborLog[]): number => {
    if (logs.length === 0) return 0;

    const intervals = logs.map(log => ({
        start: new Date(log.startTime).getTime(),
        end: new Date(log.endTime).getTime()
    })).sort((a, b) => a.start - b.start);

    let totalTime = 0;
    let currentStart = intervals[0].start;
    let currentEnd = intervals[0].end;

    for (let i = 1; i < intervals.length; i++) {
        const nextStart = intervals[i].start;
        const nextEnd = intervals[i].end;

        if (nextStart < currentEnd) {
            currentEnd = Math.max(currentEnd, nextEnd);
        } else {
            totalTime += (currentEnd - currentStart);
            currentStart = nextStart;
            currentEnd = nextEnd;
        }
    }
    totalTime += (currentEnd - currentStart);
    return totalTime / (1000 * 60 * 60); // Convert ms to hours
};

const ComponentDowntimeModal: React.FC<{
    asset: ReportRow;
    filters: { dateFrom: string; dateTo: string };
    onClose: () => void;
}> = ({ asset, filters, onClose }) => {
    const context = useContext(DataContext);
    if (!context) return null;
    const { workOrders, bomItems, parts, laborLogs } = context.data;

    const componentData = useMemo(() => {
        const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
        const to = filters.dateTo ? new Date(filters.dateTo) : null;
        if (to) to.setHours(23, 59, 59, 999);

        const assetDowntimeWOs = workOrders.filter(wo => {
            if (wo.assetId !== asset.id || wo.workOrderType !== WorkOrderType.Breakdown) {
                return false;
            }
            const created = new Date(wo.createdDate);
            if (from && created < from) return false;
            if (to && created > to) return false;
            return true;
        });

        const downtimeByComponent: Record<string, { componentName: string, failureCount: number, downtime: number }> = {};

        assetDowntimeWOs.forEach(wo => {
            if (wo.rca) {
                let componentIdentifier = "Unknown Component";
                if (wo.rca.componentAffectedId) {
                    const bomItem = bomItems.find(b => b.id === wo.rca.componentAffectedId);
                    if (bomItem) {
                        const part = parts.find(p => p.id === bomItem.partId);
                        componentIdentifier = part?.name || `Part ID: ${bomItem.partId}`;
                    } else {
                        componentIdentifier = `BOM ID: ${wo.rca.componentAffectedId}`;
                    }
                } else if (wo.rca.componentAffectedCustom) {
                    componentIdentifier = wo.rca.componentAffectedCustom;
                }
                
                if (!downtimeByComponent[componentIdentifier]) {
                    downtimeByComponent[componentIdentifier] = { componentName: componentIdentifier, failureCount: 0, downtime: 0 };
                }
                
                // Calculate effective downtime for this specific WO
                const woLogs = laborLogs.filter(log => log.workOrderId === wo.id);
                const effectiveDowntime = calculateEffectiveDowntime(woLogs);

                downtimeByComponent[componentIdentifier].failureCount += 1;
                downtimeByComponent[componentIdentifier].downtime += effectiveDowntime;
            }
        });
        
        return Object.entries(downtimeByComponent)
            .map(([key, value]) => ({ id: key, ...value }))
            .sort((a, b) => b.downtime - a.downtime);

    }, [asset.id, filters, workOrders, bomItems, parts, laborLogs]);
    
    const columns = [
        { header: 'Component', accessor: 'componentName' as keyof ComponentDowntimeRow },
        { header: 'Failures', accessor: 'failureCount' as keyof ComponentDowntimeRow },
        { header: 'Downtime (hrs)', accessor: (item: ComponentDowntimeRow) => item.downtime.toFixed(2) },
    ];

    return (
        <Modal isOpen={true} onClose={onClose} title={`Downtime Components for ${asset.assetName}`}>
            {componentData.length > 0 ? (
                <Table<ComponentDowntimeRow>
                    columns={columns}
                    data={componentData}
                />
            ) : (
                <p className="text-gray-500 dark:text-gray-400">No component failure data recorded for this asset in the selected period. Ensure Root Cause Analysis is filled out for breakdown work orders.</p>
            )}
        </Modal>
    );
};


export const AssetDowntimeReport: React.FC<AssetDowntimeReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        plantId: '',
        zoneId: '',
        assetId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<ReportRow[] | null>(null);
    const [viewingComponentsForAsset, setViewingComponentsForAsset] = useState<ReportRow | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { workOrders, assets, plants, zones } = data;

    // Filter available options based on zone access
    const availableAssets = useMemo(() => {
        let filtered = assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
        if (filters.zoneId) filtered = filtered.filter(a => a.zoneId === filters.zoneId);
        if (filters.plantId) filtered = filtered.filter(a => a.plantId === filters.plantId);
        return filtered;
    }, [assets, canSeeAllZones, accessibleZoneIds, filters.zoneId, filters.plantId]);

    const availableZones = useMemo(() => {
        let filtered = zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id));
        if (filters.plantId) filtered = filtered.filter(z => z.plantId === filters.plantId);
        return filtered;
    }, [zones, canSeeAllZones, accessibleZoneIds, filters.plantId]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        // Filter for work orders that represent downtime.
        const downtimeWOs = workOrders.filter(wo =>
            wo.workOrderType === WorkOrderType.Breakdown
        );

        // Apply filters and security
        const filteredWOs = downtimeWOs.filter(wo => {
            const asset = assets.find(a => a.id === wo.assetId);
            if (!asset) return false;

            // Security Check
            if (!canSeeAllZones && !accessibleZoneIds.includes(asset.zoneId)) {
                return false;
            }

            const plantMatch = filters.plantId ? asset.plantId === filters.plantId : true;
            const zoneMatch = filters.zoneId ? asset.zoneId === filters.zoneId : true;
            const assetMatch = filters.assetId ? wo.assetId === filters.assetId : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const created = new Date(wo.createdDate);
            
            if (from && created < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (created > to) return false;
            }
            
            return plantMatch && zoneMatch && assetMatch;
        });

        // Group by asset
        const downtimeByAsset: Record<string, { totalHours: number, count: number }> = {};
        
        // Group WOs by Asset first to calculate consolidated downtime for the asset
        const wosByAsset: Record<string, string[]> = {};
        filteredWOs.forEach(wo => {
            if (wo.assetId) {
                if (!wosByAsset[wo.assetId]) wosByAsset[wo.assetId] = [];
                wosByAsset[wo.assetId].push(wo.id);
            }
        });

        Object.entries(wosByAsset).forEach(([assetId, woIds]) => {
            const woIdsSet = new Set(woIds);
            // Get all labor logs for all breakdown WOs for this asset
            // We calculate effective downtime across ALL logs to handle overlapping WOs on same asset correctly
            const logs = data.laborLogs.filter(log => woIdsSet.has(log.workOrderId));
            
            const effectiveDowntime = calculateEffectiveDowntime(logs);
            
            downtimeByAsset[assetId] = {
                totalHours: effectiveDowntime,
                count: woIds.length
            };
        });

        const reportRows: ReportRow[] = Object.entries(downtimeByAsset).map(([assetId, data]) => {
            const asset = assets.find(a => a.id === assetId);
            const mttr = data.count > 0 ? data.totalHours / data.count : 0;
            return {
                id: assetId,
                assetName: asset?.name || 'N/A',
                downtimeHours: data.totalHours,
                eventCount: data.count,
                mttr: mttr,
            };
        });

        setReportData(reportRows);
    };

    const clearFilters = () => {
        setFilters({ plantId: '', zoneId: '', assetId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const summary = useMemo(() => {
        if (!reportData) return { totalDowntime: 0, totalEvents: 0, averageMttr: 0 };
        const totalDowntime = reportData.reduce((sum, row) => sum + row.downtimeHours, 0);
        const totalEvents = reportData.reduce((sum, row) => sum + row.eventCount, 0);
        const averageMttr = totalEvents > 0 ? totalDowntime / totalEvents : 0;
        return { totalDowntime, totalEvents, averageMttr };
    }, [reportData]);

    const columns = [
        { header: 'Asset Name', accessor: 'assetName' as keyof ReportRow },
        { header: 'Total Downtime (Hours)', accessor: (item: ReportRow) => item.downtimeHours.toFixed(2) },
        { header: 'Downtime Events', accessor: 'eventCount' as keyof ReportRow },
        { header: 'MTTR (Hours)', accessor: (item: ReportRow) => item.mttr.toFixed(2) },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <>
            <Card title="Asset Downtime Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                        <label className={filterLabelClasses}>Plant</label>
                        <select name="plantId" value={filters.plantId} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Plants</option>
                            {plants.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className={filterLabelClasses}>Zone</label>
                        <select name="zoneId" value={filters.zoneId} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Zones</option>
                            {availableZones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className={filterLabelClasses}>Asset</label>
                        <select name="assetId" value={filters.assetId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableAssets.length === 0}>
                            <option value="">All Assets in Scope</option>
                            {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className={filterLabelClasses}>Date (From)</label>
                        <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                    </div>
                    <div>
                        <label className={filterLabelClasses}>Date (To)</label>
                        <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                    </div>
                    <div className="flex items-end space-x-2">
                        <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                        <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                    </div>
                </div>

                {reportData === null && (
                    <div className="text-center py-10"><p className="text-gray-500">Select filters and click 'Run' to generate the report.</p></div>
                )}

                {reportData !== null && (
                    <>
                        <Card className="mb-6">
                            <h4 className="font-semibold text-lg">Summary</h4>
                            <div className="grid grid-cols-3 gap-4 mt-2 text-center">
                                <div><p className="text-sm text-gray-500">Total Downtime (Hours)</p><p className="text-2xl font-bold">{summary.totalDowntime.toFixed(2)}</p></div>
                                <div><p className="text-sm text-gray-500">Total Downtime Events</p><p className="text-2xl font-bold">{summary.totalEvents}</p></div>
                                <div><p className="text-sm text-gray-500">Average MTTR (Hours)</p><p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{summary.averageMttr.toFixed(2)}</p></div>
                            </div>
                        </Card>

                        {reportData.length === 0 ? (
                            <div className="text-center py-10"><p className="text-gray-500">No downtime data found for the selected criteria.</p></div>
                        ) : (
                            <Table<ReportRow>
                                columns={columns}
                                data={reportData}
                                renderRowActions={(row) => (
                                    <Button variant="secondary" size="sm" onClick={() => setViewingComponentsForAsset(row)}>
                                        View Components
                                    </Button>
                                )}
                            />
                        )}
                    </>
                )}
            </Card>
            {viewingComponentsForAsset && (
                <ComponentDowntimeModal
                    asset={viewingComponentsForAsset}
                    filters={{ dateFrom: filters.dateFrom, dateTo: filters.dateTo }}
                    onClose={() => setViewingComponentsForAsset(null)}
                />
            )}
        </>
    );
};
