
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { PRStatus, PRType, Priority } from '../../types';
import type { PurchaseRequisition, User } from '../../types';
import { useCurrencyFormatter } from '../../hooks/useCurrency';

interface PurchaseRequisitionReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const statusColors: Record<PRStatus, 'blue' | 'green' | 'red' | 'gray' | 'yellow'> = {
    [PRStatus.Draft]: 'gray',
    [PRStatus.Pending]: 'blue',
    [PRStatus.Approved]: 'green',
    [PRStatus.Rejected]: 'red',
    [PRStatus.RFQCreated]: 'yellow',
};

export const PurchaseRequisitionReport: React.FC<PurchaseRequisitionReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        status: '',
        type: '',
        priority: '',
        requesterId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<PurchaseRequisition[] | null>(null);
    const formatCurrency = useCurrencyFormatter();

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { purchaseRequisitions, users } = data;

    const getUserName = useCallback((userId: string) => users.find(u => u.id === userId)?.name || 'System', [users]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filtered = purchaseRequisitions.filter(pr => {
            const statusMatch = filters.status ? pr.status === filters.status : true;
            const typeMatch = filters.type ? pr.type === filters.type : true;
            const priorityMatch = filters.priority ? pr.priority === filters.priority : true;
            const requesterMatch = filters.requesterId ? pr.requesterId === filters.requesterId : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const requestDate = new Date(pr.requestDate);
            
            if (from && requestDate < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (requestDate > to) return false;
            }
            
            return statusMatch && typeMatch && priorityMatch && requesterMatch;
        });
        setReportData(filtered);
    };

    const clearFilters = () => {
        setFilters({ status: '', type: '', priority: '', requesterId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const summary = useMemo(() => {
        if (!reportData) return { total: 0, pending: 0, approved: 0, rejected: 0 };
        return {
            total: reportData.length,
            pending: reportData.filter(pr => pr.status === PRStatus.Pending).length,
            approved: reportData.filter(pr => pr.status === PRStatus.Approved || pr.status === PRStatus.RFQCreated).length,
            rejected: reportData.filter(pr => pr.status === PRStatus.Rejected).length,
        };
    }, [reportData]);

    const columns = [
        { header: 'PR ID', accessor: 'id' as keyof PurchaseRequisition },
        { header: 'Type', accessor: 'type' as keyof PurchaseRequisition },
        { header: 'Description', accessor: (pr: PurchaseRequisition) => {
             if (pr.type === PRType.System && pr.items) {
                 return `System: ${pr.items.length} items`;
             }
             return pr.description || 'N/A';
        }},
        { header: 'Requester', accessor: (pr: PurchaseRequisition) => getUserName(pr.requesterId) },
        { header: 'Priority', accessor: (pr: PurchaseRequisition) => pr.priority },
        { header: 'Date', accessor: 'requestDate' as keyof PurchaseRequisition },
        { header: 'Est. Cost', accessor: (pr: PurchaseRequisition) => 
            typeof pr.estimatedCost === 'number' ? formatCurrency(pr.estimatedCost) : 'N/A' 
        },
        { header: 'Status', accessor: (pr: PurchaseRequisition) => <Badge color={statusColors[pr.status]}>{pr.status}</Badge> },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Purchase Requisition Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Status</label>
                    <select name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Statuses</option>
                        {Object.values(PRStatus).map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Type</label>
                    <select name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Types</option>
                        {Object.values(PRType).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Priority</label>
                    <select name="priority" value={filters.priority} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Priorities</option>
                        {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Requester</label>
                    <select name="requesterId" value={filters.requesterId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Requesters</option>
                        {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2 col-span-full">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Summary</h4>
                        <div className="grid grid-cols-4 gap-4 mt-2 text-center">
                            <div><p className="text-sm text-gray-500">Total Requests</p><p className="text-2xl font-bold">{summary.total}</p></div>
                            <div><p className="text-sm text-gray-500">Pending Approval</p><p className="text-2xl font-bold text-blue-600">{summary.pending}</p></div>
                            <div><p className="text-sm text-gray-500">Approved/RFQ</p><p className="text-2xl font-bold text-green-600">{summary.approved}</p></div>
                            <div><p className="text-sm text-gray-500">Rejected</p><p className="text-2xl font-bold text-red-600">{summary.rejected}</p></div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No records found.</p></div>
                    ) : (
                        <Table<PurchaseRequisition> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
