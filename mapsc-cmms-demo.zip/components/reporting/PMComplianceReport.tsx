
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderStatus } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import type { User, WorkOrder } from '../../types';

interface PMComplianceReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type ReportRow = {
    id: string; // WO ID
    description: string;
    assetName: string;
    dueDate: string;
    completionDate: string | null;
    completionStatus: 'On-Time' | 'Late' | 'Overdue' | 'Pending';
    plannedDuration: number;
    actualDuration: number;
    durationVariance: number; // percentage
};

const statusColors: Record<ReportRow['completionStatus'], 'green' | 'yellow' | 'red' | 'blue'> = {
    'On-Time': 'green',
    'Late': 'yellow',
    'Overdue': 'red',
    'Pending': 'blue',
};

export const PMComplianceReport: React.FC<PMComplianceReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({ plannerGroupId: '', dateFrom: '', dateTo: '' });
    const [reportData, setReportData] = useState<ReportRow[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { workOrders, assets, plannerGroups, laborLogs, auditLog } = data;

    const getAssetName = useCallback((assetId?: string) => assets.find(a => a.id === assetId)?.name || 'N/A', [assets]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    // Helper to find actual completion date from Audit Log
    const getActualCompletionDate = (wo: WorkOrder): string | null => {
        // Look for a log entry where this WO was completed
        const completionLog = auditLog.find(log => 
            log.entityType === 'WorkOrder' && 
            log.entityId === wo.id && 
            (log.details.includes('Completed work order') || log.details.includes("Status changed to 'Completed'"))
        );

        if (completionLog) {
            return completionLog.timestamp;
        }
        
        // Fallback: If archived but no log found (rare/mock data), try labor logs max end time
        const woLogs = laborLogs.filter(l => l.workOrderId === wo.id);
        if (woLogs.length > 0) {
            const lastLog = woLogs.reduce((latest, log) => new Date(log.endTime) > new Date(latest.endTime) ? log : latest, woLogs[0]);
            return lastLog.endTime;
        }

        // Final Fallback for mock data consistency
        if (wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived) {
             return wo.dueDate; // Assume on time if no record exists in mock
        }

        return null;
    };

    const handleRunReport = () => {
        const todayStr = new Date().toISOString().split('T')[0];

        const dueWOs = workOrders.filter(wo => {
            // 1. Security Check
            const asset = assets.find(a => a.id === wo.assetId);
            const woZoneId = asset ? asset.zoneId : wo.zoneId;
            if (!canSeeAllZones && (!woZoneId || !accessibleZoneIds.includes(woZoneId))) {
                return false;
            }

            if (wo.workOrderType !== 'Preventive') return false;
            
            // Exclude cancelled ones from the main list, but we will count them for the summary later
            if (wo.status === WorkOrderStatus.Cancelled) return false;
            
            const plannerMatch = filters.plannerGroupId ? wo.planningGroupId === filters.plannerGroupId : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const created = new Date(wo.createdDate);
            
            if (from && created < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (created > to) return false;
            }
            
            return plannerMatch;
        });

        const reportRows: ReportRow[] = dueWOs.map(wo => {
            let completionStatus: ReportRow['completionStatus'] = 'Pending';
            let completionDateOnly: string | null = null;
            
            const isCompletedOrArchived = wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived;

            if (isCompletedOrArchived) {
                const actualCompletionTimestamp = getActualCompletionDate(wo);
                
                if (actualCompletionTimestamp) {
                    const completionDateTime = new Date(actualCompletionTimestamp);
                    completionDateOnly = completionDateTime.toISOString().split('T')[0];
                    
                    // Parse Due Date and set to end of day for fair comparison
                    const dueDate = new Date(wo.dueDate);
                    dueDate.setHours(23, 59, 59, 999);
                    
                    completionStatus = completionDateTime <= dueDate ? 'On-Time' : 'Late';
                } else {
                    // Should effectively not happen with robust getActualCompletionDate, 
                    // but serves as safety net for purely mocked legacy data
                    completionStatus = 'On-Time'; 
                    completionDateOnly = wo.dueDate;
                }
            } else { // It's Open or In Progress
                if (todayStr > wo.dueDate) {
                    completionStatus = 'Overdue';
                } else {
                    completionStatus = 'Pending';
                }
            }
            
            // Use the estimatedDuration stored on the WO itself as the "Planned Duration"
            // This preserves historical accuracy even if the PM plan is later edited or deleted.
            const plannedDuration = wo.estimatedDuration || 0;
            
            const actualDuration = laborLogs
                .filter(log => log.workOrderId === wo.id)
                .reduce((sum, log) => {
                    const duration = (new Date(log.endTime).getTime() - new Date(log.startTime).getTime()) / (1000 * 60 * 60);
                    return sum + duration;
                }, 0);

            const durationVariance = plannedDuration > 0 ? ((actualDuration - plannedDuration) / plannedDuration) * 100 : 0;

            return {
                id: wo.id,
                description: wo.description,
                assetName: getAssetName(wo.assetId),
                dueDate: wo.dueDate,
                completionDate: completionDateOnly,
                completionStatus: completionStatus,
                plannedDuration,
                actualDuration,
                durationVariance,
            };
        });
        
        setReportData(reportRows);
    };

    const clearFilters = () => {
        setFilters({ plannerGroupId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const summary = useMemo(() => {
        if (!reportData) return { total: 0, completedOnTime: 0, completedLate: 0, overdue: 0, compliance: 0, avgVariance: 0, cancelledPercentage: 0 };
        
        // Calculate active metrics from reportData
        const totalActive = reportData.length;
        const completedOnTime = reportData.filter(row => row.completionStatus === 'On-Time').length;
        const completedLate = reportData.filter(row => row.completionStatus === 'Late').length;
        const overdue = reportData.filter(row => row.completionStatus === 'Overdue').length;
        
        // Re-query to find ALL PMs generated in this period, including cancelled ones, to calculate the ratio
        const allPMs = workOrders.filter(wo => {
             // Security Check
            const asset = assets.find(a => a.id === wo.assetId);
            const woZoneId = asset ? asset.zoneId : wo.zoneId;
            if (!canSeeAllZones && (!woZoneId || !accessibleZoneIds.includes(woZoneId))) {
                return false;
            }

            if (wo.workOrderType !== 'Preventive') return false;
            
            const plannerMatch = filters.plannerGroupId ? wo.planningGroupId === filters.plannerGroupId : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const created = new Date(wo.createdDate);
            
            if (from && created < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (created > to) return false;
            }
            
            return plannerMatch;
        });

        const totalPMsGenerated = allPMs.length;
        const cancelledPMs = allPMs.filter(wo => wo.status === WorkOrderStatus.Cancelled).length;
        const cancelledPercentage = totalPMsGenerated > 0 ? (cancelledPMs / totalPMsGenerated) * 100 : 0;

        const totalMeasurable = completedOnTime + completedLate + overdue;
        const compliance = totalMeasurable > 0 ? (completedOnTime / totalMeasurable) * 100 : 100;

        const completedWithPlannedDuration = reportData.filter(row => (row.completionStatus === 'On-Time' || row.completionStatus === 'Late') && row.plannedDuration > 0);
        const totalVariance = completedWithPlannedDuration.reduce((sum, row) => sum + row.durationVariance, 0);
        const avgVariance = completedWithPlannedDuration.length > 0 ? totalVariance / completedWithPlannedDuration.length : 0;

        return { total: totalActive, completedOnTime, completedLate, overdue, compliance, avgVariance, cancelledPercentage };
    }, [reportData, workOrders, assets, filters, canSeeAllZones, accessibleZoneIds]);

    const columns = [
        { header: 'WO ID', accessor: 'id' as keyof ReportRow },
        { header: 'Asset', accessor: 'assetName' as keyof ReportRow },
        { header: 'Due Date', accessor: 'dueDate' as keyof ReportRow },
        { header: 'Completed', accessor: (item: ReportRow) => item.completionDate || '-' },
        { 
            header: 'Schedule Compliance', 
            accessor: (item: ReportRow) => (
                <Badge color={statusColors[item.completionStatus]}>
                    {item.completionStatus}
                </Badge>
            )
        },
        { header: 'Planned (Hrs)', accessor: (item: ReportRow) => item.plannedDuration.toFixed(1) },
        { header: 'Actual (Hrs)', accessor: (item: ReportRow) => item.actualDuration.toFixed(2) },
        { 
            header: 'Duration Variance', 
            accessor: (item: ReportRow) => {
                const variance = item.durationVariance;
                if (item.plannedDuration === 0) return 'N/A';
                const color = variance > 20 ? 'text-red-500' : variance < -20 ? 'text-green-500' : '';
                return <span className={`font-semibold ${color}`}>{variance > 0 ? '+' : ''}{variance.toFixed(0)}%</span>;
            }
        },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="PM Compliance Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Planner Group</label>
                    <select name="plannerGroupId" value={filters.plannerGroupId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Groups</option>
                        {plannerGroups.map(pg => <option key={pg.id} value={pg.id}>{pg.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Created Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Created Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2 col-span-1 sm:col-span-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500">Select filters and click 'Run Report'.</p></div>
            )}

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Report Summary</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-2 text-center">
                            <div><p className="text-sm text-gray-500">Active PMs Due</p><p className="text-2xl font-bold">{summary.total}</p></div>
                            <div><p className="text-sm text-gray-500">On-Time</p><p className="text-2xl font-bold text-green-600">{summary.completedOnTime}</p></div>
                            <div><p className="text-sm text-gray-500">Late</p><p className="text-2xl font-bold text-yellow-600">{summary.completedLate}</p></div>
                            <div>
                                <p className="text-sm text-gray-500">Schedule Compliance</p>
                                <p className="text-2xl font-bold text-indigo-600">{summary.compliance.toFixed(0)}%</p>
                            </div>
                             <div>
                                <p className="text-sm text-gray-500">Avg. Duration Variance</p>
                                <p className={`text-2xl font-bold ${summary.avgVariance > 10 ? 'text-red-500' : 'text-green-600'}`}>{summary.avgVariance > 0 ? '+' : ''}{summary.avgVariance.toFixed(0)}%</p>
                            </div>
                            <div>
                                <p className="text-sm text-gray-500">Cancelled PMs</p>
                                <p className="text-2xl font-bold text-red-500">{summary.cancelledPercentage.toFixed(1)}%</p>
                            </div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No active PM work orders found for the selected criteria.</p></div>
                    ) : (
                        <Table<ReportRow> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
