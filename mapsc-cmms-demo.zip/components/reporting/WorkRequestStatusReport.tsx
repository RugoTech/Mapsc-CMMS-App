
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { WorkRequestStatus, Priority } from '../../types';
import type { WorkRequest, User } from '../../types';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface WorkRequestStatusReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const statusColors: Record<WorkRequestStatus, 'blue' | 'green' | 'red' | 'gray'> = {
    [WorkRequestStatus.Pending]: 'blue',
    [WorkRequestStatus.Approved]: 'green',
    [WorkRequestStatus.Rejected]: 'red',
    [WorkRequestStatus.ConvertedToWO]: 'gray',
};

const pieChartColors = {
    [WorkRequestStatus.Pending]: '#3b82f6', // blue-500
    [WorkRequestStatus.Approved]: '#22c55e', // green-500
    [WorkRequestStatus.Rejected]: '#ef4444', // red-500
    [WorkRequestStatus.ConvertedToWO]: '#6b7280', // gray-500
};

const priorityColors: Record<Priority, 'blue' | 'yellow' | 'red'> = {
    [Priority.Low]: 'blue',
    [Priority.Medium]: 'yellow',
    [Priority.High]: 'red',
    [Priority.Critical]: 'red',
};

export const WorkRequestStatusReport: React.FC<WorkRequestStatusReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        plannerGroupId: '',
        status: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<WorkRequest[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data } = context;
    const { workRequests, users, plannerGroups, assets } = data;

    const getUserName = useCallback((userId: string) => users.find(u => u.id === userId)?.name || 'N/A', [users]);
    const getPlannerGroupName = useCallback((groupId?: string) => plannerGroups.find(p => p.id === groupId)?.name || 'N/A', [plannerGroups]);

    const userPlannerGroup = useMemo(() => {
        if (currentUser.role !== 'Planner') return null;
        return context.data.plannerGroups.find(pg => pg.userIds.includes(currentUser.id));
    }, [context, currentUser]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filtered = workRequests.filter(wr => {
            // 1. Security / Zone Access Check
            const asset = wr.assetId ? assets.find(a => a.id === wr.assetId) : null;
            const wrZoneId = asset?.zoneId; 
            
            let hasAccess = false;
            
            // Admins (canSeeAllZones) and Engineers can see all requests (Engineers have access to reports)
            if (canSeeAllZones || currentUser.role === 'Engineer') {
                hasAccess = true;
            } else if (wr.requesterId === currentUser.id) {
                // Requester always sees their own
                hasAccess = true;
            } else {
                const isInAccessibleZone = wrZoneId ? accessibleZoneIds.includes(wrZoneId) : false;
                
                if (currentUser.role === 'Planner') {
                    // Planners Logic:
                    if (wr.plannerGroupId) {
                        // 1. Claimed Requests: ONLY visible if assigned to THIS planner's group
                        if (userPlannerGroup && wr.plannerGroupId === userPlannerGroup.id) {
                            hasAccess = true;
                        }
                    } else {
                        // 2. Unclaimed Requests: Visible if in their Zone OR if no asset assigned (pool)
                        if (isInAccessibleZone || !wr.assetId) {
                            hasAccess = true;
                        }
                    }
                } else {
                    // Other roles restricted strictly by zone presence
                    if (isInAccessibleZone) {
                        hasAccess = true;
                    }
                }
            }

            if (!hasAccess) return false;

            // 2. Filter Criteria
            const plannerMatch = filters.plannerGroupId ? wr.plannerGroupId === filters.plannerGroupId : true;
            const statusMatch = filters.status ? wr.status === filters.status : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const requestDate = new Date(wr.requestDate);
            
            if (from && requestDate < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (requestDate > to) return false;
            }
            
            return plannerMatch && statusMatch;
        });
        setReportData(filtered);
    };

    const clearFilters = () => {
        setFilters({ plannerGroupId: '', status: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const summaryData = useMemo(() => {
        if (!reportData) return [];
        const statusCounts = reportData.reduce((acc, wr) => {
            acc[wr.status] = (acc[wr.status] || 0) + 1;
            return acc;
        }, {} as Record<WorkRequestStatus, number>);
        
        return Object.entries(statusCounts).map(([name, value]) => ({ name, value }));
    }, [reportData]);

    const columns = [
        { header: 'WR ID', accessor: 'id' as keyof WorkRequest },
        { header: 'Description', accessor: 'description' as keyof WorkRequest },
        { header: 'Requester', accessor: (item: WorkRequest) => getUserName(item.requesterId) },
        { header: 'Request Date', accessor: 'requestDate' as keyof WorkRequest },
        { header: 'Priority', accessor: (item: WorkRequest) => <Badge color={priorityColors[item.priority]}>{item.priority}</Badge> },
        { header: 'Status', accessor: (item: WorkRequest) => <Badge color={statusColors[item.status]}>{item.status}</Badge> },
        { header: 'Planner Group', accessor: (item: WorkRequest) => getPlannerGroupName(item.plannerGroupId) },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Work Request Status Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Planner Group</label>
                    <select name="plannerGroupId" value={filters.plannerGroupId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Groups</option>
                        {plannerGroups.map(pg => <option key={pg.id} value={pg.id}>{pg.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Status</label>
                    <select name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Statuses</option>
                        {Object.values(WorkRequestStatus).map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Request Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Request Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500">Select filters and click 'Run' to generate the report.</p></div>
            )}

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Report Summary</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                            <div className="md:col-span-1 flex flex-col justify-center space-y-2">
                                {summaryData.map(entry => (
                                    <div key={entry.name} className="flex justify-between items-center">
                                        <div className="flex items-center">
                                            <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: pieChartColors[entry.name as WorkRequestStatus] }}></span>
                                            <span>{entry.name}</span>
                                        </div>
                                        <span className="font-bold">{entry.value}</span>
                                    </div>
                                ))}
                                <div className="border-t pt-2 flex justify-between font-bold">
                                    <span>Total</span>
                                    <span>{reportData.length}</span>
                                </div>
                            </div>
                            <div className="md:col-span-2 h-56">
                                <ResponsiveContainer width="100%" height="100%" minWidth={0} debounce={50}>
                                    <PieChart>
                                        <Pie
                                            data={summaryData}
                                            cx="50%"
                                            cy="50%"
                                            labelLine={false}
                                            outerRadius={80}
                                            fill="#8884d8"
                                            dataKey="value"
                                            nameKey="name"
                                            label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                                        >
                                            {summaryData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={pieChartColors[entry.name as WorkRequestStatus]} />
                                            ))}
                                        </Pie>
                                        <Tooltip />
                                    </PieChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No work requests found for the selected criteria.</p></div>
                    ) : (
                        <Table<WorkRequest> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
