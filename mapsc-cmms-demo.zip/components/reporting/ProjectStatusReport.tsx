
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { ProjectStatus, WorkOrderStatus, TransactionType, POStatus } from '../../types';
import type { Project, WorkOrder, User } from '../../types';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { useSettings } from '../../contexts/SettingsContext';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface ProjectStatusReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const statusColors: Record<ProjectStatus, 'blue' | 'yellow' | 'gray' | 'green'> = {
    [ProjectStatus.Planning]: 'blue',
    [ProjectStatus.InProgress]: 'yellow',
    [ProjectStatus.OnHold]: 'gray',
    [ProjectStatus.Completed]: 'green',
};

type ReportRow = {
    id: string; // Project ID
    projectName: string;
    status: ProjectStatus;
    startDate: string;
    endDate: string;
    budget: number;
    actualCost: number;
    variance: number;
    woCount: number;
    woCompletionRate: number;
};

export const ProjectStatusReport: React.FC<ProjectStatusReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [filters, setFilters] = useState({
        status: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<ReportRow[] | null>(null);
    const formatCurrency = useCurrencyFormatter();
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { projects, workOrders, parts, inventoryTransactions, laborLogs, assets, purchaseRequisitions, rfqs, purchaseOrders } = data;

    const convertToSystemCurrency = useCallback((value: number, fromCurrency: string): number => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
    }, [settings.currency, settings.exchangeRate]);

    const calculateWorkOrderCost = useCallback((wo: WorkOrder): number => {
        // 1. Parts (System Currency) - No conversion needed as parts unitCost is now stored in system currency
        const partsCost = inventoryTransactions
            .filter(t => t.workOrderId === wo.id && t.type === TransactionType.Issue)
            .reduce((total, transaction) => {
                const part = parts.find(p => p.id === transaction.partId);
                return total + ((part?.unitCost || 0) * transaction.quantity);
            }, 0);
        
        // 2. Labor (System Currency)
        const laborCost = laborLogs
            .filter(log => log.workOrderId === wo.id)
            .reduce((sum, log) => {
                const duration = (new Date(log.endTime).getTime() - new Date(log.startTime).getTime()) / (1000 * 60 * 60);
                return sum + (duration * settings.laborRatePerHour);
            }, 0);

        // 3. External POs (Convert from PO Currency)
        const linkedPRs = purchaseRequisitions.filter(pr => pr.workOrderId === wo.id);
        const linkedPRIds = new Set(linkedPRs.map(pr => pr.id));
        const linkedRFQs = rfqs.filter(rfq => linkedPRIds.has(rfq.prId));
        const linkedRFQIds = new Set(linkedRFQs.map(rfq => rfq.id));
        
        const linkedPOs = purchaseOrders.filter(po => 
            linkedRFQIds.has(po.rfqId) && 
            (po.status === POStatus.Received || po.status === POStatus.Closed || po.status === POStatus.PartiallyReceived)
        );

        const externalCost = linkedPOs.reduce((sum, po) => {
            const receivedTotal = po.items.reduce((itemSum, item) => {
                return itemSum + (item.quantityReceived * item.unitCost);
            }, 0);
            const totalWithTax = receivedTotal * (1 + po.taxRate);
            return sum + convertToSystemCurrency(totalWithTax, po.currency);
        }, 0);

        return partsCost + laborCost + externalCost;
    }, [parts, inventoryTransactions, laborLogs, settings.laborRatePerHour, purchaseRequisitions, rfqs, purchaseOrders, convertToSystemCurrency]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filteredProjects = projects.filter(proj => {
            const statusMatch = filters.status ? proj.status === filters.status : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const startDate = new Date(proj.startDate);
            
            if (from && startDate < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (startDate > to) return false;
            }
            
            return statusMatch;
        });
        
        const reportRows: ReportRow[] = filteredProjects.map(project => {
            // Filter Project WOs by Access Rights.
            const projectWOs = workOrders.filter(wo => {
                if (wo.projectId !== project.id) return false;
                const asset = assets.find(a => a.id === wo.assetId);
                const woZoneId = asset ? asset.zoneId : wo.zoneId;
                if (!canSeeAllZones && (!woZoneId || !accessibleZoneIds.includes(woZoneId))) {
                    return false;
                }
                return true;
            });

            const actualCost = projectWOs.reduce((sum, wo) => sum + calculateWorkOrderCost(wo), 0);
            const completedWOs = projectWOs.filter(wo => wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived).length;
            const woCount = projectWOs.length;
            const woCompletionRate = woCount > 0 ? (completedWOs / woCount) * 100 : 0;
            
            // Convert budget (assumed to be set in system currency when created, or handled otherwise)
            // For now assume project.budget is in system currency
            const variance = project.budget - actualCost;

            return {
                id: project.id,
                projectName: project.name,
                status: project.status,
                startDate: project.startDate,
                endDate: project.endDate,
                budget: project.budget,
                actualCost,
                variance,
                woCount,
                woCompletionRate,
            };
        });

        setReportData(reportRows);
    };

    const clearFilters = () => {
        setFilters({ status: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const summary = useMemo(() => {
        if (!reportData) return { totalBudget: 0, totalActual: 0, totalVariance: 0 };
        const totalBudget = reportData.reduce((sum, row) => sum + row.budget, 0);
        const totalActual = reportData.reduce((sum, row) => sum + row.actualCost, 0);
        return { totalBudget, totalActual, totalVariance: totalBudget - totalActual };
    }, [reportData]);
    
    const ProgressBar: React.FC<{ value: number }> = ({ value }) => {
        const percentage = Math.min(Math.max(value, 0), 100);
        const color = percentage >= 90 ? 'bg-green-500' : percentage >= 50 ? 'bg-blue-500' : 'bg-yellow-500';
        return (
             <div className="w-full bg-gray-200 rounded-full h-4 dark:bg-gray-700">
                <div
                    className={`${color} h-4 rounded-full text-center text-xs text-white`}
                    style={{ width: `${percentage}%` }}
                >
                   {value.toFixed(0)}%
                </div>
            </div>
        )
    };

    const columns = [
        { header: 'Project Name', accessor: 'projectName' as keyof ReportRow },
        { header: 'Status', accessor: (item: ReportRow) => <Badge color={statusColors[item.status]}>{item.status}</Badge> },
        { header: 'End Date', accessor: 'endDate' as keyof ReportRow },
        { header: 'Budget', accessor: (item: ReportRow) => formatCurrency(item.budget) },
        { header: 'Actual Cost', accessor: (item: ReportRow) => formatCurrency(item.actualCost) },
        { header: 'Variance', accessor: (item: ReportRow) => <span className={item.variance < 0 ? 'text-red-500 font-bold' : 'text-green-500'}>{formatCurrency(item.variance)}</span> },
        { header: 'WO Completion', accessor: (item: ReportRow) => <ProgressBar value={item.woCompletionRate} /> },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Project Status Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Status</label>
                    <select name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Statuses</option>
                        {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Start Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                 <div>
                    <label className={filterLabelClasses}>Start Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2 col-span-1 sm:col-span-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500">Select filters and click 'Run' to generate the report.</p></div>
            )}

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Report Summary</h4>
                        <div className="grid grid-cols-3 gap-4 mt-2 text-center">
                            <div><p className="text-sm text-gray-500">Total Budget</p><p className="text-2xl font-bold">{formatCurrency(summary.totalBudget)}</p></div>
                            <div><p className="text-sm text-gray-500">Total Actual Cost</p><p className="text-2xl font-bold">{formatCurrency(summary.totalActual)}</p></div>
                            <div>
                                <p className="text-sm text-gray-500">Overall Variance</p>
                                <p className={`text-2xl font-bold ${summary.totalVariance < 0 ? 'text-red-500' : 'text-green-500'}`}>{formatCurrency(summary.totalVariance)}</p>
                            </div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No projects found for the selected criteria.</p></div>
                    ) : (
                        <Table<ReportRow> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
