
import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderStatus } from '../../types';
import type { SafetyInstruction, WorkInstruction, SOP, User, WorkOrder } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface ProcedureUsageReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type Procedure = SafetyInstruction | WorkInstruction | SOP;

type ReportRow = {
    id: string; // Procedure ID
    description: string;
    type: 'Safety Instruction' | 'Work Instruction' | 'SOP';
    usageCount: number;
};

export const ProcedureUsageReport: React.FC<ProcedureUsageReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        procedureType: '',
        assetId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<ReportRow[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { workOrders, assets, safetyInstructions, workInstructions, sops, auditLog } = data;

    // Filter available assets for dropdown
    const availableAssets = useMemo(() => {
        return assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
    }, [assets, canSeeAllZones, accessibleZoneIds]);

    const allProcedures: (Procedure & { type: 'Safety Instruction' | 'Work Instruction' | 'SOP' })[] = useMemo(() => [
        ...safetyInstructions.map(p => ({ ...p, type: 'Safety Instruction' as const })),
        ...workInstructions.map(p => ({ ...p, type: 'Work Instruction' as const })),
        ...sops.map(p => ({ ...p, type: 'SOP' as const })),
    ], [safetyInstructions, workInstructions, sops]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    // Helper to get actual completion date
    const getCompletionDate = (wo: WorkOrder) => {
        const completionLog = auditLog.find(log => 
            log.entityType === 'WorkOrder' && 
            log.entityId === wo.id && 
            (log.details.includes('Completed work order') || log.details.includes("Status changed to 'Completed'"))
        );
        
        if (completionLog) {
            return new Date(completionLog.timestamp);
        }
        return new Date(wo.dueDate); // Fallback
    };

    const handleRunReport = () => {
        // Filter WOs by status, asset, and date range
        const filteredWOs = workOrders.filter(wo => {
            // Security Check
            const asset = assets.find(a => a.id === wo.assetId);
            const woZoneId = asset ? asset.zoneId : wo.zoneId;
            if (!canSeeAllZones && (!woZoneId || !accessibleZoneIds.includes(woZoneId))) {
                return false;
            }

            if (wo.status !== WorkOrderStatus.Completed && wo.status !== WorkOrderStatus.Archived) return false;
            
            const assetMatch = filters.assetId ? wo.assetId === filters.assetId : true;

            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            
            // Use actual completion date logic
            const completedDate = getCompletionDate(wo);

            if (from && completedDate < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (completedDate > to) return false;
            }

            return assetMatch;
        });

        // Count procedure usage
        const usageCounts = new Map<string, number>();
        filteredWOs.forEach(wo => {
            wo.procedureIds.forEach(procId => {
                usageCounts.set(procId, (usageCounts.get(procId) || 0) + 1);
            });
        });

        // Filter procedures by type
        const filteredProcedures = allProcedures.filter(proc =>
            filters.procedureType ? proc.type === filters.procedureType : true
        );

        // Build report rows
        const reportRows: ReportRow[] = filteredProcedures.map(proc => ({
            id: proc.id,
            description: proc.description,
            type: proc.type,
            usageCount: usageCounts.get(proc.id) || 0,
        })).sort((a, b) => b.usageCount - a.usageCount);

        setReportData(reportRows);
    };

    const clearFilters = () => {
        setFilters({ procedureType: '', assetId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };
    
    const summary = useMemo(() => {
        if (!reportData) return { totalUsed: 0, mostUsed: 'N/A' };
        const totalUsed = reportData.filter(row => row.usageCount > 0).length;
        const mostUsed = reportData.length > 0 && reportData[0].usageCount > 0 
            ? `${reportData[0].description} (${reportData[0].usageCount} times)` 
            : 'N/A';
        return { totalUsed, mostUsed };
    }, [reportData]);

    const columns = [
        { header: 'Procedure ID', accessor: 'id' as keyof ReportRow },
        { header: 'Description', accessor: 'description' as keyof ReportRow },
        { header: 'Type', accessor: 'type' as keyof ReportRow },
        { header: 'Usage Count', accessor: 'usageCount' as keyof ReportRow },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Procedure Usage Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Procedure Type</label>
                    <select name="procedureType" value={filters.procedureType} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Types</option>
                        <option value="Safety Instruction">Safety Instruction</option>
                        <option value="Work Instruction">Work Instruction</option>
                        <option value="SOP">SOP</option>
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Asset</label>
                    <select name="assetId" value={filters.assetId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Assets</option>
                        {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date Completed (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date Completed (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500">Select filters and click 'Run' to generate the report.</p></div>
            )}

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Report Summary</h4>
                        <div className="grid grid-cols-2 gap-4 mt-2 text-center">
                            <div><p className="text-sm text-gray-500">Total Unique Procedures Used</p><p className="text-2xl font-bold">{summary.totalUsed}</p></div>
                            <div><p className="text-sm text-gray-500">Most Used Procedure</p><p className="text-base font-bold text-indigo-600 dark:text-indigo-400 truncate" title={summary.mostUsed}>{summary.mostUsed}</p></div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No data found for the selected criteria.</p></div>
                    ) : (
                        <Table<ReportRow> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
