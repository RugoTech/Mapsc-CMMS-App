
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { TransactionType } from '../../types';
import type { InventoryTransaction, User } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface StockMovementReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const transactionTypeColors: Record<TransactionType, 'blue' | 'green' | 'yellow'> = {
    [TransactionType.Receipt]: 'green',
    [TransactionType.Issue]: 'blue',
    [TransactionType.Adjustment]: 'yellow',
};

export const StockMovementReport: React.FC<StockMovementReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        partId: '',
        type: '',
        userId: '',
        workOrderId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<InventoryTransaction[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { inventoryTransactions, parts, users, assets } = data;

    const getPartName = useCallback((partId: string) => parts.find(p => p.id === partId)?.name || 'N/A', [parts]);
    const getUserName = useCallback((userId: string) => users.find(u => u.id === userId)?.name || 'N/A', [users]);

    const availableParts = useMemo(() => {
        return parts.filter(part => {
            const asset = part.assetId ? assets.find(a => a.id === part.assetId) : null;
            const partZoneId = asset?.zoneId;
            return canSeeAllZones || !partZoneId || accessibleZoneIds.includes(partZoneId);
        });
    }, [parts, assets, canSeeAllZones, accessibleZoneIds]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filtered = inventoryTransactions.filter(t => {
            // 1. Security Check
            const part = parts.find(p => p.id === t.partId);
            if (!part) {
                // If part deleted, assume visible if admin or has access to all zones
                if (!canSeeAllZones) return false;
            } else {
                const asset = part.assetId ? assets.find(a => a.id === part.assetId) : null;
                const partZoneId = asset?.zoneId;
                const hasAccess = canSeeAllZones || !partZoneId || accessibleZoneIds.includes(partZoneId);
                if (!hasAccess) return false;
            }

            const partMatch = filters.partId ? t.partId === filters.partId : true;
            const typeMatch = filters.type ? t.type === filters.type : true;
            const userMatch = filters.userId ? t.userId === filters.userId : true;
            const woMatch = filters.workOrderId ? t.workOrderId && t.workOrderId.toLowerCase().includes(filters.workOrderId.toLowerCase()) : true;
            const dateFromMatch = filters.dateFrom ? t.date >= filters.dateFrom : true;
            const dateToMatch = filters.dateTo ? t.date <= filters.dateTo : true;
            return partMatch && typeMatch && userMatch && woMatch && dateFromMatch && dateToMatch;
        });
        setReportData(filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    };

    const clearFilters = () => {
        setFilters({
            partId: '',
            type: '',
            userId: '',
            workOrderId: '',
            dateFrom: '',
            dateTo: '',
        });
        setReportData(null);
    };

    const columns = [
        { header: 'Transaction ID', accessor: 'id' as keyof InventoryTransaction },
        { header: 'Part', accessor: (item: InventoryTransaction) => getPartName(item.partId) },
        { 
            header: 'Type', 
            accessor: (item: InventoryTransaction) => <Badge color={transactionTypeColors[item.type]}>{item.type}</Badge> 
        },
        { header: 'Quantity', accessor: 'quantity' as keyof InventoryTransaction },
        { header: 'Date', accessor: 'date' as keyof InventoryTransaction },
        { header: 'User', accessor: (item: InventoryTransaction) => getUserName(item.userId) },
        { header: 'Work Order', accessor: (item: InventoryTransaction) => item.workOrderId || 'N/A' },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card
            title="Stock Movement Report"
            actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}
        >
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Part</label>
                    <select name="partId" value={filters.partId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Parts</option>
                        {availableParts.map(part => <option key={part.id} value={part.id}>{part.name}</option>)}
                    </select>
                </div>
                 <div>
                    <label className={filterLabelClasses}>Transaction Type</label>
                    <select name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Types</option>
                        {Object.values(TransactionType).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>User</label>
                    <select name="userId" value={filters.userId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Users</option>
                        {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Work Order ID</label>
                    <input type="text" name="workOrderId" value={filters.workOrderId} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search WO ID..." />
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                 <div className="flex items-end space-x-2 col-span-1 sm:col-span-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10">
                    <p className="text-gray-500 dark:text-gray-400">Select filters and click 'Run Report' to generate the stock movement log.</p>
                </div>
            )}

            {reportData !== null && reportData.length === 0 && (
                 <div className="text-center py-10">
                    <p className="text-gray-500 dark:text-gray-400">No transactions found matching the selected criteria.</p>
                </div>
            )}

            {reportData !== null && reportData.length > 0 && (
                <Table<InventoryTransaction>
                    columns={columns}
                    data={reportData}
                />
            )}
        </Card>
    );
};
