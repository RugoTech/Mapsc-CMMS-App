
import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { useSettings } from '../../contexts/SettingsContext';
import type { User } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface LaborUtilizationReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type ReportRow = {
    id: string; // user id
    user: User;
    loggedHours: number;
    capacityHours: number;
    utilization: number;
};

const UtilizationBar: React.FC<{ utilization: number }> = ({ utilization }) => {
    const displayPercentage = Math.min(utilization, 100);
    
    let barColor = 'bg-green-500';
    if (utilization > 100) barColor = 'bg-red-500';
    else if (utilization > 85) barColor = 'bg-yellow-500';
    else if (utilization < 50) barColor = 'bg-blue-500';

    return (
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-5 relative">
            <div
                className={`${barColor} h-5 rounded-full transition-all duration-500`}
                style={{ width: `${displayPercentage}%` }}
            />
            <span className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-white mix-blend-lighten">
                {utilization.toFixed(0)}%
            </span>
        </div>
    );
};


export const LaborUtilizationReport: React.FC<LaborUtilizationReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [filters, setFilters] = useState({
        workCenterId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<ReportRow[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { laborLogs, users, workCenters, zones, plannerGroups, maintenanceControllers } = data;

    // Determine visible work centers based on zone access AND hierarchy
    const visibleWorkCenters = useMemo(() => {
        if (canSeeAllZones) return workCenters;

        // Hierarchy Check: Planner Group -> Maintenance Controller -> Work Center
        const userPlannerGroup = plannerGroups.find(pg => pg.userIds.includes(currentUser.id));

        if (userPlannerGroup) {
            // 1. Find Controller Groups linked to this Planner Group
            const linkedControllerGroups = maintenanceControllers.filter(cg => cg.plannerGroupId === userPlannerGroup.id);
            const linkedControllerGroupIds = new Set(linkedControllerGroups.map(cg => cg.id));

            // 2. Find Work Centers linked to these Controller Groups
            return workCenters.filter(wc => linkedControllerGroupIds.has(wc.controllerGroupId));
        }

        // Fallback for non-planner roles (Zone-based)
        const zoneNameMap: Record<string, string> = {
            'packaging': 'pkg',
            'utilities': 'utls',
        };

        const accessibleKeywords = accessibleZoneIds
            .map(zoneId => zones.find(z => z.id === zoneId)?.name.toLowerCase())
            .filter((name): name is string => !!name)
            .map(name => zoneNameMap[name])
            .filter((keyword): keyword is string => !!keyword);

        if (accessibleKeywords.length > 0) {
            return workCenters.filter(wc => {
                const wcNameLower = wc.name.toLowerCase();
                return accessibleKeywords.some(keyword => wcNameLower.includes(keyword));
            });
        }
        
        return [];
    }, [workCenters, zones, accessibleZoneIds, canSeeAllZones, plannerGroups, maintenanceControllers, currentUser.id]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        if (!filters.dateFrom || !filters.dateTo) {
            alert('Please select a full date range.');
            return;
        }

        const from = new Date(filters.dateFrom);
        const to = new Date(filters.dateTo);
        if (to < from) {
            alert('The "To" date must be after the "From" date.');
            return;
        }
        to.setHours(23, 59, 59, 999);
        
        const diffTime = to.getTime() - from.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const periodCapacity = (diffDays / 7) * settings.workWeekHours;
        
        const workCenterName = filters.workCenterId ? workCenters.find(wc => wc.id === filters.workCenterId)?.name : null;
        
        const visibleUserIds = new Set(visibleWorkCenters.flatMap(wc => wc.userIds));

        const relevantLogs = laborLogs.filter(log => {
            const logDate = new Date(log.startTime);
            return logDate >= from && logDate <= to && visibleUserIds.has(log.userId);
        });

        const userLoggedHours = new Map<string, number>();
        relevantLogs.forEach(log => {
            const duration = (new Date(log.endTime).getTime() - new Date(log.startTime).getTime()) / (1000 * 60 * 60);
            userLoggedHours.set(log.userId, (userLoggedHours.get(log.userId) || 0) + duration);
        });

        const report = users.filter(user => {
            // 1. Security Check: Must be in a visible work center
            if (!visibleUserIds.has(user.id)) return false;

            // 2. User Filter Check: Filter by Work Center if selected
            if (workCenterName && user.workCenter !== workCenterName) {
                return false;
            }

            const isStandardResource = user.role === 'Technician' || user.role === 'Engineer';
            const hasLoggedHours = (userLoggedHours.get(user.id) || 0) > 0;

            // Include if they are a standard resource OR if they have logged hours (e.g. Operators helping out)
            return isStandardResource || hasLoggedHours;
        }).map(user => {
            const logged = userLoggedHours.get(user.id) || 0;
            
            // Only standard resources (Technicians/Engineers) have a calculated capacity. 
            // Others (like Operators) are treated as 0 planned hours (extra capacity).
            const isStandardResource = user.role === 'Technician' || user.role === 'Engineer';
            const capacity = isStandardResource ? periodCapacity : 0;

            const utilization = capacity > 0 ? (logged / capacity) * 100 : 0;
            
            return { 
                id: user.id, 
                user, 
                loggedHours: logged, 
                capacityHours: capacity,
                utilization 
            };
        }).sort((a,b) => b.utilization - a.utilization);
        
        setReportData(report);
    };

    const clearFilters = () => {
        setFilters({ workCenterId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const summary = useMemo(() => {
        if (!reportData) return { totalLogged: 0, totalCapacity: 0, overallUtilization: 0 };
        const totalLogged = reportData.reduce((sum, row) => sum + row.loggedHours, 0);
        const totalCapacity = reportData.reduce((sum, row) => sum + row.capacityHours, 0);
        const overallUtilization = totalCapacity > 0 ? (totalLogged / totalCapacity) * 100 : 0;
        return { totalLogged, totalCapacity, overallUtilization };
    }, [reportData]);

    const columns = [
        { header: 'Personnel', accessor: (item: ReportRow) => item.user.name },
        { header: 'Role', accessor: (item: ReportRow) => item.user.role },
        { header: 'Work Center', accessor: (item: ReportRow) => item.user.workCenter },
        { header: 'Logged Hours', accessor: (item: ReportRow) => item.loggedHours.toFixed(2) },
        { header: 'Capacity (hrs)', accessor: (item: ReportRow) => item.capacityHours.toFixed(2) },
        { 
            header: 'Utilization', 
            accessor: (item: ReportRow) => {
                if (item.capacityHours === 0) {
                     return item.loggedHours > 0 ? <span className="text-yellow-600 font-medium">Extra ({item.loggedHours.toFixed(1)} hrs)</span> : <span className="text-gray-400">N/A</span>;
                }
                return <UtilizationBar utilization={item.utilization} />;
            }
        },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Labor Utilization Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Work Center</label>
                    <select name="workCenterId" value={filters.workCenterId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Work Centers</option>
                        {visibleWorkCenters.map(wc => <option key={wc.id} value={wc.id}>{wc.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500">Select filters and click 'Run' to generate the report.</p></div>
            )}

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Summary</h4>
                        <div className="grid grid-cols-3 gap-4 mt-2 text-center">
                            <div><p className="text-sm text-gray-500">Total Logged Hours</p><p className="text-2xl font-bold">{summary.totalLogged.toFixed(2)}</p></div>
                            <div><p className="text-sm text-gray-500">Total Planned Capacity</p><p className="text-2xl font-bold">{summary.totalCapacity.toFixed(2)}</p></div>
                            <div>
                                <p className="text-sm text-gray-500">Overall Utilization</p>
                                <p className="text-2xl font-bold text-indigo-600">{summary.overallUtilization.toFixed(0)}%</p>
                            </div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No labor data found for the selected criteria.</p></div>
                    ) : (
                        <Table<ReportRow> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
