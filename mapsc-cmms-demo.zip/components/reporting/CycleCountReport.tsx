
import React, { useContext, useState, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { CycleCountStatus } from '../../types';
import type { CycleCount, User } from '../../types';
import { useCurrencyFormatter } from '../../hooks/useCurrency';

interface CycleCountReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const statusColors: Record<CycleCountStatus, 'blue' | 'yellow' | 'green' | 'gray'> = {
    [CycleCountStatus.Scheduled]: 'blue',
    [CycleCountStatus.InProgress]: 'yellow',
    [CycleCountStatus.Completed]: 'green',
    [CycleCountStatus.Posted]: 'gray',
};

export const CycleCountReport: React.FC<CycleCountReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        status: '',
        location: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<CycleCount[] | null>(null);
    const formatCurrency = useCurrencyFormatter();

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { cycleCounts, parts } = data;

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filtered = cycleCounts.filter(cc => {
            const statusMatch = filters.status ? cc.status === filters.status : true;
            const locationMatch = filters.location ? cc.location.toLowerCase().includes(filters.location.toLowerCase()) : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const scheduledDate = new Date(cc.scheduledDate);
            
            if (from && scheduledDate < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (scheduledDate > to) return false;
            }
            
            return statusMatch && locationMatch;
        });
        setReportData(filtered);
    };

    const clearFilters = () => {
        setFilters({ status: '', location: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const calculateVarianceValue = (cc: CycleCount) => {
        if (!cc.countItems) return 0;
        return cc.countItems.reduce((sum, item) => {
            const variance = (item.countedQty ?? item.systemQty) - item.systemQty;
            const part = parts.find(p => p.id === item.partId);
            return sum + (variance * (part?.unitCost || 0));
        }, 0);
    };

    const summary = useMemo(() => {
        if (!reportData) return { totalCounts: 0, totalNetVariance: 0, accuracy: 0 };
        let totalItems = 0;
        let accurateItems = 0;
        let totalNetVariance = 0;

        reportData.forEach(cc => {
            totalNetVariance += calculateVarianceValue(cc);
            if (cc.countItems) {
                // Only consider items that have actually been counted (not null)
                const countedItems = cc.countItems.filter(item => item.countedQty !== null);
                totalItems += countedItems.length;
                accurateItems += countedItems.filter(item => item.countedQty === item.systemQty).length;
            }
        });

        const accuracy = totalItems > 0 ? (accurateItems / totalItems) * 100 : 0;

        return {
            totalCounts: reportData.length,
            totalNetVariance,
            accuracy,
        };
    }, [reportData, parts]);

    const columns = [
        { header: 'ID', accessor: 'id' as keyof CycleCount },
        { header: 'Location', accessor: 'location' as keyof CycleCount },
        { header: 'Date', accessor: 'scheduledDate' as keyof CycleCount },
        { header: 'Status', accessor: (cc: CycleCount) => <Badge color={statusColors[cc.status]}>{cc.status}</Badge> },
        { header: 'Net Variance', accessor: (cc: CycleCount) => {
            const val = calculateVarianceValue(cc);
            return <span className={val !== 0 ? (val > 0 ? 'text-green-600' : 'text-red-600') : ''}>{formatCurrency(val)}</span>
        }},
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Cycle Count Accuracy Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Status</label>
                    <select name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Statuses</option>
                        {Object.values(CycleCountStatus).map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Location</label>
                    <input type="text" name="location" value={filters.location} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search location..."/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2 col-span-full">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Summary</h4>
                        <div className="grid grid-cols-3 gap-4 mt-2 text-center">
                            <div><p className="text-sm text-gray-500">Total Counts Performed</p><p className="text-2xl font-bold">{summary.totalCounts}</p></div>
                            <div><p className="text-sm text-gray-500">Net Variance Value</p><p className={`text-2xl font-bold ${summary.totalNetVariance !== 0 ? 'text-red-600' : 'text-green-600'}`}>{formatCurrency(summary.totalNetVariance)}</p></div>
                            <div><p className="text-sm text-gray-500">Item Accuracy</p><p className="text-2xl font-bold text-indigo-600">{summary.accuracy.toFixed(1)}%</p></div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No records found.</p></div>
                    ) : (
                        <Table<CycleCount> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
