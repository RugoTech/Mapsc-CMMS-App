
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderType, WorkOrderStatus, TransactionType, POStatus } from '../../types';
import type { WorkOrder, User } from '../../types';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { useSettings } from '../../contexts/SettingsContext';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface MaintenanceCostReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type CostData = {
    id: string;
    wo: WorkOrder;
    partsCost: number;
    laborCost: number;
    externalCost: number;
    totalCost: number;
    completionDate: string;
};

export const MaintenanceCostReport: React.FC<MaintenanceCostReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [filters, setFilters] = useState({
        assetId: '',
        type: '',
        plannerGroupId: '',
        zoneId: '',
        workCenterId: '',
        projectId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<CostData[] | null>(null);
    const formatCurrency = useCurrencyFormatter();
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { workOrders, assets, parts, plannerGroups, zones, workCenters, projects, inventoryTransactions, laborLogs, purchaseRequisitions, rfqs, purchaseOrders, auditLog } = data;

    const getAssetName = useCallback((assetId?: string) => assets.find(a => a.id === assetId)?.name || 'N/A', [assets]);
    
    // Filter dropdowns
    const availableAssets = useMemo(() => {
        return assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
    }, [assets, canSeeAllZones, accessibleZoneIds]);

    const availableZones = useMemo(() => {
        return zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id));
    }, [zones, canSeeAllZones, accessibleZoneIds]);

    const convertToSystemCurrency = useCallback((value: number, fromCurrency: string): number => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
    }, [settings.currency, settings.exchangeRate]);

    const calculateCosts = useCallback((wo: WorkOrder): Omit<CostData, 'wo' | 'id' | 'completionDate'> => {
        // 1. Inventory Parts Cost (System Currency)
        const partsCost = inventoryTransactions
            .filter(t => t.workOrderId === wo.id && t.type === TransactionType.Issue)
            .reduce((total, transaction) => {
                const part = parts.find(p => p.id === transaction.partId);
                // Use raw unitCost as it is in system currency
                return total + ((part?.unitCost || 0) * transaction.quantity);
            }, 0);
        
        // 2. Labor Cost (System Currency)
        const laborCost = laborLogs
            .filter(log => log.workOrderId === wo.id)
            .reduce((sum, log) => {
                const duration = (new Date(log.endTime).getTime() - new Date(log.startTime).getTime()) / (1000 * 60 * 60);
                return sum + (duration * settings.laborRatePerHour);
            }, 0);

        // 3. External PO Costs
        const linkedPRs = purchaseRequisitions.filter(pr => pr.workOrderId === wo.id);
        const linkedPRIds = new Set(linkedPRs.map(pr => pr.id));
        const linkedRFQs = rfqs.filter(rfq => linkedPRIds.has(rfq.prId));
        const linkedRFQIds = new Set(linkedRFQs.map(rfq => rfq.id));
        
        const linkedPOs = purchaseOrders.filter(po => 
            linkedRFQIds.has(po.rfqId) && 
            (po.status === POStatus.Received || po.status === POStatus.Closed || po.status === POStatus.PartiallyReceived)
        );

        const externalCost = linkedPOs.reduce((sum, po) => {
            const receivedTotal = po.items.reduce((itemSum, item) => {
                return itemSum + (item.quantityReceived * item.unitCost);
            }, 0);
            const totalWithTax = receivedTotal * (1 + po.taxRate);
            return sum + convertToSystemCurrency(totalWithTax, po.currency);
        }, 0);

        return { partsCost, laborCost, externalCost, totalCost: partsCost + laborCost + externalCost };
    }, [parts, inventoryTransactions, laborLogs, settings.laborRatePerHour, purchaseRequisitions, rfqs, purchaseOrders, convertToSystemCurrency]);

    const getCompletionDate = useCallback((wo: WorkOrder) => {
        // Try to find completion event in audit log
        // We look for updates to this entity where details mention "Completed work order"
        // or if it's archived, we might find "Archived work order" (which usually happens after completion)
        // Ideally we find the transition to 'Completed' status.
        const completionLog = auditLog.find(log => 
            log.entityType === 'WorkOrder' && 
            log.entityId === wo.id && 
            (log.details.includes('Completed work order') || log.details.includes("Status changed to 'Completed'"))
        );
        
        if (completionLog) {
            return new Date(completionLog.timestamp).toISOString().split('T')[0];
        }
        
        // Fallback to dueDate if no log found (e.g. for mock data initialized as completed)
        return wo.dueDate;
    }, [auditLog]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filtered = workOrders
            .filter(wo => wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived)
            .filter(wo => {
                // Security Check
                const asset = assets.find(a => a.id === wo.assetId);
                const woZoneId = asset ? asset.zoneId : wo.zoneId;
                if (!canSeeAllZones && (!woZoneId || !accessibleZoneIds.includes(woZoneId))) {
                    return false;
                }

                const completionDate = getCompletionDate(wo);

                const assetMatch = filters.assetId ? wo.assetId === filters.assetId : true;
                const typeMatch = filters.type ? wo.workOrderType === filters.type : true;
                const plannerMatch = filters.plannerGroupId ? wo.planningGroupId === filters.plannerGroupId : true;
                const zoneMatch = filters.zoneId ? woZoneId === filters.zoneId : true;
                const workCenterMatch = filters.workCenterId ? wo.workCenterId === filters.workCenterId : true;
                const projectMatch = filters.projectId ? wo.projectId === filters.projectId : true;
                const dateFromMatch = filters.dateFrom ? completionDate >= filters.dateFrom : true;
                const dateToMatch = filters.dateTo ? completionDate <= filters.dateTo : true;
                
                return assetMatch && typeMatch && plannerMatch && zoneMatch && workCenterMatch && projectMatch && dateFromMatch && dateToMatch;
            })
            .map(wo => ({
                id: wo.id,
                wo,
                completionDate: getCompletionDate(wo),
                ...calculateCosts(wo)
            }));
        setReportData(filtered);
    };

    const clearFilters = () => {
        setFilters({
            assetId: '', type: '', plannerGroupId: '', zoneId: '', workCenterId: '', projectId: '', dateFrom: '', dateTo: '',
        });
        setReportData(null);
    };

    const { totalPartsCost, totalLaborCost, totalExternalCost, grandTotal } = useMemo(() => {
        if (!reportData) return { totalPartsCost: 0, totalLaborCost: 0, totalExternalCost: 0, grandTotal: 0 };
        return reportData.reduce((acc, item) => ({
            totalPartsCost: acc.totalPartsCost + item.partsCost,
            totalLaborCost: acc.totalLaborCost + item.laborCost,
            totalExternalCost: acc.totalExternalCost + item.externalCost,
            grandTotal: acc.grandTotal + item.totalCost,
        }), { totalPartsCost: 0, totalLaborCost: 0, totalExternalCost: 0, grandTotal: 0 });
    }, [reportData]);

    const columns = [
        { header: 'WO ID', accessor: (item: CostData) => item.wo.id },
        { header: 'Description', accessor: (item: CostData) => item.wo.description },
        { header: 'Asset', accessor: (item: CostData) => getAssetName(item.wo.assetId) },
        { header: 'Completion Date', accessor: (item: CostData) => item.completionDate },
        { header: 'Parts Cost', accessor: (item: CostData) => formatCurrency(item.partsCost) },
        { header: 'Labor Cost', accessor: (item: CostData) => formatCurrency(item.laborCost) },
        { header: 'External Cost', accessor: (item: CostData) => formatCurrency(item.externalCost) },
        { header: 'Total Cost', accessor: (item: CostData) => formatCurrency(item.totalCost) },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card
            title="Maintenance Cost Reports"
            actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}
        >
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                {/* Filters */}
                <div>
                    <label className={filterLabelClasses}>Asset</label>
                    <select name="assetId" value={filters.assetId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Assets</option>
                        {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>WO Type</label>
                    <select name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Types</option>
                        {Object.values(WorkOrderType).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
                 <div>
                    <label className={filterLabelClasses}>Planner Group</label>
                    <select name="plannerGroupId" value={filters.plannerGroupId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Groups</option>
                        {plannerGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                    </select>
                </div>
                 <div>
                    <label className={filterLabelClasses}>Zone</label>
                    <select name="zoneId" value={filters.zoneId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Zones</option>
                        {availableZones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Work Center</label>
                    <select name="workCenterId" value={filters.workCenterId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Centers</option>
                        {workCenters.map(wc => <option key={wc.id} value={wc.id}>{wc.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Project</label>
                    <select name="projectId" value={filters.projectId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Projects</option>
                        {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date Completed (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date Completed (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                 <div className="flex items-end space-x-2 col-span-full">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>
            
            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500 dark:text-gray-400">Select filters and click 'Run Report'.</p></div>
            )}

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Actual Cost Summary</h4>
                        <div className="grid grid-cols-4 gap-4 mt-2 text-center">
                            <div><p className="text-sm text-gray-500">Total Parts</p><p className="text-2xl font-bold">{formatCurrency(totalPartsCost)}</p></div>
                            <div><p className="text-sm text-gray-500">Total Labor</p><p className="text-2xl font-bold">{formatCurrency(totalLaborCost)}</p></div>
                            <div><p className="text-sm text-gray-500">Total External</p><p className="text-2xl font-bold">{formatCurrency(totalExternalCost)}</p></div>
                            <div><p className="text-sm text-gray-500">Grand Total</p><p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{formatCurrency(grandTotal)}</p></div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500 dark:text-gray-400">No work orders found matching the selected criteria.</p></div>
                    ) : (
                        <Table<CostData> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
