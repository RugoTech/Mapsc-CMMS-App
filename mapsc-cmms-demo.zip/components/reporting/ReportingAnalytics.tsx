

import React, { useState, useMemo, useEffect } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { WorkOrderReport } from './WorkOrderReport';
import { MaintenanceCostReport } from './MaintenanceCostReport';
import { InventoryValuationReport } from './InventoryValuationReport';
import { StockMovementReport } from './StockMovementReport';
import { LaborUtilizationReport } from './LaborUtilizationReport';
import { PMComplianceReport } from './PMComplianceReport';
import { AssetDowntimeReport } from './AssetDowntimeReport';
import { WorkRequestStatusReport } from './WorkRequestStatusReport';
import { ProcedureUsageReport } from './ProcedureUsageReport';
import { ProjectStatusReport } from './ProjectStatusReport';
import { MachineAvailabilityReport } from './MachineAvailabilityReport';
import { MTBFReport } from './MTBFReport';
import { MTTRReport } from './MTTRReport';
import { AssetHealthScoreReport } from './AssetHealthScoreReport';
import { MaintenanceMixReport } from './MaintenanceMixReport';
import { PurchaseRequisitionReport } from './PurchaseRequisitionReport';
import { PurchaseOrderReport } from './PurchaseOrderReport';
import { CycleCountReport } from './CycleCountReport';
import { useUserPermissions } from '../../hooks/useUserPermissions';
import type { View, User } from '../../types';


type Tab = 'Standard Reports' | 'Custom Reports';
export type ReportType = 'Maintenance Mix' | 'Work Order Summary & Details' | 'Maintenance Cost Reports' | 'Inventory Valuation' | 'Stock Movement Report' | 'Labor Utilization Report' | 'PM Compliance Report' | 'Asset Downtime Report' | 'Work Request Status Report' | 'Procedure Usage Report' | 'Project Status Reports' | 'Machine Availability' | 'MTBF' | 'MTTR' | 'Asset Health Score' | 'Purchase Requisition Report' | 'Purchase Order Report' | 'Cycle Count Report';

type ReportInfo = {
    title: string;
    description: string;
    requiredView: View;
};

const reports: ReportInfo[] = [
    { title: 'Maintenance Mix', description: 'Analyzes the ratio of preventive vs. corrective vs. breakdown maintenance.', requiredView: 'Reporting & Analytics' },
    { title: 'Work Order Summary & Details', description: 'Summarizes all work orders with options to drill down into details.', requiredView: 'Reporting & Analytics' },
    { title: 'Maintenance Cost Reports', description: 'Analyze costs by asset, type, planner/controller group, work center, and project.', requiredView: 'Reporting & Analytics' },
    { title: 'Inventory Valuation', description: 'Provides the total value of on-hand inventory based on unit cost.', requiredView: 'Reporting & Analytics' },
    { title: 'Stock Movement Report', description: 'Tracks all inventory transactions including issues, receipts, and adjustments.', requiredView: 'Reporting & Analytics' },
    { title: 'Labor Utilization Report', description: 'Shows labor hours and utilization rates with a breakdown by work center.', requiredView: 'Reporting & Analytics' },
    { title: 'PM Compliance Report', description: 'Measures the on-time completion rate of scheduled PMs, broken down by planner group.', requiredView: 'Reporting & Analytics' },
    { title: 'Asset Downtime Report', description: 'Tracks and analyzes asset downtime, frequency, and duration.', requiredView: 'Reporting & Analytics' },
    { title: 'Work Request Status Report', description: 'Summarizes work requests by their status (Pending, Approved, Rejected).', requiredView: 'Reporting & Analytics' },
    { title: 'Procedure Usage Report', description: 'Shows how frequently each maintenance procedure is used in work orders.', requiredView: 'Reporting & Analytics' },
    { title: 'Project Status Reports', description: 'Tracks project progress, budget vs. actuals, and task completion rates.', requiredView: 'Reporting & Analytics' },
    { title: 'Machine Availability', description: 'Measures machine availability over a selected period based on planned time and downtime.', requiredView: 'Reporting & Analytics' },
    { title: 'MTBF', description: 'Calculates the average time elapsed between inherent failures of a mechanical or electronic system.', requiredView: 'Reporting & Analytics' },
    { title: 'MTTR', description: 'Measures the average time required to troubleshoot and repair failed equipment.', requiredView: 'Reporting & Analytics' },
    { title: 'Asset Health Score', description: 'Calculates a health score for each asset based on maintenance history, open work, and PM compliance.', requiredView: 'Asset Health Score' },
    { title: 'Purchase Requisition Report', description: 'Analyzes Purchase Requisitions volume, status, and processing times.', requiredView: 'Report: Purchase Requisitions' },
    { title: 'Purchase Order Report', description: 'Tracks Purchase Orders, spend by vendor, and order status.', requiredView: 'Report: Purchase Orders' },
    { title: 'Cycle Count Report', description: 'Reviews inventory accuracy and variance trends from cycle counting.', requiredView: 'Report: Cycle Counts' },
];

const ManageQuickReportsModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    allReports: ReportInfo[];
    selectedKeys: string[];
    onSave: (keys: string[]) => void;
}> = ({ isOpen, onClose, allReports, selectedKeys, onSave }) => {
    const [tempSelection, setTempSelection] = useState(selectedKeys);

    useEffect(() => {
        if (isOpen) {
            setTempSelection(selectedKeys);
        }
    }, [isOpen, selectedKeys]);

    const handleCheckboxChange = (reportTitle: string, isChecked: boolean) => {
        if (isChecked) {
            setTempSelection(prev => [...prev, reportTitle]);
        } else {
            setTempSelection(prev => prev.filter(key => key !== reportTitle));
        }
    };
    
    const handleSave = () => {
        onSave(tempSelection);
        onClose();
    };

    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button variant="primary" onClick={handleSave}>Save Selections</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Manage Quick Reports" footer={modalFooter}>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Select the reports you want to see on your 'Custom Reports' tab for quick access.</p>
            <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                {allReports.map(report => (
                    <div key={report.title} className="flex items-center p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
                        <input
                            id={`report-checkbox-${report.title}`}
                            type="checkbox"
                            checked={tempSelection.includes(report.title)}
                            onChange={(e) => handleCheckboxChange(report.title, e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <label htmlFor={`report-checkbox-${report.title}`} className="ml-3 block text-sm font-medium text-gray-700 dark:text-gray-300">
                            {report.title}
                        </label>
                    </div>
                ))}
            </div>
        </Modal>
    );
};

const StandardReports: React.FC<{ onSelectReport: (reportTitle: ReportType) => void, reports: ReportInfo[] }> = ({ onSelectReport, reports }) => {
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reports.map(report => (
                <Card key={report.title} title={report.title}>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 h-10">{report.description}</p>
                    <Button 
                        variant="secondary" 
                        onClick={() => onSelectReport(report.title as ReportType)}
                    >
                        Run Report
                    </Button>
                </Card>
            ))}
        </div>
    );
};

const CustomReports: React.FC<{
    customReportKeys: string[];
    onOpenManageModal: () => void;
    onSelectReport: (reportTitle: ReportType) => void;
    allReports: ReportInfo[];
}> = ({ customReportKeys, onOpenManageModal, onSelectReport, allReports }) => {

    const customReports = useMemo(() => {
        return customReportKeys
            .map(key => allReports.find(r => r.title === key))
            .filter((r): r is ReportInfo => r !== undefined);
    }, [customReportKeys, allReports]);

    return (
        <Card title="My Quick Reports" actions={<Button onClick={onOpenManageModal}>Manage Quick Reports</Button>}>
            {customReports.length === 0 ? (
                <div className="text-center p-8">
                    <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">No quick reports selected</h3>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Click 'Manage Quick Reports' to add your favorites.</p>
                </div>
            ) : (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {customReports.map(report => (
                        <Card key={report.title} title={report.title}>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 h-10">{report.description}</p>
                            <Button 
                                variant="secondary" 
                                onClick={() => onSelectReport(report.title as ReportType)}
                            >
                                Run Report
                            </Button>
                        </Card>
                    ))}
                </div>
            )}
        </Card>
    );
};


interface ReportingAnalyticsProps {
  initialReport: ReportType | null;
  onClearReport: () => void;
  currentUser: User | null;
  customReportKeys: string[];
  setCustomReportKeys: React.Dispatch<React.SetStateAction<string[]>>;
}

export const ReportingAnalytics: React.FC<ReportingAnalyticsProps> = ({ initialReport, onClearReport, currentUser, customReportKeys, setCustomReportKeys }) => {
    const [activeTab, setActiveTab] = useState<Tab>(initialReport ? 'Standard Reports' : 'Standard Reports');
    const [activeReport, setActiveReport] = useState<ReportType | null>(initialReport);
    const [isManageModalOpen, setIsManageModalOpen] = useState(false);

    const permissions = useUserPermissions(currentUser);

    const accessibleReports = useMemo(() => {
        return reports.filter(report => permissions.includes(report.requiredView));
    }, [permissions]);

    useEffect(() => {
        // If an initialReport is passed, ensure we are on a tab that can display it.
        if (initialReport) {
            const isCustom = customReportKeys.includes(initialReport);
            setActiveTab(isCustom ? 'Custom Reports' : 'Standard Reports');
            setActiveReport(initialReport);
        }
    }, [initialReport, customReportKeys]);

    const handleBack = () => {
        setActiveReport(null);
        if (onClearReport) {
            onClearReport();
        }
    };
    
    const handleSelectReport = (reportTitle: ReportType) => {
        setActiveReport(reportTitle);
    };

    const renderActiveReport = () => {
        if (activeReport === 'Maintenance Mix') return <MaintenanceMixReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Work Order Summary & Details') return <WorkOrderReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Maintenance Cost Reports') return <MaintenanceCostReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Inventory Valuation') return <InventoryValuationReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Stock Movement Report') return <StockMovementReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Labor Utilization Report') return <LaborUtilizationReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'PM Compliance Report') return <PMComplianceReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Asset Downtime Report') return <AssetDowntimeReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Work Request Status Report') return <WorkRequestStatusReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Procedure Usage Report') return <ProcedureUsageReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Project Status Reports') return <ProjectStatusReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Machine Availability') return <MachineAvailabilityReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'MTBF') return <MTBFReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'MTTR') return <MTTRReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Asset Health Score') return <AssetHealthScoreReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Purchase Requisition Report') return <PurchaseRequisitionReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Purchase Order Report') return <PurchaseOrderReport onBack={handleBack} currentUser={currentUser} />;
        if (activeReport === 'Cycle Count Report') return <CycleCountReport onBack={handleBack} currentUser={currentUser} />;
        return null;
    };

    const renderTabContent = () => {
        const activeReportComponent = renderActiveReport();
        if (activeReportComponent) {
            return activeReportComponent;
        }

        switch (activeTab) {
            case 'Custom Reports':
                return <CustomReports 
                            customReportKeys={customReportKeys}
                            onOpenManageModal={() => setIsManageModalOpen(true)}
                            onSelectReport={handleSelectReport}
                            allReports={accessibleReports}
                        />;
            case 'Standard Reports':
            default:
                return <StandardReports onSelectReport={handleSelectReport} reports={accessibleReports} />;
        }
    }

    const tabs: Tab[] = ['Standard Reports', 'Custom Reports'];

    return (
        <div className="space-y-6">
            <div>
                <div className="border-b border-gray-200 dark:border-gray-700">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        {tabs.map((tab) => (
                            <button
                                key={tab}
                                onClick={() => {
                                    setActiveTab(tab);
                                    handleBack(); // Reset report view when changing tabs
                                }}
                                className={`${
                                    activeTab === tab
                                    ? 'border-indigo-500 text-indigo-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                            >
                            {tab}
                            </button>
                        ))}
                    </nav>
                </div>
                <div className="mt-6">
                    {renderTabContent()}
                </div>
            </div>
            <ManageQuickReportsModal
                isOpen={isManageModalOpen}
                onClose={() => setIsManageModalOpen(false)}
                allReports={accessibleReports}
                selectedKeys={customReportKeys}
                onSave={setCustomReportKeys}
            />
        </div>
    );
};
