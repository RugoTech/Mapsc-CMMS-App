
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { POStatus } from '../../types';
import type { PurchaseOrder, User } from '../../types';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { useCurrencyConverter } from '../../hooks/useCurrencyConverter';
import { useSettings } from '../../contexts/SettingsContext';

interface PurchaseOrderReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const statusColors: Record<POStatus, 'gray' | 'blue' | 'yellow' | 'green' | 'red'> = {
    [POStatus.Draft]: 'gray',
    [POStatus.PendingApproval]: 'blue',
    [POStatus.PendingHighValueApproval]: 'blue',
    [POStatus.Approved]: 'green',
    [POStatus.Rejected]: 'red',
    [POStatus.AddMoreInfo]: 'blue',
    [POStatus.Submitted]: 'yellow',
    [POStatus.PartiallyReceived]: 'yellow',
    [POStatus.Received]: 'green',
    [POStatus.Closed]: 'gray',
};

export const PurchaseOrderReport: React.FC<PurchaseOrderReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const { convert } = useCurrencyConverter();
    const formatCurrency = useCurrencyFormatter();
    
    const [filters, setFilters] = useState({
        status: '',
        vendorId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<PurchaseOrder[] | null>(null);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { purchaseOrders, vendors } = data;

    const getVendorName = useCallback((vendorId: string) => vendors.find(v => v.id === vendorId)?.name || 'N/A', [vendors]);

    const convertToDefault = useCallback((value: number, fromCurrency: string): number => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
    }, [settings.currency, settings.exchangeRate]);

    const calculateTotal = (po: PurchaseOrder) => {
        const subtotal = po.items.reduce((total, item) => total + item.quantity * item.unitCost, 0);
        return subtotal * (1 + po.taxRate);
    };

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filtered = purchaseOrders.filter(po => {
            const statusMatch = filters.status ? po.status === filters.status : true;
            const vendorMatch = filters.vendorId ? po.vendorId === filters.vendorId : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const orderDate = new Date(po.orderDate);
            
            if (from && orderDate < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (orderDate > to) return false;
            }
            
            return statusMatch && vendorMatch;
        });
        setReportData(filtered);
    };

    const clearFilters = () => {
        setFilters({ status: '', vendorId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };

    const summary = useMemo(() => {
        if (!reportData) return { totalCount: 0, totalValue: 0 };
        const totalValue = reportData.reduce((sum, po) => {
            const poTotal = calculateTotal(po);
            return sum + convertToDefault(poTotal, po.currency);
        }, 0);
        return {
            totalCount: reportData.length,
            totalValue,
        };
    }, [reportData, convertToDefault]);

    const columns = [
        { header: 'PO ID', accessor: 'id' as keyof PurchaseOrder },
        { header: 'Vendor', accessor: (po: PurchaseOrder) => getVendorName(po.vendorId) },
        { header: 'Date', accessor: 'orderDate' as keyof PurchaseOrder },
        { header: 'Status', accessor: (po: PurchaseOrder) => <Badge color={statusColors[po.status]}>{po.status}</Badge> },
        { header: 'Amount', accessor: (po: PurchaseOrder) => {
            const total = calculateTotal(po);
            return formatCurrency(convertToDefault(total, po.currency));
        }},
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Purchase Order Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Status</label>
                    <select name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Statuses</option>
                        {Object.values(POStatus).map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Vendor</label>
                    <select name="vendorId" value={filters.vendorId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Vendors</option>
                        {vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2 col-span-full">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Summary</h4>
                        <div className="grid grid-cols-2 gap-4 mt-2 text-center">
                            <div><p className="text-sm text-gray-500">Total POs</p><p className="text-2xl font-bold">{summary.totalCount}</p></div>
                            <div><p className="text-sm text-gray-500">Total Value ({settings.currency})</p><p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{formatCurrency(summary.totalValue)}</p></div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No records found.</p></div>
                    ) : (
                        <Table<PurchaseOrder> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
