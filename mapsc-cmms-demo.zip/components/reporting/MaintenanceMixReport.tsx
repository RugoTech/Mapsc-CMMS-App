
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderType } from '../../types';
import type { WorkOrder, User } from '../../types';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface MaintenanceMixReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const typeColors: Record<WorkOrderType, 'red' | 'yellow' | 'blue' | 'green'> = {
    [WorkOrderType.Breakdown]: 'red',
    [WorkOrderType.Corrective]: 'yellow',
    [WorkOrderType.Preventive]: 'blue',
    [WorkOrderType.Project]: 'green',
};

const pieChartColors = {
    [WorkOrderType.Preventive]: '#3b82f6', // blue-500
    [WorkOrderType.Corrective]: '#f59e0b', // amber-500
    [WorkOrderType.Breakdown]: '#ef4444', // red-500
    [WorkOrderType.Project]: '#22c55e', // green-500
};

const RADIAN = Math.PI / 180;
const renderCustomizedLabel = ({ cx, cy, midAngle, outerRadius, percent, name }: any) => {
  const radius = outerRadius + 25;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  const cos = Math.cos(-midAngle * RADIAN);
  const sx = cx + (outerRadius + 10) * cos;
  const sy = cy + (outerRadius + 10) * Math.sin(-midAngle * RADIAN);
  const textAnchor = cos >= 0 ? 'start' : 'end';

  return (
    <g>
      <path d={`M${sx},${sy}L${x},${y}`} stroke="#999" fill="none" />
      <text x={x + (cos >= 0 ? 1 : -1) * 4} y={y} textAnchor={textAnchor} fill="currentColor" dominantBaseline="central" fontSize={12}>
          {`${name} (${(percent * 100).toFixed(0)}%)`}
      </text>
    </g>
  );
};

export const MaintenanceMixReport: React.FC<MaintenanceMixReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        plantId: '',
        zoneId: '',
        assetId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<WorkOrder[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { workOrders, assets, plants, zones } = data;

    const getAssetName = useCallback((assetId?: string) => assets.find(a => a.id === assetId)?.name || 'N/A', [assets]);
    
    // Filter available options based on zone access
    const availableZones = useMemo(() => {
        let filtered = zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id));
        if (filters.plantId) {
            filtered = filtered.filter(z => z.plantId === filters.plantId);
        }
        return filtered;
    }, [filters.plantId, zones, canSeeAllZones, accessibleZoneIds]);

    const availableAssets = useMemo(() => {
        let filtered = assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
        if (filters.zoneId) filtered = filtered.filter(a => a.zoneId === filters.zoneId);
        if (filters.plantId) filtered = filtered.filter(a => a.plantId === filters.plantId);
        return filtered;
    }, [filters.plantId, filters.zoneId, assets, canSeeAllZones, accessibleZoneIds]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const relevantTypes: WorkOrderType[] = [WorkOrderType.Preventive, WorkOrderType.Corrective, WorkOrderType.Breakdown];
        const filtered = workOrders.filter(wo => {
            // 1. Security Check
            const asset = assets.find(a => a.id === wo.assetId);
            const zoneId = asset ? asset.zoneId : wo.zoneId;
            if (!canSeeAllZones && (!zoneId || !accessibleZoneIds.includes(zoneId))) {
                return false;
            }

            // 2. Type Check
            if (!relevantTypes.includes(wo.workOrderType)) {
                return false;
            }

            // 3. Filter Check
            const plantMatch = filters.plantId ? asset?.plantId === filters.plantId : true;
            const zoneMatch = filters.zoneId ? asset?.zoneId === filters.zoneId : true;
            const assetMatch = filters.assetId ? wo.assetId === filters.assetId : true;
            
            const from = filters.dateFrom ? new Date(filters.dateFrom) : null;
            const to = filters.dateTo ? new Date(filters.dateTo) : null;
            const created = new Date(wo.createdDate);
            
            if (from && created < from) return false;
            if (to) {
                to.setHours(23, 59, 59, 999);
                if (created > to) return false;
            }
            
            return plantMatch && zoneMatch && assetMatch;
        });
        setReportData(filtered);
    };
    
    const clearFilters = () => {
        setFilters({ plantId: '', zoneId: '', assetId: '', dateFrom: '', dateTo: '' });
        setReportData(null);
    };
    
    const summaryData = useMemo(() => {
        if (!reportData) return [];
        const typeCounts = reportData.reduce((acc, wo) => {
            acc[wo.workOrderType] = (acc[wo.workOrderType] || 0) + 1;
            return acc;
        }, {} as Record<WorkOrderType, number>);
        
        return Object.entries(typeCounts).map(([name, value]) => ({ name, value }));
    }, [reportData]);
    
    const columns = [
        { header: 'WO ID', accessor: 'id' as keyof WorkOrder },
        { header: 'Description', accessor: 'description' as keyof WorkOrder },
        { 
            header: 'Type', 
            accessor: (item: WorkOrder) => <Badge color={typeColors[item.workOrderType]}>{item.workOrderType}</Badge> 
        },
        { header: 'Asset', accessor: (item: WorkOrder) => getAssetName(item.assetId) },
        { header: 'Created Date', accessor: 'createdDate' as keyof WorkOrder },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Maintenance Mix Report" actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}>
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label className={filterLabelClasses}>Plant</label>
                    <select name="plantId" value={filters.plantId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Plants</option>
                        {plants.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                </div>
                 <div>
                    <label className={filterLabelClasses}>Zone</label>
                    <select name="zoneId" value={filters.zoneId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableZones.length === 0}>
                        <option value="">All Zones</option>
                        {availableZones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Asset</label>
                    <select name="assetId" value={filters.assetId} onChange={handleFilterChange} className={filterInputClasses} disabled={availableAssets.length === 0}>
                        <option value="">All Assets in Scope</option>
                        {availableAssets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (From)</label>
                    <input type="date" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label className={filterLabelClasses}>Date (To)</label>
                    <input type="date" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end space-x-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10"><p className="text-gray-500">Select filters and click 'Run' to generate the report.</p></div>
            )}
            
            {reportData !== null && (
                 <>
                    <Card className="mb-6">
                        <h4 className="font-semibold text-lg">Work Order Mix Summary</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                            <div className="md:col-span-1 flex flex-col justify-center space-y-2">
                                {summaryData.map(entry => (
                                    <div key={entry.name} className="flex justify-between items-center">
                                        <div className="flex items-center">
                                            <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: pieChartColors[entry.name as WorkOrderType] }}></span>
                                            <span>{entry.name}</span>
                                        </div>
                                        <span className="font-bold">{entry.value}</span>
                                    </div>
                                ))}
                                <div className="border-t pt-2 flex justify-between font-bold">
                                    <span>Total</span>
                                    <span>{reportData.length}</span>
                                </div>
                            </div>
                            <div className="md:col-span-2 h-56">
                                <ResponsiveContainer width="100%" height="100%" minWidth={0} debounce={50}>
                                    <PieChart>
                                        <Pie
                                            data={summaryData}
                                            cx="50%"
                                            cy="50%"
                                            labelLine={false}
                                            outerRadius={60}
                                            fill="#8884d8"
                                            dataKey="value"
                                            nameKey="name"
                                            label={renderCustomizedLabel}
                                        >
                                            {summaryData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={pieChartColors[entry.name as WorkOrderType]} />
                                            ))}
                                        </Pie>
                                        <Tooltip />
                                    </PieChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                        <div className="text-center py-10"><p className="text-gray-500">No work orders found for the selected criteria.</p></div>
                    ) : (
                        <Table<WorkOrder> columns={columns} data={reportData} />
                    )}
                </>
            )}
        </Card>
    );
};
