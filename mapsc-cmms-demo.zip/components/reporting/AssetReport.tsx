import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { AssetStatus } from '../../types';
import type { Asset } from '../../types';

interface AssetReportProps {
    onBack: () => void;
}

const statusColors: Record<AssetStatus, 'green' | 'yellow' | 'gray'> = {
    [AssetStatus.Operational]: 'green',
    [AssetStatus.UnderMaintenance]: 'yellow',
    [AssetStatus.Decommissioned]: 'gray',
};

export const AssetReport: React.FC<AssetReportProps> = ({ onBack }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        plant: '',
        zone: '',
        status: '',
    });
    const [reportData, setReportData] = useState<Asset[] | null>(null);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { assets, plants, zones } = data;

    const getPlantName = useCallback((plantId: string) => plants.find(p => p.id === plantId)?.name || 'N/A', [plants]);
    const getZoneName = useCallback((zoneId: string) => zones.find(z => z.id === zoneId)?.name || 'N/A', [zones]);
    
    const availableZones = useMemo(() => {
        if (!filters.plant) return zones;
        return zones.filter(zone => zone.plantId === filters.plant);
    }, [filters.plant, zones]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => {
            const newFilters = { ...prev, [name]: value };
            if (name === 'plant') {
                newFilters.zone = ''; // Reset zone when plant changes
            }
            return newFilters;
        });
    };

    const handleRunReport = () => {
        const filtered = assets.filter(asset => {
            const plantMatch = filters.plant ? asset.plantId === filters.plant : true;
            const zoneMatch = filters.zone ? asset.zoneId === filters.zone : true;
            const statusMatch = filters.status ? asset.status === filters.status : true;
            return plantMatch && zoneMatch && statusMatch;
        });
        setReportData(filtered);
    };

    const clearFilters = () => {
        setFilters({ plant: '', zone: '', status: '' });
        setReportData(null);
    };

    const columns = [
        { header: 'Asset ID', accessor: 'id' as keyof Asset },
        { header: 'Name', accessor: 'name' as keyof Asset },
        { header: 'Type', accessor: 'type' as keyof Asset },
        { header: 'Plant', accessor: (item: Asset) => getPlantName(item.plantId) },
        { header: 'Zone', accessor: (item: Asset) => getZoneName(item.zoneId) },
        {
          header: 'Status',
          accessor: (item: Asset) => (
            <Badge color={statusColors[item.status]}>{item.status}</Badge>
          ),
        },
        { header: 'Meter', accessor: (item: Asset) => item.meterId || 'N/A' },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card
            title="Asset List Report"
            actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}
        >
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="plant-filter" className={filterLabelClasses}>Plant</label>
                    <select id="plant-filter" name="plant" value={filters.plant} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Plants</option>
                        {plants.map(plant => <option key={plant.id} value={plant.id}>{plant.name}</option>)}
                    </select>
                </div>
                 <div>
                    <label htmlFor="zone-filter" className={filterLabelClasses}>Zone</label>
                    <select id="zone-filter" name="zone" value={filters.zone} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Zones</option>
                        {availableZones.map(zone => <option key={zone.id} value={zone.id}>{zone.name}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="status-filter" className={filterLabelClasses}>Status</label>
                    <select id="status-filter" name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Statuses</option>
                        {Object.values(AssetStatus).map(status => <option key={status} value={status}>{status}</option>)}
                    </select>
                </div>
                 <div className="flex items-end space-x-2 col-span-1 sm:col-span-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10">
                    <p className="text-gray-500 dark:text-gray-400">Select filters and click 'Run Report' to generate the asset list.</p>
                </div>
            )}

            {reportData !== null && reportData.length === 0 && (
                 <div className="text-center py-10">
                    <p className="text-gray-500 dark:text-gray-400">No assets found matching the selected criteria.</p>
                </div>
            )}

            {reportData !== null && reportData.length > 0 && (
                <Table<Asset>
                    columns={columns}
                    data={reportData}
                />
            )}
        </Card>
    );
};