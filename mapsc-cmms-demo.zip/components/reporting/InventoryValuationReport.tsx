
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { Part, User } from '../../types';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface InventoryValuationReportProps {
    onBack: () => void;
    currentUser: User | null;
}

type ValuationData = Part & {
    totalValue: number;
};

export const InventoryValuationReport: React.FC<InventoryValuationReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        location: '',
        type: '',
        vendorId: '',
    });
    const [reportData, setReportData] = useState<ValuationData[] | null>(null);
    const formatCurrency = useCurrencyFormatter();
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { parts, vendors, assets } = data;

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filtered = parts
            .filter(part => {
                // 1. Security Check (Zone Access)
                const asset = part.assetId ? assets.find(a => a.id === part.assetId) : null;
                const partZoneId = asset?.zoneId;
                const hasAccess = canSeeAllZones || !partZoneId || accessibleZoneIds.includes(partZoneId);
                if (!hasAccess) return false;

                // 2. User Filters
                const locationMatch = filters.location ? part.location.toLowerCase().includes(filters.location.toLowerCase()) : true;
                const typeMatch = filters.type ? part.type === filters.type : true;
                const vendorMatch = filters.vendorId ? part.vendorId === filters.vendorId : true;
                return locationMatch && typeMatch && vendorMatch;
            })
            .map(part => {
                // Assume input cost is already in system currency
                return {
                    ...part,
                    totalValue: part.quantity * part.unitCost,
                };
            });
        setReportData(filtered);
    };

    const clearFilters = () => {
        setFilters({ location: '', type: '', vendorId: '' });
        setReportData(null);
    };
    
    const totalInventoryValue = useMemo(() => {
        if (!reportData) return 0;
        return reportData.reduce((sum, item) => sum + item.totalValue, 0);
    }, [reportData]);


    const columns = [
        { header: 'Part Number', accessor: 'partNumber' as keyof ValuationData },
        { header: 'Name', accessor: 'name' as keyof ValuationData },
        { header: 'Location', accessor: 'location' as keyof ValuationData },
        { header: 'Type', accessor: 'type' as keyof ValuationData },
        { header: 'On Hand Qty', accessor: 'quantity' as keyof ValuationData },
        { header: 'Unit Cost', accessor: (item: ValuationData) => formatCurrency(item.unitCost) },
        { header: 'Total Value', accessor: (item: ValuationData) => formatCurrency(item.totalValue) },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card
            title="Inventory Valuation Report"
            actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}
        >
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="location-filter" className={filterLabelClasses}>Location</label>
                    <input type="text" id="location-filter" name="location" value={filters.location} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search location..."/>
                </div>
                 <div>
                    <label htmlFor="type-filter" className={filterLabelClasses}>Type</label>
                    <select id="type-filter" name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Types</option>
                        <option value="Stock">Stock</option>
                        <option value="Non-stock">Non-stock</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="vendor-filter" className={filterLabelClasses}>Vendor</label>
                    <select id="vendor-filter" name="vendorId" value={filters.vendorId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Vendors</option>
                        {vendors.map(vendor => <option key={vendor.id} value={vendor.id}>{vendor.name}</option>)}
                    </select>
                </div>
                 <div className="flex items-end space-x-2 col-span-1 sm:col-span-2">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10">
                    <p className="text-gray-500 dark:text-gray-400">Select filters and click 'Run Report' to generate the inventory valuation.</p>
                </div>
            )}
            
            {reportData !== null && (
                <>
                    <Card className="mb-6">
                        <div className="text-center">
                            <p className="text-sm text-gray-500">Total Inventory Value</p>
                            <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{formatCurrency(totalInventoryValue)}</p>
                        </div>
                    </Card>

                    {reportData.length === 0 ? (
                         <div className="text-center py-10">
                            <p className="text-gray-500 dark:text-gray-400">No parts found matching the selected criteria.</p>
                        </div>
                    ) : (
                        <Table<ValuationData>
                            columns={columns}
                            data={reportData}
                        />
                    )}
                </>
            )}
        </Card>
    );
};
