
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { WorkOrderStatus, Priority, WorkOrderType } from '../../types';
import type { WorkOrder, User } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface WorkOrderReportProps {
    onBack: () => void;
    currentUser: User | null;
}

const statusColors: Record<WorkOrderStatus, 'blue' | 'yellow' | 'green' | 'gray' | 'red'> = {
    [WorkOrderStatus.Open]: 'blue',
    [WorkOrderStatus.InProgress]: 'yellow',
    [WorkOrderStatus.Completed]: 'green',
    [WorkOrderStatus.Archived]: 'gray',
    [WorkOrderStatus.Cancelled]: 'red',
};

const priorityColors: Record<Priority, 'blue' | 'yellow' | 'red'> = {
    [Priority.Low]: 'blue',
    [Priority.Medium]: 'yellow',
    [Priority.High]: 'red',
    [Priority.Critical]: 'red',
};

const typeColors: Record<WorkOrderType, 'red' | 'yellow' | 'blue' | 'green'> = {
    [WorkOrderType.Breakdown]: 'red',
    [WorkOrderType.Corrective]: 'yellow',
    [WorkOrderType.Preventive]: 'blue',
    [WorkOrderType.Project]: 'green',
};


export const WorkOrderReport: React.FC<WorkOrderReportProps> = ({ onBack, currentUser }) => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        status: '',
        priority: '',
        type: '',
        assetId: '',
        zoneId: '',
        dateFrom: '',
        dateTo: '',
    });
    const [reportData, setReportData] = useState<WorkOrder[] | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { workOrders, assets, zones } = data;

    const getAssetName = useCallback((assetId?: string) => assets.find(a => a.id === assetId)?.name || 'N/A', [assets]);

    const getZoneName = useCallback((workOrder: WorkOrder) => {
        const woZoneId = workOrder.assetId ? assets.find(a => a.id === workOrder.assetId)?.zoneId : workOrder.zoneId;
        if (woZoneId) {
            return zones.find(z => z.id === woZoneId)?.name || 'N/A';
        }
        return 'N/A';
    }, [assets, zones]);

    // Filter lists for dropdowns
    const availableAssets = useMemo(() => {
        return assets.filter(a => canSeeAllZones || accessibleZoneIds.includes(a.zoneId));
    }, [assets, canSeeAllZones, accessibleZoneIds]);

    const availableZones = useMemo(() => {
        return zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id));
    }, [zones, canSeeAllZones, accessibleZoneIds]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleRunReport = () => {
        const filtered = workOrders.filter(wo => {
            // Security Check
            const asset = assets.find(a => a.id === wo.assetId);
            const woZoneId = asset ? asset.zoneId : wo.zoneId;
            if (!canSeeAllZones && (!woZoneId || !accessibleZoneIds.includes(woZoneId))) {
                return false;
            }

            const statusMatch = filters.status ? wo.status === filters.status : true;
            const priorityMatch = filters.priority ? wo.priority === filters.priority : true;
            const typeMatch = filters.type ? wo.workOrderType === filters.type : true;
            const assetMatch = filters.assetId ? wo.assetId === filters.assetId : true;
            const zoneMatch = filters.zoneId ? woZoneId === filters.zoneId : true;
            const dateFromMatch = filters.dateFrom ? wo.dueDate >= filters.dateFrom : true;
            const dateToMatch = filters.dateTo ? wo.dueDate <= filters.dateTo : true;
            return statusMatch && priorityMatch && typeMatch && assetMatch && zoneMatch && dateFromMatch && dateToMatch;
        });
        setReportData(filtered);
    };

    const clearFilters = () => {
        setFilters({
            status: '',
            priority: '',
            type: '',
            assetId: '',
            zoneId: '',
            dateFrom: '',
            dateTo: '',
        });
        setReportData(null);
    };

    const columns = [
        { header: 'WO ID', accessor: 'id' as keyof WorkOrder },
        { header: 'Description', accessor: 'description' as keyof WorkOrder },
        { 
            header: 'Type', 
            accessor: (item: WorkOrder) => <Badge color={typeColors[item.workOrderType]}>{item.workOrderType}</Badge> 
        },
        { header: 'Asset', accessor: (item: WorkOrder) => getAssetName(item.assetId) },
        { header: 'Zone', accessor: (item: WorkOrder) => getZoneName(item) },
        { header: 'Priority', accessor: (item: WorkOrder) => <Badge color={priorityColors[item.priority]}>{item.priority}</Badge> },
        { header: 'Status', accessor: (item: WorkOrder) => <Badge color={statusColors[item.status]}>{item.status}</Badge> },
        { header: 'Due Date', accessor: 'dueDate' as keyof WorkOrder },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card
            title="Work Order Summary & Details Report"
            actions={<Button variant="secondary" onClick={onBack}>Back to Reports</Button>}
        >
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="status-filter" className={filterLabelClasses}>Status</label>
                    <select id="status-filter" name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Statuses</option>
                        {Object.values(WorkOrderStatus).map(status => <option key={status} value={status}>{status}</option>)}
                    </select>
                </div>
                 <div>
                    <label htmlFor="priority-filter" className={filterLabelClasses}>Priority</label>
                    <select id="priority-filter" name="priority" value={filters.priority} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Priorities</option>
                        {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="type-filter" className={filterLabelClasses}>Type</label>
                    <select id="type-filter" name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Types</option>
                        {Object.values(WorkOrderType).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="asset-filter" className={filterLabelClasses}>Asset</label>
                    <select id="asset-filter" name="assetId" value={filters.assetId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Assets</option>
                        {availableAssets.map(asset => <option key={asset.id} value={asset.id}>{asset.name}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="zone-filter" className={filterLabelClasses}>Zone</label>
                    <select id="zone-filter" name="zoneId" value={filters.zoneId} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Zones</option>
                        {availableZones.map(zone => <option key={zone.id} value={zone.id}>{zone.name}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="dateFrom-filter" className={filterLabelClasses}>Due Date (From)</label>
                    <input type="date" id="dateFrom-filter" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label htmlFor="dateTo-filter" className={filterLabelClasses}>Due Date (To)</label>
                    <input type="date" id="dateTo-filter" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                 <div className="flex items-end space-x-2 col-span-1 sm:col-span-full">
                    <Button onClick={handleRunReport} variant="primary" className="w-full">Run Report</Button>
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            {reportData === null && (
                <div className="text-center py-10">
                    <p className="text-gray-500 dark:text-gray-400">Select filters and click 'Run Report' to generate the work order list.</p>
                </div>
            )}

            {reportData !== null && reportData.length === 0 && (
                 <div className="text-center py-10">
                    <p className="text-gray-500 dark:text-gray-400">No work orders found matching the selected criteria.</p>
                </div>
            )}

            {reportData !== null && reportData.length > 0 && (
                <Table<WorkOrder>
                    columns={columns}
                    data={reportData}
                />
            )}
        </Card>
    );
};
