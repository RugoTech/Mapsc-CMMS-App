import React, { useContext, useMemo, useState } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { CostCenter } from '../../types';

type CostCenterDetail = {
    id: string;
    fullCode: string;
    plant: string;
    zone: string;
    section: string;
    account: string;
    dateCreated: string;
};

export const CostCenters: React.FC = () => {
    const context = useContext(DataContext);
    const [filters, setFilters] = useState({
        fullCode: '',
        zone: '',
        section: '',
        account: '',
        dateCreated: '',
    });

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { costCenters, plantCostCodes, zoneCostCodes, sectionCostCodes, accountCostCodes } = data;

    const costCenterDetails: CostCenterDetail[] = useMemo(() => {
        return costCenters.map(cc => {
            const pcc = plantCostCodes.find(c => c.id === cc.plantCostCodeId);
            const zcc = zoneCostCodes.find(c => c.id === cc.zoneCostCodeId);
            const scc = sectionCostCodes.find(c => c.id === cc.sectionCostCodeId);
            const acc = accountCostCodes.find(c => c.id === cc.accountCostCodeId);
            
            const fullCode = [pcc?.code, zcc?.code, scc?.code, acc?.code].join('-');

            return {
                id: cc.id,
                fullCode,
                plant: pcc?.name || 'N/A',
                zone: zcc?.name || 'N/A',
                section: scc?.name || 'N/A',
                account: acc?.name || 'N/A',
                dateCreated: cc.dateCreated,
            };
        });
    }, [costCenters, plantCostCodes, zoneCostCodes, sectionCostCodes, accountCostCodes]);
    
    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({ fullCode: '', zone: '', section: '', account: '', dateCreated: '' });
    };

    const filteredCostCenterDetails = useMemo(() => {
        return costCenterDetails.filter(cc => {
            const fullCodeMatch = filters.fullCode ? cc.fullCode.toLowerCase().includes(filters.fullCode.toLowerCase()) : true;
            const zoneMatch = filters.zone ? cc.zone.toLowerCase().includes(filters.zone.toLowerCase()) : true;
            const sectionMatch = filters.section ? cc.section.toLowerCase().includes(filters.section.toLowerCase()) : true;
            const accountMatch = filters.account ? cc.account.toLowerCase().includes(filters.account.toLowerCase()) : true;
            const dateMatch = filters.dateCreated ? cc.dateCreated === filters.dateCreated : true;

            return fullCodeMatch && zoneMatch && sectionMatch && accountMatch && dateMatch;
        });
    }, [costCenterDetails, filters]);

    const columns = [
        { header: 'Full Code', accessor: 'fullCode' as keyof CostCenterDetail },
        { header: 'Plant', accessor: 'plant' as keyof CostCenterDetail },
        { header: 'Zone', accessor: 'zone' as keyof CostCenterDetail },
        { header: 'Section', accessor: 'section' as keyof CostCenterDetail },
        { header: 'Account', accessor: 'account' as keyof CostCenterDetail },
        { header: 'Date Created', accessor: 'dateCreated' as keyof CostCenterDetail },
    ];
    
    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Cost Centers">
             <p className="text-gray-500 dark:text-gray-400 mb-4">
                This table shows the detailed breakdown of cost centers, formed by combining Plant, Zone, Section, and Account codes.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="fullCode-filter" className={filterLabelClasses}>Full Code</label>
                    <input type="text" id="fullCode-filter" name="fullCode" value={filters.fullCode} onChange={handleFilterChange} className={filterInputClasses} placeholder="e.g., 100-200..."/>
                </div>
                 <div>
                    <label htmlFor="zone-filter" className={filterLabelClasses}>Zone</label>
                    <input type="text" id="zone-filter" name="zone" value={filters.zone} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search zone..."/>
                </div>
                 <div>
                    <label htmlFor="section-filter" className={filterLabelClasses}>Section</label>
                    <input type="text" id="section-filter" name="section" value={filters.section} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search section..."/>
                </div>
                 <div>
                    <label htmlFor="account-filter" className={filterLabelClasses}>Account</label>
                    <input type="text" id="account-filter" name="account" value={filters.account} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search account..."/>
                </div>
                <div>
                    <label htmlFor="dateCreated-filter" className={filterLabelClasses}>Date Created</label>
                    <input type="date" id="dateCreated-filter" name="dateCreated" value={filters.dateCreated} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end">
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            <Table<CostCenterDetail>
                columns={columns}
                data={filteredCostCenterDetails}
            />
             <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <h4 className="font-semibold mb-2">Note:</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                    Management of individual code types (Plant, Zone, Section, Account) will be available in a future update.
                </p>
            </div>
        </Card>
    );
};