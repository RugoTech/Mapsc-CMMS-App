import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { Budget } from '../../types';
import { useCurrencyConverter } from '../../hooks/useCurrencyConverter';


const BudgetProgressBar: React.FC<{ spent: number, amount: number }> = ({ spent, amount }) => {
    const { convertAndFormat: formatCurrency } = useCurrencyConverter({ minimumFractionDigits: 0, maximumFractionDigits: 0 });
    const percentage = amount > 0 ? (spent / amount) * 100 : 0;
    const color = percentage > 90 ? 'bg-red-500' : percentage > 75 ? 'bg-yellow-500' : 'bg-green-500';

    return (
        <div className="w-full bg-gray-200 rounded-full h-4 dark:bg-gray-700 relative">
            <div
                className={`${color} h-4 rounded-full`}
                style={{ width: `${Math.min(percentage, 100)}%` }}
            ></div>
             <span className="absolute inset-0 flex items-center justify-center text-xs font-medium text-white mix-blend-lighten">
                {formatCurrency(spent)}
            </span>
        </div>
    );
};

export const Budgets: React.FC = () => {
    const context = useContext(DataContext);
    const { convertAndFormat: formatCurrency } = useCurrencyConverter({ minimumFractionDigits: 0, maximumFractionDigits: 0 });
    const [filters, setFilters] = useState({
        name: '',
        zone: '',
        fiscalYear: '',
    });

    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const { budgets, costCenters, plantCostCodes, zoneCostCodes, sectionCostCodes, accountCostCodes } = data;

    const fiscalYears = useMemo(() => {
        const years = new Set(budgets.map(b => b.fiscalYear));
        return Array.from(years).sort((a: number, b: number) => b - a);
    }, [budgets]);

    const getCostCenterName = useCallback((costCenterId: string) => {
        const cc = costCenters.find(c => c.id === costCenterId);
        if (!cc) return 'N/A';
        const pcc = plantCostCodes.find(c => c.id === cc.plantCostCodeId)?.name || '';
        const zcc = zoneCostCodes.find(c => c.id === cc.zoneCostCodeId)?.name || '';
        const scc = sectionCostCodes.find(c => c.id === cc.sectionCostCodeId)?.name || '';
        const acc = accountCostCodes.find(c => c.id === cc.accountCostCodeId)?.name || '';
        return `${pcc} - ${zcc} - ${scc} - ${acc}`;
    }, [costCenters, plantCostCodes, zoneCostCodes, sectionCostCodes, accountCostCodes]);

    const getZoneNameFromCC = useCallback((costCenterId: string) => {
        const cc = costCenters.find(c => c.id === costCenterId);
        if (!cc) return 'N/A';
        const zcc = zoneCostCodes.find(c => c.id === cc.zoneCostCodeId);
        return zcc?.name || 'N/A';
    }, [costCenters, zoneCostCodes]);

    const filteredBudgets = useMemo(() => {
        return budgets.filter(budget => {
            const nameMatch = filters.name ? budget.name.toLowerCase().includes(filters.name.toLowerCase()) : true;
            
            const cc = costCenters.find(c => c.id === budget.costCenterId);
            const zoneMatch = filters.zone ? cc?.zoneCostCodeId === filters.zone : true;

            const yearMatch = filters.fiscalYear ? budget.fiscalYear.toString() === filters.fiscalYear : true;

            return nameMatch && zoneMatch && yearMatch;
        });
    }, [budgets, filters, costCenters]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({ name: '', zone: '', fiscalYear: '' });
    };

    const columns = [
        { header: 'Budget Name', accessor: 'name' as keyof Budget },
        { header: 'Zone', accessor: (item: Budget) => getZoneNameFromCC(item.costCenterId) },
        { header: 'Cost Center', accessor: (item: Budget) => <div className="text-xs">{getCostCenterName(item.costCenterId)}</div> },
        { header: 'Fiscal Year', accessor: 'fiscalYear' as keyof Budget },
        { header: 'Amount', accessor: (item: Budget) => formatCurrency(item.amount) },
        { 
            header: 'Spent', 
            accessor: (item: Budget) => <BudgetProgressBar spent={item.spent} amount={item.amount} />
        },
        { 
            header: 'Remaining', 
            accessor: (item: Budget) => {
                const remaining = item.amount - item.spent;
                const isOverBudget = remaining < 0;
                return (
                    <span className={isOverBudget ? 'text-red-500 font-bold' : ''}>
                        {formatCurrency(remaining)}
                    </span>
                );
            }
        },
    ];

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <Card title="Budgets" actions={<Button onClick={() => alert('Add Budget functionality coming soon!')}>Add Budget</Button>}>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="name-filter" className={filterLabelClasses}>Budget Name</label>
                    <input type="text" id="name-filter" name="name" value={filters.name} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search name..."/>
                </div>
                <div>
                    <label htmlFor="zone-filter" className={filterLabelClasses}>Zone</label>
                    <select id="zone-filter" name="zone" value={filters.zone} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Zones</option>
                        {zoneCostCodes.map(zone => <option key={zone.id} value={zone.id}>{zone.name}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="fiscalYear-filter" className={filterLabelClasses}>Fiscal Year</label>
                    <select id="fiscalYear-filter" name="fiscalYear" value={filters.fiscalYear} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Years</option>
                        {fiscalYears.map(year => <option key={year} value={year}>{year}</option>)}
                    </select>
                </div>
                <div className="flex items-end">
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>
            <Table<Budget>
                columns={columns}
                data={filteredBudgets}
                renderRowActions={(budget) => (
                    <Button variant="secondary" size="sm" onClick={() => alert(`Editing budget ${budget.id}`)}>Edit</Button>
                )}
            />
        </Card>
    );
};