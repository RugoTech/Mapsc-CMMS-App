
import React, { useState, useContext, useMemo, useCallback } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import type { User, ControllerGroup, WorkCenter, LogisticsManagementGroup, AssetManagementGroup, PlannerGroup, ClerkGroup, MockData, TopManagementGroup, AuditLogEntry, SystemAdminGroup, EngineerGroup, Department } from '../../types';
import { UserForm } from './UserForm';
import { GroupForm } from './GroupForm';
import { DepartmentForm } from './DepartmentForm';

type Group = 
  | SystemAdminGroup 
  | TopManagementGroup 
  | AssetManagementGroup 
  | LogisticsManagementGroup 
  | EngineerGroup 
  | PlannerGroup 
  | ClerkGroup 
  | ControllerGroup 
  | WorkCenter;

type Tab = 
  | 'Register' 
  | 'Departments' 
  | 'System Admins' 
  | 'Top Management' 
  | 'Managers-Asset' 
  | 'Managers-Logistics' 
  | 'Engineers' 
  | 'Planning Group' 
  | 'Logistics Clerks' 
  | 'Maintenance Clerks' 
  | 'Maintenance Controllers' 
  | 'Logistics Controllers' 
  | 'Work Center Group';

const PersonnelRegister: React.FC<{ onAdd: () => void; onEdit: (user: User) => void; onDelete: (user: User) => void; currentUser: User | null }> = ({ onAdd, onEdit, onDelete, currentUser }) => {
    const context = useContext(DataContext);
    const [filter, setFilter] = useState('');

    if (!context) return null;
    const { users, systemAdmins } = context.data;

    const filteredUsers = users.filter(u => 
        u.name.toLowerCase().includes(filter.toLowerCase()) ||
        u.role.toLowerCase().includes(filter.toLowerCase()) ||
        u.department.toLowerCase().includes(filter.toLowerCase())
    );

    const columns = [
        { header: 'User ID', accessor: 'id' as keyof User },
        { header: 'Name', accessor: 'name' as keyof User },
        { header: 'Role', accessor: 'role' as keyof User },
        { header: 'Department', accessor: 'department' as keyof User },
        { header: 'Work Center/Group', accessor: 'workCenter' as keyof User },
        { 
            header: 'Status', 
            accessor: (user: User) => <Badge color={user.isActive !== false ? 'green' : 'red'}>{user.isActive !== false ? 'Active' : 'Inactive'}</Badge> 
        },
    ];

    const canManage = useMemo(() => {
        if (!currentUser) return false;
        // Strictly limit to System Administrators Group
        return systemAdmins.some(g => g.userIds.includes(currentUser.id));
    }, [currentUser, systemAdmins]);

    return (
        <Card title="Personnel Register" actions={canManage && <Button onClick={onAdd}>Add User</Button>}>
            <div className="mb-4">
                <input 
                    type="text" 
                    placeholder="Search personnel..." 
                    className="w-full md:w-1/3 px-3 py-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
                    value={filter}
                    onChange={e => setFilter(e.target.value)}
                />
            </div>
            <Table<User>
                columns={columns}
                data={filteredUsers}
                renderRowActions={(user) => canManage && (
                    <div className="flex space-x-2 justify-end">
                        <Button variant="secondary" size="sm" onClick={() => onEdit(user)}>Edit</Button>
                        <Button variant="danger" size="sm" onClick={() => onDelete(user)}>Delete</Button>
                    </div>
                )}
            />
        </Card>
    );
};

interface GroupListProps {
    title: string;
    data: Group[];
    onAdd: () => void;
    onEdit: (group: Group) => void;
    onDelete: (group: Group) => void;
    currentUser: User | null;
    getTopManagementGroupName?: (id?: string) => string;
    getManagerGroupName?: (id?: string) => string;
    getEngineerGroupName?: (id?: string) => string;
    getPlannerGroupName?: (id?: string) => string;
    getControllerGroupName?: (id?: string) => string;
}

const GroupList: React.FC<GroupListProps> = ({ 
    title, 
    data, 
    onAdd, 
    onEdit, 
    onDelete,
    currentUser,
    getTopManagementGroupName,
    getManagerGroupName,
    getEngineerGroupName,
    getPlannerGroupName,
    getControllerGroupName
}) => {
    const context = useContext(DataContext);
    
    const canManage = useMemo(() => {
        if (!currentUser || !context) return false;
        return context.data.systemAdmins.some(g => g.userIds.includes(currentUser.id));
    }, [currentUser, context]);

    const columns = [
        { header: 'Group ID', accessor: 'id' as keyof Group },
        { header: 'Group Name', accessor: 'name' as keyof Group },
        { header: 'Members', accessor: (g: Group) => g.userIds.length },
    ];

    if (data.length > 0) {
        const sample = data[0];
        if ('topManagementGroupId' in sample && getTopManagementGroupName) {
             // @ts-ignore
             columns.push({ header: 'Reporting To (Top Mgmt)', accessor: (g) => getTopManagementGroupName(g.topManagementGroupId) });
        }
        if ('managerGroupId' in sample && getManagerGroupName) {
             // @ts-ignore
             columns.push({ header: 'Reporting To (Manager)', accessor: (g) => getManagerGroupName(g.managerGroupId) });
        }
        if ('engineerGroupId' in sample && getEngineerGroupName) {
             // @ts-ignore
             columns.push({ header: 'Linked Engineer', accessor: (g) => getEngineerGroupName(g.engineerGroupId) });
        }
        if ('plannerGroupId' in sample && getPlannerGroupName) {
             // @ts-ignore
             columns.push({ header: 'Linked Planner', accessor: (g) => getPlannerGroupName(g.plannerGroupId) });
        }
        if ('controllerGroupId' in sample && getControllerGroupName) {
             // @ts-ignore
             columns.push({ header: 'Linked Controller', accessor: (g) => getControllerGroupName(g.controllerGroupId) });
        }
        if ('logisticsControllerId' in sample && getControllerGroupName) {
             // @ts-ignore
             columns.push({ header: 'Linked Controller', accessor: (g) => getControllerGroupName(g.logisticsControllerId) });
        }
    }

    return (
        <Card title={title} actions={canManage && <Button onClick={onAdd}>Add Group</Button>}>
            <Table<Group>
                columns={columns}
                data={data}
                renderRowActions={(group) => canManage && (
                    <div className="flex space-x-2 justify-end">
                        <Button variant="secondary" size="sm" onClick={() => onEdit(group)}>Edit</Button>
                        <Button variant="danger" size="sm" onClick={() => onDelete(group)}>Delete</Button>
                    </div>
                )}
            />
        </Card>
    );
};

interface PersonnelManagementProps {
    currentUser: User | null;
}

export const PersonnelManagement: React.FC<PersonnelManagementProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<Tab>('Register');
  const context = useContext(DataContext);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<User | Group | Department | null>(null);
  
  // Deletion State
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [groupToDelete, setGroupToDelete] = useState<Group | null>(null);
  const [departmentToDelete, setDepartmentToDelete] = useState<Department | null>(null);
  
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDeleteGroupModalOpen, setIsDeleteGroupModalOpen] = useState(false);
  const [isDeleteDeptModalOpen, setIsDeleteDeptModalOpen] = useState(false);

  if (!context || !currentUser) return <div>Loading...</div>;
  const { data, setData } = context;
  
  const getTopManagementGroupName = useCallback((id?: string) => id ? data.topManagementGroups.find(g => g.id === id)?.name || 'N/A' : 'N/A', [data.topManagementGroups]);
  const getManagerGroupName = useCallback((id?: string) => id ? [...data.assetManagers, ...data.logisticsManagers].find(g => g.id === id)?.name || 'N/A' : 'N/A', [data.assetManagers, data.logisticsManagers]);
  const getEngineerGroupName = useCallback((id?: string) => id ? data.engineers.find(g => g.id === id)?.name || 'N/A' : 'N/A', [data.engineers]);
  const getPlannerGroupName = useCallback((id?: string) => id ? data.plannerGroups.find(g => g.id === id)?.name || 'N/A' : 'N/A', [data.plannerGroups]);
  const getControllerGroupName = useCallback((id?: string) => id ? [...data.maintenanceControllers, ...data.logisticsControllers].find(g => g.id === id)?.name || 'N/A' : 'N/A', [data.maintenanceControllers, data.logisticsControllers]);


  const handleOpenAdd = () => {
    setEditingItem(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: User | Group | Department) => {
    setEditingItem(item);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingItem(null);
  };
  
  const handleOpenDelete = (user: User) => {
      // Basic check: don't delete self
      if (user.id === currentUser.id) {
          alert("You cannot delete your own account.");
          return;
      }
      setUserToDelete(user);
      setIsDeleteModalOpen(true);
  };

  const handleDeleteUser = () => {
      if (!userToDelete) return;
      
      setData(prevData => {
          const logEntry: AuditLogEntry = {
              id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
              timestamp: new Date().toISOString(),
              userId: currentUser!.id,
              action: 'DELETE',
              entityType: 'User',
              entityId: userToDelete.id,
              details: `Deleted user '${userToDelete.name}' (${userToDelete.id}).`,
              status: 'Success'
          };

          return {
              ...prevData,
              users: prevData.users.filter(u => u.id !== userToDelete.id),
              auditLog: [logEntry, ...prevData.auditLog]
          };
      });
      setIsDeleteModalOpen(false);
      setUserToDelete(null);
  };

  const handleOpenDeleteGroup = (group: Group) => {
      setGroupToDelete(group);
      setIsDeleteGroupModalOpen(true);
  };

  const handleDeleteGroup = () => {
      if (!groupToDelete) return;

      setData(prevData => {
          let listKey: keyof MockData | null = null;
          switch(activeTab) {
              case 'System Admins': listKey = 'systemAdmins'; break;
              case 'Top Management': listKey = 'topManagementGroups'; break;
              case 'Managers-Asset': listKey = 'assetManagers'; break;
              case 'Managers-Logistics': listKey = 'logisticsManagers'; break;
              case 'Engineers': listKey = 'engineers'; break;
              case 'Planning Group': listKey = 'plannerGroups'; break;
              case 'Logistics Clerks': listKey = 'logisticsClerks'; break;
              case 'Maintenance Clerks': listKey = 'maintenanceClerks'; break;
              case 'Maintenance Controllers': listKey = 'maintenanceControllers'; break;
              case 'Logistics Controllers': listKey = 'logisticsControllers'; break;
              case 'Work Center Group': listKey = 'workCenters'; break;
          }

          if (!listKey) return prevData;

          // @ts-ignore
          const newList = prevData[listKey].filter((g: Group) => g.id !== groupToDelete.id);

          const logEntry: AuditLogEntry = {
              id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
              timestamp: new Date().toISOString(),
              userId: currentUser!.id,
              action: 'DELETE',
              entityType: 'Group',
              entityId: groupToDelete.id,
              details: `Deleted group '${groupToDelete.name}' (${groupToDelete.id}) from ${activeTab}.`,
              status: 'Success'
          };

          return {
              ...prevData,
              [listKey]: newList,
              auditLog: [logEntry, ...prevData.auditLog]
          };
      });
      setIsDeleteGroupModalOpen(false);
      setGroupToDelete(null);
  };

  const handleOpenDeleteDepartment = (dept: Department) => {
      setDepartmentToDelete(dept);
      setIsDeleteDeptModalOpen(true);
  }

  const handleDeleteDepartment = () => {
      if (!departmentToDelete) return;
      setData(prevData => {
           const newList = prevData.departments.filter(d => d.id !== departmentToDelete.id);
           const logEntry: AuditLogEntry = {
              id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
              timestamp: new Date().toISOString(),
              userId: currentUser!.id,
              action: 'DELETE',
              entityType: 'Department',
              entityId: departmentToDelete.id,
              details: `Deleted department '${departmentToDelete.name}' (${departmentToDelete.id}).`,
              status: 'Success'
          };
          return {
              ...prevData,
              departments: newList,
              auditLog: [logEntry, ...prevData.auditLog]
          };
      });
      setIsDeleteDeptModalOpen(false);
      setDepartmentToDelete(null);
  }
  
  const handleSaveUser = (userToSave: User, selectedGroup: string | null) => {
    setData(prevData => {
        const isEditing = !!userToSave.id;
        
        let savedUser: User;
        
        if (isEditing) {
            const existingUser = prevData.users.find(u => u.id === userToSave.id);
            if (!existingUser) return prevData;
            
            // Merge existing user data with updates.
            // This ensures if 'password' was not provided in userToSave (e.g. blank in edit form),
            // the existing password from existingUser is preserved.
            // If userToSave has a password (it was changed), it overrides.
            savedUser = { ...existingUser, ...userToSave };
        } else {
            savedUser = { ...userToSave, id: `USER-${String(prevData.users.length + 1).padStart(3, '0')}` };
        }

        const userId = savedUser.id;
        
        const groupListsToUpdate = {
            systemAdmins: JSON.parse(JSON.stringify(prevData.systemAdmins)),
            topManagementGroups: JSON.parse(JSON.stringify(prevData.topManagementGroups)),
            assetManagers: JSON.parse(JSON.stringify(prevData.assetManagers)),
            logisticsManagers: JSON.parse(JSON.stringify(prevData.logisticsManagers)),
            engineers: JSON.parse(JSON.stringify(prevData.engineers)),
            plannerGroups: JSON.parse(JSON.stringify(prevData.plannerGroups)),
            logisticsClerks: JSON.parse(JSON.stringify(prevData.logisticsClerks)),
            maintenanceClerks: JSON.parse(JSON.stringify(prevData.maintenanceClerks)),
            maintenanceControllers: JSON.parse(JSON.stringify(prevData.maintenanceControllers)),
            logisticsControllers: JSON.parse(JSON.stringify(prevData.logisticsControllers)),
            workCenters: JSON.parse(JSON.stringify(prevData.workCenters)),
        };

        // 1. Remove user from all existing groups to handle re-assignment
        for (const key in groupListsToUpdate) {
            const list = groupListsToUpdate[key as keyof typeof groupListsToUpdate];
            for (const group of list) {
                group.userIds = group.userIds.filter((id: string) => id !== userId);
            }
        }

        // 2. Add user to the new selected group (if any)
        if (selectedGroup) {
            const [groupType, groupId] = selectedGroup.split(':');
            const targetList = groupListsToUpdate[groupType as keyof typeof groupListsToUpdate];

            if (targetList) {
                const group = targetList.find((g: Group) => g.id === groupId);
                if (group) {
                    if (!group.userIds.includes(userId)) {
                         group.userIds.push(userId);
                    }
                    // Also update the user's workCenter property for display consistency
                    savedUser.workCenter = group.name;
                }
            }
        } else {
             savedUser.workCenter = ''; // No group assigned
        }
        
        const logAction = isEditing ? 'UPDATE' : 'CREATE';
        const logDetails = isEditing 
          ? `Updated details for user '${savedUser.name}' (${savedUser.id}).`
          : `Created new user '${savedUser.name}' (${savedUser.id}).`;
        
        const logEntry: AuditLogEntry = {
            id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
            timestamp: new Date().toISOString(),
            userId: currentUser!.id,
            action: logAction,
            entityType: 'User',
            entityId: savedUser.id,
            details: logDetails,
            status: 'Success'
        };

        // 3. Update users array
        const newUsersArray = isEditing 
            ? prevData.users.map(u => u.id === savedUser.id ? savedUser : u)
            : [...prevData.users, savedUser];

        // 4. Return the new state
        return {
            ...prevData,
            users: newUsersArray,
            ...groupListsToUpdate,
            auditLog: [logEntry, ...prevData.auditLog]
        };
    });
    handleCloseModal();
  };

  const handleSaveDepartment = (department: Department) => {
      setData(prevData => {
          const isEditing = !!department.id;
          const savedDept = isEditing 
              ? department 
              : { ...department, id: `DEPT-${String(prevData.departments.length + 1).padStart(3, '0')}` };
          
          const logAction = isEditing ? 'UPDATE' : 'CREATE';
          const logDetails = isEditing
            ? `Updated department '${savedDept.name}' (${savedDept.id}).`
            : `Created new department '${savedDept.name}' (${savedDept.id}).`;

          const logEntry: AuditLogEntry = {
            id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
            timestamp: new Date().toISOString(),
            userId: currentUser!.id,
            action: logAction,
            entityType: 'Department',
            entityId: savedDept.id,
            details: logDetails,
            status: 'Success'
          };

          const newDepartments = isEditing
            ? prevData.departments.map(d => d.id === savedDept.id ? savedDept : d)
            : [...prevData.departments, savedDept];

          return {
              ...prevData,
              departments: newDepartments,
              auditLog: [logEntry, ...prevData.auditLog]
          };
      });
      handleCloseModal();
  };


  const handleSaveGroup = (group: Group) => {
      setData(prevData => {
          const isEditing = !!group.id;
          let listKey: keyof MockData | null = null;
          let prefix = '';

          switch(activeTab) {
              case 'System Admins': listKey = 'systemAdmins'; prefix = 'SA'; break;
              case 'Top Management': listKey = 'topManagementGroups'; prefix = 'TMG'; break;
              case 'Managers-Asset': listKey = 'assetManagers'; prefix = 'AMG'; break;
              case 'Managers-Logistics': listKey = 'logisticsManagers'; prefix = 'LMG'; break;
              case 'Engineers': listKey = 'engineers'; prefix = 'ENG'; break;
              case 'Planning Group': listKey = 'plannerGroups'; prefix = 'PG'; break;
              case 'Logistics Clerks': listKey = 'logisticsClerks'; prefix = 'LCK'; break;
              case 'Maintenance Clerks': listKey = 'maintenanceClerks'; prefix = 'MCK'; break;
              case 'Maintenance Controllers': listKey = 'maintenanceControllers'; prefix = 'MCG'; break;
              case 'Logistics Controllers': listKey = 'logisticsControllers'; prefix = 'LCG'; break;
              case 'Work Center Group': listKey = 'workCenters'; prefix = 'WC'; break;
          }

          if (!listKey) return prevData;
          
          const groupArray = prevData[listKey as keyof MockData] as Group[];
          
          let savedGroup: Group;

          if (isEditing) {
              savedGroup = group;
          } else {
              const existingIds = groupArray.map(g => parseInt(g.id.split('-')[1] || '0', 10)).filter(n => !isNaN(n));
              const maxId = existingIds.length > 0 ? Math.max(...existingIds) : 0;
              const newId = `${prefix}-${String(maxId + 1).padStart(2, '0')}`;
              savedGroup = { ...group, id: newId };
          }

          const logAction = isEditing ? 'UPDATE' : 'CREATE';
          const logDetails = isEditing
              ? `Updated details for group '${savedGroup.name}' (${savedGroup.id}).`
              : `Created new group '${savedGroup.name}' (${savedGroup.id}).`;
          
          const logEntry: AuditLogEntry = {
              id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
              timestamp: new Date().toISOString(),
              userId: currentUser!.id,
              action: logAction,
              entityType: 'Group',
              entityId: savedGroup.id,
              details: logDetails,
              status: 'Success'
          };

          if (isEditing) {
              return {
                  ...prevData,
                  [listKey]: groupArray.map(g => g.id === savedGroup.id ? savedGroup : g),
                  auditLog: [logEntry, ...prevData.auditLog]
              };
          } else {
              return {
                  ...prevData,
                  [listKey]: [...groupArray, savedGroup],
                  auditLog: [logEntry, ...prevData.auditLog]
              };
          }
      });
      handleCloseModal();
  };

  const renderTabContent = () => {
    switch (activeTab) {
        case 'Register':
            return <PersonnelRegister onAdd={handleOpenAdd} onEdit={handleOpenEdit as (user: User) => void} onDelete={handleOpenDelete} currentUser={currentUser} />;
        case 'Departments':
            return (
                <Card title="Departments" actions={context.data.systemAdmins.some(g => g.userIds.includes(currentUser.id)) && <Button onClick={handleOpenAdd}>Add Department</Button>}>
                     <Table<Department>
                        columns={[
                            { header: 'ID', accessor: 'id' },
                            { header: 'Name', accessor: 'name' },
                            { header: 'Description', accessor: 'description' },
                        ]}
                        data={data.departments}
                        renderRowActions={(dept) => (
                            context.data.systemAdmins.some(g => g.userIds.includes(currentUser.id)) && (
                                <div className="flex space-x-2 justify-end">
                                    <Button variant="secondary" size="sm" onClick={() => handleOpenEdit(dept)}>Edit</Button>
                                    <Button variant="danger" size="sm" onClick={() => handleOpenDeleteDepartment(dept)}>Delete</Button>
                                </div>
                            )
                        )}
                    />
                </Card>
            );
        case 'System Admins':
            return <GroupList title="System Admins" data={data.systemAdmins} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Top Management':
            return <GroupList title="Top Management" data={data.topManagementGroups} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Managers-Asset':
            return <GroupList title="Managers-Asset" data={data.assetManagers} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Managers-Logistics':
            return <GroupList title="Managers-Logistics" data={data.logisticsManagers} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Engineers':
            return <GroupList title="Engineers" data={data.engineers} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Planning Group':
            return <GroupList title="Planning Group" data={data.plannerGroups} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Logistics Clerks':
            return <GroupList title="Logistics Clerks" data={data.logisticsClerks} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Maintenance Clerks':
            return <GroupList title="Maintenance Clerks" data={data.maintenanceClerks} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Maintenance Controllers':
            return <GroupList title="Maintenance Controllers" data={data.maintenanceControllers} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Logistics Controllers':
            return <GroupList title="Logistics Controllers" data={data.logisticsControllers} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        case 'Work Center Group':
            return <GroupList title="Work Center Group" data={data.workCenters} onAdd={handleOpenAdd} onEdit={handleOpenEdit as (group: Group) => void} onDelete={handleOpenDeleteGroup} currentUser={currentUser} getControllerGroupName={getControllerGroupName} getPlannerGroupName={getPlannerGroupName} getManagerGroupName={getManagerGroupName} getEngineerGroupName={getEngineerGroupName} getTopManagementGroupName={getTopManagementGroupName}/>;
        default:
            return <PersonnelRegister onAdd={handleOpenAdd} onEdit={handleOpenEdit as (user: User) => void} onDelete={handleOpenDelete} currentUser={currentUser} />;
    }
  }

  const renderModal = () => {
      if (!isModalOpen) return null;
      
      if (activeTab === 'Register') {
          return <UserForm isOpen={isModalOpen} onClose={handleCloseModal} onSave={handleSaveUser} user={editingItem as User | null} />
      }
      
      if (activeTab === 'Departments') {
          return <DepartmentForm isOpen={isModalOpen} onClose={handleCloseModal} onSave={handleSaveDepartment} department={editingItem as Department | null} />
      }

      if ([
          'System Admins', 'Top Management', 'Managers-Asset', 'Managers-Logistics', 'Engineers', 'Planning Group', 'Logistics Clerks', 
          'Maintenance Clerks', 'Maintenance Controllers', 'Logistics Controllers', 'Work Center Group'
        ].includes(activeTab)) {
          return <GroupForm isOpen={isModalOpen} onClose={handleCloseModal} onSave={handleSaveGroup} group={editingItem as Group | null} groupType={activeTab} />
      }

      return null;
  };
  
  const tabs: Tab[] = ['Register', 'Departments', 'System Admins', 'Top Management', 'Managers-Asset', 'Managers-Logistics', 'Engineers', 'Planning Group', 'Logistics Clerks', 'Maintenance Clerks', 'Maintenance Controllers', 'Logistics Controllers', 'Work Center Group'];

  return (
    <div className="space-y-6">
        <div>
            <div className="border-b border-gray-200 dark:border-gray-700">
                <nav className="-mb-px flex space-x-8 overflow-x-auto" aria-label="Tabs">
                    {tabs.map((tab) => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`${
                                activeTab === tab
                                ? 'border-indigo-500 text-indigo-600'
                                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500'
                            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                        >
                        {tab === 'Register' ? 'Personnel Register' : tab}
                        </button>
                    ))}
                </nav>
            </div>
            <div className="mt-6">
                {renderTabContent()}
            </div>
        </div>
        {renderModal()}
        
        {isDeleteModalOpen && userToDelete && (
            <ConfirmationModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleDeleteUser}
                title="Confirm User Deletion"
                confirmText="Delete"
                confirmButtonVariant="danger"
            >
                <p>Are you sure you want to delete user <span className="font-bold">{userToDelete.name}</span>?</p>
                <p className="mt-2 text-sm text-gray-500">This user will be permanently removed. Any historical records linked to this user ID (like 'Created By') may display as 'N/A' or break if the system relies on them.</p>
            </ConfirmationModal>
        )}

        {isDeleteGroupModalOpen && groupToDelete && (
            <ConfirmationModal
                isOpen={isDeleteGroupModalOpen}
                onClose={() => setIsDeleteGroupModalOpen(false)}
                onConfirm={handleDeleteGroup}
                title="Confirm Group Deletion"
                confirmText="Delete"
                confirmButtonVariant="danger"
            >
                <p>Are you sure you want to delete the group <span className="font-bold">{groupToDelete.name}</span>?</p>
                <p className="mt-2 text-sm text-gray-500">This action cannot be undone.</p>
            </ConfirmationModal>
        )}

        {isDeleteDeptModalOpen && departmentToDelete && (
            <ConfirmationModal
                isOpen={isDeleteDeptModalOpen}
                onClose={() => setIsDeleteDeptModalOpen(false)}
                onConfirm={handleDeleteDepartment}
                title="Confirm Department Deletion"
                confirmText="Delete"
                confirmButtonVariant="danger"
            >
                <p>Are you sure you want to delete the department <span className="font-bold">{departmentToDelete.name}</span>?</p>
                <p className="mt-2 text-sm text-gray-500">This action cannot be undone.</p>
            </ConfirmationModal>
        )}
    </div>
  );
};
