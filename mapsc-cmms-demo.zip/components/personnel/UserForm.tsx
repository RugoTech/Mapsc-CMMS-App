
import React, { useState, useEffect, useContext, useMemo } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { User } from '../../types';

interface UserFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (user: User, selectedGroup: string | null) => void;
  user: User | null;
}

const initialUserState: Omit<User, 'id' | 'profilePictureUrl'> = {
    name: '',
    email: '',
    password: '',
    role: 'Technician',
    department: '',
    workCenter: '',
    isActive: true,
};

export const UserForm: React.FC<UserFormProps> = ({ isOpen, onClose, onSave, user }) => {
  const context = useContext(DataContext);
  const [formData, setFormData] = useState<Omit<User, 'id'> & { id?: string }>(initialUserState);
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);

  const allGroupTypes = useMemo(() => {
    if (!context) return [];
    return [
      { label: 'System Admins', groups: context.data.systemAdmins, type: 'systemAdmins' },
      { label: 'Top Management', groups: context.data.topManagementGroups, type: 'topManagementGroups' },
      { label: 'Asset Managers', groups: context.data.assetManagers, type: 'assetManagers' },
      { label: 'Logistics Managers', groups: context.data.logisticsManagers, type: 'logisticsManagers' },
      { label: 'Engineers', groups: context.data.engineers, type: 'engineers' },
      { label: 'Planning Group', groups: context.data.plannerGroups, type: 'plannerGroups' },
      { label: 'Logistics Clerks', groups: context.data.logisticsClerks, type: 'logisticsClerks' },
      { label: 'Maintenance Clerks', groups: context.data.maintenanceClerks, type: 'maintenanceClerks' },
      { label: 'Maintenance Controllers', groups: context.data.maintenanceControllers, type: 'maintenanceControllers' },
      { label: 'Logistics Controllers', groups: context.data.logisticsControllers, type: 'logisticsControllers' },
      { label: 'Work Center Group', groups: context.data.workCenters, type: 'workCenters' },
    ];
  }, [context]);

  useEffect(() => {
    if (isOpen) {
        if (user) {
            // When editing, do not populate password field for security, 
            // and keep existing password unless changed.
            setFormData({ ...user, password: '' }); 
            let currentGroup: string | null = null;
            for (const groupType of allGroupTypes) {
                const foundGroup = groupType.groups.find(g => g.userIds.includes(user.id));
                if (foundGroup) {
                    currentGroup = `${groupType.type}:${foundGroup.id}`;
                    break;
                }
            }
            setSelectedGroup(currentGroup);
        } else {
            setFormData(initialUserState);
            setSelectedGroup(null);
        }
    }
  }, [user, isOpen, allGroupTypes]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement> | { target: { name: string, value: any } }) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // If creating a new user, force lastPasswordChangeDate to null to trigger change on first login.
    const submissionData = { ...formData };
    
    // If editing and password field is empty, remove it so we don't overwrite with empty string
    if (user && !submissionData.password) {
        delete submissionData.password;
    } 
    // If creating new user, ensure password is provided
    else if (!user && !submissionData.password) {
        alert("Password is required for new users.");
        return;
    }
    
    // Reset password change date if password is being set/changed
    if (submissionData.password) {
        submissionData.lastPasswordChangeDate = undefined; // Will force reset on login
    }

    onSave(submissionData as User, selectedGroup);
  };

  const modalFooter = (
    <>
      <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
      <Button type="submit" form="user-form">{user ? 'Save Changes' : 'Add User'}</Button>
    </>
  );

  const allRoles: User['role'][] = [
    'Administrator', 'Clerk', 'Controller', 'Engineer', 'Factory Manager', 'Manager', 
    'Operator', 'Supervisor', 'Planner', 'Requester', 'Technician'
  ];

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={user ? 'Edit User' : 'Add New User'} footer={modalFooter}>
      <form id="user-form" onSubmit={handleSubmit} className="space-y-4">
        <Input id="name" name="name" label="Full Name" value={formData.name} onChange={handleChange} required />
        <Input id="email" name="email" label="Email (Login Username)" type="text" value={formData.email} onChange={handleChange} required disabled={!!user} />
        
        <Input 
            id="password" 
            name="password" 
            label={user ? "Reset Password (leave blank to keep current)" : "Initial Password"} 
            type="password" 
            value={formData.password || ''} 
            onChange={handleChange} 
            required={!user} // Required only for new users
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="role" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Role</label>
              <select id="role" name="role" value={formData.role} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                {allRoles.sort().map(role => <option key={role}>{role}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="isActive" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
              <select
                id="isActive"
                name="isActive"
                value={String(formData.isActive ?? true)}
                onChange={e => handleChange({ target: { name: 'isActive', value: e.target.value === 'true' }})}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
              >
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </div>
        </div>
        <div>
            <label htmlFor="department" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Department</label>
            <select id="department" name="department" value={formData.department} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" required>
                <option value="">Select Department...</option>
                {context?.data.departments.map(dept => (
                    <option key={dept.id} value={dept.name}>{dept.name}</option>
                ))}
            </select>
        </div>
        <div>
            <label htmlFor="group" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Group</label>
            <select id="group" name="group" value={selectedGroup || ''} onChange={e => setSelectedGroup(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                <option value="">-- No Group Assignment --</option>
                {allGroupTypes.map(groupType => (
                    <optgroup label={groupType.label} key={groupType.type}>
                        {groupType.groups.map(group => (
                            <option key={group.id} value={`${groupType.type}:${group.id}`}>
                                {group.name}
                            </option>
                        ))}
                    </optgroup>
                ))}
            </select>
        </div>
      </form>
    </Modal>
  );
};
