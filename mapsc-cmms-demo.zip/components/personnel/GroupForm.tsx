
import React, { useState, useEffect, useContext } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { WorkCenter, ControllerGroup, LogisticsManagementGroup, AssetManagementGroup, PlannerGroup, ClerkGroup, EngineerGroup, TopManagementGroup } from '../../types';

type Group = WorkCenter | ControllerGroup | LogisticsManagementGroup | AssetManagementGroup | PlannerGroup | ClerkGroup | EngineerGroup | TopManagementGroup;

interface GroupFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (group: Group) => void;
  group: Group | null;
  groupType: string;
}

interface FormData {
    id?: string;
    name: string;
    userIds: string[];
    controllerGroupId?: string;
    plannerGroupId?: string;
    logisticsControllerId?: string;
    managerGroupId?: string;
    engineerGroupId?: string;
    topManagementGroupId?: string;
}

const getInitialGroupState = (): Omit<FormData, 'id'> => ({
    name: '',
    userIds: [],
    controllerGroupId: '',
    plannerGroupId: '',
    logisticsControllerId: '',
    managerGroupId: '',
    engineerGroupId: '',
    topManagementGroupId: '',
});

export const GroupForm: React.FC<GroupFormProps> = ({ isOpen, onClose, onSave, group, groupType }) => {
  const context = useContext(DataContext);
  const [formData, setFormData] = useState<FormData>(getInitialGroupState());
  const [search, setSearch] = useState('');
  const [selectedAvailable, setSelectedAvailable] = useState<string[]>([]);
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);


  useEffect(() => {
    if (isOpen) {
        if (group) {
            const baseData = {
                id: group.id,
                name: group.name,
                userIds: [...(group.userIds || [])], // Shallow copy array to prevent mutation
            };
            let specificData: Partial<FormData> = {};

            switch (groupType) {
                case 'Work Center Group':
                    specificData.controllerGroupId = (group as WorkCenter).controllerGroupId;
                    break;
                case 'Maintenance Controllers':
                    specificData.plannerGroupId = (group as ControllerGroup).plannerGroupId;
                    break;
                case 'Logistics Controllers':
                    specificData.managerGroupId = (group as ControllerGroup).managerGroupId;
                    break;
                case 'Maintenance Clerks':
                    specificData.plannerGroupId = (group as ClerkGroup).plannerGroupId;
                    break;
                case 'Logistics Clerks':
                    specificData.logisticsControllerId = (group as ClerkGroup).logisticsControllerId;
                    break;
                case 'Planning Group':
                    specificData.engineerGroupId = (group as PlannerGroup).engineerGroupId;
                    break;
                case 'Engineers':
                    specificData.managerGroupId = (group as EngineerGroup).managerGroupId;
                    break;
                case 'Managers-Logistics':
                    specificData.topManagementGroupId = (group as LogisticsManagementGroup).topManagementGroupId;
                    break;
                case 'Managers-Asset':
                    specificData.topManagementGroupId = (group as AssetManagementGroup).topManagementGroupId;
                    break;
            }
            setFormData({ ...getInitialGroupState(), ...baseData, ...specificData });
        } else { // Adding a new group
            setFormData(getInitialGroupState());
        }
        setSearch('');
        setSelectedAvailable([]);
        setSelectedMembers([]);
    }
  }, [group, isOpen, groupType]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const allUsers = context?.data.users || [];
  const memberIds = new Set(formData.userIds || []);

  const members = allUsers
    .filter(u => memberIds.has(u.id))
    .sort((a, b) => a.name.localeCompare(b.name));

  const availableUsers = allUsers
    .filter(u => !memberIds.has(u.id) && u.name.toLowerCase().includes(search.toLowerCase()) && (u.isActive ?? true))
    .sort((a, b) => a.name.localeCompare(b.name));

  const handleAdd = () => {
    setFormData(prev => ({...prev, userIds: [...(prev.userIds || []), ...selectedAvailable]}));
    setSelectedAvailable([]);
  };

  const handleRemove = () => {
    const toRemoveSet = new Set(selectedMembers);
    setFormData(prev => ({...prev, userIds: (prev.userIds || []).filter(id => !toRemoveSet.has(id))}));
    setSelectedMembers([]);
  };

  const handleSelection = (e: React.ChangeEvent<HTMLSelectElement>, setSelected: React.Dispatch<React.SetStateAction<string[]>>) => {
    const selectedIds = Array.from(e.target.selectedOptions, (option: HTMLOptionElement) => option.value);
    setSelected(selectedIds);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalGroup = {
        ...group,
        ...formData
    };
    onSave(finalGroup as Group);
  };

  const displayGroupType = groupType.replace(' Groups', '').replace('s', '');

  const modalFooter = (
    <>
      <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
      <Button type="submit" form="group-form">{group ? 'Save Changes' : `Add ${displayGroupType}`}</Button>
    </>
  );

  const title = group ? `Edit ${displayGroupType}` : `Add New ${displayGroupType}`;
  const selectClasses = "w-full h-48 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md p-1 focus:outline-none focus:ring-2 focus:ring-indigo-500";
  const parentSelectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md";

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} footer={modalFooter} size="3xl">
      <form id="group-form" onSubmit={handleSubmit} className="space-y-4">
        <Input id="name" name="name" label={`${displayGroupType} Name`} value={formData.name} onChange={handleChange} required />
        
        {(groupType === 'Managers-Logistics' || groupType === 'Managers-Asset') && (
            <div>
                <label htmlFor="topManagementGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link to Top Management Group</label>
                <select id="topManagementGroupId" name="topManagementGroupId" value={formData.topManagementGroupId || ''} onChange={handleChange} required className={parentSelectClasses}>
                    <option value="">Select a top management group...</option>
                    {context?.data.topManagementGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
            </div>
        )}

        {groupType === 'Engineers' && (
            <div>
                <label htmlFor="managerGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link to Asset Manager Group</label>
                <select id="managerGroupId" name="managerGroupId" value={formData.managerGroupId || ''} onChange={handleChange} required className={parentSelectClasses}>
                    <option value="">Select a manager group...</option>
                    {context?.data.assetManagers.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
            </div>
        )}

        {groupType === 'Planning Group' && (
            <div>
                <label htmlFor="engineerGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link to Engineer Group</label>
                <select id="engineerGroupId" name="engineerGroupId" value={formData.engineerGroupId || ''} onChange={handleChange} required className={parentSelectClasses}>
                    <option value="">Select an engineer group...</option>
                    {context?.data.engineers.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
            </div>
        )}

        {groupType === 'Logistics Controllers' && (
            <div>
                <label htmlFor="managerGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link to Logistics Manager Group</label>
                <select id="managerGroupId" name="managerGroupId" value={formData.managerGroupId || ''} onChange={handleChange} required className={parentSelectClasses}>
                    <option value="">Select a manager group...</option>
                    {context?.data.logisticsManagers.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
            </div>
        )}

        {groupType === 'Work Center Group' && (
            <div>
                <label htmlFor="controllerGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link to Maintenance Controller</label>
                <select id="controllerGroupId" name="controllerGroupId" value={formData.controllerGroupId || ''} onChange={handleChange} required className={parentSelectClasses}>
                    <option value="">Select a controller...</option>
                    {context?.data.maintenanceControllers.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
            </div>
        )}

        {groupType === 'Maintenance Controllers' && (
            <div>
                <label htmlFor="plannerGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link to Planning Group</label>
                <select id="plannerGroupId" name="plannerGroupId" value={formData.plannerGroupId || ''} onChange={handleChange} required className={parentSelectClasses}>
                    <option value="">Select a planner...</option>
                    {context?.data.plannerGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
            </div>
        )}

        {groupType === 'Maintenance Clerks' && (
            <div>
                <label htmlFor="plannerGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link to Planning Group</label>
                <select id="plannerGroupId" name="plannerGroupId" value={formData.plannerGroupId || ''} onChange={handleChange} required className={parentSelectClasses}>
                    <option value="">Select a planner...</option>
                    {context?.data.plannerGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
            </div>
        )}
        
        {groupType === 'Logistics Clerks' && (
            <div>
                <label htmlFor="logisticsControllerId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Link to Logistics Controller</label>
                <select id="logisticsControllerId" name="logisticsControllerId" value={formData.logisticsControllerId || ''} onChange={handleChange} required className={parentSelectClasses}>
                    <option value="">Select a controller...</option>
                    {context?.data.logisticsControllers.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
            </div>
        )}
        
        <div className="border-t pt-4 mt-4">
            <h4 className="text-lg font-semibold mb-2">Manage Members</h4>
            <div className="grid grid-cols-[1fr,auto,1fr] gap-4 items-center">
                {/* Available Users */}
                <div className="flex flex-col space-y-2">
                    <label className="text-sm font-medium">Available Users ({availableUsers.length})</label>
                    <Input id="search-users" name="search" label="" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
                    <select multiple value={selectedAvailable} onChange={e => handleSelection(e, setSelectedAvailable)} className={selectClasses}>
                        {availableUsers.map(user => (
                            <option key={user.id} value={user.id}>{user.name}</option>
                        ))}
                    </select>
                </div>
                {/* Controls */}
                <div className="flex flex-col space-y-2">
                    <Button type="button" onClick={handleAdd} disabled={selectedAvailable.length === 0}>&gt;&gt;</Button>
                    <Button type="button" onClick={handleRemove} disabled={selectedMembers.length === 0}>&lt;&lt;</Button>
                </div>
                {/* Group Members */}
                <div className="flex flex-col space-y-2">
                    <label className="text-sm font-medium">Group Members ({members.length})</label>
                    <div className="h-9"></div> {/* Placeholder for alignment with search input */}
                    <select multiple value={selectedMembers} onChange={e => handleSelection(e, setSelectedMembers)} className={selectClasses}>
                        {members.map(user => (
                            <option key={user.id} value={user.id}>{user.name}</option>
                        ))}
                    </select>
                </div>
            </div>
        </div>
      </form>
    </Modal>
  );
};
