
import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import type { Department } from '../../types';

interface DepartmentFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (department: Department) => void;
  department: Department | null;
}

export const DepartmentForm: React.FC<DepartmentFormProps> = ({ isOpen, onClose, onSave, department }) => {
  const [formData, setFormData] = useState<Department>({
    id: '',
    name: '',
    description: '',
  });

  useEffect(() => {
    if (isOpen) {
      if (department) {
        setFormData(department);
      } else {
        setFormData({
          id: '',
          name: '',
          description: '',
        });
      }
    }
  }, [isOpen, department]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const modalFooter = (
    <>
      <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
      <Button type="submit" form="department-form">{department ? 'Save Changes' : 'Add Department'}</Button>
    </>
  );

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={department ? 'Edit Department' : 'Add New Department'} footer={modalFooter}>
      <form id="department-form" onSubmit={handleSubmit} className="space-y-4">
        <Input id="name" name="name" label="Department Name" value={formData.name} onChange={handleChange} required />
        <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
            <textarea
                id="description"
                name="description"
                rows={3}
                value={formData.description}
                onChange={handleChange}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-gray-900 dark:text-white"
            />
        </div>
      </form>
    </Modal>
  );
};
