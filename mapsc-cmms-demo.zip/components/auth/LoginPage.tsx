
import React, { useState, useContext } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { DataContext } from '../../contexts/DataContext';
import { Modal } from '../ui/Modal';
import { Alert } from '../ui/Alert';
import type { User } from '../../types';

interface LoginPageProps {
  onLogin: (user: User) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
    const context = useContext(DataContext);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    
    // Change Password State
    const [showChangePassword, setShowChangePassword] = useState(false);
    const [tempUser, setTempUser] = useState<User | null>(null);
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [changePasswordError, setChangePasswordError] = useState('');

    if (!context) return null;
    const { data, setData } = context;

    const handleLoginSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        const user = data.users.find(u => (u.email.toLowerCase() === email.toLowerCase() || u.name.toLowerCase() === email.toLowerCase()) && (u.isActive ?? true));

        if (!user) {
            setError('Invalid credentials.');
            return;
        }

        // Check password (simple comparison for demo)
        if (user.password !== password) {
            setError('Invalid credentials.');
            return;
        }

        // Check for password expiry (90 days)
        let isExpired = false;
        if (!user.lastPasswordChangeDate) {
            // First login or never set
            isExpired = true;
        } else {
            const lastChange = new Date(user.lastPasswordChangeDate);
            const now = new Date();
            const diffTime = Math.abs(now.getTime() - lastChange.getTime());
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            if (diffDays > 90) {
                isExpired = true;
            }
        }

        if (isExpired) {
            setTempUser(user);
            setShowChangePassword(true);
        } else {
            onLogin(user);
        }
    };

    const handleChangePasswordSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setChangePasswordError('');

        if (newPassword !== confirmPassword) {
            setChangePasswordError("Passwords do not match.");
            return;
        }

        // Password Policy Validation:
        // Min 8, Max 12
        // At least 1 Uppercase, 1 Number, 1 Symbol
        const passwordRegex = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,12})/;
        
        if (newPassword.length < 8 || newPassword.length > 12) {
            setChangePasswordError("Password must be between 8 and 12 characters.");
            return;
        }

        if (!passwordRegex.test(newPassword)) {
            setChangePasswordError("Password must contain at least one uppercase letter, one number, and one symbol (!@#$%^&*).");
            return;
        }

        if (tempUser) {
            // Update user with new password and timestamp
            const updatedUser = { 
                ...tempUser, 
                password: newPassword, 
                lastPasswordChangeDate: new Date().toISOString() 
            };

            setData(prev => ({
                ...prev,
                users: prev.users.map(u => u.id === tempUser.id ? updatedUser : u),
                // Log the password change action
                auditLog: [{
                    id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                    timestamp: new Date().toISOString(),
                    userId: tempUser.id,
                    action: 'UPDATE',
                    entityType: 'User',
                    entityId: tempUser.id,
                    details: 'User changed password due to expiration policy.',
                    status: 'Success'
                }, ...prev.auditLog]
            }));

            // Proceed to login
            onLogin(updatedUser);
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900">
            <div className="w-full max-w-md px-4">
                <div className="flex justify-center items-center mb-8">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    <span className="ml-2 text-3xl font-bold text-gray-800 dark:text-white">Mapsc CMMS</span>
                </div>
                
                <Card title="Login">
                    <form onSubmit={handleLoginSubmit} className="space-y-6">
                        {error && <Alert type="error">{error}</Alert>}
                        
                        <Input 
                            id="email" 
                            name="email" 
                            label="Email or Username" 
                            type="text" 
                            value={email} 
                            onChange={(e) => setEmail(e.target.value)} 
                            required 
                            placeholder="admin@mapsc.com"
                        />
                        
                        <div className="relative">
                            <Input 
                                id="password" 
                                name="password" 
                                label="Password" 
                                type={showPassword ? "text" : "password"} 
                                value={password} 
                                onChange={(e) => setPassword(e.target.value)} 
                                required 
                            />
                            <button
                                type="button"
                                className="absolute top-9 right-3 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                                onClick={() => setShowPassword(!showPassword)}
                                tabIndex={-1}
                            >
                                {showPassword ? (
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                                    </svg>
                                ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                    </svg>
                                )}
                            </button>
                        </div>

                        <Button type="submit" className="w-full justify-center">Sign In</Button>
                    </form>
                    
                    <div className="mt-4 text-center">
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                            Default Admin: sysadmin / Sysadmin@123
                        </p>
                    </div>
                </Card>
            </div>

            {/* Change Password Modal */}
            {showChangePassword && (
                <Modal 
                    isOpen={showChangePassword} 
                    onClose={() => { /* Prevent closing without change */ }} 
                    title="Password Expired"
                    footer={
                        <Button type="submit" form="change-password-form" className="w-full justify-center">Update Password</Button>
                    }
                >
                    <form id="change-password-form" onSubmit={handleChangePasswordSubmit} className="space-y-4">
                        <Alert type="warning">
                            Your password has expired or this is your first login. Please update your password to proceed.
                        </Alert>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                            Requirement: 8-12 chars, 1 Uppercase, 1 Number, 1 Symbol (!@#$%^&*)
                        </p>
                        {changePasswordError && <Alert type="error">{changePasswordError}</Alert>}
                        
                        <Input 
                            id="newPassword" 
                            label="New Password" 
                            type="password" 
                            value={newPassword} 
                            onChange={(e) => setNewPassword(e.target.value)} 
                            required 
                        />
                        <Input 
                            id="confirmPassword" 
                            label="Confirm New Password" 
                            type="password" 
                            value={confirmPassword} 
                            onChange={(e) => setConfirmPassword(e.target.value)} 
                            required 
                        />
                    </form>
                </Modal>
            )}
        </div>
    );
};
