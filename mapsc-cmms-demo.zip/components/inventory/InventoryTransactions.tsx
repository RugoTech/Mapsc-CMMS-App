
import React, { useContext, useState, useEffect, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import type { InventoryTransaction, PartUsed, User, AuditLogEntry } from '../../types';
import { TransactionType, WorkOrderStatus } from '../../types';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { useSettings } from '../../contexts/SettingsContext';
import { Alert } from '../ui/Alert';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { useDateFormatter } from '../../hooks/useDateFormatter';

const transactionTypeColors: Record<TransactionType, 'blue' | 'green' | 'yellow'> = {
    [TransactionType.Receipt]: 'green',
    [TransactionType.Issue]: 'blue',
    [TransactionType.Adjustment]: 'yellow',
};

interface InventoryTransactionsProps {
    currentUser: User | null;
}

export const InventoryTransactions: React.FC<InventoryTransactionsProps> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
    const formatDate = useDateFormatter();

    if (!context || !currentUser) return <div>Loading...</div>;

    const isManagerOrTopManagement = useMemo(() => {
        if (!currentUser) return false;
        if (currentUser.role === 'Manager' || currentUser.role === 'Factory Manager') return true;
        return context.data.topManagementGroups.some(g => g.userIds.includes(currentUser.id));
    }, [currentUser, context.data.topManagementGroups]);

    const canTransact = !isManagerOrTopManagement && currentUser?.role !== 'Engineer' && currentUser?.role !== 'Administrator';
    
    // --- Transaction Form Component (defined inside to have access to currentUser) ---
    const TransactionForm: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (t: InventoryTransaction) => void }> = ({ isOpen, onClose, onSave }) => {
        const context = useContext(DataContext);
        const [formData, setFormData] = useState({ 
            partId: '', 
            type: TransactionType.Issue as const,
            quantity: 1, 
            workOrderId: '', 
            userId: '' 
        });
        const [availablePartsForWO, setAvailablePartsForWO] = useState<PartUsed[]>([]);
        const [requiredQuantity, setRequiredQuantity] = useState(0);
        const [error, setError] = useState<string | null>(null);

        const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
            const { name, value } = e.target;
            setFormData(prev => ({
                ...prev,
                [name]: name === 'quantity' ? Number(value) : value,
            }));
        };

        useEffect(() => {
            if (isOpen) {
                setFormData({ 
                    partId: '', 
                    type: TransactionType.Issue as const,
                    quantity: 1, 
                    workOrderId: '', 
                    userId: currentUser?.id || ''
                });
                setAvailablePartsForWO([]);
                setRequiredQuantity(0);
                setError(null);
            }
        }, [isOpen, currentUser]);

        useEffect(() => {
            if (!context) return;
            const { workOrders, inventoryTransactions } = context.data;

            if (formData.workOrderId) {
                const wo = workOrders.find(w => w.id === formData.workOrderId);
                if (wo) {
                    const issuedQtys = inventoryTransactions
                        .filter(t => t.workOrderId === wo.id && t.type === TransactionType.Issue)
                        .reduce((acc, t) => {
                            acc[t.partId] = (acc[t.partId] || 0) + t.quantity;
                            return acc;
                        }, {} as Record<string, number>);

                    const remainingParts = wo.partsUsed
                        .map(p => ({
                            partId: p.partId,
                            quantity: p.quantity - (issuedQtys[p.partId] || 0)
                        }))
                        .filter(p => p.quantity > 0);
                    
                    setAvailablePartsForWO(remainingParts);
                    const firstPartId = remainingParts[0]?.partId || '';
                    setFormData(prev => ({ ...prev, partId: firstPartId }));
                } else {
                    setAvailablePartsForWO([]);
                    setFormData(prev => ({ ...prev, partId: '' }));
                }
            } else {
                setAvailablePartsForWO([]);
                setFormData(prev => ({...prev, partId: ''}));
            }
        }, [formData.workOrderId, context]);

        useEffect(() => {
            if (formData.partId && availablePartsForWO.length > 0) {
                const partToIssue = availablePartsForWO.find(p => p.partId === formData.partId);
                const required = partToIssue ? partToIssue.quantity : 0;
                setRequiredQuantity(required);
                setFormData(prev => ({ ...prev, quantity: required })); // Pre-fill issued quantity with required
            } else {
                setRequiredQuantity(0);
                setFormData(prev => ({ ...prev, quantity: 1 }));
            }
        }, [formData.partId, availablePartsForWO]);
        
        const handleSubmit = (e: React.FormEvent) => {
            e.preventDefault();
            setError(null);
            if (!context || !formData.partId) {
                setError('Please select a part.');
                return;
            };

            const partInfo = context.data.parts.find(p => p.id === formData.partId);
            if (!partInfo) {
                setError('Selected part not found.');
                return;
            }

            if (Number(formData.quantity) > partInfo.quantity) {
                setError(`Cannot issue more than stock on hand. On hand: ${partInfo.quantity}`);
                return;
            }
            if (Number(formData.quantity) > requiredQuantity) {
                setError(`Cannot issue more than required quantity. Required: ${requiredQuantity}`);
                return;
            }
            if (Number(formData.quantity) <= 0) {
                setError(`Issued quantity must be greater than 0.`);
                return;
            }

            const newTrans = {
                id: `TRN-${String(context.data.inventoryTransactions.length + 1).padStart(3, '0')}`,
                date: new Date().toISOString().split('T')[0],
                ...formData,
                quantity: Number(formData.quantity)
            };
            onSave(newTrans);
            onClose();
        };

        if (!context) return null;
        const { parts, users, workOrders, inventoryTransactions } = context.data;
        const selectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md";

        // Only show active Work Orders that have pending parts (not fully issued)
        const availableWorkOrders = workOrders.filter(wo => {
            const isOpen = [WorkOrderStatus.Open, WorkOrderStatus.InProgress].includes(wo.status);
            if (!isOpen || wo.partsUsed.length === 0) return false;

            // Check if any required part quantity is not fully met by issue transactions
            const hasPendingParts = wo.partsUsed.some(partUsed => {
                const totalIssued = inventoryTransactions
                    .filter(t => t.workOrderId === wo.id && t.partId === partUsed.partId && t.type === TransactionType.Issue)
                    .reduce((sum, t) => sum + t.quantity, 0);
                
                return totalIssued < partUsed.quantity;
            });

            return hasPendingParts;
        });

        return (
            <Modal isOpen={isOpen} onClose={onClose} title="Issue Parts to Work Order" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit" form="trans-form">Save</Button></>}>
                <form id="trans-form" onSubmit={handleSubmit} className="space-y-4">
                    {error && <Alert type="error">{error}</Alert>}
                    <div>
                        <label htmlFor="workOrderId" className="block text-sm font-medium">Work Order ID</label>
                        <select name="workOrderId" value={formData.workOrderId} onChange={handleChange} className={selectClasses} required>
                                <option value="">Select a Work Order...</option>
                                {availableWorkOrders.map(wo => <option key={wo.id} value={wo.id}>{wo.id} - {wo.description}</option>)}
                        </select>
                    </div>
                    <div>
                    <label htmlFor="partId" className="block text-sm font-medium">Part</label>
                    <select name="partId" value={formData.partId} onChange={handleChange} disabled={!formData.workOrderId} className={`${selectClasses} disabled:bg-gray-100 dark:disabled:bg-gray-800`}>
                        {availablePartsForWO.length > 0 ?
                            availablePartsForWO.map(p => {
                                const partInfo = parts.find(part => part.id === p.partId);
                                return <option key={p.partId} value={p.partId}>{partInfo?.name} ({partInfo?.partNumber}) - Required: {p.quantity}, On Hand: {partInfo?.quantity}</option>
                            })
                            : <option value="">{formData.workOrderId ? 'All parts issued or none planned' : 'Select a WO'}</option>
                        }
                    </select>
                    </div>

                    {!!formData.workOrderId && (
                        <Input
                            id="requiredQuantity"
                            label="Required Quantity"
                            type="number"
                            value={requiredQuantity}
                            disabled
                        />
                    )}
                    <Input
                        id="quantity"
                        label="Issued Quantity"
                        name="quantity"
                        type="number"
                        value={formData.quantity}
                        onChange={handleChange}
                        required
                        min="0"
                    />
                    <Input 
                        id="user"
                        label="User"
                        name="user"
                        value={currentUser?.name || ''}
                        disabled
                    />
                </form>
            </Modal>
        );
    };

    const { data, setData } = context;
    const { inventoryTransactions, parts, users, assets } = data;

    const getPartName = (partId: string) => parts.find(p => p.id === partId)?.name || 'N/A';
    const getUserName = (userId: string) => users.find(u => u.id === userId)?.name || 'N/A';
    
    const transactionsToDisplay = useMemo(() => {
        return inventoryTransactions
           .filter(transaction => {
               const part = parts.find(p => p.id === transaction.partId);
               if (!part) return canSeeAllZones; // Show transaction if part is deleted, but only to users with full access

               const asset = part.assetId ? assets.find(a => a.id === part.assetId) : null;
               const partZoneId = asset?.zoneId;
               
               return canSeeAllZones || !partZoneId || accessibleZoneIds.includes(partZoneId);
           })
           .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
   }, [inventoryTransactions, parts, assets, canSeeAllZones, accessibleZoneIds]);

    const handleSave = (transaction: InventoryTransaction) => {
        setData(prev => {
            const partToUpdate = prev.parts.find(p => p.id === transaction.partId);
            let newQuantity: number | undefined;

            if (transaction.type === TransactionType.Issue) {
                 if (!partToUpdate || partToUpdate.quantity < transaction.quantity) {
                    // This validation is now handled in the form, but kept as a safeguard
                    return prev;
                }
                newQuantity = (partToUpdate?.quantity || 0) - transaction.quantity;
            } else if (transaction.type === TransactionType.Receipt) {
                newQuantity = (partToUpdate?.quantity || 0) + transaction.quantity;
            } else if (transaction.type === TransactionType.Adjustment) {
                // For adjustments, quantity can be positive or negative
                newQuantity = (partToUpdate?.quantity || 0) + transaction.quantity;
            }

            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'CREATE',
                entityType: 'InventoryTransaction',
                entityId: transaction.id,
                details: `${transaction.type} ${transaction.quantity} of part '${partToUpdate?.name}' (${transaction.partId}). WO: ${transaction.workOrderId || 'N/A'}.`,
                status: 'Success'
            };

            const newTransactions = [...prev.inventoryTransactions, transaction];
            const newParts = prev.parts.map(p => {
                if (p.id === transaction.partId && newQuantity !== undefined) {
                    return {...p, quantity: newQuantity};
                }
                return p;
            });
            return {
                ...prev, 
                inventoryTransactions: newTransactions, 
                parts: newParts,
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
    };

    const columns = [
        { header: 'Transaction ID', accessor: 'id' as keyof InventoryTransaction },
        { 
            header: 'Part', 
            accessor: (item: InventoryTransaction) => getPartName(item.partId)
        },
        { 
            header: 'Type',
            accessor: (item: InventoryTransaction) => (
                <Badge color={transactionTypeColors[item.type]}>{item.type}</Badge>
            )
        },
        { header: 'Quantity', accessor: 'quantity' as keyof InventoryTransaction },
        { header: 'Date', accessor: (item: InventoryTransaction) => formatDate(item.date) },
        { header: 'User', accessor: (item: InventoryTransaction) => getUserName(item.userId) },
        { header: 'Associated WO', accessor: (item: InventoryTransaction) => item.workOrderId || 'N/A' },
    ];
    
    return (
        <>
            <Card
                title="Inventory Transactions Log"
                actions={
                    canTransact && (
                        <div className="flex flex-col items-end">
                            <Button onClick={() => setIsAddModalOpen(true)} disabled={settings.inventoryLocked}>
                                New Transaction
                            </Button>
                            {settings.inventoryLocked && (
                                <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
                                    Disabled during inventory count.
                                </p>
                            )}
                        </div>
                    )
                }
            >
                <Table<InventoryTransaction>
                    columns={columns}
                    data={transactionsToDisplay}
                />
            </Card>
            <TransactionForm isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} onSave={handleSave} />
        </>
    );
};
