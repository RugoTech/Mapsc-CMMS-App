
import React, { useState, useContext, useMemo } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { PurchaseRequisition, PRStatus, PRType, Priority, User } from '../../types';
import { Badge } from '../ui/Badge';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { Alert } from '../ui/Alert';

interface PRDetailModalProps {
    pr: PurchaseRequisition;
    currentUser: User;
    onClose: () => void;
    onEdit: (pr: PurchaseRequisition) => void;
    onStatusUpdate: (prId: string, status: PRStatus, remarks?: string) => void;
    onCreateRFQ: (pr: PurchaseRequisition, selectedVendorIds: string[]) => void;
}

const statusColors: Record<PRStatus, 'blue' | 'green' | 'red' | 'gray' | 'yellow'> = {
    [PRStatus.Draft]: 'gray',
    [PRStatus.Pending]: 'blue',
    [PRStatus.Approved]: 'green',
    [PRStatus.Rejected]: 'red',
    [PRStatus.RFQCreated]: 'yellow',
};

const priorityColors: Record<Priority, 'blue' | 'yellow' | 'red'> = {
    [Priority.Low]: 'blue',
    [Priority.Medium]: 'yellow',
    [Priority.High]: 'red',
    [Priority.Critical]: 'red',
};

const RejectModal: React.FC<{onReject: (remarks: string) => void, onClose: () => void}> = ({ onReject, onClose }) => {
    const [remarks, setRemarks] = useState('');
    const [error, setError] = useState('');

    const handleConfirm = () => {
        if (!remarks.trim()) {
            setError('Rejection remarks cannot be empty.');
            return;
        }
        onReject(remarks);
    };

    return (
        <ConfirmationModal
            isOpen={true}
            onClose={onClose}
            onConfirm={handleConfirm}
            title="Confirm Rejection"
            confirmText="Reject"
            confirmButtonVariant="danger"
        >
            <p>Please provide a reason for rejecting this purchase requisition.</p>
            <textarea value={remarks} onChange={e => setRemarks(e.target.value)} rows={3} className="mt-2 w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required/>
            {error && <Alert type="error">{error}</Alert>}
        </ConfirmationModal>
    );
};

const VendorSelectionModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (selectedVendorIds: string[]) => void;
    defaultVendorId?: string;
}> = ({ isOpen, onClose, onConfirm, defaultVendorId }) => {
    const context = useContext(DataContext);
    const [selectedVendors, setSelectedVendors] = useState<string[]>(defaultVendorId ? [defaultVendorId] : []);
    const [search, setSearch] = useState('');

    if (!context || !isOpen) return null;
    const { vendors } = context.data;

    const filteredVendors = vendors.filter(v => v.name.toLowerCase().includes(search.toLowerCase()));

    const toggleVendor = (id: string) => {
        setSelectedVendors(prev => {
            if (prev.includes(id)) {
                return prev.filter(vId => vId !== id);
            }
            if (prev.length >= 3) {
                alert("You can select a maximum of 3 vendors.");
                return prev;
            }
            return [...prev, id];
        });
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Select Vendors for RFQ">
            <div className="space-y-4">
                <p className="text-sm text-gray-500">Select up to 3 vendors to send this Request for Quotation to.</p>
                <input 
                    type="text" 
                    placeholder="Search vendors..." 
                    className="w-full px-3 py-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                />
                <div className="max-h-60 overflow-y-auto border rounded-md dark:border-gray-600">
                    {filteredVendors.map(vendor => (
                        <div 
                            key={vendor.id} 
                            onClick={() => toggleVendor(vendor.id)}
                            className={`p-3 flex items-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 ${selectedVendors.includes(vendor.id) ? 'bg-indigo-50 dark:bg-indigo-900/20' : ''}`}
                        >
                            <input 
                                type="checkbox" 
                                checked={selectedVendors.includes(vendor.id)} 
                                onChange={() => {}} 
                                className="h-4 w-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500"
                            />
                            <span className="ml-3 text-sm">{vendor.name}</span>
                        </div>
                    ))}
                </div>
                <div className="flex justify-end space-x-2 pt-4 border-t dark:border-gray-600">
                    <Button variant="secondary" onClick={onClose}>Cancel</Button>
                    <Button onClick={() => onConfirm(selectedVendors)} disabled={selectedVendors.length === 0}>
                        Create RFQ ({selectedVendors.length})
                    </Button>
                </div>
            </div>
        </Modal>
    );
};

export const PRDetailModal: React.FC<PRDetailModalProps> = ({ pr, currentUser, onClose, onEdit, onStatusUpdate, onCreateRFQ }) => {
    const context = useContext(DataContext);
    const [isRejecting, setIsRejecting] = useState(false);
    const [isVendorModalOpen, setIsVendorModalOpen] = useState(false);
    
    if (!context) return null;
    const { users, vendors, zones, parts, assets, systemAdmins, logisticsClerks, logisticsControllers, stores, plannerGroups, engineers, logisticsManagers } = context.data;

    const requester = users.find(u => u.id === pr.requesterId)?.name || 'N/A';
    
    // Logic for displaying vendor
    let vendorName = 'N/A';
    if (pr.type === PRType.System && pr.vendorId) {
        vendorName = vendors.find(v => v.id === pr.vendorId)?.name || 'N/A';
    } else if (pr.type === PRType.Manual) {
        vendorName = 'To be selected during RFQ';
    }
    
    // Logic for constructing Description for System PRs
    let displayDescription = pr.description;
    if (pr.type === PRType.System && (!displayDescription || displayDescription === 'N/A')) {
         if (pr.items && pr.items.length > 0) {
             displayDescription = pr.items.map(item => {
                 const part = parts.find(p => p.id === item.partId);
                 return part ? part.name : item.partId;
             }).join(', ');
         }
    }
    
    // Delivery Location Logic: Manual uses Zones, System uses Stores
    const deliveryZone = zones.find(z => z.id === pr.deliveryZoneId)?.name;
    const storeName = pr.storeId ? stores.find(s => s.id === pr.storeId)?.name : undefined;
    const deliveryLocationName = pr.type === PRType.System 
        ? (storeName || 'Unassigned Store') 
        : (deliveryZone || 'N/A');

    const approver = users.find(u => u.id === pr.approverId)?.name;
    const asset = assets.find(a => a.id === pr.assetId)?.name || 'N/A';
    
    // Approval Logic
    const canApprove = useMemo(() => {
        if (pr.status !== PRStatus.Pending) return false;

        // SCENARIO 3: System PRs -> Approved by Logistics Manager
        if (pr.type === PRType.System) {
            // Check if current user is in LogisticsManagers group
            return logisticsManagers.some(g => g.userIds.includes(currentUser.id));
        }

        // Manual PRs Logic
        const requesterUser = users.find(u => u.id === pr.requesterId);
        if (!requesterUser) return false;

        // SCENARIO 1: Manual PR from Planner -> Approved by their Engineer
        // Find if requester is in a Planner Group
        const requesterPlannerGroup = plannerGroups.find(pg => pg.userIds.includes(requesterUser.id));
        if (requesterPlannerGroup && requesterPlannerGroup.engineerGroupId) {
            // If requester is a planner, find the Engineer Group linked to that planner
            const linkedEngineerGroup = engineers.find(eg => eg.id === requesterPlannerGroup.engineerGroupId);
            // Check if current user is in that Engineer Group
            if (linkedEngineerGroup && linkedEngineerGroup.userIds.includes(currentUser.id)) {
                return true;
            }
        }

        // SCENARIO 2: Manual PR from Other Users (Admins/Clerks) -> Approved by Logistics Controller
        const isRequesterSystemAdmin = systemAdmins.some(g => g.userIds.includes(requesterUser.id));
        const isRequesterLogisticsClerk = logisticsClerks.some(g => g.userIds.includes(requesterUser.id));
        // Also include any other roles that are NOT Planners
        const isOtherUser = isRequesterSystemAdmin || isRequesterLogisticsClerk || (!requesterPlannerGroup && requesterUser.role !== 'Manager');

        if (isOtherUser) {
            const isCurrentUserLogisticsController = logisticsControllers.some(g => g.userIds.includes(currentUser.id));
            if (isCurrentUserLogisticsController) {
                return true;
            }
        }

        return false;

    }, [pr, currentUser, users, systemAdmins, logisticsClerks, logisticsControllers, plannerGroups, engineers, logisticsManagers]);
    
    // Update: Check if user is in Logistics Controllers group OR is a Supervisor for RFQ creation rights
    const isLogisticsController = useMemo(() => {
        return logisticsControllers.some(g => g.userIds.includes(currentUser.id)) || currentUser.role === 'Supervisor';
    }, [logisticsControllers, currentUser.id, currentUser.role]);

    const canCreateRFQ = isLogisticsController && pr.status === PRStatus.Approved;
    const canEdit = pr.requesterId === currentUser.id && (pr.status === PRStatus.Draft || pr.status === PRStatus.Rejected);


    const handleApprove = () => {
        onClose();
        onStatusUpdate(pr.id, PRStatus.Approved);
    };

    const handleReject = (remarks: string) => {
        setIsRejecting(false);
        onClose();
        onStatusUpdate(pr.id, PRStatus.Rejected, remarks);
    };
    
    const handleVendorSelection = (selectedIds: string[]) => {
        onCreateRFQ(pr, selectedIds);
        setIsVendorModalOpen(false);
    };

    const modalFooter = (
        <div className="flex justify-between w-full">
            <Button variant="secondary" onClick={() => alert('Print functionality coming soon!')}>Print</Button>
            <div className="flex space-x-2">
                 {canCreateRFQ && (
                    <Button variant="primary" onClick={() => setIsVendorModalOpen(true)}>Create RFQ</Button>
                )}
                {canApprove && (
                    <>
                        <Button variant="danger" onClick={() => setIsRejecting(true)}>Reject</Button>
                        <Button variant="primary" onClick={handleApprove}>Approve</Button>
                    </>
                )}
                 {canEdit && (
                    <Button variant="primary" onClick={() => onEdit(pr)}>Edit</Button>
                 )}
            </div>
        </div>
    );

    const DetailItem: React.FC<{label: string, children: React.ReactNode}> = ({label, children}) => (
        <div>
            <strong className="block text-xs text-gray-500 uppercase">{label}</strong>
            <div className="text-sm">{children}</div>
        </div>
    );
    
    return (
        <>
            <Modal isOpen={true} onClose={onClose} title={`Details for ${pr.id}`} footer={modalFooter}>
                <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <DetailItem label="Status"><Badge color={statusColors[pr.status]}>{pr.status}</Badge></DetailItem>
                        <DetailItem label="Priority"><Badge color={priorityColors[pr.priority]}>{pr.priority}</Badge></DetailItem>
                        <DetailItem label="Request Date">{pr.requestDate}</DetailItem>
                    </div>

                    {pr.type === PRType.Manual && (
                        <div className="grid grid-cols-2 gap-4">
                             <DetailItem label="Requester">{requester}</DetailItem>
                             <DetailItem label="Item/Service">{pr.itemType}</DetailItem>
                        </div>
                    )}
                    
                    <DetailItem label="Description">{displayDescription || 'N/A'}</DetailItem>
                    
                    {pr.specifications && <DetailItem label="Specifications"><p className="whitespace-pre-wrap">{pr.specifications}</p></DetailItem>}
                    
                    {pr.type === PRType.System && pr.items && (
                         <DetailItem label="Items / Quantity">
                             <ul className="list-disc pl-5">
                                 {pr.items.map(item => {
                                     const part = parts.find(p => p.id === item.partId);
                                     return <li key={item.partId}>{item.quantity} {item.unitOfMeasure} <span className="text-gray-500 text-xs">({part?.name || item.partId})</span></li>
                                 })}
                             </ul>
                         </DetailItem>
                    )}

                    <div className="border-t pt-4 grid grid-cols-2 gap-4">
                        <DetailItem label="Estimated Cost">{typeof pr.estimatedCost === 'number' ? `$${pr.estimatedCost.toFixed(2)}` : pr.estimatedCost}</DetailItem>
                        <DetailItem label="Vendor">{vendorName}</DetailItem>
                        <DetailItem label="Delivery Date">{pr.deliveryDate || 'N/A'}</DetailItem>
                        <DetailItem label="Delivery Location">{deliveryLocationName}</DetailItem>
                        {pr.assetId && <DetailItem label="Associated Asset">{asset}</DetailItem>}
                        {pr.workOrderId && <DetailItem label="Parent Work Order">{pr.workOrderId}</DetailItem>}
                    </div>
                    
                    {pr.justification && <DetailItem label="Justification"><p className="whitespace-pre-wrap">{pr.justification}</p></DetailItem>}
                    {pr.internalNotes && <DetailItem label="Internal Notes"><p className="whitespace-pre-wrap">{pr.internalNotes}</p></DetailItem>}

                     {pr.status !== PRStatus.Draft && pr.status !== PRStatus.Pending && (
                        <div className="border-t pt-4">
                            <h4 className="font-semibold">Approval Information</h4>
                            <div className="grid grid-cols-2 gap-4 mt-2">
                                <DetailItem label="Approver">{approver || 'N/A'}</DetailItem>
                                {pr.remarks && <DetailItem label="Remarks">{pr.remarks}</DetailItem>}
                            </div>
                        </div>
                     )}
                </div>
            </Modal>
            {isRejecting && <RejectModal onClose={() => setIsRejecting(false)} onReject={handleReject}/>}
            {isVendorModalOpen && (
                <VendorSelectionModal 
                    isOpen={isVendorModalOpen} 
                    onClose={() => setIsVendorModalOpen(false)} 
                    onConfirm={handleVendorSelection}
                    defaultVendorId={pr.type === PRType.System ? pr.vendorId : undefined}
                />
            )}
        </>
    );
};
