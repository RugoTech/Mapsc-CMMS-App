
import React, { useContext, useState, useEffect, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { Vendor, User, AuditLogEntry } from '../../types';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { Alert } from '../ui/Alert';

const VendorForm: React.FC<{ 
    isOpen: boolean, 
    onClose: () => void, 
    onSave: (v: Vendor) => void,
    vendorToEdit: Vendor | null 
}> = ({ isOpen, onClose, onSave, vendorToEdit }) => {
    const context = useContext(DataContext);
    const [formData, setFormData] = useState<Omit<Vendor, 'id'> & { id?: string }>({ name: '', contactPerson: '', email: '', phone: '', address: '' });

    useEffect(() => {
        if (isOpen) {
            if (vendorToEdit) {
                setFormData(vendorToEdit);
            } else {
                setFormData({ name: '', contactPerson: '', email: '', phone: '', address: '' });
            }
        }
    }, [isOpen, vendorToEdit]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({...prev, [e.target.name]: e.target.value}));
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!context) return;
        
        let vendorToSave: Vendor;
        if (vendorToEdit) {
            vendorToSave = formData as Vendor;
        } else {
            vendorToSave = {
                id: `VEND-${String(context.data.vendors.length + 1).padStart(3, '0')}`,
                ...formData
            } as Vendor;
        }
        onSave(vendorToSave);
        onClose();
    };
    
    const title = vendorToEdit ? 'Edit Vendor Details' : 'Add New Vendor';
    const buttonText = vendorToEdit ? 'Save Changes' : 'Save Vendor';

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={title} footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit" form="vendor-form">{buttonText}</Button></>}>
            <form id="vendor-form" onSubmit={handleSubmit} className="space-y-4">
                <Input label="Vendor Name" name="name" value={formData.name} onChange={handleChange} required />
                <Input label="Contact Person" name="contactPerson" value={formData.contactPerson} onChange={handleChange} required />
                <Input label="Email" name="email" type="email" value={formData.email} onChange={handleChange} required />
                <Input label="Phone" name="phone" value={formData.phone} onChange={handleChange} required />
                <Input label="Address" name="address" value={formData.address} onChange={handleChange} required />
            </form>
        </Modal>
    );
};

interface VendorListProps {
    onViewVendor: (vendorId: string) => void;
    currentUser: User | null;
}

export const VendorList: React.FC<VendorListProps> = ({ onViewVendor, currentUser }) => {
    const context = useContext(DataContext);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [vendorToEdit, setVendorToEdit] = useState<Vendor | null>(null);
    const [vendorToDelete, setVendorToDelete] = useState<Vendor | null>(null);
    const [deleteError, setDeleteError] = useState<string | null>(null);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { vendors } = data;

    const isLogisticsManager = useMemo(() => {
        return data.logisticsManagers.some(g => g.userIds.includes(currentUser.id));
    }, [data.logisticsManagers, currentUser.id]);

    const isLogisticsController = useMemo(() => {
        return data.logisticsControllers.some(g => g.userIds.includes(currentUser.id));
    }, [data.logisticsControllers, currentUser.id]);

    // Admin check: Role is Administrator OR Member of System Admin group
    const isAdmin = useMemo(() => {
        return currentUser.role === 'Administrator' || data.systemAdmins.some(g => g.userIds.includes(currentUser.id));
    }, [currentUser, data.systemAdmins]);

    const canAdd = isLogisticsManager || isLogisticsController || isAdmin;
    const canEdit = isLogisticsManager || isLogisticsController || isAdmin;
    const canDelete = isAdmin; // Only System Admin can delete

    const handleSave = (vendor: Vendor) => {
        setData(prev => {
            const isEditing = prev.vendors.some(v => v.id === vendor.id);
            const logAction = isEditing ? 'UPDATE' : 'CREATE';
            const logDetails = isEditing 
                ? `Updated vendor '${vendor.name}' (${vendor.id}).`
                : `Created new vendor '${vendor.name}' (${vendor.id}).`;

            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: logAction,
                entityType: 'Vendor',
                entityId: vendor.id,
                details: logDetails,
                status: 'Success'
            };

            if (isEditing) {
                return { 
                    ...prev, 
                    vendors: prev.vendors.map(v => v.id === vendor.id ? vendor : v),
                    auditLog: [logEntry, ...prev.auditLog]
                };
            } else {
                return { 
                    ...prev, 
                    vendors: [...prev.vendors, vendor],
                    auditLog: [logEntry, ...prev.auditLog]
                };
            }
        });
    };

    const handleDeleteClick = (vendor: Vendor) => {
        // Validation: Check dependencies (History)
        const hasPOs = data.purchaseOrders.some(po => po.vendorId === vendor.id);
        const hasPRs = data.purchaseRequisitions.some(pr => pr.vendorId === vendor.id);
        const hasRFQs = data.rfqs.some(rfq => rfq.vendorIds && rfq.vendorIds.includes(vendor.id));
        const hasParts = data.parts.some(p => p.vendorId === vendor.id);

        if (hasPOs || hasPRs || hasRFQs || hasParts) {
            let errorMsg = `Cannot delete vendor '${vendor.name}'. It is linked to existing history:`;
            if (hasPOs) errorMsg += `\n- Purchase Orders`;
            if (hasPRs) errorMsg += `\n- Purchase Requisitions`;
            if (hasRFQs) errorMsg += `\n- Requests for Quotation`;
            if (hasParts) errorMsg += `\n- Parts in Catalog`;
            alert(errorMsg);
            return;
        }

        setDeleteError(null);
        setVendorToDelete(vendor);
    };

    const confirmDelete = () => {
        if (!vendorToDelete) return;

        setData(prev => {
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'DELETE',
                entityType: 'Vendor',
                entityId: vendorToDelete.id,
                details: `Deleted vendor '${vendorToDelete.name}'.`,
                status: 'Success'
            };

            return {
                ...prev,
                vendors: prev.vendors.filter(v => v.id !== vendorToDelete.id),
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        setVendorToDelete(null);
    };

    const openAddForm = () => {
        setVendorToEdit(null);
        setIsFormOpen(true);
    };

    const openEditForm = (vendor: Vendor) => {
        setVendorToEdit(vendor);
        setIsFormOpen(true);
    };

    const columns = [
        { header: 'Vendor ID', accessor: 'id' as keyof Vendor },
        { header: 'Name', accessor: 'name' as keyof Vendor },
        { header: 'Contact Person', accessor: 'contactPerson' as keyof Vendor },
        { header: 'Email', accessor: 'email' as keyof Vendor },
        { header: 'Phone', accessor: 'phone' as keyof Vendor },
    ];

    return (
        <>
            <Card
                title="Approved Vendors"
                actions={
                    canAdd && (
                        <Button onClick={openAddForm}>Add Vendor</Button>
                    )
                }
            >
                <Table<Vendor>
                    columns={columns}
                    data={vendors}
                    renderRowActions={(vendor) => (
                         <div className="flex space-x-2 justify-end">
                            <Button variant="secondary" size="sm" onClick={() => onViewVendor(vendor.id)}>
                                Details
                            </Button>
                            {canEdit && (
                                <Button variant="secondary" size="sm" onClick={() => openEditForm(vendor)}>
                                    Edit
                                </Button>
                            )}
                            {canDelete && (
                                <Button variant="danger" size="sm" onClick={() => handleDeleteClick(vendor)}>
                                    Delete
                                </Button>
                            )}
                        </div>
                    )}
                />
            </Card>
            <VendorForm 
                isOpen={isFormOpen} 
                onClose={() => setIsFormOpen(false)} 
                onSave={handleSave} 
                vendorToEdit={vendorToEdit} 
            />
            {vendorToDelete && (
                <ConfirmationModal
                    isOpen={!!vendorToDelete}
                    onClose={() => setVendorToDelete(null)}
                    onConfirm={confirmDelete}
                    title="Confirm Vendor Deletion"
                    confirmText="Delete"
                    confirmButtonVariant="danger"
                >
                    <p>Are you sure you want to delete the vendor <span className="font-bold">{vendorToDelete.name}</span>?</p>
                    <p className="mt-2 text-sm text-gray-500">This action cannot be undone. Only vendors with no history (POs, PRs) can be deleted.</p>
                    {deleteError && <Alert type="error">{deleteError}</Alert>}
                </ConfirmationModal>
            )}
        </>
    );
};
