
import React, { useState, useContext, useMemo } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Badge } from '../ui/Badge';
import type { PurchaseOrder, RFQ } from '../../types';
import { POStatus, RFQStatus } from '../../types';

interface VendorDetailProps {
  vendorId: string;
  onBack: () => void;
}

type Tab = 'Purchase Orders' | 'RFQs' | 'Communication';

const poStatusColors: Record<POStatus, 'gray' | 'blue' | 'yellow' | 'green' | 'red'> = {
    [POStatus.Draft]: 'gray',
    [POStatus.PendingApproval]: 'blue',
    [POStatus.PendingHighValueApproval]: 'blue',
    [POStatus.Approved]: 'green',
    [POStatus.Rejected]: 'red',
    [POStatus.AddMoreInfo]: 'blue',
    [POStatus.Submitted]: 'yellow',
    [POStatus.PartiallyReceived]: 'yellow',
    [POStatus.Received]: 'green',
    [POStatus.Closed]: 'gray',
};

const rfqStatusColors: Record<RFQStatus, 'blue' | 'green' | 'red' | 'gray' | 'yellow'> = {
    [RFQStatus.Draft]: 'gray',
    [RFQStatus.WaitingApproval]: 'blue',
    [RFQStatus.SentToVendor]: 'yellow',
    [RFQStatus.QuotationReceived]: 'yellow',
    [RFQStatus.Approved]: 'green',
    [RFQStatus.Rejected]: 'red',
    [RFQStatus.Closed]: 'gray',
};

const formatCurrency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);


export const VendorDetail: React.FC<VendorDetailProps> = ({ vendorId, onBack }) => {
    const context = useContext(DataContext);
    const [activeTab, setActiveTab] = useState<Tab>('Purchase Orders');
    
    if (!context) return <div>Loading...</div>;

    const { data } = context;
    const vendor = data.vendors.find(v => v.id === vendorId);

    const vendorPOs = useMemo(() => {
        return data.purchaseOrders.filter(po => po.vendorId === vendorId);
    }, [data.purchaseOrders, vendorId]);

    const vendorRFQs = useMemo(() => {
        return data.rfqs.filter(rfq => rfq.vendorIds && rfq.vendorIds.includes(vendorId));
    }, [data.rfqs, vendorId]);

    const calculatePOTotal = (po: PurchaseOrder): number => {
        const subtotal = po.items.reduce((acc, item) => acc + (item.quantity * item.unitCost), 0);
        return subtotal * (1 + po.taxRate);
    };

    const renderTabContent = () => {
        switch (activeTab) {
            case 'Purchase Orders':
                const poColumns = [
                    { header: 'PO ID', accessor: 'id' as keyof PurchaseOrder },
                    { header: 'Order Date', accessor: 'orderDate' as keyof PurchaseOrder },
                    { header: 'Status', accessor: (item: PurchaseOrder) => <Badge color={poStatusColors[item.status]}>{item.status}</Badge> },
                    { header: 'Total Cost', accessor: (item: PurchaseOrder) => formatCurrency(calculatePOTotal(item)) },
                ];
                return (
                    <Card title="Past Purchase Orders">
                        <Table<PurchaseOrder>
                            columns={poColumns}
                            data={vendorPOs}
                        />
                    </Card>
                );
            case 'RFQs':
                const rfqColumns = [
                    { header: 'RFQ ID', accessor: 'id' as keyof RFQ },
                    { header: 'Date', accessor: 'date' as keyof RFQ },
                    { header: 'Status', accessor: (item: RFQ) => <Badge color={rfqStatusColors[item.status]}>{item.status}</Badge> },
                    { header: 'Description', accessor: 'description' as keyof RFQ },
                ];
                return (
                    <Card title="Past Requests for Quotation">
                        <Table<RFQ>
                            columns={rfqColumns}
                            data={vendorRFQs}
                        />
                    </Card>
                );
            case 'Communication':
                return (
                    <Card title="Communication History">
                        <div className="text-center p-8">
                            <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-200">No Communication History</h2>
                            <p className="text-gray-500 dark:text-gray-400 mt-2">Communication logging is a feature planned for a future update.</p>
                        </div>
                    </Card>
                );
            default:
                return null;
        }
    };

    if (!vendor) {
        return (
            <div>
                <p>Vendor not found.</p>
                <Button onClick={onBack}>Back to List</Button>
            </div>
        );
    }
    
    const tabs: Tab[] = ['Purchase Orders', 'RFQs', 'Communication'];
    
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-start">
                <div>
                    <Button onClick={onBack} variant="secondary" leftIcon={<svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>}>
                        Back to Vendors
                    </Button>
                    <div className="mt-4">
                        <h2 className="text-2xl font-bold">{vendor.name}</h2>
                        <p className="text-gray-500 dark:text-gray-400">{vendor.id}</p>
                    </div>
                </div>
                {/* Actions can go here if needed, like 'Edit Vendor' */}
            </div>
            
            <Card title="Vendor Information">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div><strong className="block text-gray-500">Contact Person</strong> {vendor.contactPerson}</div>
                    <div><strong className="block text-gray-500">Email</strong> {vendor.email}</div>
                    <div><strong className="block text-gray-500">Phone</strong> {vendor.phone}</div>
                    <div className="col-span-2 md:col-span-1"><strong className="block text-gray-500">Address</strong> {vendor.address}</div>
                </div>
            </Card>

            <div>
                <div className="border-b border-gray-200 dark:border-gray-700">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        {tabs.map((tab) => (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab)}
                                className={`${
                                    activeTab === tab
                                    ? 'border-indigo-500 text-indigo-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                            >
                            {tab}
                            </button>
                        ))}
                    </nav>
                </div>
                <div className="mt-6">
                    {renderTabContent()}
                </div>
            </div>
        </div>
    );
};
