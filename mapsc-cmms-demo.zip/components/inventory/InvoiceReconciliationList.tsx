
import React, { useState, useContext, useMemo, useEffect, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { DataContext } from '../../contexts/DataContext';
import type { Invoice, PurchaseOrder, User, AuditLogEntry } from '../../types';
import { POStatus, InvoiceStatus, InvoiceExceptionType, PRType } from '../../types';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { useSettings } from '../../contexts/SettingsContext';

const invoiceStatusColors: Record<InvoiceStatus, 'blue' | 'green' | 'red' | 'gray'> = {
    [InvoiceStatus.Pending]: 'blue',
    [InvoiceStatus.Approved]: 'green',
    [InvoiceStatus.Disputed]: 'red',
    [InvoiceStatus.Paid]: 'gray',
};

// --- Exception Details Modal ---
const ExceptionDetailsModal: React.FC<{
    onConfirm: (details: { exceptionType: InvoiceExceptionType, exceptionNotes: string }) => void;
    onCancel: () => void;
    initialDiscrepancies: { price: boolean; quantity: boolean };
}> = ({ onConfirm, onCancel, initialDiscrepancies }) => {

    const getDefaultType = () => {
        if (initialDiscrepancies.price && initialDiscrepancies.quantity) return InvoiceExceptionType.Other;
        if (initialDiscrepancies.price) return InvoiceExceptionType.PriceMismatch;
        if (initialDiscrepancies.quantity) return InvoiceExceptionType.QuantityMismatch;
        return InvoiceExceptionType.Other;
    };

    const [exceptionType, setExceptionType] = useState<InvoiceExceptionType>(getDefaultType());
    const [exceptionNotes, setExceptionNotes] = useState('');

    const handleConfirm = () => {
        if (!exceptionNotes.trim()) {
            alert('Exception notes are required.');
            return;
        }
        onConfirm({ exceptionType, exceptionNotes });
    };

    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onCancel}>Cancel</Button>
            <Button variant="primary" onClick={handleConfirm}>Save Exception & Approve</Button>
        </>
    );

    return (
        <Modal isOpen={true} onClose={onCancel} title="Approve with Exception" footer={modalFooter}>
            <div className="space-y-4">
                <p className="text-sm">Please select the type of exception and provide detailed notes for this approval.</p>
                <div>
                    <label htmlFor="exceptionType" className="block text-sm font-medium">Exception Type</label>
                    <select
                        id="exceptionType"
                        value={exceptionType}
                        onChange={(e) => setExceptionType(e.target.value as InvoiceExceptionType)}
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                    >
                        {Object.values(InvoiceExceptionType).map(type => <option key={type} value={type}>{type}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="exceptionNotes" className="block text-sm font-medium">Exception Notes</label>
                    <textarea
                        id="exceptionNotes"
                        rows={4}
                        value={exceptionNotes}
                        onChange={(e) => setExceptionNotes(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        placeholder="e.g., 'Approved price increase per email from vendor on 2024-08-01.'"
                        required
                    />
                </div>
            </div>
        </Modal>
    );
};


// --- Invoice Modal ---

interface InvoiceModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (invoice: Invoice) => void;
    invoice: Invoice | null;
    poForInvoice: PurchaseOrder;
}

const InvoiceModal: React.FC<InvoiceModalProps> = ({ isOpen, onClose, onSave, invoice, poForInvoice }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [invoiceData, setInvoiceData] = useState<Invoice | null>(null);
    const [isExceptionModalOpen, setIsExceptionModalOpen] = useState(false);
    const [attachmentFile, setAttachmentFile] = useState<File | null>(null);
    const formatCurrency = useCurrencyFormatter();

    const convertToDefault = useCallback((value: number, fromCurrency: string): number => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
    }, [settings.currency, settings.exchangeRate]);

    useEffect(() => {
        if (!context || !isOpen) return;
        setAttachmentFile(null);

        if (invoice) { // Editing existing invoice
            setInvoiceData(invoice);
        } else { // Creating new invoice for the given PO
            const newInvoice: Invoice = {
                id: `INV-${String(context.data.invoices.length + 1).padStart(3, '0')}`,
                poId: poForInvoice.id,
                invoiceNumber: '',
                invoiceDate: new Date().toISOString().split('T')[0],
                status: InvoiceStatus.Pending,
                items: poForInvoice.items.map((poItem, index) => {
                    const convertedUnitCost = convertToDefault(poItem.unitCost, poForInvoice.currency);
                    return {
                        poItemIndex: index,
                        partId: poItem.partId,
                        description: poItem.description,
                        orderedQty: poItem.quantity,
                        unitOfMeasure: poItem.unitOfMeasure,
                        receivedQty: poItem.quantityReceived,
                        orderedUnitCost: convertedUnitCost,
                        billedQty: poItem.quantityReceived, // Default billed to received
                        billedUnitCost: convertedUnitCost,    // Default billed to ordered (converted)
                    };
                }),
            };
            setInvoiceData(newInvoice);
        }
    }, [invoice, poForInvoice, isOpen, context, convertToDefault]);

    const handleItemChange = (itemIndex: number, field: 'billedQty' | 'billedUnitCost', value: number) => {
        if (!invoiceData) return;
        const newItems = [...invoiceData.items];
        newItems[itemIndex] = { ...newItems[itemIndex], [field]: value };
        setInvoiceData({ ...invoiceData, items: newItems });
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setAttachmentFile(e.target.files[0]);
        }
    };

    const handleFieldChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!invoiceData) return;
        setInvoiceData({ ...invoiceData, [e.target.name]: e.target.value });
    };

    const discrepancies = useMemo(() => {
        if (!invoiceData) return { hasDiscrepancy: false, items: {}, hasPriceMismatch: false, hasQuantityMismatch: false };
        let hasDiscrepancy = false;
        let hasPriceMismatch = false;
        let hasQuantityMismatch = false;
        const items: {[itemIndex: number]: string[]} = {};
        
        invoiceData.items.forEach((item, index) => {
            const msgs: string[] = [];
            if (item.billedQty > item.receivedQty) {
                hasDiscrepancy = true;
                hasQuantityMismatch = true;
                msgs.push(`Billed Qty (${item.billedQty}) > Received Qty (${item.receivedQty})`);
            }
            if (item.billedUnitCost > item.orderedUnitCost) {
                hasDiscrepancy = true;
                hasPriceMismatch = true;
                msgs.push(`Billed Price (${formatCurrency(item.billedUnitCost)}) > Ordered Price (${formatCurrency(item.orderedUnitCost)})`);
            }
            if (msgs.length > 0) {
                items[index] = msgs;
            }
        });
        return { hasDiscrepancy, items, hasPriceMismatch, hasQuantityMismatch };
    }, [invoiceData, formatCurrency]);

    const saveInvoice = (newStatus: InvoiceStatus, options: { exceptionType?: InvoiceExceptionType; exceptionNotes?: string } = {}) => {
        if (!invoiceData || !invoiceData.invoiceNumber.trim()) {
            alert("Invoice number is required.");
            return;
        }

        if (!attachmentFile && !invoiceData.attachment) {
            alert("An invoice attachment is mandatory. Please upload the invoice document.");
            return;
        }

        const finalInvoice: Invoice = {
            ...invoiceData,
            status: newStatus,
            exceptionType: options.exceptionType,
            exceptionNotes: options.exceptionNotes,
            attachment: attachmentFile
                ? { name: attachmentFile.name, url: '#' }
                : invoiceData.attachment,
        };
        onSave(finalInvoice);
    };

    const handleApprove = () => {
        if (discrepancies.hasDiscrepancy) {
            setIsExceptionModalOpen(true);
        } else {
            saveInvoice(InvoiceStatus.Approved);
        }
    };

    const handleMarkAsPaid = () => {
        saveInvoice(InvoiceStatus.Paid);
    };
    
    const handleExceptionConfirm = ({ exceptionType, exceptionNotes }: { exceptionType: InvoiceExceptionType, exceptionNotes: string }) => {
        saveInvoice(InvoiceStatus.Approved, {
            exceptionType,
            exceptionNotes,
        });
        setIsExceptionModalOpen(false);
    };

    if (!context) return null;

    const totalBilled = invoiceData ? invoiceData.items.reduce((sum, i) => sum + (i.billedQty * i.billedUnitCost), 0) : 0;
    const modalTitle = invoiceData ? (invoiceData.invoiceNumber ? `Reconcile Invoice: ${invoiceData.invoiceNumber}` : `Process Invoice for PO: ${poForInvoice.id}`) : "Process Invoice";
    const isEditable = invoiceData?.status === InvoiceStatus.Pending;

    const modalFooter = (
        invoiceData && (
            <div className="flex w-full justify-between items-center">
                <div className="font-bold text-lg">Total: {formatCurrency(totalBilled)}</div>
                <div className="flex space-x-2">
                    {invoiceData.status === InvoiceStatus.Pending && (
                         <Button 
                            variant="primary" 
                            onClick={handleApprove}
                            disabled={!isEditable}
                        >
                            {discrepancies.hasDiscrepancy ? 'Approve with Exception' : 'Approve for Payment'}
                        </Button>
                    )}
                    {invoiceData.status === InvoiceStatus.Approved && (
                        <Button 
                            variant="primary" 
                            onClick={handleMarkAsPaid}
                        >
                            Mark as Paid
                        </Button>
                    )}
                </div>
            </div>
        )
    );

    return (
        <>
        <Modal isOpen={isOpen} onClose={onClose} title={modalTitle} footer={modalFooter}>
            {invoiceData ? (
                <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <Input label="Invoice Number" name="invoiceNumber" value={invoiceData.invoiceNumber} onChange={handleFieldChange} required disabled={!isEditable}/>
                        <Input label="Invoice Date" name="invoiceDate" type="date" value={invoiceData.invoiceDate} onChange={handleFieldChange} required disabled={!isEditable}/>
                    </div>

                    {invoiceData.exceptionType && (
                        <div className="p-3 my-2 border rounded-lg bg-yellow-50 dark:bg-yellow-900/20 border-yellow-300 dark:border-yellow-700 text-sm">
                            <h4 className="font-semibold text-yellow-800 dark:text-yellow-200 flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 3.001-1.742 3.001H4.42c-1.53 0-2.493-1.667-1.743-3.001l5.58-9.92zM10 13a1 1 0 110-2 1 1 0 010 2zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                </svg>
                                Exception Approved: {invoiceData.exceptionType}
                            </h4>
                            <p className="mt-1 text-yellow-700 dark:text-yellow-300">{invoiceData.exceptionNotes}</p>
                        </div>
                    )}
                    
                    <div className="overflow-x-auto">
                        <table className="min-w-full text-sm">
                            <thead className="bg-gray-100 dark:bg-gray-700">
                                <tr>
                                    <th className="p-2 text-left">Item</th>
                                    <th className="p-2 text-center">Ordered</th>
                                    <th className="p-2 text-center">Received</th>
                                    <th className="p-2 text-center">Billed</th>
                                </tr>
                            </thead>
                            <tbody>
                                {invoiceData.items.map((item, index) => {
                                    const discrepancyMsgs = discrepancies.items[index];
                                    return (
                                        <tr key={index} className={`border-b dark:border-gray-700 ${discrepancyMsgs ? 'bg-red-100 dark:bg-red-900/30' : ''}`}>
                                            <td className="p-2 align-top">
                                                <p className="font-semibold">{item.description}</p>
                                                <p className="text-xs text-gray-500">{item.partId}</p>
                                                {discrepancyMsgs && <p className="text-xs text-red-600 dark:text-red-400 mt-1">{discrepancyMsgs.join('; ')}</p>}
                                            </td>
                                            <td className="p-2 align-top text-center">
                                                <div>{item.orderedQty} {item.unitOfMeasure}</div>
                                                <div className="text-xs text-gray-500">@ {formatCurrency(item.orderedUnitCost)}</div>
                                            </td>
                                            <td className="p-2 align-top text-center font-semibold">{item.receivedQty} {item.unitOfMeasure}</td>
                                            <td className="p-2 align-top">
                                                <div className="flex gap-1 items-center">
                                                    <Input id={`billedQty-${index}`} label="" type="number" value={item.billedQty} onChange={e => handleItemChange(index, 'billedQty', Number(e.target.value))} className="w-20 text-center" disabled={!isEditable}/>
                                                    <span className="text-xs text-gray-500">{item.unitOfMeasure}</span>
                                                    <Input id={`billedCost-${index}`} label="" type="number" value={item.billedUnitCost} onChange={e => handleItemChange(index, 'billedUnitCost', Number(e.target.value))} className="w-24 text-right" step="0.01" disabled={!isEditable}/>
                                                </div>
                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                     <div className="border-t pt-4">
                        <label htmlFor="invoiceAttachment" className="block text-sm font-medium">Invoice Attachment</label>
                        {invoiceData.attachment && !attachmentFile && (
                            <div className="text-sm mt-1">
                                Current: <a href={invoiceData.attachment.url} target="_blank" rel="noopener noreferrer" className="text-indigo-500 hover:underline">{invoiceData.attachment.name}</a>
                            </div>
                        )}
                        {attachmentFile && <div className="text-sm mt-1">New: {attachmentFile.name}</div>}
                        <input 
                            id="invoiceAttachment" 
                            type="file" 
                            onChange={handleFileChange} 
                            className="mt-2 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-900/50 file:text-indigo-700 dark:file:text-indigo-300 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-900" 
                            disabled={!isEditable}
                            required={!invoiceData.attachment}
                        />
                    </div>
                </div>
            ) : (
                <div>Loading...</div>
            )}
        </Modal>
        {isExceptionModalOpen && (
            <ExceptionDetailsModal
                onConfirm={handleExceptionConfirm}
                onCancel={() => setIsExceptionModalOpen(false)}
                initialDiscrepancies={{ price: discrepancies.hasPriceMismatch, quantity: discrepancies.hasQuantityMismatch }}
            />
        )}
        </>
    )
};

interface InvoiceReconciliationListProps {
    currentUser: User | null;
}

export const InvoiceReconciliationList: React.FC<InvoiceReconciliationListProps> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [invoiceToProcess, setInvoiceToProcess] = useState<Invoice | null>(null);
    const [poForInvoice, setPoForInvoice] = useState<PurchaseOrder | null>(null);
    const [activeTab, setActiveTab] = useState<'pending' | 'paid'>('pending');
    const formatCurrency = useCurrencyFormatter();
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { purchaseOrders, vendors, invoices, rfqs, purchaseRequisitions } = data;

    const getVendorName = useCallback((vendorId: string) => vendors.find(v => v.id === vendorId)?.name || 'N/A', [vendors]);
    
    const calculatePOTotal = useCallback((po: PurchaseOrder) => {
        const subtotal = po.items.reduce((total, item) => total + item.quantity * item.unitCost, 0);
        return subtotal * (1 + po.taxRate);
    }, []);
    
    const calculateInvoiceTotal = useCallback((invoice: Invoice) => {
        return invoice.items.reduce((total, item) => total + item.billedQty * item.billedUnitCost, 0);
    }, []);

    // Helper to convert currency to system default
    const convertToDefault = useCallback((value: number, fromCurrency: string): number => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
    }, [settings.currency, settings.exchangeRate]);

    const poReadyForInvoicing = useMemo(() => {
        return purchaseOrders.filter(po => {
            const hasOpenInvoice = invoices.some(i => i.poId === po.id && i.status !== InvoiceStatus.Paid);
            if (!hasOpenInvoice && po.status !== POStatus.Received && po.status !== POStatus.PartiallyReceived) {
                return false;
            }
    
            const rfq = rfqs.find(r => r.id === po.rfqId);
            if (!rfq) return canSeeAllZones;
            const pr = purchaseRequisitions.find(p => p.id === rfq.prId);
            if (!pr) return canSeeAllZones;
    
            const prZoneId = pr.type === PRType.System ? pr.zoneId : pr.deliveryZoneId;
            const hasZoneAccess = canSeeAllZones || !prZoneId || accessibleZoneIds.includes(prZoneId);
    
            return hasZoneAccess;
        });
    }, [purchaseOrders, invoices, rfqs, purchaseRequisitions, canSeeAllZones, accessibleZoneIds]);

    const paidInvoices = useMemo(() => {
        return invoices.filter(inv => {
            if (inv.status !== InvoiceStatus.Paid) return false;

            const po = purchaseOrders.find(p => p.id === inv.poId);
            if (!po) return canSeeAllZones; 
            const rfq = rfqs.find(r => r.id === po.rfqId);
            if (!rfq) return canSeeAllZones;
            const pr = purchaseRequisitions.find(p => p.id === rfq.prId);
            if (!pr) return canSeeAllZones;

            const prZoneId = pr.type === PRType.System ? pr.zoneId : pr.deliveryZoneId;
            const hasZoneAccess = canSeeAllZones || !prZoneId || accessibleZoneIds.includes(prZoneId);

            return hasZoneAccess;
        }).sort((a,b) => new Date(b.invoiceDate).getTime() - new Date(a.invoiceDate).getTime());
    }, [invoices, purchaseOrders, rfqs, purchaseRequisitions, canSeeAllZones, accessibleZoneIds]);


    const handleProcessInvoiceClick = (po: PurchaseOrder) => {
        const existingInvoice = invoices.find(inv => inv.poId === po.id);
        setPoForInvoice(po);
        setInvoiceToProcess(existingInvoice || null);
        setIsModalOpen(true);
    };
    
    const handleViewInvoiceDetails = (invoice: Invoice) => {
        const po = purchaseOrders.find(p => p.id === invoice.poId);
        if (po) {
            setPoForInvoice(po);
            setInvoiceToProcess(invoice);
            setIsModalOpen(true);
        } else {
            alert(`Could not find associated Purchase Order ${invoice.poId}`);
        }
    };

    const handleSaveInvoice = (invoice: Invoice) => {
        setData(prev => {
            const exists = prev.invoices.some(i => i.id === invoice.id);
            const logAction = exists ? 'UPDATE' : 'CREATE';
            const logDetails = `${logAction === 'CREATE' ? 'Created' : 'Updated'} invoice '${invoice.invoiceNumber}' (${invoice.id}) for PO ${invoice.poId}. Status: ${invoice.status}.`;
            
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: logAction,
                entityType: 'Invoice',
                entityId: invoice.id,
                details: logDetails,
                status: 'Success'
            };
    
            if (exists) {
                return { 
                    ...prev, 
                    invoices: prev.invoices.map(i => i.id === invoice.id ? invoice : i),
                    auditLog: [logEntry, ...prev.auditLog]
                };
            }
            return { 
                ...prev, 
                invoices: [...prev.invoices, invoice],
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        setInvoiceToProcess(invoice);
    };

    const pendingColumns = [
        { header: 'PO #', accessor: 'id' as keyof PurchaseOrder },
        { header: 'Vendor', accessor: (item: PurchaseOrder) => getVendorName(item.vendorId) },
        { header: 'Order Date', accessor: 'orderDate' as keyof PurchaseOrder },
        { 
            header: 'Amount', 
            accessor: (item: PurchaseOrder) => formatCurrency(convertToDefault(calculatePOTotal(item), item.currency)) 
        },
        { header: 'Receiving Status', accessor: (item: PurchaseOrder) => <Badge color="green">{item.status}</Badge> },
        { header: 'Invoice Status', accessor: (item: PurchaseOrder) => {
            const invoice = invoices.find(inv => inv.poId === item.id);
            if (!invoice) return <Badge color="gray">Not Invoiced</Badge>;
            return (
                <div className="flex items-center space-x-1">
                    <Badge color={invoiceStatusColors[invoice.status]}>{invoice.status}</Badge>
                    {invoice.exceptionType && (
                         <span title={`${invoice.exceptionType}: ${invoice.exceptionNotes}`} className="text-yellow-500">
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 3.001-1.742 3.001H4.42c-1.53 0-2.493-1.667-1.743-3.001l5.58-9.92zM10 13a1 1 0 110-2 1 1 0 010 2zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                            </svg>
                        </span>
                    )}
                </div>
            );
        }},
    ];

     const paidColumns = [
        { header: 'Invoice #', accessor: 'invoiceNumber' as keyof Invoice },
        { header: 'PO #', accessor: 'poId' as keyof Invoice },
        { header: 'Vendor', accessor: (item: Invoice) => {
            const po = purchaseOrders.find(p => p.id === item.poId);
            return po ? getVendorName(po.vendorId) : 'N/A';
        }},
        { header: 'Invoice Date', accessor: 'invoiceDate' as keyof Invoice },
        { header: 'Amount', accessor: (item: Invoice) => {
            const po = purchaseOrders.find(p => p.id === item.poId);
            const currency = po ? po.currency : settings.currency;
            return formatCurrency(convertToDefault(calculateInvoiceTotal(item), currency));
        }},
        { header: 'Status', accessor: (item: Invoice) => <Badge color={invoiceStatusColors[item.status]}>{item.status}</Badge> },
    ];

    const tabs: {id: 'pending' | 'paid', label: string}[] = [
        { id: 'pending', label: 'Pending Reconciliation' },
        { id: 'paid', label: 'Paid Invoices' },
    ];

    return (
        <>
            <Card title="Invoice Reconciliation">
                <div className="border-b border-gray-200 dark:border-gray-700">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        {tabs.map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`${
                                    activeTab === tab.id
                                    ? 'border-indigo-500 text-indigo-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                            >
                            {tab.label}
                            </button>
                        ))}
                    </nav>
                </div>

                <div className="mt-6">
                    {activeTab === 'pending' && (
                        <>
                            <p className="mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg text-sm text-gray-600 dark:text-gray-300">
                                The following purchase orders have received items and are ready for invoice processing and payment.
                            </p>
                            <Table<PurchaseOrder>
                                columns={pendingColumns}
                                data={poReadyForInvoicing}
                                renderRowActions={(po) => {
                                    const invoice = invoices.find(inv => inv.poId === po.id);
                                    if (invoice && invoice.status === InvoiceStatus.Paid) {
                                        return (
                                            <Button variant="secondary" size="sm" disabled>
                                                Reconciled
                                            </Button>
                                        );
                                    }
                                    return (
                                        <Button variant="primary" size="sm" onClick={() => handleProcessInvoiceClick(po)}>
                                            Process Invoice
                                        </Button>
                                    );
                                }}
                            />
                        </>
                    )}
                    {activeTab === 'paid' && (
                         <>
                            <p className="mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg text-sm text-gray-600 dark:text-gray-300">
                                This list shows all invoices that have been fully processed and marked as paid.
                            </p>
                            <Table<Invoice>
                                columns={paidColumns}
                                data={paidInvoices}
                                renderRowActions={(invoice) => (
                                    <Button variant="secondary" size="sm" onClick={() => handleViewInvoiceDetails(invoice)}>
                                        View Details
                                    </Button>
                                )}
                            />
                        </>
                    )}
                </div>
            </Card>
            {isModalOpen && poForInvoice && (
                <InvoiceModal
                    isOpen={isModalOpen}
                    onClose={() => { setIsModalOpen(false); setPoForInvoice(null); setInvoiceToProcess(null); }}
                    onSave={handleSaveInvoice}
                    invoice={invoiceToProcess}
                    poForInvoice={poForInvoice}
                />
            )}
        </>
    );
};
