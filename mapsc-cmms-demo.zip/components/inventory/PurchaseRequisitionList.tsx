
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { PRStatus, PRType, Priority, RFQStatus, PRItemType } from '../../types';
import type { PurchaseRequisition, RFQ, User, AuditLogEntry, Message } from '../../types';
import { InitialMPRForm } from './InitialMPRForm';
import { ManualPRForm } from './ManualPRForm';
import { PRDetailModal } from './PRDetailModal';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { useDateFormatter } from '../../hooks/useDateFormatter';

// Colors for status and priority badges
const statusColors: Record<PRStatus, 'blue' | 'green' | 'red' | 'gray' | 'yellow'> = {
    [PRStatus.Draft]: 'gray',
    [PRStatus.Pending]: 'blue',
    [PRStatus.Approved]: 'green',
    [PRStatus.Rejected]: 'red',
    [PRStatus.RFQCreated]: 'yellow',
};

const priorityColors: Record<Priority, 'blue' | 'yellow' | 'red'> = {
    [Priority.Low]: 'blue',
    [Priority.Medium]: 'yellow',
    [Priority.High]: 'red',
    [Priority.Critical]: 'red',
};

export const PurchaseRequisitionList: React.FC<{ currentUser: User | null }> = ({ currentUser }) => {
    const context = useContext(DataContext);
    // State for modals
    const [isInitialFormOpen, setIsInitialFormOpen] = useState(false);
    const [manualPRData, setManualPRData] = useState<PurchaseRequisition | null>(null);
    const [viewingPR, setViewingPR] = useState<PurchaseRequisition | null>(null);
    const formatDate = useDateFormatter();

    // State for filters
    const [filters, setFilters] = useState({ status: '', type: '', priority: '' });
    
    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { purchaseRequisitions, users, rfqs, systemAdmins, logisticsClerks, logisticsControllers, plannerGroups, engineers } = data;

    const isManagerOrTopManagement = useMemo(() => {
        if (!currentUser) return false;
        if (currentUser.role === 'Manager' || currentUser.role === 'Factory Manager') return true;
        return data.topManagementGroups.some(g => g.userIds.includes(currentUser.id));
    }, [currentUser, data.topManagementGroups]);
    
    // Updated: Check group membership for Logistics Manager
    const isLGManager = useMemo(() => {
        return data.logisticsManagers.some(g => g.userIds.includes(currentUser.id));
    }, [data.logisticsManagers, currentUser.id]);

    // Updated: Check group membership for Logistics Controller
    const isLogisticsController = useMemo(() => {
        return data.logisticsControllers.some(g => g.userIds.includes(currentUser.id)) || currentUser.role === 'Supervisor';
    }, [data.logisticsControllers, currentUser.id, currentUser.role]);

    const isTopManagement = useMemo(() => {
        return data.topManagementGroups.some(g => g.userIds.includes(currentUser.id));
    }, [data.topManagementGroups, currentUser.id]);

    const isEngManager = useMemo(() => {
        return data.assetManagers.some(g => g.userIds.includes(currentUser.id));
    }, [data.assetManagers, currentUser.id]);

    // Helper functions
    const getRequesterName = useCallback((pr: PurchaseRequisition) => {
        if (pr.type === PRType.System) return 'System';
        return pr.requesterId ? users.find(u => u.id === pr.requesterId)?.name || 'N/A' : 'N/A';
    }, [users]);
    
    const getDescription = (pr: PurchaseRequisition) => {
        if (pr.type === PRType.System) {
            const part = pr.items?.[0] ? context.data.parts.find(p => p.id === pr.items![0].partId) : null;
            return part ? `Request for ${pr.items![0].quantity} x ${part.name}` : 'System Generated Request';
        }
        return pr.description || 'N/A';
    };

    // Filtering logic
    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setFilters(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };
    const clearFilters = () => setFilters({ status: '', type: '', priority: '' });

    const filteredPRs = useMemo(() => {
        return purchaseRequisitions
            .filter(pr => {
                // Admin sees everything
                if (currentUser.role === 'Administrator') return true;
                
                // Top Management and ENG Managers see everything (View Only enforced by lack of action buttons in UI)
                if (isTopManagement || isEngManager) return true;
                
                // Requester can always see their own PRs (System or Manual)
                if (pr.requesterId === currentUser.id) return true;

                // Apply role-based visibility rules
                if (pr.type === PRType.System) {
                    // LG Manager sees Pending SPRs for approval
                    if (isLGManager && pr.status === PRStatus.Pending) return true;
                    // Logistics Controllers see Approved SPRs to create RFQs
                    if (isLogisticsController && pr.status === PRStatus.Approved) return true;
                } else { // Manual PR
                    // Approvers should see pending MPRs for their attention
                    if (pr.status === PRStatus.Pending) {
                        const requester = data.users.find(u => u.id === pr.requesterId);
                        if (requester) {
                            // 1. Logistics Controller Logic
                            // Approves PRs from System Admins or Logistics Clerks (or users not in a Planner Group)
                            const isRequesterSystemAdmin = systemAdmins.some(g => g.userIds.includes(requester.id));
                            const isRequesterLogisticsClerk = logisticsClerks.some(g => g.userIds.includes(requester.id));
                            const isRequesterPlanner = plannerGroups.some(g => g.userIds.includes(requester.id));
                            
                            if ((isRequesterSystemAdmin || isRequesterLogisticsClerk || !isRequesterPlanner) && isLogisticsController) {
                                return true;
                            }

                            // 2. Engineer Logic
                            // Approves PRs from Planners linked to their Engineer Group
                            const requesterPlannerGroup = plannerGroups.find(pg => pg.userIds.includes(requester.id));
                            if (requesterPlannerGroup && requesterPlannerGroup.engineerGroupId) {
                                const linkedEngineerGroup = engineers.find(eg => eg.id === requesterPlannerGroup.engineerGroupId);
                                if (linkedEngineerGroup && linkedEngineerGroup.userIds.includes(currentUser.id)) {
                                    return true;
                                }
                            }
                        }
                    }
                    
                    // Logistics Controllers need to see Approved Manual PRs to create RFQs
                    // This covers PRs approved by Engineers or by Controllers themselves
                    if (isLogisticsController && pr.status === PRStatus.Approved) return true;
                }

                return false; // Default to not showing if no rule matches
            })
            .filter(pr => {
                // Then apply the user's table filters
                const statusMatch = filters.status ? pr.status === filters.status : true;
                const typeMatch = filters.type ? pr.type === filters.type : true;
                const priorityMatch = filters.priority ? pr.priority === filters.priority : true;
                return statusMatch && typeMatch && priorityMatch;
            });
    }, [purchaseRequisitions, filters, currentUser, isLGManager, isLogisticsController, isTopManagement, isEngManager, data.users, systemAdmins, logisticsClerks, plannerGroups, engineers]);

    // Handlers for creating Manual PRs (two-step process)
    const handleInitialProceed = (initialData: {
        description: string;
        itemType: PRItemType;
        specifications: string;
        priority: Priority;
    }) => {
        const nextId = `MPR-${String(purchaseRequisitions.filter(p => p.type === PRType.Manual).length + 1).padStart(3, '0')}`;
        const newPR: PurchaseRequisition = {
            id: nextId,
            type: PRType.Manual,
            requestDate: new Date().toISOString().split('T')[0],
            status: PRStatus.Draft,
            requesterId: currentUser.id,
            budgetCode: '',
            ...initialData
        };
        setManualPRData(newPR);
        setIsInitialFormOpen(false);
    };
    
    const handleSaveManualPR = (prToSave: PurchaseRequisition) => {
        setData(prev => {
            const exists = prev.purchaseRequisitions.some(p => p.id === prToSave.id);
            const logAction = exists ? 'UPDATE' : 'CREATE';
            const logDetails = exists
                ? `Updated manual PR '${prToSave.description}' (${prToSave.id}).`
                : `Created new manual PR '${prToSave.description}' (${prToSave.id}).`;
            
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: logAction,
                entityType: 'PurchaseRequisition',
                entityId: prToSave.id,
                details: logDetails,
                status: 'Success'
            };

            if (exists) {
                return {
                    ...prev,
                    purchaseRequisitions: prev.purchaseRequisitions.map(p => p.id === prToSave.id ? prToSave : p),
                    auditLog: [logEntry, ...prev.auditLog]
                };
            }
            return {
                ...prev,
                purchaseRequisitions: [...prev.purchaseRequisitions, prToSave],
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        setManualPRData(null);
    };

    // Handler for status updates from detail modal
    const handleStatusUpdate = (prId: string, status: PRStatus, remarks?: string) => {
        setData(prev => {
            const pr = prev.purchaseRequisitions.find(p => p.id === prId);
            if (!pr || !pr.requesterId) return prev;
        
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'UPDATE',
                entityType: 'PurchaseRequisition',
                entityId: prId,
                details: `Updated status of PR '${getDescription(pr)}' to ${status}.`,
                status: 'Success'
            };

            let newMessages = [...prev.messages];

            // Only send message if current user is NOT the requester
            if (currentUser.id !== pr.requesterId) {
                const message: Message = {
                    id: `MSG-${String(prev.messages.length + 1).padStart(3, '0')}`,
                    sender: currentUser.name,
                    recipientId: pr.requesterId,
                    title: `Your PR ${prId} has been ${status}`,
                    body: `Your purchase requisition "${getDescription(pr)}" was updated to '${status.toLowerCase()}' by ${currentUser.name}.${remarks ? `\n\nRemarks: ${remarks}` : ''}`,
                    date: new Date().toISOString(),
                    read: false,
                };
                newMessages = [message, ...prev.messages];
            }
    
            return {
                ...prev,
                purchaseRequisitions: prev.purchaseRequisitions.map(p =>
                    p.id === prId ? { ...p, status, remarks: remarks || p.remarks, approverId: currentUser!.id } : p
                ),
                auditLog: [logEntry, ...prev.auditLog],
                messages: newMessages,
            };
        });
    };

    // Handler for creating RFQ
    const handleCreateRFQ = (pr: PurchaseRequisition, selectedVendorIds: string[]) => {
        
        if (selectedVendorIds.length === 0) {
             alert('At least one vendor must be selected to create an RFQ.');
             return;
        }

        const newRFQ: RFQ = {
            id: `RFQ-${String(rfqs.length + 1).padStart(3, '0')}`,
            date: new Date().toISOString().split('T')[0],
            prId: pr.id,
            requesterId: currentUser.id, // The user creating the RFQ (e.g., procurement)
            priority: pr.priority,
            description: getDescription(pr),
            vendorIds: selectedVendorIds, // Use the vendors selected in the modal
            deliveryDate: pr.deliveryDate || '',
            justification: pr.justification || 'As per linked PR',
            status: RFQStatus.WaitingApproval,
        };

        setData(prev => {
            const rfqLogEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'CREATE',
                entityType: 'RFQ',
                entityId: newRFQ.id,
                details: `Created RFQ ${newRFQ.id} from PR ${pr.id}.`,
                status: 'Success'
            };
    
            const prLogEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 2).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'UPDATE',
                entityType: 'PurchaseRequisition',
                entityId: pr.id,
                details: `Updated status of PR ${pr.id} to ${PRStatus.RFQCreated}.`,
                status: 'Success'
            };
            
            return {
                ...prev,
                rfqs: [...prev.rfqs, newRFQ],
                purchaseRequisitions: prev.purchaseRequisitions.map(p =>
                    p.id === pr.id ? { ...p, status: PRStatus.RFQCreated } : p
                ),
                auditLog: [rfqLogEntry, prLogEntry, ...prev.auditLog]
            }
        });
        
        setViewingPR(null);
        alert(`RFQ ${newRFQ.id} created successfully for PR ${pr.id}. It is now waiting for approval.`);
    };
    
    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    const columns = [
        { header: 'PR ID', accessor: 'id' as keyof PurchaseRequisition },
        { header: 'Type', accessor: 'type' as keyof PurchaseRequisition },
        { header: 'Description', accessor: (item: PurchaseRequisition) => <span className="truncate">{getDescription(item)}</span> },
        { header: 'Requester', accessor: (item: PurchaseRequisition) => getRequesterName(item) },
        { header: 'Priority', accessor: (item: PurchaseRequisition) => <Badge color={priorityColors[item.priority]}>{item.priority}</Badge> },
        { header: 'Status', accessor: (item: PurchaseRequisition) => <Badge color={statusColors[item.status]}>{item.status}</Badge> },
        { header: 'Request Date', accessor: (item: PurchaseRequisition) => formatDate(item.requestDate) },
    ];
    
    return (
        <>
            <Card
                title="Purchase Requisitions (PR)"
                actions={!isManagerOrTopManagement && currentUser.role !== 'Planner' && currentUser.role !== 'Supervisor' && currentUser.role !== 'Engineer' && <Button onClick={() => setIsInitialFormOpen(true)}>New Manual PR</Button>}
            >
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                        <label htmlFor="status-filter" className={filterLabelClasses}>Status</label>
                        <select id="status-filter" name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All</option>
                            {Object.values(PRStatus).map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="type-filter" className={filterLabelClasses}>Type</label>
                        <select id="type-filter" name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All</option>
                            {Object.values(PRType).map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="priority-filter" className={filterLabelClasses}>Priority</label>
                        <select id="priority-filter" name="priority" value={filters.priority} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All</option>
                            {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
                        </select>
                    </div>
                    <div className="flex items-end">
                        <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                    </div>
                </div>
                
                <Table<PurchaseRequisition>
                    columns={columns}
                    data={filteredPRs}
                    renderRowActions={pr => (
                        <Button variant="secondary" size="sm" onClick={() => setViewingPR(pr)}>
                            Details
                        </Button>
                    )}
                />
            </Card>

            <InitialMPRForm
                isOpen={isInitialFormOpen}
                onClose={() => setIsInitialFormOpen(false)}
                onProceed={handleInitialProceed}
            />

            {manualPRData && (
                <ManualPRForm
                    isOpen={!!manualPRData}
                    onClose={() => setManualPRData(null)}
                    onSave={handleSaveManualPR}
                    pr={manualPRData}
                />
            )}

            {viewingPR && (
                <PRDetailModal
                    pr={viewingPR}
                    currentUser={currentUser}
                    onClose={() => setViewingPR(null)}
                    onEdit={(prToEdit) => { setViewingPR(null); setManualPRData(prToEdit); }}
                    onStatusUpdate={handleStatusUpdate}
                    onCreateRFQ={handleCreateRFQ}
                />
            )}
        </>
    );
};
