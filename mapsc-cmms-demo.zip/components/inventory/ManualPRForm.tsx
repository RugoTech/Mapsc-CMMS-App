


import React, { useState, useEffect, useContext, useMemo, useRef } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { PurchaseRequisition, PRStatus } from '../../types';

interface ManualPRFormProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (pr: PurchaseRequisition) => void;
    pr: PurchaseRequisition;
}

export const ManualPRForm: React.FC<ManualPRFormProps> = ({ isOpen, onClose, onSave, pr }) => {
    const context = useContext(DataContext);
    const [formData, setFormData] = useState(pr);
    const [estimatedCostOption, setEstimatedCostOption] = useState<'known' | 'unknown'>(
        typeof pr.estimatedCost === 'number' ? 'known' : 'unknown'
    );
    const fileInputRef = useRef<HTMLInputElement>(null);
    const today = new Date().toISOString().split('T')[0];

    useEffect(() => {
        setFormData(pr);
        setEstimatedCostOption(typeof pr.estimatedCost === 'number' ? 'known' : 'unknown');
    }, [pr, isOpen]);

    if (!context) return null;
    const { data } = context;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({...prev, [name]: value}));
    };
    
    const handleCostOptionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value as 'known' | 'unknown';
        setEstimatedCostOption(value);
    };

    const handleSaveDraft = () => {
        const { estimatedCost, ...rest } = formData;
        const finalData: PurchaseRequisition = {
            ...rest,
            estimatedCost: estimatedCostOption === 'unknown' ? 'Vendor to determine' : Number(estimatedCost) || 0,
        };
        onSave(finalData);
    };

    const handleSubmitForApproval = () => {
        const validationErrors: string[] = [];

        // Vendor selection is NOT required during Manual PR creation to prevent bias.
        // It will be selected during RFQ creation.
        
        if (!formData.deliveryDate) {
            validationErrors.push("Desired Delivery Date");
        }
        if (!formData.deliveryZoneId) {
            validationErrors.push("Delivery Location");
        }
        if (!formData.justification?.trim()) {
            validationErrors.push("Justification / Purpose");
        }
        if (estimatedCostOption === 'known' && (typeof formData.estimatedCost !== 'number' || formData.estimatedCost < 0)) {
            validationErrors.push("A valid, non-negative Estimated Cost");
        }

        if (validationErrors.length > 0) {
            alert(`Please fill out all required fields before submitting for approval:\n\n- ${validationErrors.join('\n- ')}`);
            return;
        }

        const { estimatedCost, ...rest } = formData;
        const finalData: PurchaseRequisition = {
            ...rest,
            estimatedCost: estimatedCostOption === 'unknown' ? 'Vendor to determine' : Number(estimatedCost) || 0,
            status: PRStatus.Pending,
        };
        onSave(finalData);
    };
    
    const modalFooter = (
        <div className="flex justify-between w-full">
            <Button variant="secondary" onClick={() => alert('Print functionality coming soon!')}>Print</Button>
            <div className="flex space-x-2">
                <Button variant="secondary" onClick={handleSaveDraft}>Save Draft</Button>
                <Button onClick={handleSubmitForApproval}>Submit for Approval</Button>
            </div>
        </div>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`Complete Purchase Requisition: ${pr.id}`} footer={modalFooter}>
            <div className="space-y-4">
                <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <h3 className="font-semibold text-lg">{formData.description}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 whitespace-pre-wrap">{formData.specifications}</p>
                </div>
                
                <div className="border-t pt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                     <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Estimated Cost</label>
                        <div className="flex items-center space-x-4 mt-2">
                             <label className="flex items-center">
                                <input type="radio" name="costOption" value="known" checked={estimatedCostOption === 'known'} onChange={handleCostOptionChange} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300" />
                                <span className="ml-2 text-sm">Known Cost</span>
                            </label>
                            <label className="flex items-center">
                                <input type="radio" name="costOption" value="unknown" checked={estimatedCostOption === 'unknown'} onChange={handleCostOptionChange} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300" />
                                <span className="ml-2 text-sm">Vendor to Determine</span>
                            </label>
                        </div>
                        {estimatedCostOption === 'known' && (
                            <Input id="estimatedCost" label="" name="estimatedCost" type="number" min="0" value={String(formData.estimatedCost) === 'Vendor to determine' ? 0 : formData.estimatedCost} onChange={handleChange} className="mt-2" />
                        )}
                    </div>
                    
                    {/* Vendor selection disabled/removed for unbiased selection policy */}
                    <div>
                        <label className="block text-sm font-medium text-gray-400 cursor-not-allowed">Vendor</label>
                        <select disabled className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-gray-100 dark:bg-gray-800 border-gray-300 dark:border-gray-600 focus:outline-none sm:text-sm rounded-md cursor-not-allowed">
                            <option value="">Selection by Procurement (Unbiased)</option>
                        </select>
                        <p className="text-xs text-gray-500 mt-1">Vendor selection is handled during RFQ creation to ensure fairness.</p>
                    </div>

                    <Input id="deliveryDate" label="Desired Delivery Date" name="deliveryDate" type="date" value={formData.deliveryDate || ''} onChange={handleChange} required min={today} />
                    
                    <div>
                        <label className="block text-sm font-medium">Delivery Location</label>
                        <select name="deliveryZoneId" value={formData.deliveryZoneId || ''} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                            <option value="">Select a zone...</option>
                            {data.zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                        </select>
                    </div>

                    {formData.workOrderId && (
                        <Input id="workOrderId" label="Parent Work Order" name="workOrderId" value={formData.workOrderId} disabled />
                    )}

                    <div>
                        <label className="block text-sm font-medium">Associated Asset (Optional)</label>
                        <select name="assetId" value={formData.assetId || ''} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                            <option value="">None</option>
                            {data.assets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                        </select>
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium">Justification / Purpose</label>
                    <textarea name="justification" value={formData.justification || ''} onChange={handleChange} rows={3} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" maxLength={106}></textarea>
                </div>
                <div>
                    <label className="block text-sm font-medium">Internal Notes</label>
                    <textarea name="internalNotes" value={formData.internalNotes || ''} onChange={handleChange} rows={3} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" maxLength={106}></textarea>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Attachments</label>
                    <input ref={fileInputRef} type="file" multiple className="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-900/50 file:text-indigo-700 dark:file:text-indigo-300 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-900" />
                </div>
                <div className="border-t pt-4">
                    <h4 className="font-semibold">Approval Status</h4>
                    <p className="text-sm text-gray-500">{formData.status}</p>
                    {formData.remarks && <p className="text-sm mt-2"><strong className="block">Remarks:</strong>{formData.remarks}</p>}
                </div>

            </div>
        </Modal>
    );
};
