
import React, { useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import type { Part, InventoryTransaction, User, AuditLogEntry, MockData } from '../../types';
import { TransactionType, POStatus, WorkOrderStatus } from '../../types';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { Alert } from '../ui/Alert';
import { useZoneAccess } from '../../hooks/useZoneAccess';

const uomOptions = ['kg', 'litre', 'tonnes', 'drum', 'tin', 'pieces', 'box', 'carton', 'meter'];

const formatBinCode = (input: string): string => {
    if (!input) return '';
    // 1. Remove all whitespace
    const normalized = input.replace(/\s/g, '').toUpperCase();
    // 2. Regex for Letter(s)-Number(s) pattern
    const match = normalized.match(/^([A-Z]+)-(\d+)$/);
    if (match) {
        const prefix = match[1];
        const number = match[2];
        // Pad number to at least 2 digits
        const paddedNumber = number.padStart(2, '0');
        return `${prefix}-${paddedNumber}`;
    }
    return normalized;
};

const PartForm: React.FC<{ 
    isOpen: boolean, 
    onClose: () => void, 
    onSave: (p: Part) => void,
    partToEdit?: Part | null,
    currentUser: User | null;
    isReadOnly?: boolean;
}> = ({ isOpen, onClose, onSave, partToEdit, currentUser, isReadOnly = false }) => {
    const context = useContext(DataContext);
    
    const getInitialState = useCallback((): Omit<Part, 'id'> => {
      if (!context) return {} as Omit<Part, 'id'>; // should not happen
      return {
        partNumber: '', 
        name: '', 
        location: '', 
        quantity: 0, 
        reorderPoint: 0,
        maxQuantity: 0,
        unitCost: 0,
        unitOfMeasure: 'pieces',
        assetId: '',
        type: '' as any, // Forces manual selection
        leadTime: 0,
        vendorId: '',
        dateCreated: new Date().toISOString().split('T')[0],
        createdBy: currentUser?.id || '',
        isActive: true,
      };
    }, [context, currentUser]);

    const [formData, setFormData] = useState<Omit<Part, 'id'> & { id?: string }>(getInitialState());
    const [uomSelection, setUomSelection] = useState('pieces');
    const [customUom, setCustomUom] = useState('');
    const [selectedStoreId, setSelectedStoreId] = useState('');
    const [bin, setBin] = useState('');
    const [error, setError] = useState<string | null>(null);

    if (!context) return null;
    const { assets, vendors, stores } = context.data;

    useEffect(() => {
        if (isOpen) {
            if (partToEdit) {
                setFormData({
                    ...partToEdit,
                    isActive: partToEdit.isActive ?? true, // Default to true if undefined
                });
                const uom = partToEdit.unitOfMeasure;
                if (uom && uomOptions.includes(uom)) {
                    setUomSelection(uom);
                    setCustomUom('');
                } else {
                    setUomSelection('Other');
                    setCustomUom(uom || '');
                }

                // Try to parse location into Store and Bin
                const matchedStore = stores.find(s => partToEdit.location && partToEdit.location.includes(s.name));
                if (matchedStore) {
                    setSelectedStoreId(matchedStore.id);
                    // Remove store name and separator from location to get bin
                    const binVal = partToEdit.location.replace(matchedStore.name, '').replace(/^[, -]+/, '').trim();
                    setBin(binVal);
                } else {
                    setSelectedStoreId('');
                    // If no store matched, put the whole location in Bin so it's visible/editable
                    setBin(partToEdit.location || '');
                }

            } else {
                setFormData(getInitialState());
                setUomSelection('pieces');
                setCustomUom('');
                setSelectedStoreId('');
                setBin('');
            }
            setError(null);
        }
    }, [isOpen, partToEdit, getInitialState, stores]);

    // Automatically update Location field based on Store and Bin
    useEffect(() => {
        if (!isOpen) return;
        
        const store = stores.find(s => s.id === selectedStoreId);
        const storeName = store ? store.name : '';
        
        let newLoc = '';
        if (storeName && bin) {
            newLoc = `${storeName}, ${bin}`;
        } else if (storeName) {
            newLoc = storeName;
        } else {
            newLoc = bin;
        }
        
        setFormData(prev => ({ ...prev, location: newLoc }));
    }, [selectedStoreId, bin, stores, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({...prev, [name]: (name === 'quantity' || name === 'reorderPoint' || name === 'unitCost' || name === 'leadTime' || name === 'maxQuantity') ? Number(value) : value } as Part));
    };
    
    const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setFormData(prev => ({ ...prev, isActive: e.target.value === 'true' }));
    };

    const handleBinBlur = () => {
        setBin(prev => formatBinCode(prev));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (isReadOnly) return;
        setError(null);
        if (!context) return;
        
        const finalUom = uomSelection === 'Other' ? customUom.trim() : uomSelection;
        if (!finalUom) {
            setError('Please specify a Unit of Measure.');
            return;
        }

        // Validation for deactivation
        if (partToEdit && formData.isActive === false && (partToEdit.isActive === undefined || partToEdit.isActive === true)) {
             const { purchaseOrders, workOrders } = context.data;
             
             const activePOs = purchaseOrders.filter(po => 
                (po.status !== POStatus.Received && po.status !== POStatus.Closed && po.status !== POStatus.Rejected) &&
                po.items.some(i => i.partId === partToEdit.id)
             );

             const activeWOs = workOrders.filter(wo => 
                (wo.status === WorkOrderStatus.Open || wo.status === WorkOrderStatus.InProgress) &&
                wo.partsUsed.some(p => p.partId === partToEdit.id)
             );

             if (activePOs.length > 0 || activeWOs.length > 0) {
                 let errorMsg = "Cannot deactivate part. It is currently used in the following active processes:\n";
                 if (activePOs.length > 0) errorMsg += `- Active POs: ${activePOs.map(p => p.id).join(', ')}\n`;
                 if (activeWOs.length > 0) errorMsg += `- Active WOs: ${activeWOs.map(w => w.id).join(', ')}`;
                 setError(errorMsg);
                 return;
             }
        }

        // Duplicate Bin Code Check
        const normalizedBin = formatBinCode(bin);
        setBin(normalizedBin); // Ensure visual state matches normalized

        if (selectedStoreId && normalizedBin) {
            const store = stores.find(s => s.id === selectedStoreId);
            if (store) {
                // Construct the exact location string that would be saved
                const potentialLocation = `${store.name}, ${normalizedBin}`;
                
                // Check against existing parts
                const duplicatePart = context.data.parts.find(p => 
                    p.location === potentialLocation && 
                    p.id !== partToEdit?.id
                );

                if (duplicatePart) {
                    setError(`The Bin code '${normalizedBin}' in '${store.name}' is already occupied by part: ${duplicatePart.name} (${duplicatePart.partNumber}). Please use a different bin.`);
                    return;
                }
            }
        }

        // Construct final location with normalized bin
        const store = stores.find(s => s.id === selectedStoreId);
        const finalLocation = store ? `${store.name}, ${normalizedBin}` : normalizedBin;

        const partToSave: Part = partToEdit 
            ? { ...formData, unitOfMeasure: finalUom, location: finalLocation } as Part
            : { ...formData, id: `PART-${String(context.data.parts.length + 1).padStart(3, '0')}`, unitOfMeasure: finalUom, location: finalLocation } as Part;

        onSave(partToSave);
    };

    const selectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md disabled:bg-gray-100 dark:disabled:bg-gray-800";

    const modalTitle = isReadOnly ? 'Part Details' : (partToEdit ? 'Edit Part' : "Add New Part");
    const modalFooter = isReadOnly 
        ? <Button variant="secondary" onClick={onClose}>Close</Button>
        : <><Button variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit" form="part-form">Save</Button></>;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={modalTitle} footer={modalFooter}>
            <form id="part-form" onSubmit={handleSubmit} className="space-y-4">
                {error && <Alert type="error"><div className="whitespace-pre-wrap">{error}</div></Alert>}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input label="Part Number" name="partNumber" value={formData.partNumber} onChange={handleChange} required disabled={isReadOnly} />
                    <Input label="Name/Description" name="name" value={formData.name} onChange={handleChange} required disabled={isReadOnly} maxLength={106} />
                    
                    {/* Replaced direct Location input with Store/Bin selection */}
                    <div className="md:col-span-2 grid grid-cols-2 gap-4 p-3 bg-gray-50 dark:bg-gray-700/30 rounded-md">
                        <div>
                            <label htmlFor="store" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Store</label>
                            <select 
                                name="store" 
                                id="store"
                                value={selectedStoreId} 
                                onChange={(e) => setSelectedStoreId(e.target.value)} 
                                className={selectClasses}
                                disabled={isReadOnly}
                            >
                                <option value="">Select Store...</option>
                                {stores.map(store => (
                                    <option key={store.id} value={store.id}>{store.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <Input 
                                label="Bin" 
                                name="bin" 
                                value={bin} 
                                onChange={(e) => setBin(e.target.value)}
                                onBlur={handleBinBlur}
                                placeholder="e.g. A-01"
                                disabled={isReadOnly}
                            />
                        </div>
                        <div className="col-span-2">
                            <Input 
                                label="Full Location" 
                                name="location" 
                                value={formData.location} 
                                onChange={handleChange} 
                                required 
                                disabled 
                                className="bg-gray-100 dark:bg-gray-800 text-gray-500 cursor-not-allowed"
                            />
                        </div>
                    </div>

                    <Input label="Date Created" name="dateCreated" type="date" value={formData.dateCreated} disabled />
                    
                    <div>
                        <label htmlFor="type" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Type</label>
                        <select name="type" value={formData.type} onChange={handleChange} className={selectClasses} disabled={isReadOnly} required>
                            <option value="" disabled>Select Type...</option>
                            <option value="Stock">Stock</option>
                            <option value="Non-stock">Non-stock</option>
                        </select>
                    </div>

                    <Input label="Quantity on Hand" name="quantity" type="number" value={formData.quantity} onChange={handleChange} required disabled={!!partToEdit || isReadOnly} />
                    <Input label="Reorder Point" name="reorderPoint" type="number" value={formData.reorderPoint} onChange={handleChange} required disabled={isReadOnly} />
                    <Input label="Max Quantity" name="maxQuantity" type="number" value={formData.maxQuantity || ''} onChange={handleChange} disabled={isReadOnly} helperText="Used for calculating System PR quantity." placeholder="Optional" />
                    <Input label="Unit Cost" name="unitCost" type="number" step="0.01" value={formData.unitCost} onChange={handleChange} required disabled={isReadOnly} />
                    
                    <div className="md:col-span-2 grid grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="uomSelection" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Unit of Measure</label>
                            <select 
                                name="uomSelection" 
                                id="uomSelection"
                                value={uomSelection} 
                                onChange={(e) => setUomSelection(e.target.value)} 
                                className={selectClasses}
                                disabled={isReadOnly}
                            >
                                {uomOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                <option value="Other">Other...</option>
                            </select>
                        </div>
                        {uomSelection === 'Other' && (
                            <Input 
                                label="Custom UOM" 
                                id="customUom" 
                                name="customUom" 
                                value={customUom} 
                                onChange={(e) => setCustomUom(e.target.value)} 
                                required 
                                placeholder="e.g., set, roll"
                                disabled={isReadOnly}
                            />
                        )}
                    </div>
                    
                    <Input label="Lead Time (days)" name="leadTime" type="number" value={formData.leadTime || ''} onChange={handleChange} disabled={isReadOnly} />
                    
                    <div>
                        <label htmlFor="assetId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Asset (Optional)</label>
                        <select name="assetId" value={formData.assetId || ''} onChange={handleChange} className={selectClasses} disabled={isReadOnly}>
                            <option value="">None</option>
                            {assets.map(asset => <option key={asset.id} value={asset.id}>{asset.name}</option>)}
                        </select>
                    </div>

                    <div>
                        <label htmlFor="vendorId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Vendor</label>
                        <select name="vendorId" value={formData.vendorId || ''} onChange={handleChange} className={selectClasses} disabled={isReadOnly}>
                            <option value="">None</option>
                            {vendors.map(vendor => <option key={vendor.id} value={vendor.id}>{vendor.name} ({vendor.id})</option>)}
                        </select>
                    </div>

                    <div>
                        <label htmlFor="isActive" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                        <select name="isActive" value={String(formData.isActive)} onChange={handleStatusChange} className={selectClasses} disabled={isReadOnly}>
                            <option value="true">Active</option>
                            <option value="false">Inactive</option>
                        </select>
                    </div>
                </div>
            </form>
        </Modal>
    );
};

const PrintablePartsList: React.FC<{ parts: Part[]; data: MockData; formatCurrency: (value: number) => string }> = ({ parts, data, formatCurrency }) => {
    const { vendors, assets } = data;
    const getVendorName = (id?: string) => vendors.find(v => v.id === id)?.name || '';
    const getAssetName = (id?: string) => assets.find(a => a.id === id)?.name || '';

    return (
        <div className="font-sans text-black bg-white p-8 border-2 border-black min-h-[11in] flex flex-col box-border relative text-xs">
            <div className="flex justify-between items-start border-b-2 border-black pb-4 mb-4">
                <div>
                    <h1 className="text-2xl font-bold uppercase">Parts Catalog</h1>
                    <p className="text-sm">Inventory Master List</p>
                </div>
                <div className="text-right">
                    <p className="text-sm font-mono">Printed: {new Date().toLocaleDateString()}</p>
                    <p className="text-sm">Total Items: {parts.length}</p>
                </div>
            </div>

            <table className="w-full border-collapse border border-black">
                <thead>
                    <tr className="bg-gray-100">
                        <th className="border border-black p-1 text-left">Part ID</th>
                        <th className="border border-black p-1 text-left">Part #</th>
                        <th className="border border-black p-1 text-left">Name</th>
                        <th className="border border-black p-1 text-left">Location</th>
                        <th className="border border-black p-1 text-center">Type</th>
                        <th className="border border-black p-1 text-right">Qty</th>
                        <th className="border border-black p-1 text-center">UOM</th>
                        <th className="border border-black p-1 text-right">Cost</th>
                        <th className="border border-black p-1 text-left">Asset</th>
                        <th className="border border-black p-1 text-left">Vendor</th>
                    </tr>
                </thead>
                <tbody>
                    {parts.map((part, index) => (
                        <tr key={part.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                            <td className="border border-black p-1">{part.id}</td>
                            <td className="border border-black p-1">{part.partNumber}</td>
                            <td className="border border-black p-1">{part.name}</td>
                            <td className="border border-black p-1">{part.location}</td>
                            <td className="border border-black p-1 text-center">{part.type}</td>
                            <td className="border border-black p-1 text-right">{part.quantity}</td>
                            <td className="border border-black p-1 text-center">{part.unitOfMeasure}</td>
                            <td className="border border-black p-1 text-right">{formatCurrency(part.unitCost)}</td>
                            <td className="border border-black p-1 truncate max-w-[100px]">{getAssetName(part.assetId)}</td>
                            <td className="border border-black p-1 truncate max-w-[100px]">{getVendorName(part.vendorId)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
             <div className="mt-auto pt-4 text-xs flex justify-between border-t-2 border-black">
                <span>Mapsc CMMS</span>
                <span>Page 1 of 1</span>
            </div>
        </div>
    );
};

interface PartsCatalogProps {
    currentUser: User | null;
}

export const PartsCatalog: React.FC<PartsCatalogProps> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const [isPartFormOpen, setIsPartFormOpen] = useState(false);
    const [isPrintPreviewOpen, setIsPrintPreviewOpen] = useState(false);
    const [partToEdit, setPartToEdit] = useState<Part | null>(null);
    const [isReadOnlyView, setIsReadOnlyView] = useState(false);
    const [filters, setFilters] = useState({
        description: '',
        type: '',
        asset: '',
        vendor: '',
        dateCreated: '',
    });
    // Use formatter directly, bypassing conversion to keep cost in system default currency
    const formatCurrency = useCurrencyFormatter();
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { parts, assets, vendors } = data;

    const isLogisticsController = useMemo(() => {
        return data.logisticsControllers.some(group => group.userIds.includes(currentUser.id));
    }, [currentUser, data.logisticsControllers]);

    const getAssetName = useCallback((assetId?: string) => {
        if (!assetId) return 'N/A';
        return assets.find(a => a.id === assetId)?.name || 'N/A';
    }, [assets]);

    const getVendorName = useCallback((vendorId?: string) => {
        if (!vendorId) return 'N/A';
        return vendors.find(v => v.id === vendorId)?.name || 'N/A';
    }, [vendors]);

    const filteredParts = useMemo(() => {
        return parts.filter(part => {
            // Hide inactive parts from non-logistics users
            if (part.isActive === false && currentUser?.department !== 'Logistics') {
                return false;
            }

            const descriptionMatch = filters.description
                ? part.name.toLowerCase().includes(filters.description.toLowerCase()) || part.partNumber.toLowerCase().includes(filters.description.toLowerCase())
                : true;
            
            const typeMatch = filters.type ? part.type === filters.type : true;

            const assetMatch = filters.asset
                ? getAssetName(part.assetId).toLowerCase().includes(filters.asset.toLowerCase())
                : true;
            
            const vendorMatch = filters.vendor
                ? getVendorName(part.vendorId).toLowerCase().includes(filters.vendor.toLowerCase())
                : true;
            
            const dateCreatedMatch = filters.dateCreated ? part.dateCreated === filters.dateCreated : true;
            
            if (! (descriptionMatch && typeMatch && assetMatch && vendorMatch && dateCreatedMatch)) {
                return false;
            }

            // Zone access logic
            const asset = part.assetId ? assets.find(a => a.id === part.assetId) : null;
            const partZoneId = asset?.zoneId;
            
            // A part is visible if user has all zone access, the part has no specific zone (general stock), or the part's zone is in the user's accessible list.
            return canSeeAllZones || !partZoneId || accessibleZoneIds.includes(partZoneId);
        });
    }, [parts, assets, filters, getAssetName, getVendorName, canSeeAllZones, accessibleZoneIds, currentUser]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({
            description: '',
            type: '',
            asset: '',
            vendor: '',
            dateCreated: ''
        });
    };

    const handleSavePart = (part: Part) => {
        setData(prev => {
            const isEditing = prev.parts.some(p => p.id === part.id);
            const logAction = isEditing ? 'UPDATE' : 'CREATE';
            const logDetails = isEditing
              ? `Updated details for part '${part.name}' (${part.id}).`
              : `Created new part '${part.name}' (${part.id}).`;
            
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: logAction,
                entityType: 'Part',
                entityId: part.id,
                details: logDetails,
                status: 'Success'
            };

            if (isEditing) {
                return { 
                    ...prev, 
                    parts: prev.parts.map(p => p.id === part.id ? part : p),
                    auditLog: [logEntry, ...prev.auditLog]
                };
            } else {
                return { 
                    ...prev, 
                    parts: [...prev.parts, part],
                    auditLog: [logEntry, ...prev.auditLog]
                };
            }
        });
        setIsPartFormOpen(false);
        setPartToEdit(null);
    };
    
    const handleOpenPartForm = (part: Part | null, readOnly: boolean = false) => {
        setPartToEdit(part);
        setIsReadOnlyView(readOnly);
        setIsPartFormOpen(true);
    };

    const handleClosePartForm = () => {
        setIsPartFormOpen(false);
        setPartToEdit(null);
        setIsReadOnlyView(false);
    }

    const columns = [
        { header: 'Part ID', accessor: 'id' as keyof Part },
        { header: 'Part Number', accessor: 'partNumber' as keyof Part },
        { header: 'Description', accessor: 'name' as keyof Part },
        { header: 'Type', accessor: 'type' as keyof Part },
        { header: 'Status', accessor: (item: Part) => (
            <Badge color={(item.isActive ?? true) ? 'green' : 'gray'}>{(item.isActive ?? true) ? 'Active' : 'Inactive'}</Badge>
        )},
        { header: 'Asset', accessor: (item: Part) => getAssetName(item.assetId) },
        { header: 'Vendor', accessor: (item: Part) => getVendorName(item.vendorId) },
        { 
            header: 'On Hand', 
            accessor: (item: Part) => (
                <div className="flex items-center space-x-2">
                    <span>{item.quantity}</span>
                    {item.quantity <= item.reorderPoint && (item.isActive ?? true) && (
                        <Badge color="red">Low Stock</Badge>
                    )}
                </div>
            )
        },
        { header: 'UOM', accessor: 'unitOfMeasure' as keyof Part },
        { header: 'Reorder Point', accessor: 'reorderPoint' as keyof Part },
        { header: 'Unit Cost', accessor: (item: Part) => formatCurrency(item.unitCost) },
        { header: 'Lead Time', accessor: (item: Part) => item.leadTime ? `${item.leadTime} days` : 'N/A' },
        { header: 'Date Created', accessor: 'dateCreated' as keyof Part },
    ];
    
    const tableFooter = (
        <tr>
            <td colSpan={12} className="px-6 py-3 text-right font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">
                Total Number of Unique Parts
            </td>
            <td className="px-6 py-3 text-left font-bold text-gray-900 dark:text-white">
                {filteredParts.length}
            </td>
            <td className="no-print"></td> {/* Empty cell for actions column */}
        </tr>
    );

    const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
    const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

    return (
        <>
            <Card
                className="no-print"
                title="Parts Catalog"
                actions={
                    <div className="flex space-x-2 no-print">
                        <Button variant="secondary" onClick={() => setIsPrintPreviewOpen(true)}>Print List</Button>
                        {isLogisticsController && (
                            <Button onClick={() => handleOpenPartForm(null)}>Add Part</Button>
                        )}
                    </div>
                }
            >
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg no-print">
                    <div>
                        <label htmlFor="description-filter" className={filterLabelClasses}>Description</label>
                        <input type="text" id="description-filter" name="description" value={filters.description} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search name/number..."/>
                    </div>
                    <div>
                        <label htmlFor="type-filter" className={filterLabelClasses}>Type</label>
                        <select id="type-filter" name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                            <option value="">All Types</option>
                            <option value="Stock">Stock</option>
                            <option value="Non-stock">Non-stock</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="asset-filter" className={filterLabelClasses}>Asset</label>
                        <input type="text" id="asset-filter" name="asset" value={filters.asset} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search asset name..."/>
                    </div>
                    <div>
                        <label htmlFor="vendor-filter" className={filterLabelClasses}>Vendor</label>
                        <input type="text" id="vendor-filter" name="vendor" value={filters.vendor} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search vendor name..."/>
                    </div>
                    <div>
                        <label htmlFor="dateCreated-filter" className={filterLabelClasses}>Date Created</label>
                        <input type="date" id="dateCreated-filter" name="dateCreated" value={filters.dateCreated} onChange={handleFilterChange} className={filterInputClasses}/>
                    </div>
                    <div className="flex items-end">
                        <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                    </div>
                </div>

                <Table<Part>
                    columns={columns}
                    data={filteredParts}
                    renderRowActions={(part) => (
                        <div className="flex space-x-2">
                            {isLogisticsController ? (
                                <Button variant="secondary" size="sm" onClick={() => handleOpenPartForm(part)}>
                                    Edit
                                </Button>
                            ) : (
                                <Button variant="secondary" size="sm" onClick={() => handleOpenPartForm(part, true)}>
                                    Details
                                </Button>
                            )}
                        </div>
                    )}
                    footer={tableFooter}
                />
            </Card>
            <PartForm 
                isOpen={isPartFormOpen} 
                onClose={handleClosePartForm} 
                onSave={handleSavePart}
                partToEdit={partToEdit}
                currentUser={currentUser}
                isReadOnly={isReadOnlyView}
            />

            {isPrintPreviewOpen && (
                <Modal
                    isOpen={isPrintPreviewOpen}
                    onClose={() => setIsPrintPreviewOpen(false)}
                    title="Print Preview: Parts Catalog"
                    size="5xl"
                    footer={
                        <div className="flex justify-between w-full">
                            <Button variant="secondary" onClick={() => setIsPrintPreviewOpen(false)}>Cancel</Button>
                            <Button variant="primary" onClick={() => {
                                setIsPrintPreviewOpen(false);
                                setTimeout(() => window.print(), 100);
                            }}>Confirm Print</Button>
                        </div>
                    }
                >
                    <div className="bg-gray-100 dark:bg-gray-900 p-4 overflow-auto flex justify-center max-h-[70vh]">
                        <div className="transform scale-100 origin-top w-full max-w-[8.5in]">
                            <PrintablePartsList parts={filteredParts} data={data} formatCurrency={formatCurrency} />
                        </div>
                    </div>
                </Modal>
            )}

            {/* Hidden Component for Actual Printing */}
            <div className="hidden print:block">
                <PrintablePartsList parts={filteredParts} data={data} formatCurrency={formatCurrency} />
            </div>
        </>
    );
};
