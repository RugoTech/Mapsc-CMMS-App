
import React, { useContext, useState, useEffect, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import type { CycleCount, CycleCountItem, InventoryTransaction, Part, User } from '../../types';
import { CycleCountStatus, TransactionType } from '../../types';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { Alert } from '../ui/Alert';
import { useZoneAccess } from '../../hooks/useZoneAccess';

const statusColors: Record<CycleCountStatus, 'blue' | 'yellow' | 'green' | 'gray'> = {
    [CycleCountStatus.Scheduled]: 'blue',
    [CycleCountStatus.InProgress]: 'yellow',
    [CycleCountStatus.Completed]: 'green',
    [CycleCountStatus.Posted]: 'gray',
};

// --- Modals for Perform/View ---

const PerformCountModal: React.FC<{
    cc: CycleCount;
    onClose: () => void;
    onSaveProgress: (updatedCC: CycleCount) => void;
    onFinalize: (updatedCC: CycleCount) => void;
}> = ({ cc, onClose, onSaveProgress, onFinalize }) => {
    const context = useContext(DataContext);
    const [counts, setCounts] = useState<Record<string, string>>({});
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const initialCounts: Record<string, string> = {};
        cc.countItems?.forEach(item => {
            initialCounts[item.partId] = item.countedQty === null ? '' : String(item.countedQty);
        });
        setCounts(initialCounts);
        setError(null);
    }, [cc]);

    if (!context) return null;
    const { parts } = context.data;

    const handleCountChange = (partId: string, value: string) => {
        setCounts(prev => ({ ...prev, [partId]: value }));
    };
    
    const handleSave = (isFinal: boolean) => {
        setError(null);
        let allCounted = true;
        const updatedItems: CycleCountItem[] = cc.countItems!.map(item => {
            const countedValue = counts[item.partId];
            if (countedValue === '' || countedValue === null) {
                allCounted = false;
                return { ...item, countedQty: null };
            }
            return { ...item, countedQty: parseInt(countedValue, 10) };
        });

        if (isFinal && !allCounted) {
            setError('Please enter a count for all items before finalizing.');
            return;
        }

        const updatedCC: CycleCount = {
            ...cc,
            countItems: updatedItems,
            status: isFinal ? CycleCountStatus.Completed : CycleCountStatus.InProgress,
        };
        
        if (isFinal) {
            onFinalize(updatedCC);
        } else {
            onSaveProgress(updatedCC);
        }
    };
    
    return (
        <Modal 
            isOpen={true} 
            onClose={onClose} 
            title={`Perform Count for ${cc.location}`}
            footer={
                <div className="w-full flex justify-between">
                    <Button variant="secondary" onClick={() => handleSave(false)}>Save Progress</Button>
                    <Button variant="primary" onClick={() => handleSave(true)}>Finalize Count</Button>
                </div>
            }
        >
            <div className="max-h-[60vh] overflow-y-auto">
                {error && <Alert type="error">{error}</Alert>}
                <table className="min-w-full divide-y dark:divide-gray-600 mt-2">
                    <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0">
                        <tr>
                            <th className="p-2 text-left text-sm font-medium">Part</th>
                            <th className="p-2 text-center text-sm font-medium">System Qty</th>
                            <th className="p-2 text-center text-sm font-medium w-32">Counted Qty</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y dark:divide-gray-600">
                        {cc.countItems?.map(item => {
                            const part = parts.find(p => p.id === item.partId);
                            return (
                                <tr key={item.partId}>
                                    <td className="p-2">
                                        <p className="font-medium">{part?.name}</p>
                                        <p className="text-xs text-gray-500">{part?.partNumber}</p>
                                    </td>
                                    <td className="p-2 text-center">{item.systemQty}</td>
                                    <td className="p-2">
                                        <Input
                                            id={`count-${item.partId}`}
                                            label=""
                                            type="number"
                                            min="0"
                                            value={counts[item.partId] || ''}
                                            onChange={e => handleCountChange(item.partId, e.target.value)}
                                            className="text-center"
                                        />
                                    </td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        </Modal>
    );
};

const ViewResultsModal: React.FC<{
    cc: CycleCount;
    onClose: () => void;
    onPost: () => void;
    canPost: boolean;
}> = ({ cc, onClose, onPost, canPost }) => {
    const context = useContext(DataContext);
    const formatCurrency = useCurrencyFormatter();
    if (!context) return null;
    const { parts } = context.data;

    const results = cc.countItems?.map(item => {
        const part = parts.find(p => p.id === item.partId);
        const variance = (item.countedQty ?? item.systemQty) - item.systemQty;
        const varianceValue = variance * (part?.unitCost || 0);
        return { ...item, part, variance, varianceValue };
    }) || [];

    const totalVarianceValue = results.reduce((sum, item) => sum + item.varianceValue, 0);
    const itemsWithVariance = results.filter(r => r.variance !== 0).length;

    const footer = (
        <div className="w-full flex justify-between items-center">
            <Button variant="secondary" onClick={onClose}>Close</Button>
            {!cc.isPosted && canPost && (
                 <Button variant="primary" onClick={onPost}>Post Adjustments</Button>
            )}
        </div>
    );
    
    return (
        <Modal isOpen={true} onClose={onClose} title={`Count Results for ${cc.location}`} footer={footer}>
            <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg text-center">
                    <div>
                        <p className="text-xs uppercase text-gray-500">Items with Variance</p>
                        <p className={`text-lg font-bold ${itemsWithVariance > 0 ? 'text-red-500' : ''}`}>{itemsWithVariance}</p>
                    </div>
                     <div>
                        <p className="text-xs uppercase text-gray-500">Total Variance Value</p>
                        <p className={`text-lg font-bold ${totalVarianceValue !== 0 ? (totalVarianceValue > 0 ? 'text-green-500' : 'text-red-500') : ''}`}>{formatCurrency(totalVarianceValue)}</p>
                    </div>
                     <div>
                        <p className="text-xs uppercase text-gray-500">Status</p>
                        <p className="text-lg font-bold">{cc.isPosted ? 'Posted' : 'Completed'}</p>
                    </div>
                </div>
                 <div className="max-h-[50vh] overflow-y-auto">
                    <table className="min-w-full text-sm">
                         <thead className="bg-gray-100 dark:bg-gray-700 sticky top-0">
                            <tr>
                                <th className="p-2 text-left">Part</th>
                                <th className="p-2 text-center">System Qty</th>
                                <th className="p-2 text-center">Counted Qty</th>
                                <th className="p-2 text-center">Variance</th>
                                <th className="p-2 text-right">Variance Value</th>
                            </tr>
                        </thead>
                        <tbody>
                            {results.map(res => (
                                <tr key={res.partId} className={`border-b dark:border-gray-600 ${res.variance !== 0 ? 'bg-red-100 dark:bg-red-900/30' : ''}`}>
                                    <td className="p-2">{res.part?.name}</td>
                                    <td className="p-2 text-center">{res.systemQty}</td>
                                    <td className="p-2 text-center">{res.countedQty}</td>
                                    <td className={`p-2 text-center font-bold ${res.variance !== 0 ? 'text-red-500' : ''}`}>{res.variance}</td>
                                    <td className={`p-2 text-right font-bold ${res.varianceValue !== 0 ? (res.varianceValue > 0 ? 'text-green-500' : 'text-red-500') : ''}`}>{formatCurrency(res.varianceValue)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                 </div>
            </div>
        </Modal>
    );
};

// --- Main Component ---
interface CycleCountListProps {
    currentUser: User | null;
}

export const CycleCountList: React.FC<CycleCountListProps> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [selectedCC, setSelectedCC] = useState<CycleCount | null>(null);
    const [modalToShow, setModalToShow] = useState<'perform' | 'results' | null>(null);
    const [isPostingConfirmOpen, setIsPostingConfirmOpen] = useState(false);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    // Updated Permission Logic
    const isLogisticsManager = context?.data.logisticsManagers.some(g => g.userIds.includes(currentUser?.id || '')) || false;
    const isLogisticsController = context?.data.logisticsControllers.some(g => g.userIds.includes(currentUser?.id || '')) || false;

    const canSchedule = useMemo(() => {
        if (!currentUser) return false;
        const isSupervisor = currentUser.department === 'Logistics' && currentUser.role === 'Supervisor';
        return isLogisticsManager || isLogisticsController || isSupervisor;
    }, [currentUser, isLogisticsManager, isLogisticsController]);

    const isReadOnlyViewer = useMemo(() => {
        if (!currentUser || !context) return false;
        const { topManagementGroups, assetManagers } = context.data;

        if (currentUser.role === 'Administrator') {
            return true;
        }

        const isTopManagement = topManagementGroups.some(g => g.userIds.includes(currentUser.id));
        // FIX: Changed 'managers' to 'assetManagers' to prevent crash
        const isEngManager = assetManagers.some(g => g.userIds.includes(currentUser.id));

        return isTopManagement || isEngManager;
    }, [currentUser, context]);
    
    const isStoreClerk = useMemo(() => {
        if (!currentUser) return false;
        return currentUser.role === 'Clerk' && currentUser.department === 'Logistics';
    }, [currentUser]);

    if (!context) return <div>Loading...</div>;

    const { data, setData } = context;
    const { cycleCounts, parts, assets } = data;

    
    const visibleCycleCounts = useMemo(() => {
        // Logistics Managers/Controllers and Admins see all counts
        if (canSeeAllZones || isLogisticsManager || isLogisticsController) return cycleCounts;
        
        // For others, restrict by zone access
        const visiblePartIds = new Set(
            parts.filter(p => {
                const asset = p.assetId ? assets.find(a => a.id === p.assetId) : null;
                const partZoneId = asset?.zoneId;
                return !partZoneId || accessibleZoneIds.includes(partZoneId);
            }).map(p => p.id)
        );

        return cycleCounts.filter(cc => {
            // Explicitly allow creator to see their own counts regardless of other restrictions
            if (cc.createdBy === currentUser?.id) return true;

            // Safety check: p.location can theoretically be undefined in partial updates, though types say string
            const partsInLocation = parts.filter(p => p.location && p.location.includes(cc.location));
            return partsInLocation.some(p => visiblePartIds.has(p.id));
        });
    }, [cycleCounts, parts, assets, canSeeAllZones, accessibleZoneIds, isLogisticsManager, isLogisticsController, currentUser?.id]);

    const handleScheduleSave = (cc: Omit<CycleCount, 'id'>) => {
        setData(prev => ({
            ...prev,
            cycleCounts: [
                ...prev.cycleCounts,
                { 
                    ...cc, 
                    id: `CC-${String(prev.cycleCounts.length + 1).padStart(3, '0')}`,
                    createdBy: currentUser?.id // Track creator
                }
            ]
        }));
    };

    const handleOpenModal = (cc: CycleCount) => {
        let ccWithItems = { ...cc };
        if (cc.status === CycleCountStatus.Scheduled && !cc.countItems) {
            const partsInLocation = parts.filter(p => p.location.includes(cc.location));
            ccWithItems.countItems = partsInLocation.map(p => ({
                partId: p.id,
                systemQty: p.quantity,
                countedQty: null,
            }));
        }
        setSelectedCC(ccWithItems);
        if (cc.status === CycleCountStatus.Scheduled || cc.status === CycleCountStatus.InProgress) {
            setModalToShow('perform');
        } else {
            setModalToShow('results');
        }
    };
    
    const handleCloseModals = () => {
        setSelectedCC(null);
        setModalToShow(null);
    };

    const handleSaveCount = (updatedCC: CycleCount) => {
        setData(prev => ({
            ...prev,
            cycleCounts: prev.cycleCounts.map(c => c.id === updatedCC.id ? updatedCC : c)
        }));
        if(updatedCC.status === CycleCountStatus.Completed) {
            handleCloseModals();
        } else {
            setSelectedCC(updatedCC); // Update state for save progress
        }
    };

    const handleConfirmPost = () => {
        if (!selectedCC) return;
        
        setData(prev => {
            const newTransactions: InventoryTransaction[] = [];
            const updatedParts = [...prev.parts];

            selectedCC.countItems?.forEach(item => {
                const variance = (item.countedQty ?? item.systemQty) - item.systemQty;
                if (variance !== 0) {
                    newTransactions.push({
                        id: `TRN-${String(prev.inventoryTransactions.length + newTransactions.length + 1).padStart(3, '0')}`,
                        partId: item.partId,
                        type: TransactionType.Adjustment,
                        quantity: variance,
                        date: new Date().toISOString().split('T')[0],
                        userId: currentUser?.id || 'USER-001'
                    });
                    
                    const partIndex = updatedParts.findIndex(p => p.id === item.partId);
                    if (partIndex !== -1) {
                        updatedParts[partIndex] = {
                            ...updatedParts[partIndex],
                            quantity: updatedParts[partIndex].quantity + variance
                        };
                    }
                }
            });

            const updatedCycleCounts = prev.cycleCounts.map(c => 
                c.id === selectedCC.id ? { ...c, status: CycleCountStatus.Posted, isPosted: true } : c
            );

            return {
                ...prev,
                cycleCounts: updatedCycleCounts,
                parts: updatedParts,
                inventoryTransactions: [...prev.inventoryTransactions, ...newTransactions]
            };
        });
        
        setIsPostingConfirmOpen(false);
        handleCloseModals();
        alert('Adjustments posted successfully.');
    };

    const renderRowActions = (cc: CycleCount) => {
        const isCompleted = cc.status === CycleCountStatus.Completed || cc.status === CycleCountStatus.Posted;
        const isReadOnly = isReadOnlyViewer || isStoreClerk;

        if (isReadOnly) {
            if (isCompleted) {
                return (
                    <Button variant="secondary" size="sm" onClick={() => handleOpenModal(cc)}>
                        View Results
                    </Button>
                );
            }
            return null;
        }

        // Logic for "Perform Count" restriction
        const today = new Date().toISOString().split('T')[0];
        // Ensure count cannot be performed before scheduled date
        const isScheduledDateReached = cc.scheduledDate <= today;
        const canPerform = isCompleted || isScheduledDateReached;

        return (
            <Button 
                variant="secondary" 
                size="sm" 
                onClick={() => handleOpenModal(cc)}
                disabled={!canPerform}
                title={!canPerform ? `Cannot perform count before ${cc.scheduledDate}` : ''}
            >
                {isCompleted ? 'View Results' : 'Perform Count'}
            </Button>
        );
    };

    const columns = [
        { header: 'Count ID', accessor: 'id' as keyof CycleCount },
        { header: 'Location', accessor: 'location' as keyof CycleCount },
        { header: 'Scheduled Date', accessor: 'scheduledDate' as keyof CycleCount },
        { 
            header: 'Status',
            accessor: (item: CycleCount) => <Badge color={statusColors[item.status]}>{item.status}</Badge>
        },
    ];
    
    // Updated Posting Permission:
    // ONLY Managers-Logistics can post AND only for counts they created.
    const canPost = isLogisticsManager && selectedCC?.createdBy === currentUser?.id;

    return (
        <>
            <Card
                title="Physical Inventory / Cycle Counting"
                actions={canSchedule && <Button onClick={() => setIsAddModalOpen(true)}>Schedule Count</Button>}
            >
                <Table<CycleCount>
                    columns={columns}
                    data={visibleCycleCounts}
                    renderRowActions={renderRowActions}
                />
            </Card>
            
            <ScheduleCountForm isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} onSave={handleScheduleSave} />

            {modalToShow === 'perform' && selectedCC && (
                <PerformCountModal
                    cc={selectedCC}
                    onClose={handleCloseModals}
                    onSaveProgress={handleSaveCount}
                    onFinalize={handleSaveCount}
                />
            )}
            
            {modalToShow === 'results' && selectedCC && (
                <ViewResultsModal
                    cc={selectedCC}
                    onClose={handleCloseModals}
                    onPost={() => setIsPostingConfirmOpen(true)}
                    canPost={!!canPost}
                />
            )}

            {isPostingConfirmOpen && (
                <ConfirmationModal
                    isOpen={isPostingConfirmOpen}
                    onClose={() => setIsPostingConfirmOpen(false)}
                    onConfirm={handleConfirmPost}
                    title="Confirm Post Adjustments"
                    confirmText="Post"
                    confirmButtonVariant="primary"
                >
                    <p>Are you sure you want to post these adjustments? This will update the system quantity on hand for all items with a variance.</p>
                    <p className="mt-2 text-sm text-red-600 dark:text-red-400">This action cannot be undone.</p>
                </ConfirmationModal>
            )}
        </>
    );
};

const ScheduleCountForm: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (cc: Omit<CycleCount, 'id'>) => void }> = ({ isOpen, onClose, onSave }) => {
    const context = useContext(DataContext);
    const [formData, setFormData] = useState({ location: '', scheduledDate: '' });
    const [error, setError] = useState('');

    useEffect(() => {
        if(isOpen) {
            setFormData({ location: '', scheduledDate: '' });
            setError('');
        }
    }, [isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData(prev => ({...prev, [e.target.name]: e.target.value}));
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!context) return;

        const hasOpenCountForLocation = context.data.cycleCounts.some(
            cc => cc.location === formData.location &&
            (cc.status === CycleCountStatus.Scheduled || cc.status === CycleCountStatus.InProgress)
        );

        if(hasOpenCountForLocation) {
            setError(`An open cycle count for "${formData.location}" already exists. Please complete or delete it before scheduling a new one.`);
            return;
        }

        const newCC = {
            status: CycleCountStatus.Scheduled,
            ...formData
        };
        onSave(newCC);
        onClose();
    };

    if (!context) return null;
    const { stores } = context.data;
    const selectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md text-gray-900 dark:text-white";

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Schedule New Cycle Count" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit" form="cc-form">Schedule</Button></>}>
            <form id="cc-form" onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="location" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Store / Location</label>
                    <select 
                        id="location"
                        name="location" 
                        value={formData.location} 
                        onChange={handleChange} 
                        required 
                        className={selectClasses}
                    >
                        <option value="">Select a Store...</option>
                        {stores.map(store => (
                            <option key={store.id} value={store.name}>{store.name}</option>
                        ))}
                    </select>
                </div>
                <Input label="Scheduled Date" name="scheduledDate" type="date" value={formData.scheduledDate} onChange={handleChange} required />
                {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
            </form>
        </Modal>
    );
};
