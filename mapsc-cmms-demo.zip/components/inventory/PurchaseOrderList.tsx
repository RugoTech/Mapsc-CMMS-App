
// ... existing imports ...
import React, { useContext, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import type { PurchaseOrder, POItem, InventoryTransaction, Part, RFQ, PurchaseRequisition, User, AuditLogEntry, Message, MockData, Settings } from '../../types';
import { POStatus, POType, RFQStatus, PRType, PRItemType, TransactionType, Priority } from '../../types';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { useSettings } from '../../contexts/SettingsContext';
import { Alert } from '../ui/Alert';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import { useDateFormatter } from '../../hooks/useDateFormatter';

// ... (statusColors, PrintablePurchaseOrderDocument - unchanged)

const statusColors: Record<POStatus, 'gray' | 'blue' | 'yellow' | 'green' | 'red'> = {
    [POStatus.Draft]: 'gray',
    [POStatus.PendingApproval]: 'blue',
    [POStatus.PendingHighValueApproval]: 'blue',
    [POStatus.Approved]: 'green',
    [POStatus.Rejected]: 'red',
    [POStatus.AddMoreInfo]: 'blue',
    [POStatus.Submitted]: 'yellow',
    [POStatus.PartiallyReceived]: 'yellow',
    [POStatus.Received]: 'green',
    [POStatus.Closed]: 'gray',
};

// ... (PrintablePurchaseOrderDocument, RejectPOModal if any - keep implied)

// --- Detail Modal ---
const PODetailModal: React.FC<{ 
    po: PurchaseOrder; 
    onClose: () => void; 
    currentUser: User | null; 
    onUpdateStatus: (poId: string, status: POStatus, remarks?: string) => void; 
    onPrintPreview: () => void;
}> = ({ po, onClose, currentUser, onUpdateStatus, onPrintPreview }) => {
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const formatDefaultCurrency = useCurrencyFormatter();
    const formatDate = useDateFormatter();
    const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);

    const poCurrencyFormatter = useMemo(() => {
        try {
            return new Intl.NumberFormat('en-US', { style: 'currency', currency: po.currency });
        } catch (e) {
            console.warn(`Invalid currency code in PO: ${po.currency}. Falling back to default.`);
            return new Intl.NumberFormat('en-US', { style: 'currency', currency: settings.currency });
        }
    }, [po.currency, settings.currency]);


    if (!context || !currentUser) return null;

    const { data } = context;
    const { vendors, users, topManagementGroups, logisticsManagers, logisticsControllers, stores } = data;
    const vendorName = vendors.find(v => v.id === po.vendorId)?.name || 'N/A';
    const approver1Name = po.approverId ? users.find(u => u.id === po.approverId)?.name : null;
    const approver2Name = po.highValueApproverId ? users.find(u => u.id === po.highValueApproverId)?.name : null;

    const subtotalInPoCurrency = po.items.reduce((sum, item) => sum + item.quantity * item.unitCost, 0);
    const taxInPoCurrency = subtotalInPoCurrency * po.taxRate;
    const totalInPoCurrency = subtotalInPoCurrency + taxInPoCurrency;

    const convertToDefault = (value: number, fromCurrency: string): number => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
    };
    
    const totalInDefault = convertToDefault(totalInPoCurrency, po.currency);

    const isLGManager = logisticsManagers.some(g => g.userIds.includes(currentUser.id));
    const isTopManagement = topManagementGroups.some(g => g.userIds.includes(currentUser.id));
    
    // Check if user is in Logistics Controllers group
    const isLogisticsController = logisticsControllers.some(g => g.userIds.includes(currentUser.id));
    const isSupervisor = currentUser.role === 'Supervisor';
    
    const canApproveLevel1 = !!isLGManager && po.status === POStatus.PendingApproval;
    const canApproveLevel2 = isTopManagement && po.status === POStatus.PendingHighValueApproval;
    const canApprove = canApproveLevel1 || canApproveLevel2;
    
    // Requirement Update: Allow Logistics Controllers/Supervisors to Submit to Vendor once Approved
    // Note: Added isLGManager as a fallback option to ensure process continuity if controllers are unavailable.
    const canSubmitToVendor = (isSupervisor || isLogisticsController || isLGManager) && po.status === POStatus.Approved;

    const itemsColumns = [
        { header: 'Part', accessor: (item: POItem) => item.description },
        { header: 'Qty', accessor: (item: POItem) => `${item.quantity} ${item.unitOfMeasure}` },
        { header: `Unit Cost (${po.currency})`, accessor: (item: POItem) => poCurrencyFormatter.format(item.unitCost) },
        { header: `Line Total (${po.currency})`, accessor: (item: POItem) => poCurrencyFormatter.format(item.quantity * item.unitCost) },
    ];
    
    const printableStatuses = [POStatus.Approved, POStatus.Submitted, POStatus.PartiallyReceived, POStatus.Received, POStatus.Closed];

    const storeName = po.storeId ? stores.find(s => s.id === po.storeId)?.name : undefined;
    const shipToDisplay = storeName ? `${storeName} (System Default)` : po.shipToAddress;

    const footer = (
        <div className="flex w-full justify-between items-center no-print">
            <div>
                {printableStatuses.includes(po.status) && (
                    <Button variant="secondary" onClick={onPrintPreview}>Print</Button>
                )}
            </div>
            <div className="flex space-x-2">
                {canApprove && (
                    <>
                        <Button variant="danger" onClick={() => setIsRejectModalOpen(true)}>Reject</Button>
                        <Button variant="primary" onClick={() => onUpdateStatus(po.id, POStatus.Approved)}>Approve PO</Button>
                    </>
                )}
                {canSubmitToVendor && (
                    <Button variant="primary" onClick={() => onUpdateStatus(po.id, POStatus.Submitted)}>Submit to Vendor</Button>
                )}
                 <Button variant="secondary" onClick={onClose}>Close</Button>
            </div>
        </div>
    );

    return (
        <>
            <Modal isOpen={true} onClose={onClose} title={`Details for ${po.id}`} footer={footer} size="5xl">
                {/* ... (Content remains mostly the same) ... */}
                <div className="space-y-4 text-sm">
                     {po.status === POStatus.AddMoreInfo && po.rejectionRemarks && (
                        <Alert type="warning" title="Changes Requested by Approver">
                            {po.rejectionRemarks}
                        </Alert>
                    )}
                    <div className="grid grid-cols-3 gap-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div><strong className="block text-xs text-gray-500 uppercase">Status</strong><Badge color={statusColors[po.status]}>{po.status}</Badge></div>
                        <div><strong className="block text-xs text-gray-500 uppercase">Vendor</strong>{vendorName}</div>
                        <div><strong className="block text-xs text-gray-500 uppercase">Order Date</strong>{formatDate(po.orderDate)}</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                        <div><strong className="block text-xs text-gray-500 uppercase">Parent PR</strong>{po.prId}</div>
                        <div><strong className="block text-xs text-gray-500 uppercase">Parent RFQ</strong>{po.rfqId}</div>
                        <div><strong className="block text-xs text-gray-500 uppercase">Delivery Date</strong>{formatDate(po.expectedDeliveryDate)}</div>
                        <div><strong className="block text-xs text-gray-500 uppercase">Payment Terms</strong>{po.paymentTerms}</div>
                        <div className="col-span-2"><strong className="block text-xs text-gray-500 uppercase">Ship To</strong>{shipToDisplay}</div>
                    </div>

                    <div className="pt-2">
                        <h4 className="font-semibold mb-2">Items</h4>
                        <Table<POItem & { id: number }> columns={itemsColumns} data={po.items.map((item, index) => ({...item, id: index}))} />
                    </div>
                    
                    <div className="flex justify-end pt-2 border-t dark:border-gray-600">
                        <div className="w-64 space-y-1">
                            <div className="flex justify-between"><span className="text-gray-500">Subtotal ({po.currency}):</span><span>{poCurrencyFormatter.format(subtotalInPoCurrency)}</span></div>
                            <div className="flex justify-between"><span className="text-gray-500">Tax ({po.taxRate * 100}%):</span><span>{poCurrencyFormatter.format(taxInPoCurrency)}</span></div>
                            <div className="flex justify-between font-bold text-base"><span >Total ({po.currency}):</span><span>{poCurrencyFormatter.format(totalInPoCurrency)}</span></div>
                             {po.currency !== settings.currency && (
                                <div className="flex justify-between text-xs text-gray-500 pt-1 border-t">
                                    <span >(Approx. {settings.currency}):</span>
                                    <span>{formatDefaultCurrency(totalInDefault)}</span>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="border-t dark:border-gray-600 pt-4 mt-4">
                        <h4 className="font-semibold mb-2">Approval Status</h4>
                        <div className="text-sm">
                            {po.status === POStatus.PendingApproval && <p>Waiting for Logistics Manager approval.</p>}
                            {po.status === POStatus.PendingHighValueApproval && (
                                <div>
                                    <p>Waiting for Top Management approval.</p>
                                    {approver1Name && <p className="text-xs text-gray-500 mt-1">Level 1 approved by: {approver1Name}</p>}
                                </div>
                            )}
                            {po.status === POStatus.Approved && (
                                <div>
                                    <p className="text-green-600 font-semibold">Fully Approved. Ready to submit to vendor.</p>
                                    {approver1Name && <p className="text-xs text-gray-500 mt-1">Approved by: {approver1Name}</p>}
                                    {approver2Name && <p className="text-xs text-gray-500">High-value approval by: {approver2Name}</p>}
                                </div>
                            )}
                            {po.status === POStatus.Rejected && (
                                 <div>
                                    <p className="text-red-600 font-semibold">Rejected & Archived.</p>
                                    {(approver1Name || approver2Name) && <p className="text-xs text-gray-500 mt-1">Rejected by: {approver1Name || approver2Name}</p>}
                                    {po.rejectionRemarks && <p className="text-xs text-gray-500 mt-1">Reason: {po.rejectionRemarks}</p>}
                                 </div>
                            )}
                        </div>
                    </div>
                </div>
            </Modal>
            {/* ... Rejection logic ... */}
        </>
    );
};

// ... (Rest of PurchaseOrderList component structure and helpers remain unchanged)

interface PurchaseOrderListProps {
    rfqToCreateFromId: string | null;
    onCreationDone: () => void;
    currentUser: User | null;
}

export const PurchaseOrderList: React.FC<PurchaseOrderListProps> = ({ rfqToCreateFromId, onCreationDone, currentUser }) => {
    // ... Hooks, context, existing methods ...
    const context = useContext(DataContext);
    const { settings } = useSettings();
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [poToEdit, setPoToEdit] = useState<PurchaseOrder | null>(null);
    const [poToView, setPoToView] = useState<PurchaseOrder | null>(null);
    const [poToReceive, setPoToReceive] = useState<PurchaseOrder | null>(null);
    const [filters, setFilters] = useState({ id: '', vendorId: '', status: '' });
    const [showMyActionsOnly, setShowMyActionsOnly] = useState(false);
    const formatCurrency = useCurrencyFormatter();
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
    const formatDate = useDateFormatter();
    const [isPrintPreviewOpen, setIsPrintPreviewOpen] = useState(false);
    const [poToPrint, setPoToPrint] = useState<PurchaseOrder | null>(null);

    useEffect(() => {
        if (rfqToCreateFromId) {
            const existingPO = context?.data.purchaseOrders.find(po => po.rfqId === rfqToCreateFromId);
            if (existingPO) {
                setPoToView(existingPO);
            } else {
                setPoToEdit(null);
                setIsFormOpen(true);
            }
            onCreationDone();
        }
    }, [rfqToCreateFromId, onCreationDone, context?.data.purchaseOrders]);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { purchaseOrders, vendors, inventoryTransactions, parts, rfqs, purchaseRequisitions } = data;
    
    // Identify user roles for visibility logic
    const isTopManagement = useMemo(() => data.topManagementGroups.some(g => g.userIds.includes(currentUser?.id || '')), [data, currentUser]);
    const isLGManager = useMemo(() => data.logisticsManagers.some(g => g.userIds.includes(currentUser?.id || '')), [data, currentUser]);
    const isLogisticsController = useMemo(() => data.logisticsControllers.some(g => g.userIds.includes(currentUser?.id || '')), [data, currentUser]);
    
    const isPrivilegedViewer = useMemo(() => {
        if (!currentUser) return false;
        if (canSeeAllZones) return true;
        if (isTopManagement) return true;
        if (isLGManager) return true;
        if (isLogisticsController) return true;
        if (currentUser.role === 'Supervisor') return true;
        return false;
    }, [currentUser, canSeeAllZones, isTopManagement, isLGManager, isLogisticsController]);

    const getVendorName = (vendorId: string) => vendors.find(v => v.id === vendorId)?.name || 'N/A';
    
    // Helper implementations
    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => { setFilters(prev => ({ ...prev, [e.target.name]: e.target.value })); };
    const clearFilters = () => { setFilters({ id: '', vendorId: '', status: '' }); setShowMyActionsOnly(false); };
    
    const needsMyAction = (po: PurchaseOrder) => {
        if (!currentUser) return false;
        if (po.status === POStatus.PendingApproval && isLGManager) return true;
        if (po.status === POStatus.PendingHighValueApproval && isTopManagement) return true;
        // Requirement: Add check for Submit action
        if (po.status === POStatus.Approved && (isLogisticsController || currentUser.role === 'Supervisor' || isLGManager)) return true;
        return false;
    };

    const filteredPOs = useMemo(() => {
        return purchaseOrders.filter(po => {
            if (!isPrivilegedViewer) {
                const rfq = rfqs.find(r => r.id === po.rfqId);
                const pr = rfq ? purchaseRequisitions.find(p => p.id === rfq.prId) : null;
                if (pr) {
                    const zoneId = pr.type === PRType.System ? pr.zoneId : pr.deliveryZoneId;
                    if (zoneId && !accessibleZoneIds.includes(zoneId)) return false;
                } else { if (po.createdBy !== currentUser.id) return false; }
            }
            if (showMyActionsOnly && !needsMyAction(po)) return false;
            const idMatch = filters.id ? po.id.toLowerCase().includes(filters.id.toLowerCase()) : true;
            const vendorMatch = filters.vendorId ? po.vendorId === filters.vendorId : true;
            const statusMatch = filters.status ? po.status === filters.status : true;
            return idMatch && vendorMatch && statusMatch;
        });
    }, [purchaseOrders, filters, isPrivilegedViewer, accessibleZoneIds, rfqs, purchaseRequisitions, currentUser, showMyActionsOnly]);

    const calculateTotal = (po: PurchaseOrder) => (po.items.reduce((total, item) => total + item.quantity * item.unitCost, 0)) * (1 + po.taxRate);
    const convertToDefault = (value: number, fromCurrency: string) => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
    };

    const columns = [
        { header: 'PO ID', accessor: 'id' as keyof PurchaseOrder },
        { header: 'Vendor', accessor: (item: PurchaseOrder) => getVendorName(item.vendorId) },
        { header: 'Order Date', accessor: (item: PurchaseOrder) => formatDate(item.orderDate) },
        { header: 'Expected Delivery', accessor: (item: PurchaseOrder) => formatDate(item.expectedDeliveryDate) },
        { header: 'Status', accessor: (item: PurchaseOrder) => <Badge color={statusColors[item.status]}>{item.status}</Badge> },
        { header: 'Total', accessor: (item: PurchaseOrder) => formatCurrency(convertToDefault(calculateTotal(item), item.currency)) },
    ];

    // ... (Handlers) ...
    // Redefining handleUpdateStatus briefly for context validity in output
    const handleUpdateStatus = (poId: string, newStatus: POStatus, remarks?: string) => {
        setData(prev => {
            const poToUpdate = prev.purchaseOrders.find(p => p.id === poId);
            if (!poToUpdate) return prev;
            const updatedPO = { ...poToUpdate, status: newStatus, rejectionRemarks: remarks || poToUpdate.rejectionRemarks };
            
            // Record approver ID
            if (newStatus === POStatus.Approved) {
                // If it was pending first level
                if (poToUpdate.status === POStatus.PendingApproval) updatedPO.approverId = currentUser.id;
                // If it was pending second level
                if (poToUpdate.status === POStatus.PendingHighValueApproval) updatedPO.highValueApproverId = currentUser.id;
            }

            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: 'UPDATE',
                entityType: 'PurchaseOrder',
                entityId: poId,
                details: `Updated status of PO ${poId} to ${newStatus}.`,
                status: 'Success'
            };

            return { 
                ...prev, 
                purchaseOrders: prev.purchaseOrders.map(p => p.id === poId ? updatedPO : p),
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        setPoToView(null);
    };

    return (
        <>
            <Card title="Purchase Orders" actions={(currentUser.role === 'Supervisor' || isLogisticsController) && <Button onClick={() => { setPoToEdit(null); setIsFormOpen(true);}}>New Purchase Order</Button>}>
                {/* ... (Filters JSX - same as before) ... */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                        <label htmlFor="id-filter" className="block text-sm font-medium text-gray-700 dark:text-gray-300">PO ID</label>
                        <input type="text" id="id-filter" name="id" value={filters.id} onChange={handleFilterChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm sm:text-sm" placeholder="Search ID..."/>
                    </div>
                    <div>
                        <label htmlFor="vendorId-filter" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Vendor</label>
                        <select id="vendorId-filter" name="vendorId" value={filters.vendorId} onChange={handleFilterChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 sm:text-sm rounded-md">
                            <option value="">All Vendors</option>
                            {vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="status-filter" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                        <select id="status-filter" name="status" value={filters.status} onChange={handleFilterChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 sm:text-sm rounded-md">
                            <option value="">All Statuses</option>
                            {Object.values(POStatus).map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>
                    <div className="flex items-end space-x-2">
                        <Button onClick={clearFilters} variant="secondary" className="w-full">Clear Filters</Button>
                        {currentUser && (
                            <button
                                onClick={() => setShowMyActionsOnly(!showMyActionsOnly)}
                                className={`w-full px-4 py-2 text-sm font-medium rounded-md border shadow-sm transition-colors ${showMyActionsOnly ? 'bg-indigo-100 text-indigo-800 border-indigo-200' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`}
                            >
                                {showMyActionsOnly ? 'Show All' : 'My Actions'}
                            </button>
                        )}
                    </div>
                </div>

                <Table<PurchaseOrder>
                    columns={columns}
                    data={filteredPOs}
                    renderRowActions={(po) => (
                        <div className="flex space-x-2 items-center">
                            {needsMyAction(po) && <span className="text-xs font-bold text-indigo-600 animate-pulse mr-2">Action Required</span>}
                            <Button size="sm" variant="secondary" onClick={() => setPoToView(po)}>Details</Button>
                            {/* ... (Other existing buttons logic would be here) ... */}
                        </div>
                    )}
                />
            </Card>
            {/* ... (Modals) ... */}
            {poToView && (
                <PODetailModal
                    po={poToView}
                    currentUser={currentUser}
                    onClose={() => setPoToView(null)}
                    onUpdateStatus={handleUpdateStatus}
                    onPrintPreview={() => { setPoToPrint(poToView); setIsPrintPreviewOpen(true); }}
                />
            )}
            {/* ... */}
        </>
    );
};
