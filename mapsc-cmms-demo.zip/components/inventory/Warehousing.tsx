
import React, { useContext, useState, useMemo, useEffect } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { Store, User, AuditLogEntry } from '../../types';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { Alert } from '../ui/Alert';

const StoreForm: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (store: Store) => void;
    storeToEdit: Store | null;
    currentUser: User | null;
}> = ({ isOpen, onClose, onSave, storeToEdit, currentUser }) => {
    const [formData, setFormData] = useState<Store>({
        id: '',
        name: '',
        location: '',
        description: '',
        createdBy: currentUser?.id || '',
    });

    useEffect(() => {
        if (isOpen) {
            if (storeToEdit) {
                setFormData(storeToEdit);
            } else {
                setFormData({
                    id: '',
                    name: '',
                    location: '',
                    description: '',
                    createdBy: currentUser?.id || '',
                });
            }
        }
    }, [isOpen, storeToEdit, currentUser]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="store-form">{storeToEdit ? 'Save Changes' : 'Create Store'}</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={storeToEdit ? 'Edit Store' : 'Add New Store'} footer={modalFooter}>
            <form id="store-form" onSubmit={handleSubmit} className="space-y-4">
                <Input label="Store Name" name="name" value={formData.name} onChange={handleChange} required />
                <Input label="Location / Address" name="location" value={formData.location} onChange={handleChange} required />
                <div>
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
                    <textarea
                        id="description"
                        name="description"
                        rows={3}
                        value={formData.description || ''}
                        onChange={handleChange}
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        maxLength={106}
                    />
                </div>
            </form>
        </Modal>
    );
};

export const Warehousing: React.FC<{ currentUser: User | null }> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [storeToEdit, setStoreToEdit] = useState<Store | null>(null);
    const [storeToDelete, setStoreToDelete] = useState<Store | null>(null);
    const [deleteError, setDeleteError] = useState<string | null>(null);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { stores, parts } = data;

    // Permission Logic
    const isLogisticsController = useMemo(() => {
        return data.logisticsControllers.some(g => g.userIds.includes(currentUser.id));
    }, [data.logisticsControllers, currentUser.id]);

    // Only Logistics Controllers can Create/Edit/Delete.
    // Others (Logistics Clerks, Top Management) are View Only based on route protection, 
    // but UI buttons are hidden here for safety.
    const canManage = isLogisticsController;

    const handleSaveStore = (store: Store) => {
        setData(prev => {
            const isEditing = !!store.id;
            let newStores = [...prev.stores];
            let logAction = 'CREATE';
            let savedStore = store;

            if (isEditing) {
                logAction = 'UPDATE';
                newStores = newStores.map(s => s.id === store.id ? store : s);
            } else {
                const newId = `STORE-${String(newStores.length + 1).padStart(3, '0')}`;
                savedStore = { ...store, id: newId };
                newStores.push(savedStore);
            }

            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: logAction,
                entityType: 'Store',
                entityId: savedStore.id,
                details: `${logAction === 'CREATE' ? 'Created' : 'Updated'} store '${savedStore.name}'.`,
                status: 'Success'
            };

            return {
                ...prev,
                stores: newStores,
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        setIsFormOpen(false);
        setStoreToEdit(null);
    };

    const handleDeleteClick = (store: Store) => {
        // Validation: Check if parts are allocated (using string matching on location for now as parts don't have storeId yet)
        // In a real scenario, parts would link to storeId. Here we simulate by checking if any part location string includes the store name.
        // However, to be safer and future-proof, we should check if any Purchase Requisitions or Orders link to this storeId.
        
        const linkedPRs = data.purchaseRequisitions.some(pr => pr.storeId === store.id);
        const linkedPOs = data.purchaseOrders.some(po => po.storeId === store.id);
        
        // Also strictly check parts if we migrate them later. For now, flexible check on location string matches store name? 
        // The prompt says "if there are not Parts inside/allocated". 
        // Since we haven't migrated Parts to use storeId, we will do a basic check on `part.location` containing the store name to prevent accidental deletion of "active" stores.
        const hasParts = parts.some(p => p.location.toLowerCase().includes(store.name.toLowerCase()));

        if (linkedPRs || linkedPOs || hasParts) {
            alert(`Cannot delete store '${store.name}'. It is referenced by active Parts, Purchase Requisitions, or Purchase Orders.`);
            return;
        }

        setDeleteError(null);
        setStoreToDelete(store);
    };

    const confirmDelete = () => {
        if (!storeToDelete) return;
        
        setData(prev => {
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: 'DELETE',
                entityType: 'Store',
                entityId: storeToDelete.id,
                details: `Deleted store '${storeToDelete.name}'.`,
                status: 'Success'
            };

            return {
                ...prev,
                stores: prev.stores.filter(s => s.id !== storeToDelete.id),
                auditLog: [logEntry, ...prev.auditLog]
            };
        });
        setStoreToDelete(null);
    };

    const columns = [
        { header: 'Store ID', accessor: 'id' as keyof Store },
        { header: 'Name', accessor: 'name' as keyof Store },
        { header: 'Location', accessor: 'location' as keyof Store },
        { header: 'Description', accessor: 'description' as keyof Store },
    ];

    return (
        <>
            <Card 
                title="Warehousing" 
                actions={canManage && <Button onClick={() => { setStoreToEdit(null); setIsFormOpen(true); }}>Add Store</Button>}
            >
                <Table<Store>
                    columns={columns}
                    data={stores}
                    renderRowActions={(store) => canManage && (
                        <div className="flex space-x-2 justify-end">
                            <Button variant="secondary" size="sm" onClick={() => { setStoreToEdit(store); setIsFormOpen(true); }}>Edit</Button>
                            <Button variant="danger" size="sm" onClick={() => handleDeleteClick(store)}>Delete</Button>
                        </div>
                    )}
                />
            </Card>

            <StoreForm
                isOpen={isFormOpen}
                onClose={() => setIsFormOpen(false)}
                onSave={handleSaveStore}
                storeToEdit={storeToEdit}
                currentUser={currentUser}
            />

            {storeToDelete && (
                <ConfirmationModal
                    isOpen={!!storeToDelete}
                    onClose={() => setStoreToDelete(null)}
                    onConfirm={confirmDelete}
                    title="Confirm Store Deletion"
                    confirmText="Delete"
                    confirmButtonVariant="danger"
                >
                    <p>Are you sure you want to delete the store <span className="font-bold">{storeToDelete.name}</span>?</p>
                    {deleteError && <Alert type="error">{deleteError}</Alert>}
                </ConfirmationModal>
            )}
        </>
    );
};
