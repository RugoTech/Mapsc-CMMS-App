
import React, { useContext, useMemo, useState, useEffect } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { Part, PurchaseRequisition, User, Message } from '../../types';
import { PRType, PRStatus, Priority, RFQStatus, POStatus } from '../../types';
import { Modal } from '../ui/Modal';
import { Badge } from '../ui/Badge';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface InventoryAlertsProps {
    currentUser: User | null;
}

export const InventoryAlerts: React.FC<InventoryAlertsProps> = ({ currentUser }) => {
    const context = useContext(DataContext);
    const [infoModalContent, setInfoModalContent] = useState<{ title: string; content: React.ReactNode } | null>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
    const [autoPrCheckComplete, setAutoPrCheckComplete] = useState(false);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { parts, purchaseRequisitions, assets, zones, plantCostCodes, zoneCostCodes, sectionCostCodes, accountCostCodes, vendors, rfqs, purchaseOrders, stores } = data;
    
    const isManagerOrTopManagement = useMemo(() => {
        if (!currentUser) return false;
        if (currentUser.role === 'Manager' || currentUser.role === 'Factory Manager' || currentUser.role === 'Administrator') return true;
        return data.topManagementGroups.some(g => g.userIds.includes(currentUser.id));
    }, [currentUser, data.topManagementGroups]);

    const lowStockParts = useMemo(() => parts.filter(p => {
        if (p.isActive === false) return false; // Skip inactive parts
        if (p.quantity > p.reorderPoint) return false;

        const asset = p.assetId ? assets.find(a => a.id === p.assetId) : null;
        const partZoneId = asset?.zoneId;
        
        return canSeeAllZones || !partZoneId || accessibleZoneIds.includes(partZoneId);
    }), [parts, assets, canSeeAllZones, accessibleZoneIds]);

    const inProcessPartIds = useMemo(() => {
        const inProcessIds = new Set<string>();
        const systemPRs = purchaseRequisitions.filter(pr => pr.type === PRType.System);

        for (const pr of systemPRs) {
            if (pr.status === PRStatus.Rejected) {
                continue; // This PR is dead, part is available for a new PR.
            }
            
            const rfq = rfqs.find(r => r.prId === pr.id);
            // If an RFQ was created, it might have been rejected.
            if (rfq && (rfq.status === RFQStatus.Rejected || rfq.status === RFQStatus.Closed)) {
                 // Check if it was closed because a PO was made anyway.
                 const poForClosedRfq = purchaseOrders.find(p => p.rfqId === rfq.id);
                 if (!poForClosedRfq) {
                    continue; // RFQ is dead-end, part is available.
                 }
            }

            const po = purchaseOrders.find(p => p.rfqId === rfq?.id);

            // If there is no PO yet, or the PO is not yet finished receiving, the part is in process.
            if (!po || (po.status !== POStatus.Received && po.status !== POStatus.Closed)) {
                pr.items?.forEach(item => inProcessIds.add(item.partId));
            }
        }
        return inProcessIds;
    }, [purchaseRequisitions, rfqs, purchaseOrders]);
    
    const creatableLowStockParts = useMemo(() =>
        lowStockParts.filter(part => !inProcessPartIds.has(part.id)),
    [lowStockParts, inProcessPartIds]);

    const generatePRsForParts = (partsToProcess: Part[]) => {
        if (partsToProcess.length === 0) {
            return { generatedCount: 0, warnings: [] };
        }
        
        const newPRs: PurchaseRequisition[] = [];
        const newMessages: Message[] = [];
        const warnings: string[] = [];
        let generatedCount = 0;

        partsToProcess.forEach(part => {
            if (!part.vendorId) {
                warnings.push(`'${part.name}': No vendor assigned.`);
                return;
            }

            let quantityToOrder = 0;
            if (part.maxQuantity && part.maxQuantity > 0) {
                quantityToOrder = part.maxQuantity - part.quantity;
            } else {
                quantityToOrder = Math.ceil((part.reorderPoint * 1.5) - part.quantity);
            }

            if (quantityToOrder <= 0) {
                return;
            }

            let budgetCode = '100-200-300-400';
            let prZoneId = '';
            const asset = assets.find(a => a.id === part.assetId);
            if(asset) {
                const zone = zones.find(z => z.id === asset.zoneId);
                prZoneId = zone?.id || '';
                const pcc = plantCostCodes.find(pcc => pcc.name.includes('Main'));
                const zcc = zoneCostCodes.find(zcc => zcc.name === zone?.name);
                const scc = sectionCostCodes.find(scc => scc.name.includes('Mechanical'));
                const acc = accountCostCodes.find(acc => acc.name.includes('Maintenance'));
                
                if (pcc && zcc && scc && acc) {
                    budgetCode = [pcc.code, zcc.code, scc.code, acc.code].join('-');
                }
            }

            // Determine Store for Delivery based on part location
            // Simple fuzzy match: If part location name matches a store name, use that store ID.
            // Otherwise, default to the first available store or stay undefined if none.
            let targetStoreId: string | undefined = undefined;
            const partLocationLower = part.location.toLowerCase();
            const matchedStore = stores.find(s => partLocationLower.includes(s.name.toLowerCase()));
            if (matchedStore) {
                targetStoreId = matchedStore.id;
            } else if (stores.length > 0) {
                // Default to first store if no match found (assumes central receiving)
                targetStoreId = stores[0].id; 
            }

            const newPR: PurchaseRequisition = {
                id: `SPR-${String(purchaseRequisitions.filter(p => p.type === PRType.System).length + newPRs.length + 1).padStart(3, '0')}`,
                type: PRType.System,
                requestDate: new Date().toISOString().split('T')[0],
                status: PRStatus.Pending,
                priority: Priority.High,
                vendorId: part.vendorId,
                budgetCode,
                requesterId: currentUser.id,
                justification: 'Low stock level',
                zoneId: prZoneId, // Used for budget/accounting logic
                storeId: targetStoreId, // Used for delivery logic
                items: [{ partId: part.id, quantity: quantityToOrder, unitCost: part.unitCost, unitOfMeasure: part.unitOfMeasure }],
                deliveryDate: new Date(Date.now() + (part.leadTime || 7) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            };
            newPRs.push(newPR);
            
            const message: Message = {
                id: 'temp', // temp id
                sender: 'System',
                recipientId: 'USER-003', // Supervisor
                title: `Low Stock PR Generated: ${part.name}`,
                body: `Part ${part.name} (${part.partNumber}) is below reorder point. System PR ${newPR.id} has been generated.`,
                date: new Date().toISOString(),
                read: false,
            };
            newMessages.push(message);

            generatedCount++;
        });

        if (newPRs.length > 0) {
            setData(prev => ({
                ...prev,
                purchaseRequisitions: [...prev.purchaseRequisitions, ...newPRs],
                messages: [
                    ...newMessages.map((msg, idx) => ({...msg, id: `MSG-${String(prev.messages.length + idx + 1).padStart(3, '0')}`})),
                    ...prev.messages
                ]
            }));
        }
        
        return { generatedCount, warnings };
    };

    const handleGeneratePRs = () => {
        const { generatedCount, warnings } = generatePRsForParts(creatableLowStockParts);
        
        let alertMessage = '';
        if (generatedCount > 0) {
            alertMessage += `${generatedCount} new Purchase Requisition(s) generated for low stock items.\n\n`;
        }
        if (warnings.length > 0) {
            alertMessage += `Could not generate PRs for the following items:\n- ${warnings.join('\n- ')}\n\n`;
        }
        if (!alertMessage) {
            alertMessage = 'No new PRs were generated. Items may already have an open PR or are missing required information (like a vendor).';
        }

        setInfoModalContent({
            title: generatedCount > 0 ? "PR Generation Complete" : "PR Generation Notice",
            content: <p className="whitespace-pre-wrap">{alertMessage.trim()}</p>
        });
    };
    
    useEffect(() => {
        if (autoPrCheckComplete || !currentUser || currentUser.role !== 'Supervisor') {
            return;
        }

        const { generatedCount, warnings } = generatePRsForParts(creatableLowStockParts);

        if (generatedCount > 0 || warnings.length > 0) {
            let alertMessage = 'Automatic System PR Check Complete:\n\n';
            if (generatedCount > 0) {
                alertMessage += `${generatedCount} new Purchase Requisition(s) were automatically generated.\n\n`;
            }
            if (warnings.length > 0) {
                alertMessage += `Could not generate PRs for the following items:\n- ${warnings.join('\n- ')}\n\n`;
            }
            setInfoModalContent({
                title: "Automatic PR Generation Summary",
                content: <p className="whitespace-pre-wrap">{alertMessage.trim()}</p>
            });
        }
        
        setAutoPrCheckComplete(true);
    }, [autoPrCheckComplete, currentUser, creatableLowStockParts]);


    const handleCreatePR = (part: Part) => {
        if (inProcessPartIds.has(part.id)) {
            setInfoModalContent({ title: "Action Not Needed", content: <p>A Purchase Requisition or Order already exists for {part.name}.</p> });
            return;
        }
        
        const { generatedCount, warnings } = generatePRsForParts([part]);

        if (generatedCount > 0) {
             setInfoModalContent({ title: "Success", content: <p>Purchase Requisition created for {part.name}.</p>});
        } else if (warnings.length > 0) {
            setInfoModalContent({ title: "Cannot Create PR", content: <p>Could not create PR: {warnings[0]}</p> });
        }
    };

    const columns = [
        { header: 'Part Number', accessor: 'partNumber' as keyof Part },
        { header: 'Description', accessor: 'name' as keyof Part },
        { header: 'Location', accessor: 'location' as keyof Part },
        { 
            header: 'On Hand', 
            accessor: 'quantity' as keyof Part
        },
        { header: 'Reorder Point', accessor: 'reorderPoint' as keyof Part },
    ];
    
    return (
        <>
            <Card
                title="Inventory Alerts (Low Stock)"
                actions={
                    lowStockParts.length > 0 && !isManagerOrTopManagement ? (
                        <Button
                            onClick={handleGeneratePRs}
                            disabled={creatableLowStockParts.length === 0}
                            title={creatableLowStockParts.length === 0 ? "All low stock items have pending or processed PRs" : "Generate PRs for all eligible low stock items"}
                        >
                            Generate All Missing PRs ({creatableLowStockParts.length})
                        </Button>
                    ) : null
                }
            >
                {lowStockParts.length > 0 ? (
                    <Table<Part>
                        columns={columns}
                        data={lowStockParts}
                        renderRowActions={(part) => {
                            const isInProcess = inProcessPartIds.has(part.id);
                            
                            let buttonText = 'Create PR';
                            let isDisabled = false;
                            let buttonTitle = 'Create a new Purchase Requisition';

                            if (isInProcess) {
                                buttonText = 'In Process';
                                isDisabled = true;
                                buttonTitle = 'A Purchase Requisition or active PO already exists for this item.';
                            }

                            return (
                                !isManagerOrTopManagement && (
                                    <Button
                                        variant="secondary"
                                        size="sm"
                                        onClick={() => handleCreatePR(part)}
                                        disabled={isDisabled}
                                        title={buttonTitle}
                                    >
                                        {buttonText}
                                    </Button>
                                )
                            )
                        }}
                    />
                ) : (
                    <div className="text-center py-8">
                        <p className="text-gray-500 dark:text-gray-400">No parts are currently below their reorder point.</p>
                    </div>
                )}
            </Card>
            {infoModalContent && (
                <Modal
                    isOpen={!!infoModalContent}
                    onClose={() => setInfoModalContent(null)}
                    title={infoModalContent.title}
                    footer={<Button onClick={() => setInfoModalContent(null)}>OK</Button>}
                >
                    {infoModalContent.content}
                </Modal>
            )}
        </>
    );
};
