
import React, { useState, useContext, useMemo, useEffect } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Modal } from '../ui/Modal';
import { DataContext } from '../../contexts/DataContext';
import type { RFQ, User, AuditLogEntry, Message } from '../../types';
import {
  RFQStatus,
  Priority,
  PRType,
} from '../../types';
import { ConfirmationModal } from '../ui/ConfirmationModal';


const statusColors: Record<RFQStatus, 'blue' | 'green' | 'red' | 'gray' | 'yellow'> = {
    [RFQStatus.Draft]: 'gray',
    [RFQStatus.WaitingApproval]: 'blue',
    [RFQStatus.SentToVendor]: 'yellow',
    [RFQStatus.QuotationReceived]: 'yellow',
    [RFQStatus.Approved]: 'green',
    [RFQStatus.Rejected]: 'red',
    [RFQStatus.Closed]: 'gray',
};

const priorityColors: Record<Priority, 'blue' | 'yellow' | 'red'> = {
    [Priority.Low]: 'blue',
    [Priority.Medium]: 'yellow',
    [Priority.High]: 'red',
    [Priority.Critical]: 'red',
};

// --- Modals ---

const RejectModal: React.FC<{onReject: (remarks: string) => void, onClose: () => void}> = ({ onReject, onClose }) => {
    const [remarks, setRemarks] = useState('');
    return (
        <ConfirmationModal
            isOpen={true}
            onClose={onClose}
            onConfirm={() => onReject(remarks)}
            title="Confirm Rejection"
            confirmText="Reject"
            confirmButtonVariant="danger"
        >
            <p>Please provide a reason for rejecting this RFQ.</p>
            <textarea value={remarks} onChange={e => setRemarks(e.target.value)} rows={3} className="mt-2 w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required/>
        </ConfirmationModal>
    );
};

const RFQDetailModal: React.FC<{
    rfq: RFQ | null;
    currentUser: User | null;
    onClose: () => void;
    onStatusUpdate: (rfqId: string, status: RFQStatus, remarks?: string) => void;
    onCreatePO?: (rfqId: string) => void;
    poExists?: boolean;
}> = ({ rfq, currentUser, onClose, onStatusUpdate, onCreatePO, poExists }) => {
    const context = useContext(DataContext);
    const [isRejecting, setIsRejecting] = useState(false);
    
    if (!rfq || !context || !currentUser) return null;

    const { vendors, users, purchaseRequisitions, parts } = context.data;
    
    const getVendorNames = (ids: string[]) => {
        return ids.map(id => vendors.find(v => v.id === id)?.name || id).join(', ');
    }
    const vendorDisplay = getVendorNames(rfq.vendorIds);

    const approverName = users.find(u => u.id === rfq.approverId)?.name;
    const parentPR = purchaseRequisitions.find(pr => pr.id === rfq.prId);
    const prRequesterName = parentPR?.requesterId ? users.find(u => u.id === parentPR.requesterId)?.name : 'System';
    const rfqRequester = users.find(u => u.id === rfq.requesterId);

    // --- Role-based action flags ---
    const isLogisticsManager = context.data.logisticsManagers.some(g => g.userIds.includes(currentUser.id));
    const isLogisticsController = context.data.logisticsControllers.some(g => g.userIds.includes(currentUser.id)) || currentUser.role === 'Supervisor';
    
    const canApprove = isLogisticsManager && rfq.status === RFQStatus.WaitingApproval;
    const canSendToVendor = isLogisticsController && rfq.status === RFQStatus.Approved;
    const canMarkAsQuoted = isLogisticsController && rfq.status === RFQStatus.SentToVendor;
    
    // STRICT Workflow: Create PO only after Quote is Received.
    const canCreatePO = isLogisticsController && rfq.status === RFQStatus.QuotationReceived && !poExists && onCreatePO;

    const handleUpdate = (status: RFQStatus, remarks?: string) => {
        onStatusUpdate(rfq.id, status, remarks);
    };

    const handleReject = (remarks: string) => {
        if(!remarks.trim()) { alert("Rejection remarks are required."); return; }
        handleUpdate(RFQStatus.Rejected, remarks);
        setIsRejecting(false);
        onClose();
    };
    
    const modalFooter = (
        <div className="flex justify-between w-full">
            <Button variant="secondary" onClick={() => window.print()}>Print</Button>
            <div className="flex space-x-2">
                {canApprove && (
                    <>
                        <Button variant="danger" onClick={() => setIsRejecting(true)}>Decline</Button>
                        <Button variant="primary" onClick={() => handleUpdate(RFQStatus.Approved)}>Approve</Button>
                    </>
                )}
                {canSendToVendor && (
                    <Button variant="primary" onClick={() => handleUpdate(RFQStatus.SentToVendor)}>Send to Vendor</Button>
                )}
                {canMarkAsQuoted && (
                    <Button variant="primary" onClick={() => handleUpdate(RFQStatus.QuotationReceived)}>Mark as Quoted</Button>
                )}
                {canCreatePO && (
                    <Button variant="primary" onClick={() => onCreatePO!(rfq.id)}>Create PO</Button>
                )}
                {poExists && onCreatePO && (
                    <Button variant="secondary" onClick={() => onCreatePO(rfq.id)}>View PO</Button>
                )}
            </div>
        </div>
    );
    
    const DetailItem: React.FC<{label: string, children: React.ReactNode}> = ({label, children}) => (
        <div>
            <strong className="block text-xs text-gray-500 uppercase">{label}</strong>
            <div className="text-sm">{children}</div>
        </div>
    );

    return (
        <>
        <Modal isOpen={!!rfq} onClose={onClose} title={`Details for ${rfq.id}`} footer={modalFooter}>
             <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <DetailItem label="Status"><Badge color={statusColors[rfq.status]}>{rfq.status}</Badge></DetailItem>
                    <DetailItem label="Priority"><Badge color={priorityColors[rfq.priority]}>{rfq.priority}</Badge></DetailItem>
                    <DetailItem label="RFQ Date">{rfq.date}</DetailItem>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <DetailItem label="Parent PR">{rfq.prId}</DetailItem>
                    <DetailItem label="Vendor(s)">{vendorDisplay}</DetailItem>
                </div>

                {parentPR && (
                    <div className="p-3 border dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-800 space-y-2">
                        <h4 className="font-semibold text-sm">Parent PR Details ({parentPR.id})</h4>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                            <DetailItem label="PR Type">{parentPR.type}</DetailItem>
                            {parentPR.type === PRType.Manual && (
                                <DetailItem label="PR Requester">{prRequesterName}</DetailItem>
                            )}
                        </div>
                        {parentPR.justification && <DetailItem label="PR Justification"><p className="whitespace-pre-wrap text-xs">{parentPR.justification}</p></DetailItem>}
                        {parentPR.type === PRType.Manual && parentPR.specifications && (
                            <DetailItem label="PR Specifications"><p className="whitespace-pre-wrap text-xs">{parentPR.specifications}</p></DetailItem>
                        )}
                        {parentPR.type === PRType.System && parentPR.items && (
                            <DetailItem label="PR Items">
                                <ul className="list-disc pl-5">
                                    {parentPR.items.map(item => {
                                        const part = parts.find(p => p.id === item.partId);
                                        return <li key={item.partId} className="text-xs">{item.quantity} x {part?.name || item.partId}</li>
                                    })}
                                </ul>
                            </DetailItem>
                        )}
                    </div>
                )}
                
                <DetailItem label="Description of Items/Services">
                    <p className="whitespace-pre-wrap">{rfq.description}</p>
                </DetailItem>

                <div className="border-t pt-4 grid grid-cols-2 gap-4">
                    <DetailItem label="Requestor (Procurement)">
                        {rfqRequester ? `${rfqRequester.name}, ${rfqRequester.department} (${rfqRequester.email})` : rfq.requesterId}
                    </DetailItem>
                    <DetailItem label="Desired Delivery Date">{rfq.deliveryDate}</DetailItem>
                </div>
                
                {(rfq.status === RFQStatus.Approved || rfq.status === RFQStatus.Rejected) && (
                     <div className="border-t pt-4">
                        <h4 className="font-semibold">Approval Information</h4>
                        <div className="grid grid-cols-2 gap-4 mt-2">
                            <DetailItem label="Approver">{approverName || 'N/A'}</DetailItem>
                            {rfq.remarks && <DetailItem label="Remarks">{rfq.remarks}</DetailItem>}
                        </div>
                    </div>
                )}
            </div>
        </Modal>
        {isRejecting && <RejectModal onClose={() => setIsRejecting(false)} onReject={handleReject}/>}
        </>
    );
};

// --- Main List Component ---

interface RFQListProps {
  onCreatePO: (rfqId: string) => void;
  currentUser: User | null;
}

export const RFQList: React.FC<RFQListProps> = ({ onCreatePO, currentUser }) => {
    const context = useContext(DataContext);
    const [viewingRFQ, setViewingRFQ] = useState<RFQ | null>(null);

    if (!context || !currentUser) return <div>Loading...</div>;

    const { data, setData } = context;
    const { rfqs, vendors, purchaseOrders, purchaseRequisitions } = data;
    
    useEffect(() => {
        if (viewingRFQ) {
            const freshRFQ = data.rfqs.find(r => r.id === viewingRFQ.id);
            if (freshRFQ && freshRFQ.status !== viewingRFQ.status) {
                setViewingRFQ(freshRFQ);
            } else if (!freshRFQ) {
                setViewingRFQ(null);
            }
        }
    }, [data.rfqs]);

    // Helper to display abbreviated vendor names for multiple selections
    const getVendorDisplay = (vendorIds: string[]) => {
        if (!vendorIds || vendorIds.length === 0) return 'N/A';
        if (vendorIds.length === 1) {
            return vendors.find(v => v.id === vendorIds[0])?.name || vendorIds[0];
        }
        
        // Multiple vendors: Show shortened names (e.g. "Grainger, Motion")
        return vendorIds.map(id => {
            const vendor = vendors.find(v => v.id === id);
            // Simplistic "first name" extraction for company names: take first word
            return vendor ? vendor.name.split(' ')[0] : id;
        }).join(', ');
    };
    
    const handleStatusUpdate = (rfqId: string, status: RFQStatus, remarks?: string) => {
        setData(prev => {
            const rfq = prev.rfqs.find(r => r.id === rfqId);
            if (!rfq) return prev;
            
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prev.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'UPDATE',
                entityType: 'RFQ',
                entityId: rfqId,
                details: `Updated status of RFQ ${rfqId} to ${status}.`,
                status: 'Success'
            };

            let newMessages = [...prev.messages];

            // Only send notification if current user is NOT the requester (avoid self-notification)
            if (currentUser.id !== rfq.requesterId) {
                const message: Message = {
                    id: `MSG-${String(prev.messages.length + 1).padStart(3, '0')}`,
                    sender: currentUser.name,
                    recipientId: rfq.requesterId,
                    title: `RFQ ${rfqId} status changed to ${status}`,
                    body: `Your RFQ "${rfq.description}" has been updated to '${status.toLowerCase()}' by ${currentUser.name}.${remarks ? `\n\nRemarks: ${remarks}` : ''}`,
                    date: new Date().toISOString(),
                    read: false,
                };
                newMessages = [message, ...prev.messages];
            }
    
            return {
                ...prev,
                rfqs: prev.rfqs.map(r =>
                    r.id === rfqId ? { ...r, status, remarks: remarks || r.remarks, approverId: currentUser!.id } : r
                ),
                auditLog: [logEntry, ...prev.auditLog],
                messages: newMessages,
            };
        });
    };

    const isTopManagement = useMemo(() => {
        return data.topManagementGroups.some(g => g.userIds.includes(currentUser.id));
    }, [data.topManagementGroups, currentUser.id]);

    const isEngManager = useMemo(() => {
        return data.assetManagers.some(g => g.userIds.includes(currentUser.id));
    }, [data.assetManagers, currentUser.id]);

    const isLogisticsManager = useMemo(() => {
        return data.logisticsManagers.some(g => g.userIds.includes(currentUser.id));
    }, [data.logisticsManagers, currentUser.id]);

    const isLogisticsController = useMemo(() => {
        return data.logisticsControllers.some(g => g.userIds.includes(currentUser.id)) || currentUser.role === 'Supervisor';
    }, [data.logisticsControllers, currentUser.id, currentUser.role]);

    const filteredRfqs = useMemo(() => {
        // Supervisors (Logistics Controllers) and LG Manager see all RFQs for logistics
        // Top Management and ENG-Managers see all (View Only enforced by UI buttons)
        if (isLogisticsController || isLogisticsManager || isTopManagement || isEngManager) {
            return rfqs;
        }
        // Others see RFQs related to PRs they requested
        const userPRIds = new Set(purchaseRequisitions.filter(pr => pr.requesterId === currentUser.id).map(pr => pr.id));
        return rfqs.filter(rfq => userPRIds.has(rfq.prId));
    }, [rfqs, currentUser, purchaseRequisitions, isTopManagement, isEngManager, isLogisticsManager, isLogisticsController]);

    const columns = [
        { header: 'RFQ Number', accessor: 'id' as keyof RFQ },
        { header: 'Parent PR', accessor: 'prId' as keyof RFQ },
        { header: 'Vendor(s)', accessor: (item: RFQ) => getVendorDisplay(item.vendorIds) },
        { header: 'Date', accessor: 'date' as keyof RFQ },
        { header: 'Status', accessor: (item: RFQ) => <Badge color={statusColors[item.status]}>{item.status}</Badge> },
    ];
    
    return (
        <>
            <Card title="Request for Quotations (RFQs)">
                <Table<RFQ>
                    columns={columns}
                    data={filteredRfqs}
                    renderRowActions={(rfq) => {
                        const poExists = purchaseOrders.some(po => po.rfqId === rfq.id);
                        
                        // Enforce Workflow: Must be Quoted to create PO
                        const isReadyForPO = rfq.status === RFQStatus.QuotationReceived;
                        const canCreatePO = isLogisticsController && !poExists && isReadyForPO;
                        
                        return (
                            <div className="flex space-x-2 justify-end">
                                <Button variant="secondary" size="sm" onClick={() => setViewingRFQ(rfq)}>Details</Button>
                                {canCreatePO && (
                                    <Button variant="primary" size="sm" onClick={() => onCreatePO(rfq.id)}>Create PO</Button>
                                )}
                                {poExists && isLogisticsController && (
                                     <Button variant="secondary" size="sm" onClick={() => onCreatePO(rfq.id)}>View PO</Button>
                                )}
                            </div>
                        )
                    }}
                />
            </Card>

            <RFQDetailModal
                rfq={viewingRFQ}
                currentUser={currentUser}
                onClose={() => setViewingRFQ(null)}
                onStatusUpdate={handleStatusUpdate}
                onCreatePO={onCreatePO}
                poExists={purchaseOrders.some(po => po.rfqId === viewingRFQ?.id)}
            />
        </>
    );
};
