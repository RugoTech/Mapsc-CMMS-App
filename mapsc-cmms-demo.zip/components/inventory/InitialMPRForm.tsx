
import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Priority, PRItemType } from '../../types';
import { Alert } from '../ui/Alert';

interface InitialMPRFormProps {
    isOpen: boolean;
    onClose: () => void;
    onProceed: (initialData: {
        description: string;
        itemType: PRItemType;
        specifications: string;
        priority: Priority;
    }) => void;
}

export const InitialMPRForm: React.FC<InitialMPRFormProps> = ({ isOpen, onClose, onProceed }) => {
    const [description, setDescription] = useState('');
    const [itemType, setItemType] = useState<PRItemType | ''>('');
    const [specifications, setSpecifications] = useState('');
    const [priority, setPriority] = useState<Priority>(Priority.Medium);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (isOpen) {
            setDescription('');
            setItemType('');
            setSpecifications('');
            setPriority(Priority.Medium);
            setError(null);
        }
    }, [isOpen]);

    const handleProceed = () => {
        setError(null);
        if (!itemType) {
            setError('Please select a Request Type.');
            return;
        }
        if (!description.trim()) {
            setError('Description cannot be empty.');
            return;
        }
        onProceed({ description, itemType: itemType as PRItemType, specifications, priority });
    };

    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button onClick={handleProceed}>Proceed</Button>
        </>
    );

    const priorityOptions = [
        { value: Priority.High, label: 'Urgent' },
        { value: Priority.Medium, label: 'Routine' },
        { value: Priority.Low, label: 'Low Priority' },
    ];

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title="Create Manual PR (Step 1 of 2)"
            footer={modalFooter}
        >
            <div className="space-y-4">
                {error && <Alert type="error">{error}</Alert>}
                <div>
                    <label htmlFor="itemType" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Request Type</label>
                    <select
                        id="itemType"
                        name="itemType"
                        value={itemType}
                        onChange={(e) => setItemType(e.target.value as PRItemType)}
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                    >
                        <option value="" disabled>Select Type...</option>
                        <option value={PRItemType.Item}>Item</option>
                        <option value={PRItemType.Service}>Service</option>
                    </select>
                </div>

                <div>
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description of Items/Services</label>
                    <textarea 
                        id="description" 
                        value={description} 
                        onChange={e => setDescription(e.target.value)} 
                        rows={3} 
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" 
                        required 
                        maxLength={106}
                    />
                </div>
                
                 <div>
                    <label htmlFor="specifications" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Specifications or Requirements</label>
                    <textarea 
                        id="specifications" 
                        value={specifications} 
                        onChange={e => setSpecifications(e.target.value)} 
                        rows={4} 
                        className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" 
                        maxLength={106}
                    />
                </div>

                <div>
                    <label htmlFor="priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Priority Level</label>
                     <select
                        id="priority"
                        name="priority"
                        value={priority}
                        onChange={(e) => setPriority(e.target.value as Priority)}
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                    >
                        {priorityOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                    </select>
                </div>
            </div>
        </Modal>
    );
};
