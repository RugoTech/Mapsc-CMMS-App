import React, { useState, useEffect, useContext, useRef } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { useZoneAccess } from '../../hooks/useZoneAccess';
import type { View, Asset, WorkOrder, Part, User, Vendor } from '../../types';

interface GlobalSearchProps {
  onViewAsset: (id: string) => void;
  onViewWorkOrder: (id: string) => void;
  onViewVendor: (id: string) => void;
  onNavigate: (view: View) => void;
  currentUser: User | null;
}

interface SearchResults {
    assets: Asset[];
    workOrders: WorkOrder[];
    parts: Part[];
    vendors: Vendor[];
}

export const GlobalSearch: React.FC<GlobalSearchProps> = ({ onViewAsset, onViewWorkOrder, onNavigate, onViewVendor, currentUser }) => {
    const context = useContext(DataContext);
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<SearchResults | null>(null);
    const [isOpen, setIsOpen] = useState(false);
    const searchContainerRef = useRef<HTMLDivElement>(null);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    useEffect(() => {
        const handleOutsideClick = (event: MouseEvent) => {
            if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleOutsideClick);
        return () => {
            document.removeEventListener('mousedown', handleOutsideClick);
        };
    }, []);
    
    useEffect(() => {
        if (!context) return;
        
        if (query.trim().length < 2) {
            setResults(null);
            return;
        }

        const lowerCaseQuery = query.toLowerCase();
        const { assets, workOrders, parts, vendors } = context.data;

        const filteredAssets = assets.filter(asset => 
            (canSeeAllZones || accessibleZoneIds.includes(asset.zoneId)) &&
            (asset.id.toLowerCase().includes(lowerCaseQuery) || asset.name.toLowerCase().includes(lowerCaseQuery))
        ).slice(0, 5);

        const filteredWorkOrders = workOrders.filter(wo => {
            const asset = assets.find(a => a.id === wo.assetId);
            const zoneId = asset ? asset.zoneId : wo.zoneId;
            const hasAccess = canSeeAllZones || (zoneId && accessibleZoneIds.includes(zoneId));

            return hasAccess && (
                wo.id.toLowerCase().includes(lowerCaseQuery) ||
                wo.description.toLowerCase().includes(lowerCaseQuery)
            );
        }).slice(0, 5);
        
        const filteredParts = parts.filter(part =>
            part.id.toLowerCase().includes(lowerCaseQuery) ||
            part.partNumber.toLowerCase().includes(lowerCaseQuery) ||
            part.name.toLowerCase().includes(lowerCaseQuery)
        ).slice(0, 5);
        
        const filteredVendors = vendors.filter(vendor =>
            vendor.id.toLowerCase().includes(lowerCaseQuery) ||
            vendor.name.toLowerCase().includes(lowerCaseQuery)
        ).slice(0, 5);

        setResults({
            assets: filteredAssets,
            workOrders: filteredWorkOrders,
            parts: filteredParts,
            vendors: filteredVendors,
        });
        setIsOpen(true);

    }, [query, context, accessibleZoneIds, canSeeAllZones]);

    const handleSelect = (action: () => void) => {
        action();
        setQuery('');
        setResults(null);
        setIsOpen(false);
    }

    const hasResults = results && (results.assets.length > 0 || results.workOrders.length > 0 || results.parts.length > 0 || results.vendors.length > 0);

    return (
        <div className="relative w-full max-w-lg" ref={searchContainerRef}>
            <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                     <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                    </svg>
                </div>
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onFocus={() => setIsOpen(true)}
                    placeholder="Search assets, WOs, parts, vendors..."
                    className="block w-full bg-gray-100 dark:bg-gray-700 border border-transparent dark:border-gray-600 rounded-md py-2 pl-10 pr-3 text-sm placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:bg-white dark:focus:bg-gray-900 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
            </div>
            {isOpen && query.length > 1 && (
                <div className="absolute z-10 mt-1 w-full bg-white dark:bg-gray-800 shadow-lg rounded-md overflow-hidden border border-gray-200 dark:border-gray-700">
                    {hasResults ? (
                        <ul className="max-h-96 overflow-y-auto">
                            {results.assets.length > 0 && (
                                <>
                                    <li className="px-4 py-2 text-xs font-semibold text-gray-500 bg-gray-50 dark:bg-gray-700/50 uppercase">Assets</li>
                                    {results.assets.map(asset => (
                                        <li key={asset.id} onClick={() => handleSelect(() => onViewAsset(asset.id))} className="px-4 py-2 hover:bg-indigo-500 hover:text-white cursor-pointer text-sm">
                                            {asset.name} <span className="text-gray-400">({asset.id})</span>
                                        </li>
                                    ))}
                                </>
                            )}
                            {results.workOrders.length > 0 && (
                                <>
                                    <li className="px-4 py-2 text-xs font-semibold text-gray-500 bg-gray-50 dark:bg-gray-700/50 uppercase">Work Orders</li>
                                    {results.workOrders.map(wo => (
                                        <li key={wo.id} onClick={() => handleSelect(() => onViewWorkOrder(wo.id))} className="px-4 py-2 hover:bg-indigo-500 hover:text-white cursor-pointer text-sm">
                                            {wo.description} <span className="text-gray-400">({wo.id})</span>
                                        </li>
                                    ))}
                                </>
                            )}
                             {results.parts.length > 0 && (
                                <>
                                    <li className="px-4 py-2 text-xs font-semibold text-gray-500 bg-gray-50 dark:bg-gray-700/50 uppercase">Parts</li>
                                    {results.parts.map(part => (
                                        <li key={part.id} onClick={() => handleSelect(() => onNavigate('Parts Catalog'))} className="px-4 py-2 hover:bg-indigo-500 hover:text-white cursor-pointer text-sm">
                                            {part.name} <span className="text-gray-400">({part.partNumber})</span>
                                        </li>
                                    ))}
                                </>
                            )}
                            {results.vendors.length > 0 && (
                                <>
                                    <li className="px-4 py-2 text-xs font-semibold text-gray-500 bg-gray-50 dark:bg-gray-700/50 uppercase">Vendors</li>
                                    {results.vendors.map(vendor => (
                                        <li key={vendor.id} onClick={() => handleSelect(() => onViewVendor(vendor.id))} className="px-4 py-2 hover:bg-indigo-500 hover:text-white cursor-pointer text-sm">
                                            {vendor.name} <span className="text-gray-400">({vendor.id})</span>
                                        </li>
                                    ))}
                                </>
                            )}
                        </ul>
                    ) : (
                        <div className="px-4 py-4 text-sm text-gray-500 text-center">No results found.</div>
                    )}
                </div>
            )}
        </div>
    );
};