import React from 'react';
import { Button } from '../ui/Button';
import { GlobalSearch } from './GlobalSearch';
import { ThemeToggle } from './ThemeToggle';
import type { View, User } from '../../types';

interface HeaderProps {
  currentView: string;
  toggleSidebar: () => void;
  onGoToLanding: () => void;
  onLogout: () => void;
  onViewAsset: (id: string) => void;
  onViewWorkOrder: (id: string) => void;
  onViewVendor: (id: string) => void;
  onNavigate: (view: View) => void;
  currentUser: User | null;
}

export const Header: React.FC<HeaderProps> = ({ currentView, toggleSidebar, onGoToLanding, onLogout, onViewAsset, onViewWorkOrder, onNavigate, onViewVendor, currentUser }) => {
  return (
    <header className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 border-b dark:border-gray-700 shadow-sm z-10">
      <div className="flex items-center flex-shrink-0 w-1/3">
        <button
          onClick={toggleSidebar}
          className="text-gray-500 dark:text-gray-400 focus:outline-none focus:text-gray-600 dark:focus:text-gray-200 mr-4"
          aria-label="Toggle sidebar"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
          </svg>
        </button>
        <h1 className="text-xl md:text-2xl font-semibold text-gray-800 dark:text-white truncate">{currentView}</h1>
      </div>
      
      <div className="flex-1 flex justify-center px-4 lg:px-8">
        <GlobalSearch 
          onViewAsset={onViewAsset}
          onViewWorkOrder={onViewWorkOrder}
          onNavigate={onNavigate}
          onViewVendor={onViewVendor}
          currentUser={currentUser}
        />
      </div>
      
      <div className="flex items-center justify-end space-x-2 flex-shrink-0 w-1/3">
        <ThemeToggle />
        <Button variant="secondary" size="sm" onClick={onGoToLanding}>Home</Button>
        <Button variant="danger" size="sm" onClick={onLogout}>Logout</Button>
      </div>
    </header>
  );
};