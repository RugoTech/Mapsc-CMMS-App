
import React, { useState, useEffect, useContext, useMemo } from 'react';
import type { View, User } from '../../types';
import { DataContext } from '../../contexts/DataContext';
import { UserProfileModal } from '../user/UserProfileModal';
import { useUserPermissions } from '../../hooks/useUserPermissions';

interface NavItemData {
  view?: View;
  label: string;
  icon: React.ReactElement<any>;
  children?: Omit<NavItemData, 'children' | 'icon'>[];
}

const navItems: NavItemData[] = [
    { view: 'Dashboard', label: 'Dashboard', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg> },
    {
        label: 'Asset Management',
        icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" /></svg>,
        children: [
            { view: 'Assets', label: 'Asset Register' },
            { view: 'Asset Location', label: 'Asset Location' },
            { view: 'Asset Meters', label: 'Asset Meters' },
            { view: 'Asset Documentation', label: 'Asset Documentation' },
            { view: 'Asset History', label: 'Asset History' },
        ]
    },
    {
        label: 'Maintenance Management',
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 16v-2m8-8h2M4 12H2m15.364 6.364l-1.414-1.414M6.05 19.95l1.414-1.414M19.95 6.05l-1.414 1.414M6.05 6.05l1.414 1.414M12 18a6 6 0 100-12 6 6 0 000 12z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14a2 2 0 100-4 2 2 0 000 4z" /></svg>,
        children: [
            { view: 'Work Requests', label: 'Work Requests' },
            { view: 'Work Orders', label: 'Work Orders' },
            { view: 'Labor Allocation', label: 'Labor Allocation' },
            { view: 'Procedures', label: 'Procedures' },
            { view: 'Preventive Maintenance', label: 'Preventive Maintenance Scheduling' },
        ]
    },
    { view: 'Projects', label: 'Projects', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg> },
    {
        label: 'Inventory Management',
        icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg>,
        children: [
            { view: 'Warehousing', label: 'Warehousing' },
            { view: 'Parts Catalog', label: 'Parts Catalog' },
            { view: 'Inventory Transactions', label: 'Inventory Transactions' },
            { view: 'Purchase Requisitions', label: 'Purchase Requisitions (PR)' },
            { view: 'RFQs', label: 'RFQs' },
            { view: 'Purchase Orders', label: 'Purchase Orders (PO)' },
            { view: 'Invoice Reconciliation', label: 'Invoice Reconciliation' },
            { view: 'Vendors', label: 'Vendors' },
            { view: 'Inventory Alerts', label: 'Inventory Alerts' },
            { view: 'Cycle Counting', label: 'Physical Inventory/Cycle Counting' },
        ]
    },
    { view: 'Personnel Management', label: 'Personnel Management', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg> },
    { view: 'Reporting & Analytics', label: 'Reporting & Analytics', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg> },
    { view: 'Messages', label: 'Messages', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg> },
    { view: 'Admin & Settings', label: 'Admin & Settings', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924-1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0 3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.096 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> }
];

interface SidebarProps {
  currentView: View;
  setCurrentView: (view: View) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  currentUser: User | null;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, isOpen, setIsOpen, currentUser }) => {
    const context = useContext(DataContext);
    const [isUserModalOpen, setIsUserModalOpen] = useState(false);
    const permissions = useUserPermissions(currentUser);

    const unreadMessagesCount = useMemo(() => {
        if (!context || !currentUser) return 0;
        return context.data.messages.filter(m => m.recipientId === currentUser.id && !m.read).length;
    }, [context?.data.messages, currentUser]);

    const filteredNavItems = useMemo(() => {
        if (!currentUser) return []; // Should not happen when sidebar is visible

        return navItems.map(item => {
            // If the item is a parent with children
            if (item.children) {
                // Filter its children based on permissions
                const accessibleChildren = item.children.filter(child => child.view && permissions.includes(child.view));
                
                // If there are any accessible children, show the parent with its filtered children
                if (accessibleChildren.length > 0) {
                    return { ...item, children: accessibleChildren };
                }
                // Otherwise, don't show the parent at all
                return null;
            }

            // If the item is a direct link, check if it's in permissions
            if (item.view && permissions.includes(item.view)) {
                return item;
            }
            
            // If no access, filter it out
            return null;
        }).filter((item): item is NavItemData => item !== null);
    }, [permissions, currentUser]);
    
    const handleSaveProfile = (updatedUser: User) => {
        if (!context) return;
        context.setData(prevData => ({
            ...prevData,
            users: prevData.users.map(u => u.id === updatedUser.id ? updatedUser : u)
        }));
    };
    
    const getInitialOpenMenus = () => {
        const parent = navItems.find(item => item.children?.some(child => child.view === currentView));
        return parent ? [parent.label] : [];
    };

    const [openMenus, setOpenMenus] = useState<string[]>(getInitialOpenMenus);
    
    useEffect(() => {
        const parent = navItems.find(item => item.children?.some(child => child.view === currentView));
        if (parent && !openMenus.includes(parent.label)) {
            setOpenMenus([parent.label]);
        }
    }, [currentView]);


    const toggleMenu = (label: string) => {
        setOpenMenus(prevOpenMenus => {
            if (prevOpenMenus.includes(label)) {
                return [];
            }
            return [label];
        });
    };

    const isParentActive = (item: NavItemData) => {
        return item.children?.some(child => child.view === currentView);
    };
    
    const getInitials = (name: string) => {
      const names = name.split(' ');
      if (names.length > 1) {
        return `${names[0][0]}${names[1][0]}`;
      }
      return names[0][0];
    }

  return (
    <>
      {/* Overlay for mobile */}
      <div
        className={`fixed inset-0 z-20 bg-black bg-opacity-50 transition-opacity md:hidden ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsOpen(false)}
      ></div>

      <aside
        className={`fixed inset-y-0 left-0 z-30 w-64 bg-white dark:bg-gray-800 border-r dark:border-gray-700 p-4 flex flex-col transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between mb-8">
            <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                <span className="ml-2 text-xl font-bold text-gray-800 dark:text-white">Mapsc CMMS</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="md:hidden text-gray-500 hover:text-gray-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        <nav className="flex-1 space-y-2 overflow-y-auto">
          {filteredNavItems.map(item => (
              <div key={item.label}>
                {item.children ? (
                    <>
                        <button
                            onClick={() => toggleMenu(item.label)}
                            className={`w-full flex items-center justify-between px-4 py-2.5 text-sm font-medium text-left transition-colors duration-200 rounded-lg ${
                                isParentActive(item)
                                ? 'text-gray-900 dark:text-white bg-gray-200 dark:bg-gray-700'
                                : 'text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white hover:bg-gray-200 dark:hover:bg-gray-700'
                            }`}
                        >
                            <div className="flex items-center">
                                {React.cloneElement(item.icon, { className: 'h-6 w-6 mr-3' })}
                                <span>{item.label}</span>
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 transform transition-transform ${openMenus.includes(item.label) ? 'rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                        {openMenus.includes(item.label) && (
                            <div className="pl-8 pt-2 space-y-2">
                                {item.children.map(child => (
                                    <a
                                        key={child.view}
                                        href="#"
                                        onClick={(e) => { e.preventDefault(); setCurrentView(child.view!); }}
                                        className={`block px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
                                            currentView === child.view
                                            ? 'bg-indigo-600 text-white'
                                            : 'text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white hover:bg-gray-200 dark:hover:bg-gray-700'
                                        }`}
                                    >
                                        {child.label}
                                    </a>
                                ))}
                            </div>
                        )}
                    </>
                ) : (
                    <a
                        href="#"
                        onClick={(e) => { e.preventDefault(); setCurrentView(item.view!); }}
                        className={`flex items-center justify-between px-4 py-2.5 text-sm font-medium transition-colors duration-200 rounded-lg ${
                            currentView === item.view
                            ? 'bg-indigo-600 text-white'
                            : 'text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white hover:bg-gray-200 dark:hover:bg-gray-700'
                        }`}
                    >
                        <div className="flex items-center">
                            {React.cloneElement(item.icon, { className: 'h-6 w-6 mr-3' })}
                            {item.label}
                        </div>
                        {item.view === 'Messages' && unreadMessagesCount > 0 && (
                            <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                                {unreadMessagesCount}
                            </span>
                        )}
                    </a>
                )}
              </div>
          ))}
        </nav>
        
        {/* User Profile Section */}
        <div className="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700">
            {currentUser && (
                <div className="flex items-center p-2 rounded-lg">
                    {currentUser.profilePictureUrl ? (
                        <img src={currentUser.profilePictureUrl} alt={currentUser.name} className="w-10 h-10 rounded-full object-cover mr-3" />
                    ) : (
                        <div className="w-10 h-10 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold mr-3">
                            {getInitials(currentUser.name)}
                        </div>
                    )}
                    <div className="flex-1">
                        <p className="font-semibold text-sm text-gray-800 dark:text-white truncate">{currentUser.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{currentUser.role}</p>
                    </div>
                    <button 
                        onClick={() => setIsUserModalOpen(true)} 
                        className="ml-2 p-1 text-gray-400 hover:text-gray-600 dark:hover:text-white rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        aria-label="User settings"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924-1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0 3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.096 2.572-1.065z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    </button>
                </div>
            )}
        </div>
      </aside>
      
      {currentUser && (
        <UserProfileModal 
            isOpen={isUserModalOpen}
            onClose={() => setIsUserModalOpen(false)}
            user={currentUser}
            onSave={handleSaveProfile}
        />
      )}
    </>
  );
};
