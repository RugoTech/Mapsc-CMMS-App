
import React, { useState, useEffect, useRef } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import type { User } from '../../types';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onSave: (updatedUser: User) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose, user, onSave }) => {
  const [profilePictureUrl, setProfilePictureUrl] = useState(user.profilePictureUrl);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
        setProfilePictureUrl(user.profilePictureUrl);
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
    }
  }, [user, isOpen]);

  const handlePictureChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const tempUrl = URL.createObjectURL(file);
      setProfilePictureUrl(tempUrl);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Password Change Logic
    if (newPassword || confirmPassword) {
        if (!currentPassword) {
            alert("Please enter your current password to change it.");
            return;
        }
        if (newPassword !== confirmPassword) {
            alert("New passwords do not match.");
            return;
        }
        
        // Password Policy Validation:
        // Min 8, Max 12
        // At least 1 Uppercase, 1 Number, 1 Symbol
        const passwordRegex = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,12})/;
        
        if (newPassword.length < 8 || newPassword.length > 12) {
            alert("Password must be between 8 and 12 characters.");
            return;
        }

        if (!passwordRegex.test(newPassword)) {
            alert("Password must contain at least one uppercase letter, one number, and one symbol (!@#$%^&*).");
            return;
        }

        // In a real application, you would verify the current password and send the new one to the backend here.
        alert("Password updated successfully.");
    }

    onSave({ ...user, profilePictureUrl });
    onClose();
  };
  
  const getInitials = (name: string) => {
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[1][0]}`;
    }
    return name[0] || '';
  }

  const modalFooter = (
    <>
      <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
      <Button type="submit" form="user-profile-form">Save Changes</Button>
    </>
  );

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="My Profile" footer={modalFooter}>
      <form onSubmit={handleSave} id="user-profile-form" className="space-y-6">
        
        <div className="flex flex-col items-center space-y-4">
          {profilePictureUrl ? (
            <img src={profilePictureUrl} alt={user.name} className="w-24 h-24 rounded-full object-cover" />
          ) : (
            <div className="w-24 h-24 rounded-full bg-indigo-500 text-white flex items-center justify-center text-3xl font-bold">
              {getInitials(user.name)}
            </div>
          )}
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handlePictureChange}
            className="hidden" 
            accept="image/*"
          />
          <Button type="button" variant="secondary" onClick={() => fileInputRef.current?.click()}>
            Change Picture
          </Button>
        </div>

        <div>
          <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Profile Information</h4>
          <div className="space-y-4">
            <Input 
              id="userName" 
              label="Full Name" 
              type="text" 
              defaultValue={user.name}
              disabled
            />
            <Input 
              id="userRole" 
              label="Role" 
              type="text" 
              defaultValue={user.role}
              disabled 
            />
            <Input 
              id="userDepartment" 
              label="Department" 
              type="text" 
              defaultValue={user.department}
              disabled 
            />
            <Input 
              id="userWorkCenter" 
              label="Work Center" 
              type="text" 
              defaultValue={user.workCenter}
              disabled
            />
          </div>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
            <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Change Password</h4>
            <p className="text-xs text-gray-500 mb-4">Requirement: 8-12 chars, 1 Uppercase, 1 Number, 1 Symbol</p>
            <div className="space-y-4">
                 <Input 
                    id="currentPassword" 
                    label="Current Password" 
                    type="password" 
                    placeholder="Enter your current password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                />
                <Input 
                    id="newPassword" 
                    label="New Password" 
                    type="password" 
                    placeholder="Enter a new password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                />
                <Input 
                    id="confirmPassword" 
                    label="Confirm New Password" 
                    type="password" 
                    placeholder="Confirm your new password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                />
            </div>
        </div>
      </form>
    </Modal>
  );
};
