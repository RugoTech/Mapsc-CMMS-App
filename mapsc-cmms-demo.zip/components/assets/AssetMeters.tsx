
import React, { useContext, useState } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import type { Meter, User, AuditLogEntry } from '../../types';
import { MeterType } from '../../types';
import { AddMeterForm } from './AddMeterForm';
import { MeterLogModal } from './MeterLogModal';
import { ConfirmationModal } from '../ui/ConfirmationModal';

interface AssetMetersProps {
  assetId: string;
  currentUser: User | null;
}

export const AssetMeters: React.FC<AssetMetersProps> = ({ assetId, currentUser }) => {
  const context = useContext(DataContext);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedMeter, setSelectedMeter] = useState<Meter | null>(null);
  const [meterToToggle, setMeterToToggle] = useState<Meter | null>(null);
  const [toggleWarning, setToggleWarning] = useState<React.ReactNode | null>(null);

  if (!context) return <div>Loading...</div>;

  const { data, setData } = context;
  const meters = data.meters.filter(m => m.assetId === assetId);

  const handleSaveMeter = (meterData: Partial<Meter>) => {
    setData(prevData => {
      let updatedMeters;
      let updatedAssets;

      if (meterData.id && !meterData.name) {
          // LINK EXISTING METER
          // 1. Find the meter and update its assetId
          updatedMeters = prevData.meters.map(m => 
              m.id === meterData.id ? { ...m, assetId: assetId } : m
          );
          // 2. Find the asset and update its meterId
          updatedAssets = prevData.assets.map(a => 
              a.id === assetId ? { ...a, meterId: meterData.id! } : a
          );
      } else {
          // CREATE NEW METER (Legacy/Fallback support, though UI now restricts this in Asset Context)
          const newMeterId = `MTR-${String(prevData.meters.length + 1).padStart(3, '0')}`;
          const newMeter: Meter = {
            id: newMeterId,
            lastReadingDate: new Date().toISOString().split('T')[0],
            createdBy: currentUser!.id,
            name: meterData.name!,
            type: meterData.type!,
            lastReading: meterData.lastReading!,
            unitOfMeasure: meterData.unitOfMeasure!,
            assetId: assetId, // Assign to this asset
            isActive: true,
            maxReadingLimit: meterData.maxReadingLimit,
          };

          updatedMeters = [...prevData.meters, newMeter];
          
          updatedAssets = prevData.assets.map(asset => {
            if (asset.id === assetId) {
              return { ...asset, meterId: newMeterId };
            }
            return asset;
          });
      }

      return {
        ...prevData,
        assets: updatedAssets,
        meters: updatedMeters,
      };
    });
    setIsAddModalOpen(false);
  };

  const handleViewLog = (meter: Meter) => {
    setSelectedMeter(meter);
  };

  const handleCloseLog = () => {
    setSelectedMeter(null);
  };

  const handleToggleClick = (meter: Meter) => {
      const isActive = meter.isActive ?? true;
      
      if (isActive) {
          const linkedPMs = data.preventiveMaintenances.filter(
              pm => pm.triggerType === 'Meter' && pm.meterId === meter.id
          );
          
          if (linkedPMs.length > 0) {
              setToggleWarning(
                  <div>
                      <p className="mb-2 font-semibold text-red-600">Warning: This meter is linked to the following active PM plans:</p>
                      <ul className="list-disc pl-5 mb-4 text-sm">
                          {linkedPMs.map(pm => (
                              <li key={pm.id}>{pm.name} ({pm.id})</li>
                          ))}
                      </ul>
                      <p>Deactivating this meter will prevent these plans from generating future work orders based on usage.</p>
                  </div>
              );
          } else {
              setToggleWarning(null);
          }
      } else {
          setToggleWarning(null);
      }
      setMeterToToggle(meter);
  };

  const confirmToggleStatus = () => {
      if (!meterToToggle) return;
      
      setData(prevData => {
          const updatedMeters = prevData.meters.map(m => 
              m.id === meterToToggle.id ? { ...m, isActive: !(m.isActive ?? true) } : m
          );
          
          const action = (meterToToggle.isActive ?? true) ? 'DEACTIVATE' : 'ACTIVATE';
          const logEntry: AuditLogEntry = {
            id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
            timestamp: new Date().toISOString(),
            userId: currentUser!.id,
            action: 'UPDATE',
            entityType: 'Meter',
            entityId: meterToToggle.id,
            details: `${action === 'ACTIVATE' ? 'Activated' : 'Deactivated'} meter '${meterToToggle.name}'.`,
            status: 'Success'
          };

          return {
              ...prevData,
              meters: updatedMeters,
              auditLog: [logEntry, ...prevData.auditLog]
          };
      });
      setMeterToToggle(null);
      setToggleWarning(null);
  };

  const columns = [
    { header: 'Name', accessor: 'name' as keyof Meter },
    { 
      header: 'Type',
      accessor: (item: Meter) => (
        <Badge color={item.type === MeterType.Automatic ? 'blue' : 'gray'}>{item.type}</Badge>
      )
    },
    { header: 'Last Reading', accessor: 'lastReading' as keyof Meter },
    { header: 'Unit', accessor: 'unitOfMeasure' as keyof Meter },
    { header: 'Date Read', accessor: 'lastReadingDate' as keyof Meter },
    { 
        header: 'Status', 
        accessor: (item: Meter) => (
            <Badge color={item.isActive ?? true ? 'green' : 'red'}>
                {item.isActive ?? true ? 'Active' : 'Inactive'}
            </Badge>
        )
    },
  ];

  return (
    <>
      <Card title="Asset Meters" actions={currentUser?.role === 'Planner' && <Button onClick={() => setIsAddModalOpen(true)}>Link Meter</Button>}>
          {meters.length > 0 ? (
               <Table<Meter>
                  columns={columns}
                  data={meters}
                  renderRowActions={(meter) => (
                      <div className="space-x-2">
                          <Button variant="secondary" size="sm" onClick={() => handleViewLog(meter)}>
                              View Log
                          </Button>
                          {(currentUser?.role === 'Planner' || currentUser?.role === 'Administrator') && (
                                <Button 
                                    variant={(meter.isActive ?? true) ? 'danger' : 'secondary'} 
                                    size="sm" 
                                    onClick={() => handleToggleClick(meter)}
                                >
                                    {(meter.isActive ?? true) ? 'Deactivate' : 'Activate'}
                                </Button>
                            )}
                      </div>
                  )}
              />
          ) : (
              <p className="text-gray-500 dark:text-gray-400">No meters have been added to this asset.</p>
          )}
      </Card>
      <AddMeterForm
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSave={handleSaveMeter}
        assetId={assetId}
        currentUser={currentUser}
      />
      {selectedMeter && (
          <MeterLogModal 
            isOpen={!!selectedMeter}
            onClose={handleCloseLog}
            meter={selectedMeter}
            currentUser={currentUser}
          />
      )}
      {meterToToggle && (
            <ConfirmationModal
                isOpen={!!meterToToggle}
                onClose={() => { setMeterToToggle(null); setToggleWarning(null); }}
                onConfirm={confirmToggleStatus}
                title={`Confirm Meter ${(meterToToggle.isActive ?? true) ? 'Deactivation' : 'Activation'}`}
                confirmText={(meterToToggle.isActive ?? true) ? 'Deactivate' : 'Activate'}
                confirmButtonVariant={(meterToToggle.isActive ?? true) ? 'danger' : 'primary'}
            >
                {toggleWarning ? toggleWarning : (
                    <p>Are you sure you want to {(meterToToggle.isActive ?? true) ? 'deactivate' : 'activate'} the meter <span className="font-bold">{meterToToggle.name}</span>?</p>
                )}
            </ConfirmationModal>
        )}
    </>
  );
};