
import React, { useState, useEffect, useContext, useCallback } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { Document, User } from '../../types';

interface AddDocumentFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (document: Omit<Document, 'id' | 'url'> & { file?: File }) => void;
  assetId?: string;
  currentUser: User | null;
}

type FormState = Omit<Document, 'id' | 'url'>;

export const AddDocumentForm: React.FC<AddDocumentFormProps> = ({ isOpen, onClose, onSave, assetId, currentUser }) => {
    const context = useContext(DataContext);
    const [formData, setFormData] = useState<FormState | null>(null);
    const [file, setFile] = useState<File | undefined>(undefined);
    
    const getInitialState = useCallback((): FormState => {
        return {
            name: '',
            type: '' as any, // Forces user to select
            assetId: assetId || '', // Forces user to select if not provided
            dateCreated: new Date().toISOString().split('T')[0],
            createdBy: currentUser?.id || '',
            vendorId: '',
        };
    }, [assetId, currentUser]);

    useEffect(() => {
        if (isOpen) {
            setFormData(getInitialState());
            setFile(undefined);
        }
    }, [isOpen, getInitialState]);

    if (!context || !formData) return null;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => (prev ? { ...prev, [name]: value } : null));
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!file) {
            alert('Please select a file to upload.');
            return;
        }
        if (!formData.type) {
            alert('Please select a Document Type.');
            return;
        }
        if (!formData.assetId) {
            alert('Please select an Asset.');
            return;
        }
        if (formData) {
            onSave({ ...formData, file });
        }
    };
    
    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="add-document-form">Save Document</Button>
        </>
    );
    
    const selectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md";

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Add New Document" footer={modalFooter}>
            <form id="add-document-form" onSubmit={handleSubmit} className="space-y-4">
                 {!assetId && (
                     <div>
                        <label htmlFor="assetId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Asset</label>
                        <select id="assetId" name="assetId" value={formData.assetId} onChange={handleChange} required className={selectClasses}>
                            <option value="" disabled>Select an asset...</option>
                            {context.data.assets.map(asset => (
                                <option key={asset.id} value={asset.id}>{asset.name} ({asset.id})</option>
                            ))}
                        </select>
                    </div>
                )}
                <Input id="name" name="name" label="Document Name" value={formData.name} onChange={handleChange} required />
                <div>
                    <label htmlFor="type" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Document Type</label>
                    <select id="type" name="type" value={formData.type} onChange={handleChange} className={selectClasses} required>
                        <option value="" disabled>Select Document Type...</option>
                        <option>Work Instruction</option>
                        <option>SOP</option>
                        <option>Schematic</option>
                        <option>PI Drawing</option>
                        <option>Safety Instruction</option>
                        <option>MSDS</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="file" className="block text-sm font-medium text-gray-700 dark:text-gray-300">File</label>
                    <input id="file" name="file" type="file" onChange={handleFileChange} required className="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-900/50 file:text-indigo-700 dark:file:text-indigo-300 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-900" />
                </div>
                <div className="grid grid-cols-2 gap-4 border-t pt-4">
                    <Input label="Created By" value={context.data.users.find(u => u.id === formData.createdBy)?.name || ''} disabled />
                    <Input label="Date Created" type="date" value={formData.dateCreated} disabled />
                </div>
            </form>
        </Modal>
    );
};