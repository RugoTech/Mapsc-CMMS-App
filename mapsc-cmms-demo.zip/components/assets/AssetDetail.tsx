
import React, { useState, useContext, useMemo, useCallback, useEffect } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { AssetMeters } from './AssetMeters';
import { AssetDocumentation } from './AssetDocumentation';
import { AssetHistory } from './AssetHistory';
import { AssetBom } from './AssetBom';
import { Badge } from '../ui/Badge';
import type { Asset, PreventiveMaintenance, SOP, WorkInstruction, SafetyInstruction, PMFrequency, User, AuditLogEntry } from '../../types';
import { AssetStatus } from '../../types';
import { AddAssetForm } from './AddAssetForm';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useAssetHealthScore, HealthLevel } from '../../hooks/useAssetHealthScore';
import { useCurrencyFormatter } from '../../hooks/useCurrency';

interface AssetDetailProps {
  assetId: string;
  onBack: () => void;
  currentUser: User | null;
}

const statusColors: Record<AssetStatus, 'green' | 'yellow' | 'gray'> = {
    [AssetStatus.Operational]: 'green',
    [AssetStatus.UnderMaintenance]: 'yellow',
    [AssetStatus.Decommissioned]: 'gray',
};

type Tab = 'Details' | 'Meters' | 'Documentation' | 'BOM' | 'History';

const CreatePMForm: React.FC<{ 
    isOpen: boolean;
    onClose: () => void;
    onSave: (pm: PreventiveMaintenance) => void;
    asset: Asset;
    currentUser: User | null;
}> = ({ isOpen, onClose, onSave, asset, currentUser }) => {
    const context = useContext(DataContext);
    const allProcedures = useMemo(() => {
        if (!context) return [];
        const { safetyInstructions, workInstructions, sops } = context.data;
        return [...safetyInstructions, ...workInstructions, ...sops];
    }, [context]);
    
    const getInitialState = useCallback((): Omit<PreventiveMaintenance, 'id'> => ({
        name: '', 
        assetId: asset.id, 
        procedureIds: [], 
        duration: 0,
        createdDate: new Date().toISOString().split('T')[0],
        createdBy: currentUser?.id || '',
        triggerType: 'Calendar',
        frequency: undefined,
        nextDueDate: '',
        meterId: '',
        meterTriggerValue: 0,
        lastTriggerReading: 0,
    }), [context, allProcedures, asset, currentUser]);

    const [formData, setFormData] = useState(getInitialState());

    useEffect(() => {
        if(isOpen) {
            setFormData(getInitialState());
        }
    }, [isOpen, getInitialState]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        let processedValue: string | number | 'Calendar' | 'Meter' | PMFrequency | undefined = value;
        if (type === 'number') {
            processedValue = Number(value);
        }
        if (value === '') {
             processedValue = undefined;
        }
        setFormData(prev => ({...prev, [name]: processedValue}));
    };
    
    const handleProcedureToggle = (procedureId: string) => {
        setFormData(prev => {
            const currentIds = prev.procedureIds || [];
            if (currentIds.includes(procedureId)) {
                return { ...prev, procedureIds: currentIds.filter(id => id !== procedureId) };
            } else {
                return { ...prev, procedureIds: [...currentIds, procedureId] };
            }
        });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.procedureIds || formData.procedureIds.length === 0) {
            alert('Please select at least one procedure.');
            return;
        }
        if (formData.triggerType === 'Calendar' && !formData.frequency) {
            alert('Please select a frequency.');
            return;
        }
        onSave(formData as PreventiveMaintenance);
    };
    
    if (!context) return null;
    const assetMeters = context.data.meters.filter(m => m.assetId === formData.assetId);

    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="pm-form">Save</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`Create PM Schedule for ${asset.name}`} footer={modalFooter}>
            <form id="pm-form" onSubmit={handleSubmit} className="space-y-4">
                <Input label="PM Name" name="name" value={formData.name} onChange={handleChange} required />
                <Input label="Duration (Hrs)" name="duration" type="number" step="0.01" min="0" value={formData.duration} onChange={handleChange} required />
                <Input label="Asset" value={`${asset.name} (${asset.id})`} disabled />
                
                <div>
                    <label className="block text-sm font-medium mb-2">Procedures</label>
                    <div className="border border-gray-300 dark:border-gray-600 rounded-md p-2 h-40 overflow-y-auto bg-white dark:bg-gray-700">
                        {allProcedures.map(p => (
                            <div key={p.id} className="flex items-start mb-2">
                                <input 
                                    type="checkbox" 
                                    id={`proc-${p.id}`} 
                                    checked={formData.procedureIds?.includes(p.id)} 
                                    onChange={() => handleProcedureToggle(p.id)}
                                    className="mt-1 h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                />
                                <label htmlFor={`proc-${p.id}`} className="ml-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer select-none">
                                    <span className="font-semibold">{p.id}</span> - {p.description}
                                </label>
                            </div>
                        ))}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Select one or more procedures.</p>
                </div>
                
                <div className="border-t pt-4">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Trigger Type</label>
                    <div className="flex items-center space-x-4 mt-2">
                        <label className="flex items-center">
                            <input type="radio" name="triggerType" value="Calendar" checked={formData.triggerType === 'Calendar'} onChange={handleChange} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300" />
                            <span className="ml-2 text-sm">Calendar</span>
                        </label>
                        <label className="flex items-center">
                            <input type="radio" name="triggerType" value="Meter" checked={formData.triggerType === 'Meter'} onChange={handleChange} className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300" />
                            <span className="ml-2 text-sm">Meter</span>
                        </label>
                    </div>
                </div>

                {formData.triggerType === 'Calendar' && (
                    <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                        <div>
                            <label htmlFor="frequency" className="block text-sm font-medium">Frequency</label>
                            <select name="frequency" value={formData.frequency || ''} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                <option value="" disabled>Select Frequency...</option>
                                <option value="Weekly">Weekly</option>
                                <option value="Bi-Weekly">Bi-Weekly</option>
                                <option value="Monthly">Monthly</option>
                                <option value="6-Monthly">6-Monthly</option>
                                <option value="Annually">Annually</option>
                            </select>
                        </div>
                        <Input label="Next Due Date" name="nextDueDate" type="date" value={formData.nextDueDate || ''} onChange={handleChange} required />
                    </div>
                )}
                
                {formData.triggerType === 'Meter' && (
                    <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                        <div>
                            <label htmlFor="meterId" className="block text-sm font-medium">Meter</label>
                            <select name="meterId" value={formData.meterId || ''} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" disabled={assetMeters.length === 0}>
                                <option value="">Select a meter...</option>
                                {assetMeters.map(m => <option key={m.id} value={m.id}>{m.name} ({m.unitOfMeasure})</option>)}
                            </select>
                            {assetMeters.length === 0 && <p className="text-xs text-red-500 mt-1">No meters found for the selected asset.</p>}
                        </div>
                        <Input label="Trigger Interval" name="meterTriggerValue" type="number" min="1" value={formData.meterTriggerValue || ''} onChange={handleChange} required />
                        <Input label="Last Triggered Reading" name="lastTriggerReading" type="number" min="0" value={formData.lastTriggerReading || '0'} onChange={handleChange} helperText="The meter reading when the last PM was done. Set to 0 for the first time."/>
                    </div>
                )}
            </form>
        </Modal>
    );
};


export const AssetDetail: React.FC<AssetDetailProps> = ({ assetId, onBack, currentUser }) => {
  const [activeTab, setActiveTab] = useState<Tab>('Details');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPMFormOpen, setIsPMFormOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const context = useContext(DataContext);
  const { score, level, factors } = useAssetHealthScore(assetId);
  // Use formatter directly to preserve input as default currency
  const formatCurrency = useCurrencyFormatter();

  const healthLevelColors: Record<HealthLevel, 'green' | 'blue' | 'yellow' | 'red'> = {
      Excellent: 'green',
      Good: 'blue',
      Fair: 'yellow',
      Poor: 'red',
  };

  if (!context || !currentUser) return <div>Loading...</div>;

  const { data, setData } = context;
  const asset = context.data.assets.find(a => a.id === assetId);

  const isManagerOrTopManagement = useMemo(() => {
    if (!currentUser) return false;
    if (currentUser.role === 'Manager' || currentUser.role === 'Factory Manager') return true;
    return data.topManagementGroups.some(g => g.userIds.includes(currentUser.id));
  }, [currentUser, data.topManagementGroups]);

  const canEditAsset = currentUser?.role === 'Engineer' && !isManagerOrTopManagement;
  const canCreatePM = currentUser?.role === 'Planner' && !isManagerOrTopManagement;

  const handleSaveAsset = (updatedAsset: Asset) => {
      const logEntry: AuditLogEntry = {
        id: `LOG-${String(data.auditLog.length + 1).padStart(3, '0')}`,
        timestamp: new Date().toISOString(),
        userId: currentUser!.id,
        action: 'UPDATE',
        entityType: 'Asset',
        entityId: updatedAsset.id,
        details: `Updated details for asset '${updatedAsset.name}' (${updatedAsset.id}).`,
        status: 'Success'
      };
      setData(prevData => ({
          ...prevData,
          assets: prevData.assets.map(a => a.id === updatedAsset.id ? updatedAsset : a),
          auditLog: [logEntry, ...prevData.auditLog]
      }));
      setIsEditModalOpen(false);
  };

  const handleSavePM = (pm: PreventiveMaintenance) => {
      setData(prevData => {
        const newPM = {
          ...pm,
          id: `PM-${String(prevData.preventiveMaintenances.length + 1).padStart(3, '0')}`,
        };
        return {
          ...prevData,
          preventiveMaintenances: [...prevData.preventiveMaintenances, newPM],
        };
      });
      alert(`PM Schedule "${pm.name}" created successfully for asset ${asset?.name}!`);
      setIsPMFormOpen(false);
    };

  const handleConfirmDelete = () => {
    // Safeguard: check for associated records before deleting
    const hasWorkOrders = data.workOrders.some(wo => wo.assetId === assetId);
    const hasPMs = data.preventiveMaintenances.some(pm => pm.assetId === assetId);
    const hasMeters = data.meters.some(m => m.assetId === assetId);
    const hasDocuments = data.documents.some(d => d.assetId === assetId);

    if (hasWorkOrders || hasPMs || hasMeters || hasDocuments) {
        const reasons: string[] = [];
        if (hasWorkOrders) reasons.push("Work Orders/History");
        if (hasPMs) reasons.push("PM Schedules");
        if (hasMeters) reasons.push("Linked Meters");
        if (hasDocuments) reasons.push("Documentation");

        alert(`Cannot delete this asset because it has associated details: ${reasons.join(', ')}. Please remove these associations or decommission the asset instead.`);
        setIsDeleteConfirmOpen(false);
        return;
    }

    const logEntry: AuditLogEntry = {
        id: `LOG-${String(data.auditLog.length + 1).padStart(3, '0')}`,
        timestamp: new Date().toISOString(),
        userId: currentUser!.id,
        action: 'DELETE',
        entityType: 'Asset',
        entityId: assetId,
        details: `Deleted asset '${asset?.name}' (${assetId}).`,
        status: 'Success'
      };
    setData(prevData => ({
        ...prevData,
        assets: prevData.assets.filter(a => a.id !== assetId),
        auditLog: [logEntry, ...prevData.auditLog]
    }));
    alert(`Asset ${assetId} has been deleted.`);
    onBack();
  };

  if (!asset) {
    return (
      <div>
        <p>Asset not found.</p>
        <Button onClick={onBack}>Back to List</Button>
      </div>
    );
  }

  const plant = context.data.plants.find(p => p.id === asset.plantId);
  const zone = context.data.zones.find(z => z.id === asset.zoneId);
  const area = context.data.areas.find(a => a.id === asset.areaId);

  // Determine dynamic meter reading display
  const linkedMeters = data.meters.filter(m => m.assetId === assetId);
  const primaryMeter = linkedMeters.length > 0 ? linkedMeters[0] : null;
  const currentMeterReadingDisplay = primaryMeter 
    ? `${primaryMeter.lastReading.toLocaleString()} ${primaryMeter.unitOfMeasure}`
    : asset.meterReading.toLocaleString();

  const renderTabContent = () => {
    switch (activeTab) {
        case 'Meters':
            return <AssetMeters assetId={asset.id} currentUser={currentUser} />;
        case 'Documentation':
            return <AssetDocumentation assetId={asset.id} currentUser={currentUser} />;
        case 'BOM':
            return <AssetBom assetId={asset.id} currentUser={currentUser} />;
        case 'History':
            return <AssetHistory assetId={asset.id} />;
        case 'Details':
        default:
            return (
                <div className="space-y-6">
                    <Card title="Asset Properties">
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                            <div><strong className="block text-gray-500">Type</strong> {asset.type}</div>
                            <div><strong className="block text-gray-500">Manufacturer</strong> {asset.manufacturer}</div>
                            <div><strong className="block text-gray-500">Model</strong> {asset.model}</div>
                            <div><strong className="block text-gray-500">Serial Number</strong> {asset.serialNumber}</div>
                            <div><strong className="block text-gray-500">Plant</strong> {plant?.name || 'N/A'}</div>
                            <div><strong className="block text-gray-500">Zone</strong> {zone?.name || 'N/A'}</div>
                            <div><strong className="block text-gray-500">Area</strong> {area?.name || 'N/A'}</div>
                            <div><strong className="block text-gray-500">Purchase Date</strong> {asset.purchaseDate}</div>
                            <div><strong className="block text-gray-500">Cost</strong> {formatCurrency(asset.cost)}</div>
                            <div><strong className="block text-gray-500">Current Meter</strong> {currentMeterReadingDisplay}</div>
                            <div>
                                <strong className="block text-gray-500">Warranty</strong> 
                                {asset.underWarranty ? `Yes, until ${asset.warrantyExpiryDate}` : 'No'}
                            </div>
                        </div>
                    </Card>
                    <Card title="Health Score Factors">
                        {factors.openCriticalWos === 0 && factors.openHighWos === 0 && factors.recentBreakdowns === 0 && factors.overduePms === 0 ? (
                            <p className="text-sm text-gray-500">No negative factors contributing to the score.</p>
                        ) : (
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                                {factors.openCriticalWos > 0 && <li className="text-red-600">{factors.openCriticalWos} open critical work order(s)</li>}
                                {factors.openHighWos > 0 && <li className="text-yellow-600">{factors.openHighWos} open high-priority work order(s)</li>}
                                {factors.recentBreakdowns > 0 && <li className="text-red-600">{factors.recentBreakdowns} breakdown(s) in the last 90 days</li>}
                                {factors.overduePms > 0 && <li className="text-yellow-600">{factors.overduePms} overdue PM schedule(s)</li>}
                            </ul>
                        )}
                    </Card>
                </div>
            );
    }
  }
  
  const tabs: Tab[] = ['Details', 'Meters', 'Documentation', 'BOM', 'History'];

  return (
    <>
    <div className="space-y-6">
        <div className="flex justify-between items-center">
            <div>
                <Button onClick={onBack} variant="secondary" leftIcon={<svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>}>
                    Back to Assets
                </Button>
                <div className="mt-4">
                    <h2 className="text-2xl font-bold flex items-center">{asset.name} 
                        <Badge color={statusColors[asset.status]}><span className="ml-3">{asset.status}</span></Badge>
                        <span className="ml-3 font-semibold text-sm">Health Score:</span>
                        <Badge color={healthLevelColors[level]}><span className="ml-1">{score}</span></Badge>
                    </h2>
                    <p className="text-gray-500 dark:text-gray-400">{asset.id}</p>
                </div>
            </div>
            <div className="flex space-x-2">
                {canCreatePM && (
                    <Button 
                        onClick={() => setIsPMFormOpen(true)}
                        disabled={asset.status !== AssetStatus.Operational}
                        title={asset.status !== AssetStatus.Operational ? `Cannot create PM: Asset is ${asset.status}` : "Create PM Schedule"}
                    >
                        Create PM Schedule
                    </Button>
                )}
                {canEditAsset && (
                    <>
                        <Button variant="secondary" onClick={() => setIsEditModalOpen(true)}>Edit Asset</Button>
                        <Button variant="danger" onClick={() => setIsDeleteConfirmOpen(true)}>Delete Asset</Button>
                    </>
                )}
            </div>
        </div>
        
        <div>
            <div className="border-b border-gray-200 dark:border-gray-700">
                <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                    {tabs.map((tab) => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`${
                                activeTab === tab
                                ? 'border-indigo-500 text-indigo-600'
                                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500'
                            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                        >
                        {tab}
                        </button>
                    ))}
                </nav>
            </div>
            <div className="mt-6">
                {renderTabContent()}
            </div>
        </div>

        {asset && (
            <AddAssetForm
                isOpen={isEditModalOpen}
                onClose={() => setIsEditModalOpen(false)}
                onSave={handleSaveAsset}
                assetToEdit={asset}
                currentUser={currentUser}
            />
        )}
        <CreatePMForm
          isOpen={isPMFormOpen}
          onClose={() => setIsPMFormOpen(false)}
          onSave={handleSavePM}
          asset={asset}
          currentUser={currentUser}
        />
    </div>
    <ConfirmationModal
        isOpen={isDeleteConfirmOpen}
        onClose={() => setIsDeleteConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Confirm Asset Deletion"
        confirmText="Delete"
        confirmButtonVariant="danger"
    >
        <p>Are you sure you want to delete asset <span className="font-bold">{asset.name} ({asset.id})</span>?</p>
        <p className="mt-2 text-sm text-gray-500">This action cannot be undone and will permanently remove the asset.</p>
    </ConfirmationModal>
    </>
  );
};
