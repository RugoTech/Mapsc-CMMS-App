
import React, { useState, useContext, useEffect } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import type { Plant, Zone, Area, MockData, User, AuditLogEntry } from '../../types';

type Tab = 'Plant' | 'Zone' | 'Area';
type LocationItem = Plant | Zone | Area;

// A generic form for Plant, Zone, Area
interface LocationFormProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (item: any) => void;
    item: LocationItem | null;
    tab: Tab;
}

const LocationForm: React.FC<LocationFormProps> = ({ isOpen, onClose, onSave, item, tab }) => {
    const context = useContext(DataContext);
    const [formData, setFormData] = useState<any>({ name: '' });

    useEffect(() => {
        if (item) {
            setFormData(item);
        } else {
            const initialData: any = { name: '' };
            if (tab === 'Zone') {
                initialData.plantId = context?.data.plants[0]?.id || '';
                initialData.planningGroupId = '';
            }
            if (tab === 'Area') {
                 initialData.zoneId = '';
            }
            setFormData(initialData);
        }
    }, [item, isOpen, tab, context]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData((prev: any) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };
    
    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="location-form">{item ? 'Save Changes' : `Add ${tab}`}</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={item ? `Edit ${tab}` : `Add New ${tab}`} footer={modalFooter}>
            <form id="location-form" onSubmit={handleSubmit} className="space-y-4">
                <Input id="name" name="name" label={`${tab} Name`} value={formData.name} onChange={handleChange} required />
                {tab === 'Zone' && (
                    <>
                        <div>
                            <label htmlFor="plantId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Plant</label>
                            <select id="plantId" name="plantId" value={formData.plantId || ''} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                <option value="" disabled>Select a plant...</option>
                                {context?.data.plants.map(plant => <option key={plant.id} value={plant.id}>{plant.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="planningGroupId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Default Planning Group</label>
                            <select id="planningGroupId" name="planningGroupId" value={formData.planningGroupId || ''} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                <option value="">Select Planning Group...</option>
                                {context?.data.plannerGroups.map(pg => (
                                    <option key={pg.id} value={pg.id}>{pg.name}</option>
                                ))}
                            </select>
                        </div>
                    </>
                )}
                {tab === 'Area' && (
                     <div>
                        <label htmlFor="zoneId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Zone</label>
                        <select id="zoneId" name="zoneId" value={formData.zoneId || ''} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                            <option value="" disabled>Select a zone...</option>
                            {context?.data.zones.map(zone => <option key={zone.id} value={zone.id}>{zone.name}</option>)}
                        </select>
                    </div>
                )}
            </form>
        </Modal>
    );
};

interface AssetLocationManagementProps {
    currentUser: User | null;
}

// Main component
export const AssetLocationManagement: React.FC<AssetLocationManagementProps> = ({ currentUser }) => {
    const [activeTab, setActiveTab] = useState<Tab>('Plant');
    const context = useContext(DataContext);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<LocationItem | null>(null);
    
    // Deletion State
    const [itemToDelete, setItemToDelete] = useState<LocationItem | null>(null);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

    if (!context || !currentUser) return <div>Loading...</div>;
    const { data, setData } = context;

    const handleOpenAdd = () => {
        setEditingItem(null);
        setIsModalOpen(true);
    };

    const handleOpenEdit = (item: LocationItem) => {
        setEditingItem(item);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingItem(null);
    };
    
    const handleOpenDelete = (item: LocationItem) => {
        // Check dependencies before allowing delete confirmation for Area
        if (activeTab === 'Area') {
            const hasAssets = data.assets.some(a => a.areaId === item.id);
            if (hasAssets) {
                alert("Cannot delete this Area because it is linked to one or more Assets.");
                return;
            }
        }
        setItemToDelete(item);
        setIsDeleteModalOpen(true);
    };

    const handleDelete = () => {
        if (!itemToDelete) return;

        setData(prevData => {
            let listKey: keyof MockData | null = null;
            let entityType = '';

            switch(activeTab) {
                case 'Plant': listKey = 'plants'; entityType = 'Plant'; break;
                case 'Zone': listKey = 'zones'; entityType = 'Zone'; break;
                case 'Area': listKey = 'areas'; entityType = 'Area'; break;
            }

            if (!listKey) return prevData;

            // Remove item
            // @ts-ignore
            const newList = prevData[listKey].filter(i => i.id !== itemToDelete.id);
            
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser!.id,
                action: 'DELETE',
                entityType: entityType,
                entityId: itemToDelete.id,
                details: `Deleted ${entityType} '${itemToDelete.name}' (${itemToDelete.id}).`,
                status: 'Success'
            };

            return {
                ...prevData,
                [listKey]: newList,
                auditLog: [logEntry, ...prevData.auditLog]
            };
        });
        
        setIsDeleteModalOpen(false);
        setItemToDelete(null);
    };
    
    const handleSave = (item: LocationItem) => {
        setData(prevData => {
            const isEditing = !!item.id;
            let listKey: keyof MockData | null = null;
            let prefix = '';

            switch(activeTab) {
                case 'Plant': listKey = 'plants'; prefix = 'PLANT'; break;
                case 'Zone': listKey = 'zones'; prefix = 'ZONE'; break;
                case 'Area': listKey = 'areas'; prefix = 'AREA'; break;
            }

            if (!listKey) return prevData;

            const itemArray = prevData[listKey as keyof MockData] as LocationItem[];

            if (isEditing) {
                return {
                    ...prevData,
                    [listKey]: itemArray.map(i => i.id === item.id ? item : i)
                };
            } else {
                const newId = `${prefix}-${String(itemArray.length + 1).padStart(2, '0')}`;
                const newItem = { ...item, id: newId };
                return {
                    ...prevData,
                    [listKey]: [...itemArray, newItem]
                };
            }
        });
        handleCloseModal();
    };

    const renderTabContent = () => {
        let columns: any[] = [];
        let tableData: any[] = [];

        switch (activeTab) {
            case 'Plant':
                columns = [
                    { header: 'Plant ID', accessor: 'id' },
                    { header: 'Plant Name', accessor: 'name' },
                ];
                tableData = data.plants;
                break;
            case 'Zone':
                 columns = [
                    { header: 'Zone ID', accessor: 'id' },
                    { header: 'Zone Name', accessor: 'name' },
                    { header: 'Plant', accessor: (item: Zone) => data.plants.find(p => p.id === item.plantId)?.name || 'N/A' },
                    { header: 'Planning Group', accessor: (item: Zone) => data.plannerGroups.find(pg => pg.id === item.planningGroupId)?.name || 'N/A' },
                ];
                tableData = data.zones;
                break;
            case 'Area':
                 columns = [
                    { header: 'Area ID', accessor: 'id' },
                    { header: 'Area Name', accessor: 'name' },
                    { header: 'Zone', accessor: (item: Area) => data.zones.find(z => z.id === item.zoneId)?.name || 'N/A' },
                ];
                tableData = data.areas;
                break;
        }

        const canEditPlant = currentUser?.role === 'Administrator';
        const canEditZoneArea = currentUser?.role === 'Engineer';
        const canDeleteArea = currentUser?.role === 'Administrator' && activeTab === 'Area';

        let canShowAddButton = false;
        if (activeTab === 'Plant' && canEditPlant) {
            canShowAddButton = true;
        } else if ((activeTab === 'Zone' || activeTab === 'Area') && canEditZoneArea) {
            canShowAddButton = true;
        }
        
        return (
            <Card title={`${activeTab} Management`} actions={canShowAddButton && <Button onClick={handleOpenAdd}>Add {activeTab}</Button>}>
                 <Table
                    columns={columns}
                    data={tableData}
                    renderRowActions={(item) => {
                        let canShowEditButton = false;
                        if (activeTab === 'Plant' && canEditPlant) {
                            canShowEditButton = true;
                        } else if ((activeTab === 'Zone' || activeTab === 'Area') && canEditZoneArea) {
                            canShowEditButton = true;
                        }

                        return (
                            <div className="flex space-x-2 justify-end">
                                {canShowEditButton && (
                                    <Button variant="secondary" size="sm" onClick={() => handleOpenEdit(item)}>Edit</Button>
                                )}
                                {canDeleteArea && (
                                    <Button variant="danger" size="sm" onClick={() => handleOpenDelete(item)}>Delete</Button>
                                )}
                            </div>
                        );
                    }}
                />
            </Card>
        );
    };

    const tabs: Tab[] = ['Plant', 'Zone', 'Area'];
    
    return (
        <div className="space-y-6">
            <div>
                <div className="border-b border-gray-200 dark:border-gray-700">
                    <nav className="-mb-px flex space-x-8 overflow-x-auto" aria-label="Tabs">
                        {tabs.map((tab) => (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab)}
                                className={`${
                                    activeTab === tab
                                    ? 'border-indigo-500 text-indigo-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500'
                                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                            >
                            {tab}
                            </button>
                        ))}
                    </nav>
                </div>
                <div className="mt-6">
                    {renderTabContent()}
                </div>
            </div>
            {isModalOpen && <LocationForm isOpen={isModalOpen} onClose={handleCloseModal} onSave={handleSave} item={editingItem} tab={activeTab} />}
            
            {isDeleteModalOpen && itemToDelete && (
                <ConfirmationModal
                    isOpen={isDeleteModalOpen}
                    onClose={() => setIsDeleteModalOpen(false)}
                    onConfirm={handleDelete}
                    title={`Confirm Delete ${activeTab}`}
                    confirmText="Delete"
                    confirmButtonVariant="danger"
                >
                    <p>Are you sure you want to delete the {activeTab} <span className="font-bold">{itemToDelete.name}</span>?</p>
                    <p className="mt-2 text-sm text-gray-500">This action cannot be undone.</p>
                </ConfirmationModal>
            )}
        </div>
    );
};
