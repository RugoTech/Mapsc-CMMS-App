import React, { useContext, useState, useMemo, useCallback } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { AddDocumentForm } from './AddDocumentForm';
import type { Document, User } from '../../types';

interface AllDocumentsListProps {
    currentUser: User | null;
}

export const AllDocumentsList: React.FC<AllDocumentsListProps> = ({ currentUser }) => {
  const context = useContext(DataContext);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [filters, setFilters] = useState({
    name: '',
    asset: '',
    type: '',
    vendor: '',
    dateCreated: '',
  });

  if (!context) return <div>Loading...</div>;

  const { data, setData } = context;
  const { documents, assets, vendors, users } = data;

  const getAssetName = useCallback((assetId: string) => assets.find(a => a.id === assetId)?.name || 'N/A', [assets]);
  const getVendorName = useCallback((vendorId?: string) => vendors.find(v => v.id === vendorId)?.name || 'N/A', [vendors]);
  const getUserName = useCallback((userId: string) => users.find(u => u.id === userId)?.name || 'N/A', [users]);

  const handleSaveDocument = (newDocData: Omit<Document, 'id' | 'url'> & { file?: File }) => {
    setData(prevData => {
        const newDocument: Document = {
            id: `DOC-${String(prevData.documents.length + 1).padStart(3, '0')}`,
            url: '#', // Placeholder URL for the uploaded file
            ...newDocData,
        };
        return {
            ...prevData,
            documents: [...prevData.documents, newDocument],
        };
    });
    setIsAddModalOpen(false);
  };

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilters({ name: '', asset: '', type: '', vendor: '', dateCreated: '' });
  };

  const filteredDocuments = useMemo(() => {
    return documents.filter(doc => {
        const nameMatch = filters.name ? doc.name.toLowerCase().includes(filters.name.toLowerCase()) : true;
        
        const assetName = getAssetName(doc.assetId);
        const assetMatch = filters.asset 
            ? assetName.toLowerCase().includes(filters.asset.toLowerCase()) || doc.assetId.toLowerCase().includes(filters.asset.toLowerCase())
            : true;
        
        const typeMatch = filters.type ? doc.type === filters.type : true;
        
        const vendorName = getVendorName(doc.vendorId);
        const vendorMatch = filters.vendor ? vendorName.toLowerCase().includes(filters.vendor.toLowerCase()) : true;
        
        const dateMatch = filters.dateCreated ? doc.dateCreated === filters.dateCreated : true;

        return nameMatch && assetMatch && typeMatch && vendorMatch && dateMatch;
    });
  }, [documents, filters, getAssetName, getVendorName]);

  const columns = [
    { header: 'Document Name', accessor: 'name' as keyof Document },
    { header: 'Asset', accessor: (item: Document) => getAssetName(item.assetId) },
    { header: 'Type', accessor: 'type' as keyof Document },
    { header: 'Vendor', accessor: (item: Document) => getVendorName(item.vendorId) },
    { header: 'Date Created', accessor: 'dateCreated' as keyof Document },
    { header: 'Created By', accessor: (item: Document) => getUserName(item.createdBy) },
  ];

  const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

  const docTypes = ['Work Instruction', 'SOP', 'Schematic', 'PI Drawing', 'Safety Instruction', 'MSDS'];

  return (
    <>
        <Card title="All Asset Documentation" actions={<Button onClick={() => setIsAddModalOpen(true)}>Add Document</Button>}>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="name-filter" className={filterLabelClasses}>Document Name</label>
                    <input type="text" id="name-filter" name="name" value={filters.name} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search name..."/>
                </div>
                 <div>
                    <label htmlFor="asset-filter" className={filterLabelClasses}>Asset</label>
                    <input type="text" id="asset-filter" name="asset" value={filters.asset} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search asset name/ID..."/>
                </div>
                <div>
                    <label htmlFor="type-filter" className={filterLabelClasses}>Type</label>
                    <select id="type-filter" name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Types</option>
                        {docTypes.map(type => <option key={type} value={type}>{type}</option>)}
                    </select>
                </div>
                 <div>
                    <label htmlFor="vendor-filter" className={filterLabelClasses}>Vendor</label>
                     <input type="text" id="vendor-filter" name="vendor" value={filters.vendor} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search vendor..."/>
                </div>
                 <div>
                    <label htmlFor="dateCreated-filter" className={filterLabelClasses}>Date Created</label>
                    <input type="date" id="dateCreated-filter" name="dateCreated" value={filters.dateCreated} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end">
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>
            {documents.length > 0 ? (
                <Table<Document>
                    columns={columns}
                    data={filteredDocuments}
                    renderRowActions={(doc) => (
                        <a href={doc.url} target="_blank" rel="noopener noreferrer">
                            <Button variant="secondary" size="sm">View</Button>
                        </a>
                    )}
                />
            ) : (
                <p className="text-gray-500 dark:text-gray-400">No documents have been added to the system.</p>
            )}
        </Card>
        <AddDocumentForm
            isOpen={isAddModalOpen}
            onClose={() => setIsAddModalOpen(false)}
            onSave={handleSaveDocument}
            currentUser={currentUser}
        />
    </>
  );
};