
import React, { useContext, useState, useMemo, useCallback, useRef } from 'react';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DataContext } from '../../contexts/DataContext';
import { AssetStatus, User } from '../../types';
import type { Asset, AuditLogEntry } from '../../types';
import { AddAssetForm } from './AddAssetForm';
import { useAssetHealthScore, HealthLevel } from '../../hooks/useAssetHealthScore';
import { useZoneAccess } from '../../hooks/useZoneAccess';


interface AssetListProps {
    onViewAsset: (assetId: string) => void;
    currentUser: User | null;
}

const statusColors: Record<AssetStatus, 'green' | 'yellow' | 'gray'> = {
    [AssetStatus.Operational]: 'green',
    [AssetStatus.UnderMaintenance]: 'yellow',
    [AssetStatus.Decommissioned]: 'gray',
};

const HealthScoreBadge: React.FC<{ assetId: string }> = ({ assetId }) => {
    const { score, level } = useAssetHealthScore(assetId);

    const levelColors: Record<HealthLevel, 'green' | 'blue' | 'yellow' | 'red'> = {
        Excellent: 'green',
        Good: 'blue',
        Fair: 'yellow',
        Poor: 'red',
    };

    return <Badge color={levelColors[level]}>{score}</Badge>;
};


export const AssetList: React.FC<AssetListProps> = ({ onViewAsset, currentUser }) => {
  const context = useContext(DataContext);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);
  const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);
  
  // State for filtering
  const [filters, setFilters] = useState({
    id: '',
    name: '',
    type: '',
    zone: '',
    status: '',
  });

  if (!context || !currentUser) return <div>Loading...</div>;

  const { data, setData } = context;
  const { assets, plants, zones } = data;

  const isManagerOrTopManagement = useMemo(() => {
    if (!currentUser) return false;
    if (currentUser.role === 'Manager' || currentUser.role === 'Factory Manager') return true;
    return data.topManagementGroups.some(g => g.userIds.includes(currentUser.id));
  }, [currentUser, data.topManagementGroups]);

  const canAddAsset = currentUser?.role === 'Engineer' && !isManagerOrTopManagement;

  const getPlantName = useCallback((plantId: string) => {
    return plants.find(p => p.id === plantId)?.name || 'N/A';
  }, [plants]);

  const getZoneName = useCallback((zoneId: string) => {
    return zones.find(z => z.id === zoneId)?.name || 'N/A';
  }, [zones]);
  
  const handleSaveAsset = (newAsset: Asset) => {
      const logEntry: AuditLogEntry = {
        id: `LOG-${String(data.auditLog.length + 1).padStart(3, '0')}`,
        timestamp: new Date().toISOString(),
        userId: currentUser!.id,
        action: 'CREATE',
        entityType: 'Asset',
        entityId: newAsset.id,
        details: `Created new asset '${newAsset.name}' with ID ${newAsset.id}.`,
        status: 'Success'
      };
      
      setData(prevData => {
          let updatedMeters = [...prevData.meters];
          
          // Automatically link the meter to this asset if a meter was selected
          if (newAsset.meterId) {
              updatedMeters = updatedMeters.map(m => 
                  m.id === newAsset.meterId 
                      ? { ...m, assetId: newAsset.id } 
                      : m
              );
          }

          return {
              ...prevData,
              assets: [...prevData.assets, newAsset],
              meters: updatedMeters,
              auditLog: [logEntry, ...prevData.auditLog]
          };
      });
  };
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilters({ id: '', name: '', type: '', zone: '', status: '' });
  };

  const filteredAssets = useMemo(() => {
    return assets.filter(asset => {
        const zoneAccessMatch = canSeeAllZones || accessibleZoneIds.includes(asset.zoneId);
        if (!zoneAccessMatch) return false;

        const idMatch = filters.id ? asset.id.toLowerCase().includes(filters.id.toLowerCase()) : true;
        const nameMatch = filters.name ? asset.name.toLowerCase().includes(filters.name.toLowerCase()) : true;
        const typeMatch = filters.type ? asset.type.toLowerCase().includes(filters.type.toLowerCase()) : true;
        const zoneMatch = filters.zone ? asset.zoneId === filters.zone : true;
        const statusMatch = filters.status ? asset.status === filters.status : true;

        return idMatch && nameMatch && typeMatch && zoneMatch && statusMatch;
    });
  }, [assets, filters, accessibleZoneIds, canSeeAllZones]);

  const handlePrint = () => {
    if (printRef.current) {
        const printContent = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=800,width=1000');
        if (printWindow) {
            printWindow.document.write('<html><head><title>Asset Register</title>');
            printWindow.document.write(`
                <style>
                    body { font-family: sans-serif; margin: 2rem; }
                    table { width: 100%; border-collapse: collapse; font-size: 12px; }
                    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    tr:nth-child(even) { background-color: #f9f9f9; }
                    h1 { font-size: 24px; margin-bottom: 1rem; }
                    .no-print { display: none; }
                    /* Badge styles for printing */
                    span { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                    span[class*="bg-blue-100"] { background-color: #DBEAFE !important; color: #1E40AF !important; }
                    span[class*="bg-green-100"] { background-color: #D1FAE5 !important; color: #065F46 !important; }
                    span[class*="bg-yellow-100"] { background-color: #FEF3C7 !important; color: #92400E !important; }
                    span[class*="bg-red-100"] { background-color: #FEE2E2 !important; color: #991B1B !important; }
                    span[class*="bg-gray-100"] { background-color: #F3F4F6 !important; color: #1F2937 !important; }
                </style>
            `);
            printWindow.document.write('</head><body>');
            printWindow.document.write('<h1>Asset Register</h1>');
            printWindow.document.write(printContent);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 500);
        }
    }
  };


  const columns = [
    { header: 'Asset ID', accessor: 'id' as keyof Asset },
    { header: 'Name', accessor: 'name' as keyof Asset },
    { header: 'Health Score', accessor: (item: Asset) => <HealthScoreBadge assetId={item.id} /> },
    { header: 'Type', accessor: 'type' as keyof Asset },
    { header: 'Plant', accessor: (item: Asset) => getPlantName(item.plantId) },
    { header: 'Zone', accessor: (item: Asset) => getZoneName(item.zoneId) },
    {
      header: 'Status',
      accessor: (item: Asset) => (
        <Badge color={statusColors[item.status]}>{item.status}</Badge>
      ),
    },
    { header: 'Meter', accessor: (item: Asset) => item.meterId || 'N/A' },
  ];
  
  const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

  return (
    <>
        <Card
            title="Asset Register"
            actions={
                <div className="flex space-x-2">
                    <Button variant="secondary" onClick={handlePrint}>Print List</Button>
                    {canAddAsset && (
                        <Button onClick={() => setIsAddModalOpen(true)}>Add Asset</Button>
                    )}
                </div>
            }
        >
             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="id-filter" className={filterLabelClasses}>Asset ID</label>
                    <input type="text" id="id-filter" name="id" value={filters.id} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search ID..."/>
                </div>
                <div>
                    <label htmlFor="name-filter" className={filterLabelClasses}>Asset Name</label>
                    <input type="text" id="name-filter" name="name" value={filters.name} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search name..."/>
                </div>
                <div>
                    <label htmlFor="type-filter" className={filterLabelClasses}>Type</label>
                    <input type="text" id="type-filter" name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search type..."/>
                </div>
                <div>
                    <label htmlFor="zone-filter" className={filterLabelClasses}>Zone</label>
                    <select id="zone-filter" name="zone" value={filters.zone} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Zones</option>
                        {zones.filter(z => canSeeAllZones || accessibleZoneIds.includes(z.id)).map(zone => <option key={zone.id} value={zone.id}>{zone.name}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="status-filter" className={filterLabelClasses}>Status</label>
                    <select id="status-filter" name="status" value={filters.status} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Statuses</option>
                        {Object.values(AssetStatus).map(status => <option key={status} value={status}>{status}</option>)}
                    </select>
                </div>
                <div className="flex items-end">
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>
            <div ref={printRef}>
                <Table<Asset>
                    columns={columns}
                    data={filteredAssets}
                    renderRowActions={(asset) => (
                        <Button variant="secondary" size="sm" onClick={() => onViewAsset(asset.id)}>
                            Details
                        </Button>
                    )}
                />
            </div>
        </Card>
        <AddAssetForm 
            isOpen={isAddModalOpen} 
            onClose={() => setIsAddModalOpen(false)} 
            onSave={handleSaveAsset}
            currentUser={currentUser}
        />
    </>
  );
};
