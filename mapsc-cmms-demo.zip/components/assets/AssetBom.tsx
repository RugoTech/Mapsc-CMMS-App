
import React, { useContext, useState, useMemo, useEffect } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { BomItemForm } from './BomItemForm';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import type { BomItem, Part, Asset, User, AuditLogEntry } from '../../types';

interface AssetBomProps {
    assetId: string;
    currentUser: User | null;
}

type TreeNode = {
    bomItem: BomItem;
    part: Part;
    children: TreeNode[];
    level: number;
};

const BomNode: React.FC<{
    node: TreeNode;
    onSelect: (node: TreeNode) => void;
    selectedNode: TreeNode | null;
}> = ({ node, onSelect, selectedNode }) => {
    const isSelected = selectedNode?.bomItem.id === node.bomItem.id;

    return (
        <li>
            <div
                onClick={() => onSelect(node)}
                style={{ paddingLeft: `${(node.level - 1) * 20 + 8}px` }} // 20px per level, plus 8px base padding
                className={`flex items-center py-2 pr-2 rounded-md cursor-pointer transition-colors duration-200 ${
                    isSelected
                        ? 'bg-indigo-600 text-white'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    {node.children.length > 0 ? (
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    ) : (
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7" />
                    )}
                </svg>
                <span className="flex-grow truncate">{node.part.name}</span>
                <span className="text-xs ml-2 px-2 py-0.5 rounded-full bg-gray-200 dark:bg-gray-600">{`x${node.bomItem.quantity}`}</span>
            </div>
            {node.children.length > 0 && (
                <ul>
                    {node.children.map(child => (
                        <BomNode
                            key={child.bomItem.id}
                            node={child}
                            onSelect={onSelect}
                            selectedNode={selectedNode}
                        />
                    ))}
                </ul>
            )}
        </li>
    );
};


const DetailItem: React.FC<{ label: string, children: React.ReactNode }> = ({ label, children }) => (
    <div>
        <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</dt>
        <dd className="mt-1 text-sm text-gray-900 dark:text-white">{children || 'N/A'}</dd>
    </div>
);


export const AssetBom: React.FC<AssetBomProps> = ({ assetId, currentUser }) => {
    const context = useContext(DataContext);
    const [selectedNode, setSelectedNode] = useState<TreeNode | null>(null);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [itemToEdit, setItemToEdit] = useState<BomItem | null>(null);
    const [itemToDelete, setItemToDelete] = useState<BomItem | null>(null);

    // Local state for BOM items
    const [localBomItems, setLocalBomItems] = useState<BomItem[]>([]);
    const [initialBomItems, setInitialBomItems] = useState<BomItem[]>([]);

    if (!context) return <div>Loading...</div>;
    const { data, setData } = context;
    const { assets, bomItems: globalBomItems, parts, vendors } = data;

    // Initialize local state from global context
    useEffect(() => {
        const assetItems = globalBomItems.filter(item => item.assetId === assetId);
        // Use deep copy to prevent mutation and for reliable dirty checking
        const deepCopiedItems = JSON.parse(JSON.stringify(assetItems));
        setLocalBomItems(deepCopiedItems);
        setInitialBomItems(deepCopiedItems);
    }, [assetId, globalBomItems]);
    
    // Check if there are unsaved changes
    const isDirty = useMemo(() => {
        return JSON.stringify(localBomItems) !== JSON.stringify(initialBomItems);
    }, [localBomItems, initialBomItems]);

    const asset = useMemo(() => assets.find(a => a.id === assetId), [assets, assetId]);

    const bomTree = useMemo(() => {
        if (!asset) return [];
        
        const itemMap = new Map<string, BomItem>();
        localBomItems.forEach(item => itemMap.set(item.id, item));

        const getLevel = (itemId: string): number => {
            let level = 2; // Children start at level 2
            let currentItem = itemMap.get(itemId);
            while (currentItem?.parentId) {
                level++;
                currentItem = itemMap.get(currentItem.parentId);
            }
            return level;
        };

        const nodeMap = new Map<string, TreeNode>();
        localBomItems.forEach(item => {
            const part = parts.find(p => p.id === item.partId);
            if (part) {
                nodeMap.set(item.id, {
                    bomItem: item,
                    part: part,
                    children: [],
                    level: getLevel(item.id),
                });
            }
        });

        const childTree: TreeNode[] = [];
        nodeMap.forEach(node => {
            if (node.bomItem.parentId) {
                const parentNode = nodeMap.get(node.bomItem.parentId);
                parentNode?.children.push(node);
            } else {
                childTree.push(node);
            }
        });
        
        const sortChildren = (nodes: TreeNode[]) => {
            nodes.sort((a, b) => a.part.name.localeCompare(b.part.name));
            nodes.forEach(node => sortChildren(node.children));
        };
        sortChildren(childTree);

        const assetAsPart: Part = {
            id: asset.id,
            partNumber: asset.serialNumber,
            name: asset.name,
            location: '',
            quantity: 1,
            reorderPoint: 0,
            unitCost: asset.cost,
            unitOfMeasure: 'EA',
            type: 'Non-stock',
            dateCreated: asset.purchaseDate,
            createdBy: asset.createdBy,
        };
        const assetAsBomItem: BomItem = {
            id: `asset-root-${asset.id}`,
            assetId: asset.id,
            partId: asset.id,
            quantity: 1,
            unitOfMeasure: 'EA',
            parentId: null,
            notes: asset.bomNotes || `Main asset: ${asset.type} - ${asset.model}`
        };

        const rootNode: TreeNode = {
            bomItem: assetAsBomItem,
            part: assetAsPart,
            children: childTree,
            level: 1,
        };

        return [rootNode];
    }, [assetId, asset, localBomItems, parts]);
    
    useEffect(() => {
        if (bomTree.length > 0) {
            const selectedExists = localBomItems.some(item => item.id === selectedNode?.bomItem.id);
            if (!selectedNode || (!selectedNode.bomItem.id.startsWith('asset-root-') && !selectedExists)) {
                setSelectedNode(bomTree[0]);
            }
        } else {
            setSelectedNode(null);
        }
    }, [bomTree, selectedNode, localBomItems]);

    const handleOpenAddForm = () => {
        setItemToEdit(null);
        setIsFormOpen(true);
    };

    const handleOpenEditForm = () => {
        if (selectedNode) {
            if (selectedNode.bomItem.id.startsWith('asset-root-')) {
                alert("The root asset cannot be edited. Add or edit its components instead.");
                return;
            }
            setItemToEdit(selectedNode.bomItem);
            setIsFormOpen(true);
        }
    };

    const handleOpenDeleteConfirm = () => {
        if (selectedNode && !selectedNode.bomItem.id.startsWith('asset-root-')) {
            setItemToDelete(selectedNode.bomItem);
        }
    };

    const handleSaveItem = (item: BomItem) => {
        const isEditing = item.id && (item.id.startsWith('BOM-') || item.id.startsWith('temp-'));
        if (isEditing) {
            setLocalBomItems(prev => prev.map(i => i.id === item.id ? item : i));
        } else {
            const newItem = { ...item, id: `temp-${Date.now()}` };
            setLocalBomItems(prev => [...prev, newItem]);
        }
        setIsFormOpen(false);
        setItemToEdit(null);
    };
    
    const handleConfirmDelete = () => {
        if (!itemToDelete) return;

        const getDescendants = (itemId: string, items: BomItem[]): string[] => {
            const children = items.filter(i => i.parentId === itemId);
            let descendants = children.map(c => c.id);
            children.forEach(c => {
                descendants.push(...getDescendants(c.id, items));
            });
            return descendants;
        };

        const idsToDelete = [itemToDelete.id, ...getDescendants(itemToDelete.id, localBomItems)];
        const idsToDeleteSet = new Set(idsToDelete);

        setLocalBomItems(prev => prev.filter(item => !idsToDeleteSet.has(item.id)));
        setItemToDelete(null);
        
        if (selectedNode && idsToDeleteSet.has(selectedNode.bomItem.id)) {
            setSelectedNode(bomTree.length > 0 ? bomTree[0] : null);
        }
    };

    const handleSaveChanges = () => {
        setData(prevData => {
            const otherAssetsBomItems = prevData.bomItems.filter(item => item.assetId !== assetId);
            
            const idMap = new Map<string, string>();
            let currentIdCounter = prevData.bomItems.length;

            const newBomItemsWithPermanentIds = localBomItems.map(item => {
                if (item.id.startsWith('temp-')) {
                    const newId = `BOM-${String(++currentIdCounter).padStart(3, '0')}`;
                    idMap.set(item.id, newId);
                    return { ...item, id: newId };
                }
                return item;
            });
            
            const finalBomItems = newBomItemsWithPermanentIds.map(item => {
                if (item.parentId && item.parentId.startsWith('temp-')) {
                    const newParentId = idMap.get(item.parentId);
                    if (newParentId) { return { ...item, parentId: newParentId }; }
                }
                return item;
            });
            
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser?.id || 'SYSTEM',
                action: 'UPDATE',
                entityType: 'AssetBOM',
                entityId: assetId,
                details: `Updated Bill of Materials for asset '${asset?.name}' (${assetId}).`,
                status: 'Success'
            };

            return { 
                ...prevData, 
                bomItems: [...otherAssetsBomItems, ...finalBomItems],
                auditLog: [logEntry, ...prevData.auditLog] 
            };
        });
        // The useEffect watching globalBomItems will reset local state and isDirty flag.
    };

    const handleCancel = () => {
        setLocalBomItems(initialBomItems);
        if (bomTree.length > 0) {
            setSelectedNode(bomTree[0]);
        }
    };

    const vendorName = selectedNode?.part.vendorId ? vendors.find(v => v.id === selectedNode.part.vendorId)?.name : null;

    return (
        <>
            <Card title="Bill of Materials" actions={<Button onClick={handleOpenAddForm}>Add Item</Button>}>
                {isDirty && (
                    <div className="p-4 mb-4 border-b dark:border-gray-700 bg-yellow-50 dark:bg-yellow-900/20 flex justify-between items-center rounded-t-lg -mt-4 -mx-4">
                        <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-200">You have unsaved changes.</p>
                        <div className="flex space-x-2">
                            <Button variant="secondary" size="sm" onClick={handleCancel}>Cancel</Button>
                            <Button variant="primary" size="sm" onClick={handleSaveChanges}>Save Changes</Button>
                        </div>
                    </div>
                )}
                {bomTree.length === 0 ? (
                    <p className="text-gray-500 dark:text-gray-400">No Bill of Materials defined for this asset.</p>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="md:col-span-1">
                            <h3 className="text-lg font-semibold mb-2">Asset Structure</h3>
                            <div className="p-2 border rounded-lg bg-gray-50 dark:bg-gray-900 h-[60vh] overflow-y-auto">
                                <ul>
                                    {bomTree.map(node => (
                                        <BomNode
                                            key={node.bomItem.id}
                                            node={node}
                                            onSelect={setSelectedNode}
                                            selectedNode={selectedNode}
                                        />
                                    ))}
                                </ul>
                            </div>
                        </div>
                        <div className="md:col-span-2">
                            {selectedNode ? (
                                <Card title="Component Details">
                                    <dl className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-6">
                                        <DetailItem label="Part Name">{selectedNode.part.name}</DetailItem>
                                        <DetailItem label="Part Number">{selectedNode.part.partNumber}</DetailItem>
                                        <DetailItem label="Description">
                                            {selectedNode.level === 1 && asset
                                                ? `${asset.type} - ${asset.model}`
                                                : selectedNode.part.name}
                                        </DetailItem>
                                        <DetailItem label="Quantity">{selectedNode.bomItem.quantity}</DetailItem>
                                        <DetailItem label="Unit of Measure">{selectedNode.bomItem.unitOfMeasure}</DetailItem>
                                        <DetailItem label="Level">{selectedNode.level}</DetailItem>
                                        <DetailItem label="Procurement Type">
                                            {vendorName ? `Vendor (${vendorName})` : 'N/A'}
                                        </DetailItem>
                                        <DetailItem label="Lead Time">
                                            {selectedNode.part.leadTime ? `${selectedNode.part.leadTime} days` : 'N/A'}
                                        </DetailItem>
                                        <div className="md:col-span-2">
                                            <DetailItem label="Notes">{selectedNode.bomItem.notes}</DetailItem>
                                        </div>
                                    </dl>
                                    <div className="mt-4 flex space-x-2 border-t pt-4 dark:border-gray-700">
                                        <Button size="sm" variant="secondary" onClick={handleOpenEditForm} disabled={!selectedNode || selectedNode.level === 1}>Edit</Button>
                                        <Button size="sm" variant="danger" onClick={handleOpenDeleteConfirm} disabled={!selectedNode || selectedNode.level === 1}>Delete</Button>
                                    </div>
                                </Card>
                            ) : (
                                <div className="flex items-center justify-center h-full bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                                    <p className="text-gray-500">Select an item from the structure to see details.</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </Card>
             {isFormOpen && (
                <BomItemForm
                    isOpen={isFormOpen}
                    onClose={() => setIsFormOpen(false)}
                    onSave={handleSaveItem}
                    itemToEdit={itemToEdit}
                    allAssetBomItems={localBomItems}
                    assetId={assetId}
                />
            )}
            {itemToDelete && (
                <ConfirmationModal
                    isOpen={!!itemToDelete}
                    onClose={() => setItemToDelete(null)}
                    onConfirm={handleConfirmDelete}
                    title="Confirm BOM Item Deletion"
                    confirmText="Delete"
                    confirmButtonVariant="danger"
                >
                    <p>Are you sure you want to delete <span className="font-bold">{parts.find(p => p.id === itemToDelete.partId)?.name}</span>?</p>
                    <p className="mt-2 text-sm text-gray-500">This will also delete all of its child components in the BOM.</p>
                </ConfirmationModal>
            )}
        </>
    );
};
