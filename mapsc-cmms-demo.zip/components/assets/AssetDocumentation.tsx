import React, { useContext, useState } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { AddDocumentForm } from './AddDocumentForm';
import type { Document, User } from '../../types';

interface AssetDocumentationProps {
  assetId: string;
  currentUser: User | null;
}

const DocIcon: React.FC<{ type: string }> = ({ type }) => {
    let icon;
    switch(type) {
        case 'Work Instruction':
        case 'SOP':
            icon = 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253';
            break;
        case 'Schematic':
        case 'PI Drawing':
            icon = 'M10 20l4-16m4 4l-4 4-4 4m12-4h-4M2 10h4';
            break;
        case 'Safety Instruction':
        case 'MSDS':
            icon = 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z';
            break;
        default:
            icon = 'M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z';
    }
    return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={icon} />
        </svg>
    );
};

export const AssetDocumentation: React.FC<AssetDocumentationProps> = ({ assetId, currentUser }) => {
  const context = useContext(DataContext);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  if (!context) return <div>Loading...</div>;

  const { data, setData } = context;
  const documents = data.documents.filter(d => d.assetId === assetId);

  const handleSaveDocument = (newDocData: Omit<Document, 'id' | 'url'> & { file?: File }) => {
    setData(prevData => {
        const newDocument: Document = {
            id: `DOC-${String(prevData.documents.length + 1).padStart(3, '0')}`,
            url: '#', // Placeholder URL for the uploaded file
            ...newDocData,
        };
        return {
            ...prevData,
            documents: [...prevData.documents, newDocument],
        };
    });
    setIsAddModalOpen(false);
  };

  return (
    <>
        <Card title="Asset Documentation" actions={<Button onClick={() => setIsAddModalOpen(true)}>Add Document</Button>}>
            {documents.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {documents.map(doc => (
                        <div key={doc.id} className="border dark:border-gray-700 rounded-lg p-4 flex items-center space-x-4">
                            <DocIcon type={doc.type} />
                            <div className="flex-1">
                                <p className="font-semibold text-sm truncate">{doc.name}</p>
                                <p className="text-xs text-gray-500">{doc.type}</p>
                                <p className="text-xs text-gray-400 mt-1">{doc.dateCreated}</p>
                            </div>
                            <a href={doc.url} target="_blank" rel="noopener noreferrer">
                                <Button variant="secondary" size="sm">View</Button>
                            </a>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-gray-500 dark:text-gray-400">No documents have been added to this asset.</p>
            )}
        </Card>
        <AddDocumentForm
            isOpen={isAddModalOpen}
            onClose={() => setIsAddModalOpen(false)}
            onSave={handleSaveDocument}
            assetId={assetId}
            currentUser={currentUser}
        />
    </>
  );
};