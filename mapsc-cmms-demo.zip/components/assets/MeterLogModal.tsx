
import React, { useContext, useState, useMemo } from 'react';
import { Modal } from '../ui/Modal';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import { AddMeterReadingForm } from './AddMeterReadingForm';
import { MeterType, WorkOrder, Priority, WorkOrderStatus, WorkOrderType } from '../../types';
import type { Meter, MeterReading, User, AuditLogEntry } from '../../types';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface MeterLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  meter: Meter;
  currentUser: User | null;
}

export const MeterLogModal: React.FC<MeterLogModalProps> = ({ isOpen, onClose, meter, currentUser }) => {
    const context = useContext(DataContext);
    const [isAddReadingModalOpen, setIsAddReadingModalOpen] = useState(false);
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    if (!context || !currentUser) return null;

    const { data, setData } = context;
    
    const currentMeter = data.meters.find(m => m.id === meter.id) || meter;

    const meterReadings = data.meterReadings
        .filter(r => r.meterId === currentMeter.id)
        .sort((a, b) => {
            const dateComparison = new Date(b.date).getTime() - new Date(a.date).getTime();
            if (dateComparison !== 0) {
                return dateComparison;
            }
            return b.id.localeCompare(a.id);
        });
        
    const getUserName = (userId: string) => data.users.find(u => u.id === userId)?.name || 'N/A';
    
    const handleSaveReading = (value: number) => {
        const newWorkOrders: WorkOrder[] = [];
        const pmUpdates: { pmId: string, newLastReading: number }[] = [];
        let workOrdersGeneratedCount = 0;

        const relevantPMs = data.preventiveMaintenances.filter(
            pm => pm.triggerType === 'Meter' && pm.meterId === currentMeter.id
        );

        relevantPMs.forEach(pm => {
            if (!pm.meterTriggerValue || pm.meterTriggerValue <= 0) return;

            let lastReading = pm.lastTriggerReading || 0;
            let nextDueReading = lastReading + pm.meterTriggerValue;

            while (value >= nextDueReading) {
                // Use the duration directly from the PM Plan as per requirement
                const estimatedDuration = pm.duration || 0;

                const newWO: WorkOrder = {
                    id: `WO-${String(data.workOrders.length + newWorkOrders.length + 1).padStart(3, '0')}`,
                    description: `${pm.name} (Triggered at ${nextDueReading} ${currentMeter.unitOfMeasure})`,
                    assetId: pm.assetId,
                    priority: Priority.Medium,
                    status: WorkOrderStatus.Open,
                    dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                    createdDate: new Date().toISOString().split('T')[0],
                    createdBy: currentUser!.id,
                    partsUsed: [],
                    estimatedDuration: estimatedDuration,
                    laborHours: 0,
                    workOrderType: WorkOrderType.Preventive,
                    pmPlanId: pm.id,
                    assignedUserIds: [],
                    procedureIds: pm.procedureIds, // Correctly use procedureIds array
                };
                newWorkOrders.push(newWO);
                workOrdersGeneratedCount++;

                lastReading = nextDueReading;
                nextDueReading = lastReading + pm.meterTriggerValue;
            }

            if (lastReading !== (pm.lastTriggerReading || 0)) {
                pmUpdates.push({ pmId: pm.id, newLastReading: lastReading });
            }
        });

        setData(prevData => {
            const newReading: MeterReading = {
                id: `MR-${String(prevData.meterReadings.length + 1).padStart(3, '0')}`,
                meterId: currentMeter.id,
                value: value,
                date: new Date().toISOString().split('T')[0],
                userId: currentUser!.id,
            };

            const updatedMeters = prevData.meters.map(m =>
                m.id === currentMeter.id
                    ? { ...m, lastReading: value, lastReadingDate: newReading.date }
                    : m
            );

            const updatedPMs = prevData.preventiveMaintenances.map(pm => {
                const update = pmUpdates.find(u => u.pmId === pm.id);
                return update ? { ...pm, lastTriggerReading: update.newLastReading } : pm;
            });
            
            const logEntry: AuditLogEntry = {
                id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
                timestamp: new Date().toISOString(),
                userId: currentUser.id,
                action: 'CREATE',
                entityType: 'MeterReading',
                entityId: newReading.id,
                details: `Recorded reading ${value} ${currentMeter.unitOfMeasure} for meter '${currentMeter.name}' (${currentMeter.id}).`,
                status: 'Success'
            };
            
            return {
                ...prevData,
                meterReadings: [...prevData.meterReadings, newReading],
                meters: updatedMeters,
                preventiveMaintenances: updatedPMs,
                workOrders: [...prevData.workOrders, ...newWorkOrders],
                auditLog: [logEntry, ...prevData.auditLog]
            };
        });

        if (workOrdersGeneratedCount > 0) {
            alert(`${workOrdersGeneratedCount} Preventive Maintenance work order(s) were automatically generated based on this reading.`);
        }

        setIsAddReadingModalOpen(false);
    };


    const columns = [
        { header: 'Date', accessor: 'date' as keyof MeterReading },
        { header: 'Reading', accessor: 'value' as keyof MeterReading },
        { header: 'Recorded By', accessor: (item: MeterReading) => getUserName(item.userId) },
    ];
    
    const canAddReading = useMemo(() => {
        if (currentMeter.isActive === false) return false;

        if (currentMeter.type !== MeterType.Manual) return false;
        
        if (currentMeter.assetId) {
            // Attached Meter Logic
            const asset = data.assets.find(a => a.id === currentMeter.assetId);
            if (!asset) return false;

            // Rule: Only Planners or Maintenance Clerks (and Admins)
            const isAuthorizedRole = 
                currentUser.role === 'Administrator' || 
                currentUser.role === 'Planner' || 
                (currentUser.role === 'Clerk' && currentUser.department === 'Maintenance');
            
            if (!isAuthorizedRole) return false;

            // Rule: Must belong to the zone
            return canSeeAllZones || accessibleZoneIds.includes(asset.zoneId);
        } else {
            // Unattached Meter Logic
            // Rule: Only the creator can add readings
            return currentMeter.createdBy === currentUser.id;
        }
    }, [currentMeter, currentUser, data.assets, canSeeAllZones, accessibleZoneIds]);

    const modalFooter = canAddReading ? 
        <Button onClick={() => setIsAddReadingModalOpen(true)}>Add Reading</Button> : 
        (currentMeter.isActive === false ? <span className="text-red-500 font-bold text-sm mr-2">Meter Inactive</span> : null);

    return (
        <>
            <Modal isOpen={isOpen} onClose={onClose} title={`Reading Log for ${currentMeter.name} (${currentMeter.unitOfMeasure})`} footer={modalFooter}>
                {meterReadings.length > 0 ? (
                    <Table<MeterReading>
                        columns={columns}
                        data={meterReadings}
                    />
                ) : (
                    <p className="text-gray-500 dark:text-gray-400">No reading history found for this meter.</p>
                )}
            </Modal>
            {currentMeter.type === MeterType.Manual && (
                <AddMeterReadingForm
                    isOpen={isAddReadingModalOpen}
                    onClose={() => setIsAddReadingModalOpen(false)}
                    onSave={handleSaveReading}
                    lastReading={currentMeter.lastReading}
                    existingReadings={meterReadings}
                    maxReadingLimit={currentMeter.maxReadingLimit}
                />
            )}
        </>
    );
};
