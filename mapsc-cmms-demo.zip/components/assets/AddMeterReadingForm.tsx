
import React, { useState, useEffect } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import type { MeterReading } from '../../types';

interface AddMeterReadingFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (value: number) => void;
  lastReading: number;
  existingReadings: MeterReading[];
  maxReadingLimit?: number;
}

export const AddMeterReadingForm: React.FC<AddMeterReadingFormProps> = ({ isOpen, onClose, onSave, lastReading, existingReadings, maxReadingLimit }) => {
    const [reading, setReading] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        if (isOpen) {
            setReading('');
            setError('');
        }
    }, [isOpen]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        const readingValue = parseFloat(reading);

        if (isNaN(readingValue)) {
            setError('Please enter a valid number for the reading.');
            return;
        }

        if (readingValue < lastReading) {
            setError(`New reading must be greater than or equal to the last reading of ${lastReading}.`);
            return;
        }

        // Calculate the usage/difference
        const difference = readingValue - lastReading;

        if (maxReadingLimit !== undefined && difference > maxReadingLimit) {
            setError(`Usage (${difference}) exceeds the defined maximum usage limit of ${maxReadingLimit}. Please verify the value.`);
            return;
        }

        const today = new Date().toISOString().split('T')[0];
        const isDuplicate = existingReadings.some(
            r => r.date === today && r.value === readingValue
        );

        if (isDuplicate) {
            setError(`A reading of ${readingValue} has already been recorded for today. Please enter a different value.`);
            return;
        }

        onSave(readingValue);
    };

    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="add-reading-form">Save Reading</Button>
        </>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Add New Meter Reading" footer={modalFooter}>
            <form id="add-reading-form" onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <Input
                        id="reading"
                        name="reading"
                        label={`New Reading (must be >= ${lastReading})`}
                        type="number"
                        min={lastReading}
                        value={reading}
                        onChange={(e) => setReading(e.target.value)}
                        required
                    />
                    {maxReadingLimit !== undefined && (
                        <p className="text-xs text-gray-500 mt-1">
                            Valuation Limit: Usage (Current - Previous) cannot exceed {maxReadingLimit}.
                        </p>
                    )}
                    {error && <p className="text-sm text-red-600 dark:text-red-400 mt-2">{error}</p>}
                </div>
            </form>
        </Modal>
    );
};
