import React, { useContext } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import type { WorkOrder } from '../../types';
import { TransactionType } from '../../types';
import { useCurrencyConverter } from '../../hooks/useCurrencyConverter';
import { useSettings } from '../../contexts/SettingsContext';

interface AssetHistoryProps {
  assetId: string;
}

export const AssetHistory: React.FC<AssetHistoryProps> = ({ assetId }) => {
  const context = useContext(DataContext);
  const { settings } = useSettings();
  const { convertAndFormat: formatCurrency } = useCurrencyConverter();
  if (!context) return <div>Loading...</div>;

  const { workOrders, parts, inventoryTransactions, laborLogs } = context.data;
  const assetWorkOrders = workOrders.filter(wo => wo.assetId === assetId);

  const getPartName = (partId: string) => parts.find(p => p.id === partId)?.name || 'N/A';
  
  const calculateTotalCost = (wo: WorkOrder) => {
    const partsCost = inventoryTransactions
        .filter(t => t.workOrderId === wo.id && t.type === TransactionType.Issue)
        .reduce((total, transaction) => {
            const part = parts.find(p => p.id === transaction.partId);
            return total + (part?.unitCost || 0) * transaction.quantity;
        }, 0);
    
    const laborCost = laborLogs
        .filter(log => log.workOrderId === wo.id)
        .reduce((sum, log) => {
            const duration = (new Date(log.endTime).getTime() - new Date(log.startTime).getTime()) / (1000 * 60 * 60);
            return sum + (duration * settings.laborRatePerHour);
        }, 0);

    return partsCost + laborCost;
  };

  const totalMaintenanceCost = assetWorkOrders.reduce((total, wo) => total + calculateTotalCost(wo), 0);

  const columns = [
    { header: 'WO ID', accessor: 'id' as keyof WorkOrder },
    { header: 'Description', accessor: 'description' as keyof WorkOrder },
    { header: 'Date Completed', accessor: 'dueDate' as keyof WorkOrder },
    {
        header: 'Parts Used',
        accessor: (item: WorkOrder) => {
            const issuedParts = inventoryTransactions.filter(t => t.workOrderId === item.id && t.type === TransactionType.Issue);
            return (
                <ul className="text-xs">
                    {issuedParts.length > 0 ? issuedParts.map(p => (
                        <li key={p.id}>{p.quantity} x {getPartName(p.partId)}</li>
                    )) : 'None'}
                </ul>
            )
        }
    },
    { header: 'Labor Hours', accessor: 'laborHours' as keyof WorkOrder },
    {
        header: 'Total Cost',
        accessor: (item: WorkOrder) => formatCurrency(calculateTotalCost(item))
    },
  ];

  return (
    <Card title="Maintenance History">
        <div className="mb-6 p-4 bg-gray-100 dark:bg-gray-700 rounded-lg">
            <h4 className="text-lg font-semibold">Lifetime Maintenance Cost</h4>
            <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{formatCurrency(totalMaintenanceCost)}</p>
        </div>
        {assetWorkOrders.length > 0 ? (
             <Table<WorkOrder>
                columns={columns}
                data={assetWorkOrders}
            />
        ) : (
            <p className="text-gray-500 dark:text-gray-400">No work order history for this asset.</p>
        )}
    </Card>
  );
};