
import React, { useState, useEffect, useContext, useMemo } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { MeterType } from '../../types';
import type { Meter, User } from '../../types';
import { DataContext } from '../../contexts/DataContext';
import { useZoneAccess } from '../../hooks/useZoneAccess';

interface AddMeterFormProps {
  isOpen: boolean;
  onClose: () => void;
  // Changed to accept Partial<Meter> to support linking (which only sends ID) or creating (which sends full data)
  onSave: (meter: Partial<Meter>) => void;
  assetId?: string;
  currentUser: User | null;
  meterToEdit?: Meter | null;
}

const initialFormState = {
    name: '',
    type: MeterType.Manual,
    lastReading: 0,
    unitOfMeasure: '',
    assetId: '',
    maxReadingLimit: undefined as number | undefined,
};

export const AddMeterForm: React.FC<AddMeterFormProps> = ({ isOpen, onClose, onSave, assetId, currentUser, meterToEdit }) => {
    const context = useContext(DataContext);
    const [formData, setFormData] = useState(initialFormState);
    const [selectedMeterId, setSelectedMeterId] = useState('');
    const [error, setError] = useState('');
    const { accessibleZoneIds, canSeeAllZones } = useZoneAccess(currentUser);

    // Logic for "Create Mode": List assets that don't have a meter yet
    const assetsWithNoMeter = useMemo(() => {
        if (!context || !currentUser) return [];
        
        return context.data.assets.filter(asset => {
            const hasNoMeter = !asset.meterId;
            
            // Access Check: User has global or zone-specific access
            // Requirement: Planners can ONLY access assets in their linked zones.
            const hasZoneAccess = canSeeAllZones || accessibleZoneIds.includes(asset.zoneId);
            
            return hasNoMeter && hasZoneAccess;
        });
    }, [context, currentUser, accessibleZoneIds, canSeeAllZones]);

    // Logic for "Link Mode": List unassigned meters, filtered by Planning Group permissions
    const availableMetersToLink = useMemo(() => {
        if (!context || !currentUser || !assetId) return [];
        const { meters, plannerGroups } = context.data;
        
        // 1. Find the user's planner group
        const userPlannerGroup = plannerGroups.find(pg => pg.userIds.includes(currentUser.id));
        const allowedUserIds = userPlannerGroup ? userPlannerGroup.userIds : [currentUser.id];
        
        // 2. Determine if user has broad access (Admin/Manager)
        const hasBroadAccess = ['Administrator', 'Factory Manager', 'Manager'].includes(currentUser.role);

        return meters.filter(m => {
            // Must be unassigned
            const isUnassigned = !m.assetId;
            // Must be created by someone in their group (or themselves if no group), unless broad access
            const isVisible = hasBroadAccess || allowedUserIds.includes(m.createdBy);
            
            return isUnassigned && isVisible;
        });
    }, [context, currentUser, assetId]);

    // Check if editing allowed for Initial Reading
    const isInitialReadingEditable = useMemo(() => {
        if (!meterToEdit || !context) return true; // New meter or no context
        // Check if meter has any readings in the history
        const hasHistory = context.data.meterReadings.some(r => r.meterId === meterToEdit.id);
        return !hasHistory;
    }, [meterToEdit, context]);

    useEffect(() => {
        if (isOpen) {
            if (assetId) {
                // Link Mode Reset
                setSelectedMeterId('');
            } else if (meterToEdit) {
                // Edit Mode
                setFormData({
                    name: meterToEdit.name,
                    type: meterToEdit.type,
                    lastReading: meterToEdit.lastReading,
                    unitOfMeasure: meterToEdit.unitOfMeasure,
                    assetId: meterToEdit.assetId || '',
                    maxReadingLimit: meterToEdit.maxReadingLimit,
                });
            } else {
                // Create Mode Reset
                setFormData({...initialFormState, assetId: ''});
            }
            setError('');
        }
    }, [isOpen, assetId, meterToEdit]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        let processedValue: string | number | undefined = value;
        
        if (name === 'lastReading' || name === 'maxReadingLimit') {
            if (value === '') {
                processedValue = undefined;
            } else {
                processedValue = Math.max(0, parseFloat(value) || 0);
            }
        }

        setFormData(prev => ({ 
            ...prev, 
            [name]: processedValue
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (assetId) {
            // Link Mode
            if (!selectedMeterId) {
                setError('Please select a meter to link.');
                return;
            }
            onSave({ id: selectedMeterId });
        } else {
            // Create/Edit Mode
            if (!context) return;
            const trimmedName = formData.name.trim();
            if (!trimmedName) {
                setError("Meter name cannot be empty.");
                return;
            }

            // Duplicate check (skip if editing self)
            const isDuplicate = context.data.meters.some(
                meter => 
                    meter.id !== meterToEdit?.id && // Skip self
                    meter.assetId === formData.assetId && 
                    meter.name.toLowerCase() === trimmedName.toLowerCase()
            );

            if (formData.assetId && isDuplicate) {
                setError(`A meter with the name "${trimmedName}" already exists for the selected asset.`);
                return;
            }
            
            const payload = { ...formData, name: trimmedName } as Meter;
            if (meterToEdit) {
                payload.id = meterToEdit.id;
            }
            onSave(payload);
        }
    };
    
    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="add-meter-form">{assetId ? 'Link Meter' : 'Save Meter'}</Button>
        </>
    );

    const title = assetId ? 'Link Existing Meter' : (meterToEdit ? 'Edit Meter' : 'Add New Meter');

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={title} footer={modalFooter}>
            <form id="add-meter-form" onSubmit={handleSubmit} className="space-y-4">
                {assetId ? (
                    // --- LINK MODE (Inside Asset Detail) ---
                    <div>
                        <label htmlFor="selectedMeterId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Select Unassigned Meter</label>
                        <select 
                            id="selectedMeterId" 
                            value={selectedMeterId} 
                            onChange={(e) => setSelectedMeterId(e.target.value)} 
                            required 
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                        >
                            <option value="">-- Select Meter --</option>
                            {availableMetersToLink.map(m => (
                                <option key={m.id} value={m.id}>{m.name} ({m.unitOfMeasure}) - Created by: {context?.data.users.find(u => u.id === m.createdBy)?.name || m.createdBy}</option>
                            ))}
                        </select>
                        {availableMetersToLink.length === 0 && (
                            <p className="text-sm text-red-500 mt-2">No unassigned meters available. Please create a new meter in the 'Asset Meters' main view first.</p>
                        )}
                        {error && <p className="text-sm text-red-600 dark:text-red-400 mt-1">{error}</p>}
                    </div>
                ) : (
                    // --- CREATE/EDIT MODE (Inside All Meters List) ---
                    <>
                        <div>
                            <label htmlFor="assetId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Asset</label>
                            <select id="assetId" name="assetId" value={formData.assetId} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                <option value="">None (Unassigned)</option>
                                {assetsWithNoMeter.map(asset => (
                                    <option key={asset.id} value={asset.id}>{asset.name} ({asset.id})</option>
                                ))}
                                {/* If editing and assigned asset is not in "no meter" list (because it has THIS meter), add it manually */}
                                {meterToEdit && meterToEdit.assetId && !assetsWithNoMeter.some(a => a.id === meterToEdit.assetId) && (
                                    <option key={meterToEdit.assetId} value={meterToEdit.assetId}>
                                        {context?.data.assets.find(a => a.id === meterToEdit.assetId)?.name} ({meterToEdit.assetId})
                                    </option>
                                )}
                            </select>
                        </div>
                        <div>
                            <Input id="name" name="name" label="Meter Name" value={formData.name} onChange={handleChange} required />
                            {error && <p className="text-sm text-red-600 dark:text-red-400 mt-1">{error}</p>}
                        </div>
                        <div>
                            <label htmlFor="type" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Meter Type</label>
                            <select id="type" name="type" value={formData.type} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                {Object.values(MeterType).map(type => (
                                    <option key={type} value={type}>{type}</option>
                                ))}
                            </select>
                        </div>
                        {formData.type === MeterType.Manual && (
                            <Input 
                                id="maxReadingLimit" 
                                name="maxReadingLimit" 
                                label="Max Expected Usage per Reading (Valuation Limit)" 
                                type="number" 
                                min="0" 
                                value={formData.maxReadingLimit !== undefined ? formData.maxReadingLimit : ''} 
                                onChange={handleChange} 
                                placeholder="Leave empty for no limit"
                                helperText="Enter the maximum expected difference allowed between the new reading and the previous reading."
                            />
                        )}
                        <Input id="unitOfMeasure" name="unitOfMeasure" label="Unit of Measure" value={formData.unitOfMeasure} onChange={handleChange} required placeholder="e.g., Hours, PSI, Cycles" />
                        <Input 
                            id="lastReading" 
                            name="lastReading" 
                            label="Initial Reading" 
                            type="number" 
                            min="0" 
                            value={formData.lastReading} 
                            onChange={handleChange} 
                            disabled={!isInitialReadingEditable}
                            helperText={!isInitialReadingEditable ? "Cannot edit initial reading because meter logs exist." : ""}
                        />
                    </>
                )}
            </form>
        </Modal>
    );
};
