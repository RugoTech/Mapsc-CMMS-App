import React, { useState, useEffect, useContext, useCallback } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { BomItem } from '../../types';

interface BomItemFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: BomItem) => void;
  itemToEdit: BomItem | null;
  allAssetBomItems: BomItem[];
  assetId: string;
}

export const BomItemForm: React.FC<BomItemFormProps> = ({ isOpen, onClose, onSave, itemToEdit, allAssetBomItems, assetId }) => {
    const context = useContext(DataContext);
    
    const getInitialState = useCallback((): Omit<BomItem, 'id'> => {
        const firstPart = context?.data.parts[0];
        return {
            assetId: assetId,
            partId: firstPart?.id || '',
            quantity: 1,
            unitOfMeasure: firstPart?.unitOfMeasure || 'pcs',
            notes: '',
            parentId: null,
        }
    }, [assetId, context]);

    const [formData, setFormData] = useState<Omit<BomItem, 'id'> & { id?: string }>(getInitialState());

    useEffect(() => {
        if (isOpen) {
            setFormData(itemToEdit ? itemToEdit : getInitialState());
        }
    }, [itemToEdit, isOpen, getInitialState]);
    
    useEffect(() => {
        if (!context) return;
        const part = context.data.parts.find(p => p.id === formData.partId);
        if (part) {
            setFormData(prev => ({...prev, unitOfMeasure: part.unitOfMeasure}));
        }
    }, [formData.partId, context]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        const isNumber = name === 'quantity';
        const finalValue = name === 'parentId' && value === 'null' ? null : value;
        setFormData(prev => ({ ...prev, [name]: isNumber ? Number(value) : finalValue }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData as BomItem);
    };
    
    if (!context) return null;
    const { parts } = context.data;
    
    const getDescendants = (itemId: string, items: BomItem[]): string[] => {
        const children = items.filter(i => i.parentId === itemId);
        let descendants = children.map(c => c.id);
        children.forEach(c => {
            descendants.push(...getDescendants(c.id, items));
        });
        return descendants;
    };

    const descendantIds = itemToEdit ? getDescendants(itemToEdit.id, allAssetBomItems) : [];
    const possibleParents = allAssetBomItems.filter(item => item.id !== itemToEdit?.id && !descendantIds.includes(item.id));
    
    const modalFooter = (
        <>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="bom-item-form">{itemToEdit ? 'Save Changes' : 'Add Item'}</Button>
        </>
    );

    const selectClasses = "mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md";
    const textareaClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={itemToEdit ? 'Edit BOM Item' : 'Add BOM Item'} footer={modalFooter}>
            <form id="bom-item-form" onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="partId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Part</label>
                    <select id="partId" name="partId" value={formData.partId} onChange={handleChange} required className={selectClasses}>
                        {parts.map(part => (
                            <option key={part.id} value={part.id}>{part.name} ({part.partNumber})</option>
                        ))}
                    </select>
                </div>
                <Input label="Quantity" id="quantity" name="quantity" type="number" value={formData.quantity} onChange={handleChange} required min="1" />
                <Input label="Unit of Measure" id="unitOfMeasure" name="unitOfMeasure" value={formData.unitOfMeasure} onChange={handleChange} required />
                <div>
                    <label htmlFor="parentId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Parent Assembly</label>
                    <select id="parentId" name="parentId" value={formData.parentId || 'null'} onChange={handleChange} className={selectClasses}>
                        <option value="null">None (Top Level)</option>
                        {possibleParents.map(parentItem => {
                            const parentPart = parts.find(p => p.id === parentItem.partId);
                            return <option key={parentItem.id} value={parentItem.id}>{parentPart?.name}</option>
                        })}
                    </select>
                </div>
                <div>
                    <label htmlFor="notes" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Notes</label>
                    <textarea id="notes" name="notes" value={formData.notes || ''} onChange={handleChange} rows={3} className={textareaClasses}></textarea>
                </div>
            </form>
        </Modal>
    );
};