
import React, { useState, useContext, useEffect, useCallback, useMemo } from 'react';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DataContext } from '../../contexts/DataContext';
import type { Asset, User } from '../../types';
import { AssetStatus } from '../../types';

interface AddAssetFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (asset: Asset) => void;
  assetToEdit?: Asset | null;
  currentUser: User | null;
}

export const AddAssetForm: React.FC<AddAssetFormProps> = ({ isOpen, onClose, onSave, assetToEdit, currentUser }) => {
    const context = useContext(DataContext);
    
    const getInitialState = useCallback((): Asset => {
        if (!context) {
            // This is a fallback, should ideally not be reached if context is available.
            return {
                id: `ASSET-000`, name: '', type: '', manufacturer: '', model: '', serialNumber: '',
                plantId: '', zoneId: '', areaId: '', purchaseDate: '', cost: 0, status: AssetStatus.Operational,
                meterReading: 0, underWarranty: false, warrantyExpiryDate: '', custodianId: '', meterId: '', createdBy: '',
            };
        }
        const { data } = context;

        return {
            id: `ASSET-${String(data.assets.length + 1).padStart(3, '0')}`,
            name: '',
            type: '',
            manufacturer: '',
            model: '',
            serialNumber: '',
            plantId: '',
            zoneId: '',
            areaId: '',
            purchaseDate: '',
            cost: 0,
            status: AssetStatus.Operational,
            meterReading: 0,
            underWarranty: false,
            warrantyExpiryDate: '',
            custodianId: '',
            meterId: '',
            createdBy: currentUser?.id || '',
        };
    }, [context, currentUser]);

    const [asset, setAsset] = useState<Asset | null>(null);

    useEffect(() => {
        if (isOpen) {
            if (assetToEdit) {
                setAsset(assetToEdit);
            } else {
                setAsset(getInitialState());
            }
        }
    }, [isOpen, assetToEdit, getInitialState]);

    const { data } = context || {};
    const { assets, meters, plannerGroups, plants, zones, areas } = data || {};

    const assignedMeterIds = useMemo(() => 
        new Set(
            (assets || [])
                .map(a => a.meterId)
                .filter((id): id is string => !!id)
        ), 
    [assets]);
    
    const availableMeters = useMemo(() => {
        if (!meters) return [];
        return meters.filter(meter => {
            // Available if not assigned
            if (!assignedMeterIds.has(meter.id)) {
                return true;
            }
            // Also available if it's assigned to the asset we are currently editing
            if (assetToEdit && assetToEdit.meterId === meter.id) {
                return true;
            }
            return false;
        });
    }, [meters, assignedMeterIds, assetToEdit]);


    if (!context || !asset || !assets || !meters || !plannerGroups || !plants || !zones || !areas) return null;
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        
        setAsset(prev => {
            if (!prev) return null;

            let processedValue: string | number | boolean = value;
            
            if (name === 'meterReading') {
                // This case essentially becomes dead code for user interaction as the field is disabled,
                // but kept for robust logic.
                processedValue = Math.max(0, parseFloat(value) || 0);
            } else if (name === 'underWarranty') {
                processedValue = value === 'true';
            } else if (name === 'meterId') {
                // When meter ID changes, update reading automatically
                const selectedMeter = meters.find(m => m.id === value);
                // If a meter is selected, update the reading. 
                // Note: We are updating 'prev' copy below, so we need to handle this side-effect.
                // However, React state updates are batched. We can just let the newState calculation handle it.
            }

            const newState = {
                ...prev,
                [name]: processedValue,
            };
            
            // Logic: Update Meter Reading based on Meter Selection
            if (name === 'meterId') {
                const selectedMeter = meters.find(m => m.id === value);
                if (selectedMeter) {
                    newState.meterReading = selectedMeter.lastReading;
                } else {
                    newState.meterReading = 0; // Reset if "None" selected
                }
            }
            
            // If warranty is set to 'No', clear the expiry date
            if (name === 'underWarranty' && value === 'false') {
                newState.warrantyExpiryDate = '';
            }

            // Cascading logic
            if (name === 'plantId') {
                newState.zoneId = '';
                newState.areaId = '';
            }
            if (name === 'zoneId') {
                newState.areaId = '';
                
                // Auto-fill Planning Group based on Zone selection
                const selectedZoneId = processedValue as string;
                const zone = zones.find(z => z.id === selectedZoneId);
                
                if (zone && zone.planningGroupId) {
                    newState.custodianId = zone.planningGroupId;
                } else {
                    // Fallback logic if zone doesn't have a strict planning group assigned
                    const existingAsset = assets.find(a => a.zoneId === selectedZoneId);
                    const targetPlannerId = existingAsset ? existingAsset.custodianId : (selectedZoneId === 'ZONE-02' ? 'PG-02' : 'PG-01');
                    if (plannerGroups.some(pg => pg.id === targetPlannerId)) {
                        newState.custodianId = targetPlannerId;
                    }
                }
            }

            return newState;
        });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (asset) {
            onSave(asset);
            onClose();
        }
    };
    
    const modalFooter = (
        <>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
            <Button type="submit" form="add-asset-form">{assetToEdit ? 'Save Changes' : 'Save Asset'}</Button>
        </>
    );
    
    const filteredZones = asset.plantId ? zones.filter(z => z.plantId === asset.plantId) : [];
    const filteredAreas = asset.zoneId ? areas.filter(a => a.zoneId === asset.zoneId) : [];

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={assetToEdit ? 'Edit Asset' : 'Add New Asset'} footer={modalFooter}>
            <form onSubmit={handleSubmit} id="add-asset-form" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input id="id" name="id" label="Asset ID" type="text" value={asset.id} onChange={handleChange} required disabled={!!assetToEdit}/>
                    <Input id="name" name="name" label="Asset Name/Description" type="text" value={asset.name} onChange={handleChange} required />
                    <Input id="type" name="type" label="Asset Type/Category" type="text" value={asset.type} onChange={handleChange} required />
                    <Input id="manufacturer" name="manufacturer" label="Manufacturer" type="text" value={asset.manufacturer} onChange={handleChange} />
                    <Input id="model" name="model" label="Model" type="text" value={asset.model} onChange={handleChange} />
                    <Input id="serialNumber" name="serialNumber" label="Serial Number" type="text" value={asset.serialNumber} onChange={handleChange} />
                    <Input id="purchaseDate" name="purchaseDate" label="Purchase Date" type="date" value={asset.purchaseDate} onChange={handleChange} required />
                    <Input 
                        id="meterReading" 
                        name="meterReading" 
                        label="Meter Reading" 
                        type="number" 
                        min="0" 
                        value={asset.meterReading} 
                        onChange={handleChange} 
                        disabled // Always disabled as per requirement
                        helperText="Auto-populated from connected meter."
                    />
                    
                    <div>
                        <label htmlFor="underWarranty" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Warranty</label>
                        <select id="underWarranty" name="underWarranty" value={String(asset.underWarranty)} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                            <option value="false">No</option>
                            <option value="true">Yes</option>
                        </select>
                    </div>

                    <Input
                        id="warrantyExpiryDate"
                        name="warrantyExpiryDate"
                        label="Warranty Expiry Date"
                        type="date"
                        value={asset.warrantyExpiryDate || ''}
                        onChange={handleChange}
                        disabled={!asset.underWarranty}
                    />

                    <div>
                        <label htmlFor="plantId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Plant</label>
                        <select id="plantId" name="plantId" value={asset.plantId} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                            <option value="" disabled>Select a plant...</option>
                            {plants.map(plant => (
                                <option key={plant.id} value={plant.id}>{plant.name}</option>
                            ))}
                        </select>
                    </div>

                     <div>
                        <label htmlFor="zoneId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Zone</label>
                        <select id="zoneId" name="zoneId" value={asset.zoneId} onChange={handleChange} required disabled={!asset.plantId} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md disabled:bg-gray-100 dark:disabled:bg-gray-800">
                            <option value="" disabled>Select a zone...</option>
                            {filteredZones.map(zone => (
                                <option key={zone.id} value={zone.id}>{zone.name}</option>
                            ))}
                        </select>
                    </div>

                     <div>
                        <label htmlFor="areaId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Area</label>
                        <select id="areaId" name="areaId" value={asset.areaId} onChange={handleChange} required disabled={!asset.zoneId} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md disabled:bg-gray-100 dark:disabled:bg-gray-800">
                            <option value="" disabled>Select an area...</option>
                            {filteredAreas.map(area => (
                                <option key={area.id} value={area.id}>{area.name}</option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label htmlFor="status" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Current Status</label>
                        <select id="status" name="status" value={asset.status} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                            {Object.values(AssetStatus).map(status => (
                                <option key={status} value={status}>{status}</option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label htmlFor="custodianId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Planning Group</label>
                        <select id="custodianId" name="custodianId" value={asset.custodianId} onChange={handleChange} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                            <option value="" disabled>Select a planning group...</option>
                            {plannerGroups.map(group => (
                                <option key={group.id} value={group.id}>{group.name}</option>
                            ))}
                        </select>
                    </div>
                </div>
                 <div>
                    <label htmlFor="meterId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Connect to Meter (Optional)</label>
                    <select id="meterId" name="meterId" value={asset.meterId || ''} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                        <option value="">None</option>
                        {availableMeters.map(meter => (
                            <option key={meter.id} value={meter.id}>{meter.name} ({meter.id})</option>
                        ))}
                    </select>
                </div>
            </form>
        </Modal>
    );
};
