
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import type { Meter, User, AuditLogEntry, PreventiveMaintenance } from '../../types';
import { MeterType } from '../../types';
import { AddMeterForm } from './AddMeterForm';
import { MeterLogModal } from './MeterLogModal';
import { ConfirmationModal } from '../ui/ConfirmationModal';

interface AllMetersListProps {
    currentUser: User | null;
}

export const AllMetersList: React.FC<AllMetersListProps> = ({ currentUser }) => {
  const context = useContext(DataContext);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedMeter, setSelectedMeter] = useState<Meter | null>(null);
  const [meterToEdit, setMeterToEdit] = useState<Meter | null>(null);
  const [meterToToggle, setMeterToToggle] = useState<Meter | null>(null);
  const [toggleWarning, setToggleWarning] = useState<React.ReactNode | null>(null);
  
  const [filters, setFilters] = useState({
    name: '',
    asset: '',
    type: '',
  });

  if (!context || !currentUser) return <div>Loading...</div>;

  const { data, setData } = context;
  const { meters, assets } = data;
  
  const getAssetName = useCallback((assetId: string) => assets.find(a => a.id === assetId)?.name || 'N/A', [assets]);
  
  const handleSaveMeter = (meterData: Partial<Meter>) => {
    setData(prevData => {
      let updatedMeters;
      let updatedAssets = prevData.assets;
      let logAction = 'CREATE';
      let logDetails = '';
      let entityId = '';

      if (meterData.id) {
          // Edit Existing Meter
          logAction = 'UPDATE';
          entityId = meterData.id;
          logDetails = `Updated meter '${meterData.name}' (${meterData.id}).`;
          
          updatedMeters = prevData.meters.map(m => 
              m.id === meterData.id ? { ...m, ...meterData } : m
          );

          // Handle Asset Re-assignment if changed
          if (meterData.assetId !== undefined) {
              // 1. Remove meterId from old asset if it was assigned elsewhere
              updatedAssets = updatedAssets.map(a => a.meterId === meterData.id ? { ...a, meterId: undefined } : a);
              
              // 2. Assign to new asset if one is selected
              if (meterData.assetId) {
                  updatedAssets = updatedAssets.map(a => a.id === meterData.assetId ? { ...a, meterId: meterData.id! } : a);
              }
          }
      } else {
          // Create New Meter
          const newMeterId = `MTR-${String(prevData.meters.length + 1).padStart(3, '0')}`;
          entityId = newMeterId;
          logDetails = `Created new meter '${meterData.name}' (${newMeterId}).`;

          const newMeter: Meter = {
            id: newMeterId,
            lastReadingDate: new Date().toISOString().split('T')[0],
            createdBy: currentUser!.id,
            name: meterData.name!,
            type: meterData.type!,
            lastReading: meterData.lastReading || 0,
            unitOfMeasure: meterData.unitOfMeasure!,
            assetId: meterData.assetId || '',
            isActive: true,
            maxReadingLimit: meterData.maxReadingLimit,
          };
          
          updatedMeters = [...prevData.meters, newMeter];

          if (newMeter.assetId) {
              updatedAssets = prevData.assets.map(asset => {
                if (asset.id === newMeter.assetId) {
                  return { ...asset, meterId: newMeterId };
                }
                return asset;
              });
          }
      }

      const logEntry: AuditLogEntry = {
        id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
        timestamp: new Date().toISOString(),
        userId: currentUser.id,
        action: logAction,
        entityType: 'Meter',
        entityId: entityId,
        details: logDetails,
        status: 'Success'
      };

      return {
        ...prevData,
        assets: updatedAssets,
        meters: updatedMeters,
        auditLog: [logEntry, ...prevData.auditLog]
      };
    });
    setIsAddModalOpen(false);
    setMeterToEdit(null);
  };

  const handleViewLog = (meter: Meter) => {
    setSelectedMeter(meter);
  };

  const handleCloseLog = () => {
    setSelectedMeter(null);
  };
  
  const handleEditClick = (meter: Meter) => {
      setMeterToEdit(meter);
      setIsAddModalOpen(true);
  };

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilters({ name: '', asset: '', type: '' });
  };

  const filteredMeters = useMemo(() => {
    return meters.filter(meter => {
        const nameMatch = filters.name ? meter.name.toLowerCase().includes(filters.name.toLowerCase()) : true;
        
        const assetName = getAssetName(meter.assetId);
        const assetMatch = filters.asset 
            ? assetName.toLowerCase().includes(filters.asset.toLowerCase()) || meter.assetId.toLowerCase().includes(filters.asset.toLowerCase())
            : true;
        
        const typeMatch = filters.type ? meter.type === filters.type : true;

        return nameMatch && assetMatch && typeMatch;
    });
  }, [meters, filters, getAssetName]);

  const handleToggleClick = (meter: Meter) => {
      // If currently active (true or undefined), we are deactivating it.
      // Check for linked PMs.
      const isActive = meter.isActive ?? true;
      
      if (isActive) {
          const linkedPMs = data.preventiveMaintenances.filter(
              pm => pm.triggerType === 'Meter' && pm.meterId === meter.id
          );
          
          if (linkedPMs.length > 0) {
              setToggleWarning(
                  <div>
                      <p className="mb-2 font-semibold text-red-600">Warning: This meter is linked to the following active PM plans:</p>
                      <ul className="list-disc pl-5 mb-4 text-sm">
                          {linkedPMs.map(pm => (
                              <li key={pm.id}>{pm.name} ({pm.id})</li>
                          ))}
                      </ul>
                      <p>Deactivating this meter will prevent these plans from generating future work orders based on usage.</p>
                  </div>
              );
          } else {
              setToggleWarning(null);
          }
      } else {
          setToggleWarning(null);
      }
      setMeterToToggle(meter);
  };

  const confirmToggleStatus = () => {
      if (!meterToToggle) return;
      
      setData(prevData => {
          const updatedMeters = prevData.meters.map(m => 
              m.id === meterToToggle.id ? { ...m, isActive: !(m.isActive ?? true) } : m
          );
          
          const action = (meterToToggle.isActive ?? true) ? 'DEACTIVATE' : 'ACTIVATE';
          const logEntry: AuditLogEntry = {
            id: `LOG-${String(prevData.auditLog.length + 1).padStart(3, '0')}`,
            timestamp: new Date().toISOString(),
            userId: currentUser.id,
            action: 'UPDATE',
            entityType: 'Meter',
            entityId: meterToToggle.id,
            details: `${action === 'ACTIVATE' ? 'Activated' : 'Deactivated'} meter '${meterToToggle.name}'.`,
            status: 'Success'
          };

          return {
              ...prevData,
              meters: updatedMeters,
              auditLog: [logEntry, ...prevData.auditLog]
          };
      });
      setMeterToToggle(null);
      setToggleWarning(null);
  };

  const columns = [
    { header: 'Meter Name', accessor: 'name' as keyof Meter },
    { 
      header: 'Asset', 
      accessor: (item: Meter) => getAssetName(item.assetId)
    },
    { 
      header: 'Type',
      accessor: (item: Meter) => (
        <Badge color={item.type === MeterType.Automatic ? 'blue' : 'gray'}>{item.type}</Badge>
      )
    },
    { header: 'Last Reading', accessor: 'lastReading' as keyof Meter },
    { header: 'Unit', accessor: 'unitOfMeasure' as keyof Meter },
    { header: 'Date Read', accessor: 'lastReadingDate' as keyof Meter },
    { 
        header: 'Status', 
        accessor: (item: Meter) => (
            <Badge color={item.isActive ?? true ? 'green' : 'red'}>
                {item.isActive ?? true ? 'Active' : 'Inactive'}
            </Badge>
        )
    },
  ];

  const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

  return (
    <>
        <Card title="All Asset Meters" actions={currentUser?.role === 'Planner' && <Button onClick={() => { setMeterToEdit(null); setIsAddModalOpen(true); }}>Add Meter</Button>}>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="name-filter" className={filterLabelClasses}>Meter Name</label>
                    <input type="text" id="name-filter" name="name" value={filters.name} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search name..."/>
                </div>
                <div>
                    <label htmlFor="asset-filter" className={filterLabelClasses}>Asset</label>
                    <input type="text" id="asset-filter" name="asset" value={filters.asset} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search asset name or ID..."/>
                </div>
                <div>
                    <label htmlFor="type-filter" className={filterLabelClasses}>Type</label>
                    <select id="type-filter" name="type" value={filters.type} onChange={handleFilterChange} className={filterInputClasses}>
                        <option value="">All Types</option>
                        {Object.values(MeterType).map(type => <option key={type} value={type}>{type}</option>)}
                    </select>
                </div>
                <div className="flex items-end">
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>
            {meters.length > 0 ? (
                <Table<Meter>
                    columns={columns}
                    data={filteredMeters}
                    renderRowActions={(meter) => (
                        <div className="space-x-2">
                            <Button variant="secondary" size="sm" onClick={() => handleViewLog(meter)}>
                                View Log
                            </Button>
                            {(currentUser?.role === 'Planner' || currentUser?.role === 'Administrator') && (
                                <>
                                    <Button variant="secondary" size="sm" onClick={() => handleEditClick(meter)}>
                                        Edit
                                    </Button>
                                    <Button 
                                        variant={(meter.isActive ?? true) ? 'danger' : 'secondary'} 
                                        size="sm" 
                                        onClick={() => handleToggleClick(meter)}
                                    >
                                        {(meter.isActive ?? true) ? 'Deactivate' : 'Activate'}
                                    </Button>
                                </>
                            )}
                        </div>
                    )}
                />
            ) : (
                <p className="text-gray-500 dark:text-gray-400">No meters have been created in the system.</p>
            )}
        </Card>
        <AddMeterForm
            isOpen={isAddModalOpen}
            onClose={() => setIsAddModalOpen(false)}
            onSave={handleSaveMeter}
            currentUser={currentUser}
            meterToEdit={meterToEdit}
        />
        {selectedMeter && (
            <MeterLogModal 
                isOpen={!!selectedMeter}
                onClose={handleCloseLog}
                meter={selectedMeter}
                currentUser={currentUser}
            />
        )}
        {meterToToggle && (
            <ConfirmationModal
                isOpen={!!meterToToggle}
                onClose={() => { setMeterToToggle(null); setToggleWarning(null); }}
                onConfirm={confirmToggleStatus}
                title={`Confirm Meter ${(meterToToggle.isActive ?? true) ? 'Deactivation' : 'Activation'}`}
                confirmText={(meterToToggle.isActive ?? true) ? 'Deactivate' : 'Activate'}
                confirmButtonVariant={(meterToToggle.isActive ?? true) ? 'danger' : 'primary'}
            >
                {toggleWarning ? toggleWarning : (
                    <p>Are you sure you want to {(meterToToggle.isActive ?? true) ? 'deactivate' : 'activate'} the meter <span className="font-bold">{meterToToggle.name}</span>?</p>
                )}
            </ConfirmationModal>
        )}
    </>
  );
};