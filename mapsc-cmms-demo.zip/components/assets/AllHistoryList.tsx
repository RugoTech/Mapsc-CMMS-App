
import React, { useContext, useState, useMemo, useCallback } from 'react';
import { DataContext } from '../../contexts/DataContext';
import { Card } from '../ui/Card';
import { Table } from '../ui/Table';
import { Button } from '../ui/Button';
import { WorkOrder, TransactionType, WorkOrderStatus, POStatus } from '../../types';
import { useSettings } from '../../contexts/SettingsContext';
import { useCurrencyFormatter } from '../../hooks/useCurrency';
import { Modal } from '../ui/Modal';

// Printable Component
const PrintableHistoryReport: React.FC<{
    workOrders: WorkOrder[];
    totalCost: number;
    filters: { asset: string; dateFrom: string; dateTo: string };
    getAssetName: (id: string) => string;
    calculateTotalCost: (wo: WorkOrder) => number;
    formatCurrency: (value: number) => string;
}> = ({ workOrders, totalCost, filters, getAssetName, calculateTotalCost, formatCurrency }) => {
    return (
        <div className="font-sans text-black bg-white p-8 border-2 border-gray-300 print:border-none min-h-[11in] flex flex-col box-border">
            <div className="flex justify-between items-start mb-6 border-b pb-4">
                <div>
                    <h1 className="text-2xl font-bold uppercase">Maintenance History</h1>
                    <p className="text-sm text-gray-600">System-Wide Report</p>
                </div>
                <div className="text-right text-sm">
                    <p>Generated: {new Date().toLocaleString()}</p>
                </div>
            </div>

            <div className="mb-6 grid grid-cols-2 gap-4 text-sm bg-gray-50 p-4 rounded border">
                <div>
                    <span className="font-bold block">Filters Applied:</span>
                    <p>Asset: {filters.asset || 'All'}</p>
                    <p>Date Range: {filters.dateFrom || 'Start'} to {filters.dateTo || 'End'}</p>
                </div>
                <div className="text-right">
                    <span className="font-bold block">Total Maintenance Cost:</span>
                    <p className="text-xl font-bold">{formatCurrency(totalCost)}</p>
                </div>
            </div>

            <table className="w-full text-xs border-collapse border border-gray-300">
                <thead>
                    <tr className="bg-gray-100">
                        <th className="border border-gray-300 p-2 text-left">WO ID</th>
                        <th className="border border-gray-300 p-2 text-left">Asset</th>
                        <th className="border border-gray-300 p-2 text-left">Description</th>
                        <th className="border border-gray-300 p-2 text-left">Date</th>
                        <th className="border border-gray-300 p-2 text-right">Labor (Hrs)</th>
                        <th className="border border-gray-300 p-2 text-right">Total Cost</th>
                    </tr>
                </thead>
                <tbody>
                    {workOrders.map(wo => (
                        <tr key={wo.id}>
                            <td className="border border-gray-300 p-2">{wo.id}</td>
                            <td className="border border-gray-300 p-2">{getAssetName(wo.assetId || '')}</td>
                            <td className="border border-gray-300 p-2">{wo.description}</td>
                            <td className="border border-gray-300 p-2">{wo.dueDate}</td>
                            <td className="border border-gray-300 p-2 text-right">{wo.laborHours.toFixed(2)}</td>
                            <td className="border border-gray-300 p-2 text-right font-medium">{formatCurrency(calculateTotalCost(wo))}</td>
                        </tr>
                    ))}
                    {workOrders.length === 0 && (
                        <tr>
                            <td colSpan={6} className="border border-gray-300 p-4 text-center italic text-gray-500">No records found.</td>
                        </tr>
                    )}
                </tbody>
            </table>
            
            <div className="mt-auto pt-4 text-xs text-center border-t text-gray-500">
                Mapsc CMMS Report
            </div>
        </div>
    );
};

export const AllHistoryList: React.FC = () => {
  const context = useContext(DataContext);
  const { settings } = useSettings();
  const formatCurrency = useCurrencyFormatter(); // Formats number to system currency string
  
  const [filters, setFilters] = useState({
    asset: '',
    dateFrom: '',
    dateTo: '',
  });
  
  const [isPrintPreviewOpen, setIsPrintPreviewOpen] = useState(false);

  if (!context) return <div>Loading...</div>;

  const { workOrders, parts, assets, inventoryTransactions, laborLogs, purchaseRequisitions, rfqs, purchaseOrders } = context.data;

  const getAssetName = useCallback((assetId: string) => assets.find(a => a.id === assetId)?.name || 'N/A', [assets]);
  const getPartName = (partId: string) => parts.find(p => p.id === partId)?.name || 'N/A';
  
  // Helper to convert PO currency to System Default Currency
  const convertToSystemCurrency = useCallback((value: number, fromCurrency: string): number => {
        if (fromCurrency === settings.currency) return value;
        if (fromCurrency === 'USD') return value / (settings.exchangeRate.USD || 1);
        if (fromCurrency === 'EUR') return value / (settings.exchangeRate.EUR || 1);
        return value;
  }, [settings.currency, settings.exchangeRate]);

  const calculateTotalCost = useCallback((wo: WorkOrder) => {
    // 1. Inventory Parts Cost (System Currency)
    const partsCost = inventoryTransactions
        .filter(t => t.workOrderId === wo.id && t.type === TransactionType.Issue)
        .reduce((total, transaction) => {
            const part = parts.find(p => p.id === transaction.partId);
            // Use raw unitCost as it is in system currency
            return total + ((part?.unitCost || 0) * transaction.quantity);
        }, 0);
    
    // 2. Labor Cost (System Currency -> System Currency)
    const laborCost = laborLogs
        .filter(log => log.workOrderId === wo.id)
        .reduce((sum, log) => {
            const duration = (new Date(log.endTime).getTime() - new Date(log.startTime).getTime()) / (1000 * 60 * 60);
            return sum + (duration * settings.laborRatePerHour);
        }, 0);
    
    // 3. External PO Cost (PO Currency -> System Currency)
    // Find linked PRs -> RFQs -> POs
    const linkedPRs = purchaseRequisitions.filter(pr => pr.workOrderId === wo.id);
    const linkedPRIds = new Set(linkedPRs.map(pr => pr.id));
    const linkedRFQs = rfqs.filter(rfq => linkedPRIds.has(rfq.prId));
    const linkedRFQIds = new Set(linkedRFQs.map(rfq => rfq.id));
    
    // Only count cost for POs that are Received, Closed, or Partially Received
    const linkedPOs = purchaseOrders.filter(po => 
        linkedRFQIds.has(po.rfqId) && 
        (po.status === POStatus.Received || po.status === POStatus.Closed || po.status === POStatus.PartiallyReceived)
    );

    const externalCost = linkedPOs.reduce((sum, po) => {
        // Calculate actual received cost
        const receivedTotal = po.items.reduce((itemSum, item) => {
            return itemSum + (item.quantityReceived * item.unitCost);
        }, 0);
        const totalWithTax = receivedTotal * (1 + po.taxRate);
        return sum + convertToSystemCurrency(totalWithTax, po.currency);
    }, 0);
        
    return partsCost + laborCost + externalCost;
  }, [inventoryTransactions, parts, laborLogs, settings.laborRatePerHour, purchaseRequisitions, rfqs, purchaseOrders, convertToSystemCurrency]);
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilters({ asset: '', dateFrom: '', dateTo: '' });
  };

  const filteredWorkOrders = useMemo(() => {
    return workOrders
        .filter(wo => wo.status === WorkOrderStatus.Completed || wo.status === WorkOrderStatus.Archived)
        .filter(wo => {
            if (!wo.assetId) return false;
            const assetName = getAssetName(wo.assetId);
            const assetMatch = filters.asset ? assetName.toLowerCase().includes(filters.asset.toLowerCase()) : true;
            
            const dateFromMatch = filters.dateFrom ? wo.dueDate >= filters.dateFrom : true;
            const dateToMatch = filters.dateTo ? wo.dueDate <= filters.dateTo : true;

            return assetMatch && dateFromMatch && dateToMatch;
        })
        .sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime());
  }, [workOrders, filters, getAssetName]);

  const totalMaintenanceCost = useMemo(() => {
      return filteredWorkOrders.reduce((total, wo) => total + calculateTotalCost(wo), 0);
  }, [filteredWorkOrders, calculateTotalCost]);

  const columns = [
    { header: 'WO ID', accessor: 'id' as keyof WorkOrder },
    { header: 'Asset', accessor: (item: WorkOrder) => getAssetName(item.assetId!) },
    { header: 'Description', accessor: 'description' as keyof WorkOrder },
    { header: 'Date Completed', accessor: 'dueDate' as keyof WorkOrder },
    {
        header: 'Parts Used',
        accessor: (item: WorkOrder) => {
            const issuedParts = inventoryTransactions.filter(t => t.workOrderId === item.id && t.type === TransactionType.Issue);
            return (
                <ul className="text-xs list-disc pl-3">
                    {issuedParts.length > 0 ? issuedParts.map(p => (
                        <li key={p.id}>{p.quantity} x {getPartName(p.partId)}</li>
                    )) : <span className="text-gray-400">None</span>}
                </ul>
            )
        }
    },
    { header: 'Labor Hours', accessor: (item: WorkOrder) => item.laborHours.toFixed(2) },
    {
        header: 'Total Cost',
        accessor: (item: WorkOrder) => formatCurrency(calculateTotalCost(item))
    },
  ];

  const filterInputClasses = "mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm";
  const filterLabelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300";

  const handlePrintConfirm = () => {
      setIsPrintPreviewOpen(false);
      setTimeout(() => {
          window.print();
      }, 200);
  };

  return (
    <>
        <Card 
            title="System-Wide Maintenance History"
            actions={<Button variant="secondary" onClick={() => setIsPrintPreviewOpen(true)}>Print</Button>}
        >
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                    <label htmlFor="asset-filter" className={filterLabelClasses}>Asset</label>
                    <input type="text" id="asset-filter" name="asset" value={filters.asset} onChange={handleFilterChange} className={filterInputClasses} placeholder="Search asset name..."/>
                </div>
                <div>
                    <label htmlFor="dateFrom-filter" className={filterLabelClasses}>Date Completed (From)</label>
                    <input type="date" id="dateFrom-filter" name="dateFrom" value={filters.dateFrom} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div>
                    <label htmlFor="dateTo-filter" className={filterLabelClasses}>Date Completed (To)</label>
                    <input type="date" id="dateTo-filter" name="dateTo" value={filters.dateTo} onChange={handleFilterChange} className={filterInputClasses}/>
                </div>
                <div className="flex items-end">
                    <Button onClick={clearFilters} variant="secondary" className="w-full">Clear</Button>
                </div>
            </div>

            <div className="mb-6 p-4 bg-gray-100 dark:bg-gray-700 rounded-lg">
                <h4 className="text-lg font-semibold">Total Maintenance Cost (Filtered)</h4>
                <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{formatCurrency(totalMaintenanceCost)}</p>
                <p className="text-xs text-gray-500 mt-1">Includes Inventory Parts, Labor, and External Purchase Orders.</p>
            </div>
            {filteredWorkOrders.length > 0 ? (
                <Table<WorkOrder>
                    columns={columns}
                    data={filteredWorkOrders}
                />
            ) : (
                <p className="text-gray-500 dark:text-gray-400">No completed work order history found.</p>
            )}
        </Card>

        {/* Print Preview Modal */}
        {isPrintPreviewOpen && (
            <Modal
                isOpen={isPrintPreviewOpen}
                onClose={() => setIsPrintPreviewOpen(false)}
                title="Print Preview: System-Wide Maintenance History"
                size="5xl"
                footer={
                    <div className="flex justify-between w-full">
                        <Button variant="secondary" onClick={() => setIsPrintPreviewOpen(false)}>Cancel</Button>
                        <Button variant="primary" onClick={handlePrintConfirm}>Confirm Print</Button>
                    </div>
                }
            >
                <div className="bg-gray-100 dark:bg-gray-900 p-4 overflow-auto flex justify-center max-h-[70vh]">
                    <div className="transform scale-100 origin-top w-full max-w-[8.5in]">
                        <PrintableHistoryReport 
                            workOrders={filteredWorkOrders}
                            totalCost={totalMaintenanceCost}
                            filters={filters}
                            getAssetName={getAssetName}
                            calculateTotalCost={calculateTotalCost}
                            formatCurrency={formatCurrency}
                        />
                    </div>
                </div>
            </Modal>
        )}

        {/* Hidden Printable Content */}
        <div className="hidden print:block">
            <PrintableHistoryReport 
                workOrders={filteredWorkOrders}
                totalCost={totalMaintenanceCost}
                filters={filters}
                getAssetName={getAssetName}
                calculateTotalCost={calculateTotalCost}
                formatCurrency={formatCurrency}
            />
        </div>
    </>
  );
};
