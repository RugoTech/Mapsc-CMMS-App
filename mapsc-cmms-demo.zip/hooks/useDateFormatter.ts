
import { useCallback } from 'react';
import { useSettings } from '../contexts/SettingsContext';

export const useDateFormatter = () => {
    const { settings } = useSettings();

    const formatDate = useCallback((dateValue: string | Date | undefined | null): string => {
        if (!dateValue) return '';

        const date = typeof dateValue === 'string' ? new Date(dateValue) : dateValue;
        
        // Check for invalid date
        if (isNaN(date.getTime())) return String(dateValue);

        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();

        switch (settings.dateFormat) {
            case 'DD/MM/YYYY':
                return `${day}/${month}/${year}`;
            case 'MM/DD/YYYY':
                return `${month}/${day}/${year}`;
            case 'YYYY-MM-DD':
                return `${year}-${month}-${day}`;
            default:
                return `${year}-${month}-${day}`;
        }
    }, [settings.dateFormat]);

    return formatDate;
};
