
import { useEffect, useContext, useRef } from 'react';
import { DataContext } from '../contexts/DataContext';
import { User, Message, WorkOrderStatus, ProjectStatus } from '../types';

export const useSystemNotifications = (currentUser: User | null) => {
    const context = useContext(DataContext);
    const processedRef = useRef(false);

    useEffect(() => {
        if (!context || !currentUser || processedRef.current) return;

        const { data, setData } = context;
        const { parts, workOrders, projects, preventiveMaintenances, users } = data;
        
        const newMessages: Message[] = [];
        const now = new Date();
        const today = now.toISOString().split('T')[0];

        // Helper to create message
        const createMsg = (recipientId: string, title: string, body: string) => {
            // Simple de-duplication check based on title and recipient for this session
            const exists = data.messages.some(m => m.recipientId === recipientId && m.title === title && m.date.startsWith(today));
            if (!exists) {
                newMessages.push({
                    id: `MSG-SYS-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
                    sender: 'System',
                    recipientId,
                    title,
                    body,
                    date: new Date().toISOString(),
                    read: false
                });
            }
        };

        // 1. Critical Low Stock -> Notify Logistics Supervisors/Managers
        const lowStockParts = parts.filter(p => (p.isActive ?? true) && p.quantity <= p.reorderPoint);
        if (lowStockParts.length > 0) {
            const recipients = users.filter(u => u.department === 'Logistics' && (u.role === 'Manager' || u.role === 'Supervisor'));
            recipients.forEach(u => {
                createMsg(
                    u.id,
                    'Critical Low Stock Alert',
                    `There are ${lowStockParts.length} parts below reorder point. Please check Inventory Alerts.`
                );
            });
        }

        // 2. Overdue PMs -> Notify Planners
        const overduePMs = preventiveMaintenances.filter(pm => 
            pm.triggerType === 'Calendar' && pm.nextDueDate && pm.nextDueDate < today
        );
        if (overduePMs.length > 0) {
            const planners = users.filter(u => u.role === 'Planner');
            planners.forEach(u => {
                createMsg(
                    u.id,
                    'Overdue PM Schedules',
                    `${overduePMs.length} PM schedules are overdue for generation. Please review Preventive Maintenance.`
                );
            });
        }

        // 3. Overdue Work Orders -> Notify Assigned Users & Planners
        const overdueWOs = workOrders.filter(wo => 
            wo.status !== WorkOrderStatus.Completed && 
            wo.status !== WorkOrderStatus.Archived && 
            wo.dueDate < today
        );
        
        overdueWOs.forEach(wo => {
            // Notify Assigned
            wo.assignedUserIds.forEach(userId => {
                createMsg(
                    userId,
                    `Overdue: WO ${wo.id}`,
                    `Work Order ${wo.id} (${wo.description}) was due on ${wo.dueDate}.`
                );
            });
            // Notify Planners associated (or all planners if simplified)
            const planners = users.filter(u => u.role === 'Planner');
            planners.forEach(u => {
                 createMsg(
                    u.id,
                    `Overdue: WO ${wo.id}`,
                    `Work Order ${wo.id} (${wo.description}) is overdue.`
                );
            });
        });

        // 4. Overdue Projects -> Notify Managers
        const overdueProjects = projects.filter(p => 
            p.status === ProjectStatus.InProgress && p.endDate < today
        );
        if (overdueProjects.length > 0) {
            const managers = users.filter(u => u.role === 'Manager' || u.role === 'Factory Manager');
            managers.forEach(u => {
                createMsg(
                    u.id,
                    'Overdue Projects Alert',
                    `${overdueProjects.length} projects have passed their end date. Please review Project status.`
                );
            });
        }

        if (newMessages.length > 0) {
            setData(prev => ({
                ...prev,
                messages: [...newMessages, ...prev.messages]
            }));
        }

        processedRef.current = true;
    }, [context, currentUser]);
};
