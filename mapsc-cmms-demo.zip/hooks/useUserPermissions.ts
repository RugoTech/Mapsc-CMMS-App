
import { useMemo, useContext } from 'react';
import { DataContext } from '../contexts/DataContext';
import { standaloneRolePermissions, allViews } from '../auth/permissions';
import type { User, View } from '../types';

export const useUserPermissions = (currentUser: User | null): View[] => {
    const context = useContext(DataContext);

    return useMemo(() => {
        if (!currentUser || !context) return [];
        const { data } = context;
        // Use dynamic permissions from state
        const dynamicGroupPermissions = data.groupPermissions;
        
        const permissionSet = new Set<View>();

        // 1. Get permissions from standalone role
        const rolePerms = standaloneRolePermissions[currentUser.role];
        if (rolePerms) {
            rolePerms.forEach(p => permissionSet.add(p));
        }
        
        // If user is in admin group, grant all permissions. This stacks with role permissions.
        if (data.systemAdmins.some(g => g.userIds.includes(currentUser.id))) {
            allViews.forEach(p => permissionSet.add(p));
        }

        // 2. Get permissions from group memberships using dynamic state
        if (data.topManagementGroups.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.TopManagementGroup?.forEach(p => permissionSet.add(p));
        }
        if (data.assetManagers.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.AssetManagers?.forEach(p => permissionSet.add(p));
        }
        if (data.logisticsManagers.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.LogisticsManagers?.forEach(p => permissionSet.add(p));
        }
        if (data.engineers.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.Engineers?.forEach(p => permissionSet.add(p));
        }
        if (data.plannerGroups.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.PlannerGroup?.forEach(p => permissionSet.add(p));
        }
        if (data.logisticsClerks.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.LogisticsClerks?.forEach(p => permissionSet.add(p));
        }
        if (data.maintenanceClerks.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.MaintenanceClerks?.forEach(p => permissionSet.add(p));
        }
        if (data.maintenanceControllers.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.MaintenanceControllers?.forEach(p => permissionSet.add(p));
        }
        if (data.logisticsControllers.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.LogisticsControllers?.forEach(p => permissionSet.add(p));
        }
        if (data.workCenters.some(g => g.userIds.includes(currentUser.id))) {
            dynamicGroupPermissions.WorkCenter?.forEach(p => permissionSet.add(p));
        }
        
        return Array.from(permissionSet);
    }, [currentUser, context]);
};
