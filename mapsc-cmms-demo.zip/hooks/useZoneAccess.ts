
import { useMemo, useContext } from 'react';
import { DataContext } from '../contexts/DataContext';
import type { User } from '../types';

interface ZoneAccess {
    accessibleZoneIds: string[];
    canSeeAllZones: boolean;
}

export const useZoneAccess = (currentUser: User | null): ZoneAccess => {
    const context = useContext(DataContext);
    
    return useMemo(() => {
        if (!currentUser || !context) {
            return { accessibleZoneIds: [], canSeeAllZones: false };
        }

        const { zones, logisticsManagers, assetManagers, topManagementGroups } = context.data;

        // Roles with universal access
        if (currentUser.role === 'Administrator' || currentUser.role === 'Factory Manager') {
            const allZoneIds = zones.map(z => z.id);
            return { accessibleZoneIds: allZoneIds, canSeeAllZones: true };
        }

        // Logistics Managers have full visibility (e.g. for Maintenance Management)
        const isLogisticsManager = logisticsManagers.some(g => g.userIds.includes(currentUser.id));
        if (isLogisticsManager) {
             const allZoneIds = zones.map(z => z.id);
             return { accessibleZoneIds: allZoneIds, canSeeAllZones: true };
        }

        // Asset Managers have full visibility
        const isAssetManager = assetManagers.some(g => g.userIds.includes(currentUser.id));
        if (isAssetManager) {
             const allZoneIds = zones.map(z => z.id);
             return { accessibleZoneIds: allZoneIds, canSeeAllZones: true };
        }

        // Top Management have full visibility
        const isTopManagement = topManagementGroups.some(g => g.userIds.includes(currentUser.id));
        if (isTopManagement) {
             const allZoneIds = zones.map(z => z.id);
             return { accessibleZoneIds: allZoneIds, canSeeAllZones: true };
        }
        
        // Specific hierarchical roles (as defined in the user prompt - legacy support)
        switch (currentUser.id) {
            case 'USER-016': // Mark Manager (ENG-Manager)
                return { accessibleZoneIds: ['ZONE-01', 'ZONE-02', 'ZONE-04'], canSeeAllZones: false };
            case 'USER-001': // Alice Smith (LG-Manager)
                return { accessibleZoneIds: ['ZONE-04'], canSeeAllZones: false };
            case 'USER-011': // Eve Engineer (Utilities Engineer)
                return { accessibleZoneIds: ['ZONE-01', 'ZONE-04'], canSeeAllZones: false };
            case 'USER-012': // Gary Gadget (Packaging Engineer)
                return { accessibleZoneIds: ['ZONE-02'], canSeeAllZones: false };
        }

        // Store Clerks and Logistics Supervisors have full visibility of all zones/inventory.
        if (currentUser.department === 'Logistics' && (currentUser.role === 'Clerk' || currentUser.role === 'Supervisor')) {
            const allZoneIds = context.data.zones.map(z => z.id);
            return { accessibleZoneIds: allZoneIds, canSeeAllZones: true };
        }

        // For all other users, rely on their directly assigned zoneIds
        return {
            accessibleZoneIds: currentUser.zoneIds || [],
            canSeeAllZones: false,
        };

    }, [currentUser, context]);
};
