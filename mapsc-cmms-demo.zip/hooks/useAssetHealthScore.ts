import { useMemo, useContext } from 'react';
import { DataContext } from '../contexts/DataContext';
import { WorkOrder, PreventiveMaintenance, WorkOrderType, Priority, WorkOrderStatus } from '../types';

export type HealthLevel = 'Excellent' | 'Good' | 'Fair' | 'Poor';

export interface AssetHealth {
    score: number;
    level: HealthLevel;
    factors: {
        openCriticalWos: number;
        openHighWos: number;
        recentBreakdowns: number;
        overduePms: number;
    };
}

export const useAssetHealthScore = (assetId: string): AssetHealth => {
    const context = useContext(DataContext);

    return useMemo(() => {
        if (!context) {
            return {
                score: 0,
                level: 'Poor',
                factors: { openCriticalWos: 0, openHighWos: 0, recentBreakdowns: 0, overduePms: 0 },
            };
        }

        const { workOrders, preventiveMaintenances, meters } = context.data;
        let score = 100;
        
        const factors = {
            openCriticalWos: 0,
            openHighWos: 0,
            recentBreakdowns: 0,
            overduePms: 0,
        };

        const now = new Date();
        const ninetyDaysAgo = new Date();
        ninetyDaysAgo.setDate(now.getDate() - 90);

        // 1. Analyze Work Orders for this asset
        const assetWorkOrders = workOrders.filter(wo => wo.assetId === assetId);

        assetWorkOrders.forEach(wo => {
            // Penalty for open work orders
            if (wo.status === WorkOrderStatus.Open || wo.status === WorkOrderStatus.InProgress) {
                if (wo.priority === Priority.Critical) {
                    score -= 25;
                    factors.openCriticalWos++;
                } else if (wo.priority === Priority.High) {
                    score -= 15;
                    factors.openHighWos++;
                } else {
                    score -= 5;
                }
            }

            // Penalty for recent breakdowns/corrective actions
            const woDate = new Date(wo.createdDate);
            if (woDate > ninetyDaysAgo) {
                if (wo.workOrderType === WorkOrderType.Breakdown) {
                    score -= 20;
                    factors.recentBreakdowns++;
                } else if (wo.workOrderType === WorkOrderType.Corrective) {
                    score -= 10;
                }
            }
        });

        // 2. Analyze PM Compliance
        const assetPMs = preventiveMaintenances.filter(pm => pm.assetId === assetId);
        assetPMs.forEach(pm => {
            let isOverdue = false;
            if (pm.triggerType === 'Calendar' && pm.nextDueDate) {
                if (new Date(pm.nextDueDate) < now) {
                    isOverdue = true;
                }
            } else if (pm.triggerType === 'Meter' && pm.meterId && pm.meterTriggerValue) {
                const meter = meters.find(m => m.id === pm.meterId);
                if (meter) {
                    const lastTrigger = pm.lastTriggerReading || 0;
                    const nextTriggerPoint = lastTrigger + pm.meterTriggerValue;
                    if (meter.lastReading >= nextTriggerPoint) {
                        isOverdue = true;
                    }
                }
            }
            if (isOverdue) {
                score -= 15;
                factors.overduePms++;
            }
        });

        const finalScore = Math.max(0, Math.round(score));

        let level: HealthLevel;
        if (finalScore >= 90) level = 'Excellent';
        else if (finalScore >= 70) level = 'Good';
        else if (finalScore >= 50) level = 'Fair';
        else level = 'Poor';
        
        return { score: finalScore, level, factors };

    }, [assetId, context]);
};
