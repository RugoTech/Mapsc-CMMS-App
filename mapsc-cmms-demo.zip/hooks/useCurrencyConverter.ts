import { useMemo } from 'react';
import { useSettings } from '../contexts/SettingsContext';
import { useCurrencyFormatter } from './useCurrency';
import type { CurrencyFormatOptions } from './useCurrency';

// Assume all base values in the database/mockData are in USD.
const BASE_CURRENCY = 'USD';

export const useCurrencyConverter = (options?: CurrencyFormatOptions) => {
    const { settings } = useSettings();
    const formatCurrency = useCurrencyFormatter(options);

    const convert = useMemo(() => {
        // If the display currency is the same as the base currency, no conversion needed.
        if (settings.currency === BASE_CURRENCY) {
            return (value: number) => value;
        }

        // The rate is how many USD for 1 unit of the display currency.
        // e.g., 1 KES = 0.0075 USD. rate = 0.0075.
        // To convert from USD to KES, we divide.
        const rate = settings.exchangeRate.USD;
        if (rate > 0) {
            return (valueInUsd: number) => valueInUsd / rate;
        }
        
        // If we can't convert, return the original value. A warning is logged.
        console.warn(`Cannot convert from ${BASE_CURRENCY} to ${settings.currency}. Exchange rate for USD must be configured and greater than 0.`);
        return (value: number) => value;

    }, [settings.currency, settings.exchangeRate]);

    const convertAndFormat = useMemo(() => {
        return (value: number) => {
            const convertedValue = convert(value);
            return formatCurrency(convertedValue);
        }
    }, [convert, formatCurrency]);

    return { convert, convertAndFormat };
};