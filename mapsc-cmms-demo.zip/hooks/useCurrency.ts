import { useMemo } from 'react';
import { useSettings } from '../contexts/SettingsContext';

export interface CurrencyFormatOptions {
    minimumFractionDigits?: number;
    maximumFractionDigits?: number;
}

export const useCurrencyFormatter = (options?: CurrencyFormatOptions) => {
    const { settings } = useSettings();
    const { minimumFractionDigits = 2, maximumFractionDigits = 2 } = options || {};
    
    const formatCurrency = useMemo(() => {
        let currencyCode = settings.currency;
        try {
            // Test if the currency is supported to avoid errors
            new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode });
        } catch (e) {
            console.warn(`Currency code "${currencyCode}" not supported by Intl.NumberFormat. Falling back to USD.`);
            currencyCode = 'USD';
        }

        return (value: number) => {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: currencyCode,
                minimumFractionDigits,
                maximumFractionDigits,
            }).format(value);
        };

    }, [settings.currency, minimumFractionDigits, maximumFractionDigits]);

    return formatCurrency;
};