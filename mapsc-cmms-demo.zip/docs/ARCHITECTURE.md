
# Application Architecture

This document outlines the technical architecture of the Mapsc CMMS application.

## Frontend Stack

- **Framework**: [React](https://reactjs.org/) (v19) with [TypeScript](https://www.typescriptlang.org/) for robust, type-safe code.
- **Styling**: [Tailwind CSS](https://tailwindcss.com/) for a utility-first styling approach, enabling rapid and consistent UI development. Dark mode is supported.
- **Charts**: [Recharts](https://recharts.org/) for creating responsive and interactive charts in the Reporting & Analytics module.
- **AI Integration**: [Google Gemini API](https://ai.google.dev/) via the `@google/genai` SDK for features like AI-powered troubleshooting.

## State Management

The application utilizes React's built-in Context API for managing global state. This approach was chosen for its simplicity and direct integration with React, avoiding the need for larger third-party libraries like Redux for this project's scale.

The state is divided into three primary contexts:

1.  **`DataContext`**: This is the main "database" of the application. It holds all the mock data (`mockData.ts`) for assets, work orders, parts, users, etc. All components that need to read or modify application data consume this context.

2.  **`SettingsContext`**: This context isolates system-wide settings (e.g., currency, date format, labor rates). This separation makes it easy to manage and apply settings globally without cluttering the main data context.

3.  **`ThemeContext`**: Manages the application's theme (light, dark, or system). It handles applying the correct CSS classes to the root HTML element and persists the user's preference in `localStorage`.

## Folder Structure

The project is organized into the following key directories:

-   **/components**: Contains all React components, further organized by feature/module (e.g., `assets`, `maintenance`, `inventory`).
    -   **/ui**: Reusable, generic UI components like `Card`, `Button`, `Table`, `Modal`.
    -   **/layout**: Components that define the main application layout, such as `Header` and `Sidebar`.
-   **/contexts**: Holds the definitions and providers for the React Contexts used for state management.
-   **/data**: Contains the `mockData.ts` file, which acts as the in-memory database for the application.
-   **/hooks**: Custom React hooks for encapsulating reusable logic, such as `useUserPermissions`, `useCurrencyFormatter`, and `useAssetHealthScore`.
-   **/services**: Modules for interacting with external APIs. `geminiService.ts` is an example, containing logic to communicate with the Gemini API.
-   **/docs**: Project documentation files (like this one).
-   **/auth**: Contains permission definitions and logic related to user roles.

## Core Principles

-   **Component-Based**: The UI is built from small, reusable components.
-   **Centralized Data**: All application data flows from a single source of truth (`DataContext`), making state management predictable.
-   **Role-Based Access Control (RBAC)**: The `useUserPermissions` hook determines which views and actions are available to the currently logged-in user, providing a secure and tailored experience.
-   **Offline First**: As there is no backend, the application is fully functional offline after the initial load.
