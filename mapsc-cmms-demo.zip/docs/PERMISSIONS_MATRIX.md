
# User Roles & Rights Matrix

This document outlines the access permissions configured in the Mapsc CMMS system. Permissions are additive: a user receives the union of permissions from their **Base Role** and any **Groups** they belong to.

## Base Roles

| Role | Description | Key Permissions |
| :--- | :--- | :--- |
| **Administrator** | System Admin | **Full Access** to all modules, including System Settings and Audit Trails. |
| **Manager** | Department Head | Full access to Operational modules (Assets, Maintenance, Inventory, Personnel, Reports). **No access** to System Settings or Audit Logs. |
| **Factory Manager** | Executive | Same as Manager (Operational oversight). |
| **Engineer** | Technical Lead | Assets, Maintenance Planning, Reports, Procedures. |
| **Planner** | Maintenance Planner | Work Order Planning, PM Scheduling, Resource Allocation, Procurement Requests. |
| **Supervisor** | Logistics/Team Lead | Inventory Control, Procurement Approvals (RFQs, POs), Reporting. |
| **Controller** | Group Lead | View access to relevant module metrics and personnel. |
| **Clerk** | Data Entry | Basic transaction entry (Labor logs, Inventory transactions). |
| **Technician** | Field Worker | (Usually accessed via Groups) Work Orders, Asset Details. |
| **Operator** | Machine Operator | Submit Work Requests, View Asset status. |
| **Requester** | General Staff | Submit and View own Work Requests. |

## Group Permissions

Groups provide specialized access based on the user's function within the organization.

| Group Type | Typical Members | Access Scope |
| :--- | :--- | :--- |
| **Top Management** | Factory Mgr, Directors | **Full Operational Access**. Can approve high-value POs. No Admin access. |
| **Asset Managers** | Engineering Mgrs | **Full Operational Access**. Manage Assets, Maintenance strategies. |
| **Logistics Managers** | Supply Chain Mgrs | **Full Operational Access**. Approve POs, manage Inventory strategies. |
| **Engineers** | Reliability Engineers | Asset Configuration, Procedures, Analysis Reports, PM Definitions. |
| **Planner Group** | Maint. Planners | Planning & Scheduling, creating WOs, PMs, PRs. |
| **Maint. Controllers** | Team Leads | Oversee WOs, Assign Labor, View Asset Health. |
| **Logistics Controllers** | Warehouse Supv. | Full Inventory control: Cycle Counts, RFQs, POs, Vendors. |
| **Logistics Clerks** | Storekeepers | Issue/Receive Parts, View Inventory, Create Manual PRs. |
| **Maint. Clerks** | Dept Admins | Assist with WO data entry, View Assets. |
| **Work Center** | Technicians | Execute WOs, Log Labor, View assigned Assets. |

## Restricted Views (Admin Only)

The following views are strictly limited to the **Administrator** role and cannot be accessed by Managers or other high-level groups:

1.  **Admin & Settings** (Main Panel)
2.  **System Settings** (Configuration)
3.  **Audit Trails** (Security Logs)
4.  **User Rights & Permissions** (Access Control Audit)
5.  **Data Import/Export** (Bulk Data Tools)

## Data Visibility Rules

Beyond view access, data visibility is further restricted by **Zone**:

*   **Universal Viewers**: Administrators, Factory Managers, Logistics Managers (for inventory).
*   **Zone-Restricted**: Engineers, Planners, Technicians, Controllers only see Assets, Work Orders, and Parts linked to the Zones they are assigned to.
