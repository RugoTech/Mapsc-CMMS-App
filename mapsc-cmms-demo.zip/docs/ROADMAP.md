
# Project Roadmap

This document outlines the planned features and improvements for the Mapsc CMMS application.

## Short-Term (Next 3 Months)

-   **Enhanced Notifications**:
    -   Implement a real-time notification bell in the header for events like new work requests, low stock alerts, and approval requests.
    -   Dashboard KPIs will update in real-time.

-   **Improved Mobile Experience**:
    -   Refine UI components for better usability on smaller screens.
    -   Ensure all tables and forms are fully responsive.

-   **Vendor Communication Log**:
    -   Implement the "Communication" tab on the Vendor Detail page.
    -   Allow users to log emails, phone calls, and meetings with vendors.

## Mid-Term (3-9 Months)

-   **Native Mobile Application**:
    -   Develop a companion mobile app (likely using React Native) for technicians in the field.
    -   Features to include: viewing assigned WOs, logging labor, issuing parts via barcode scanning, and completing tasks.

-   **Advanced AI Diagnostics**:
    -   Expand the AI troubleshooting feature to accept image and audio inputs.
    -   Allow technicians to upload a photo of a failed component or a sound recording of a machine for AI analysis.

-   **Deeper Module Integration**:
    -   Automatic re-ordering of parts based on usage in PM Work Orders.
    -   Link asset downtime directly to production loss metrics.
    -   Integrate safety procedures more tightly into the WO completion workflow.

-   **Advanced Project Management**:
    -   Introduce Gantt charts for visualizing project timelines and dependencies.
    -   Add task management within projects.

## Long-Term (1+ Year)

-   **IoT Integration**:
    -   Integrate with IoT sensors for real-time, automatic meter readings.
    -   Trigger maintenance alerts based on live data (e.g., vibration, temperature).

-   **Predictive Maintenance (PdM)**:
    -   Utilize historical data and AI to predict asset failures before they occur.
    -   Automatically generate predictive maintenance work orders based on failure probability.

-   **Multi-Language Support**:
    -   Internationalize the application to support multiple languages.

-   **Customizable Workflows & Forms**:
    -   Allow administrators to create custom fields for assets, WOs, etc.
    -   Implement a workflow builder to define custom approval processes.

-   **Full Backend Implementation**:
    -   Replace the `mockData.ts` file with a robust backend service and database (e.g., Node.js with PostgreSQL) to make the application a full-stack, production-ready solution.
