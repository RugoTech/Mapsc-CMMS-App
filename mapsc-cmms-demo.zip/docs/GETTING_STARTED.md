
# Getting Started Guide

Welcome to the Mapsc CMMS demo! This guide will help you log in and start exploring the application's features.

## 1. Logging In

The application starts on a login page. Since this is a demo, there is no password required. Simply choose an account to simulate logging in as that user.

Each account represents a different **role** within a typical organization, such as:
-   **Factory Manager**: High-level overview of all operations.
-   **Administrator**: Full access to all features, including settings.
-   **Manager (Engineering/Logistics)**: Oversees a specific department.
-   **Engineer**: Responsible for asset management and technical specifications.
-   **Planner**: Manages work orders and maintenance schedules.
-   **Supervisor**: Approves requisitions and manages procurement workflows.
-   **Clerk**: Handles inventory transactions and data entry.

**To start, we recommend logging in as an `Administrator` (`admin@mapsc.com`) to see all available features.**

## 2. The Landing Page

After logging in, you will be taken to a central landing page. This page acts as a main menu, providing quick access to the major modules of the CMMS.

Click on any of the cards to navigate directly to that module. For a general overview, click on **Dashboard**.

## 3. The Main Application

The main application consists of three parts:

1.  **Sidebar (Left)**: The primary navigation menu. It's organized by module. Click on a category to expand it and see the available views.
2.  **Header (Top)**: Shows the title of your current view, a global search bar, and buttons for returning to the landing page or logging out.
3.  **Main Content Area**: This is where the selected view (e.g., the Asset List, a Work Order, a Report) is displayed.

## 4. Things to Try

Here are a few steps to explore the core functionality:

-   **View an Asset**:
    1.  Navigate to **Asset Management** -> **Asset Register** from the sidebar.
    2.  Click the "Details" button on any asset (e.g., `ASSET-001`).
    3.  Explore the different tabs: view its BOM, maintenance history, and attached documents.

-   **Explore a Work Order**:
    1.  Navigate to **Maintenance Management** -> **Work Orders**.
    2.  Click "Details" on an existing Work Order (e.g., `WO-001`).
    3.  Examine the resources planned, labor logs, and associated costs.
    4.  If the WO is a breakdown, check the "Root Cause Analysis" tab.

-   **Run a Report**:
    1.  Navigate to **Reporting & Analytics**.
    2.  Choose a report, for example, **Asset Downtime Report**.
    3.  Select a date range and click "Run Report" to see the results.

-   **Use the Global Search**:
    1.  In the header, type `WO-001` or `HVAC` into the search bar.
    2.  The dropdown will show matching results. Click one to navigate directly to it.

Enjoy exploring the Mapsc CMMS!
