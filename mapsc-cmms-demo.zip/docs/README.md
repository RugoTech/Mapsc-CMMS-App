
# Mapsc CMMS Documentation

Welcome to the official documentation for the Mapsc Computerized Maintenance Management System (CMMS).

## Overview

Mapsc CMMS is a comprehensive, modern web application designed to streamline maintenance operations for industrial and manufacturing environments. It provides a centralized platform for managing assets, tracking maintenance tasks, controlling inventory, and analyzing operational data to improve efficiency and reduce downtime.

The system features an AI-powered diagnostic assistant to help technicians troubleshoot equipment failures more effectively.

### Key Modules

- **Asset Management**: A complete register of all company assets, their locations, specifications, and history.
- **Maintenance Management**: Track work requests, create and manage work orders (preventive, corrective, breakdown), and schedule procedures.
- **Inventory Management**: A full procurement-to-payment system, including parts catalog, purchase requisitions, RFQs, purchase orders, and inventory tracking.
- **Personnel & Budgeting**: Manage user roles, permissions, and track maintenance costs against predefined budgets.
- **Reporting & Analytics**: A powerful suite of standard reports to analyze asset health, maintenance costs, PM compliance, and more.

## Navigation

To learn more about the project, please explore the other documents in this folder:

- **[Getting Started](./GETTING_STARTED.md)**: A guide for new users to explore the demo application.
- **[Features](./FEATURES.md)**: A complete list of currently implemented features.
- **[Architecture](./ARCHITECTURE.md)**: An in-depth look at the technical stack and project structure.
- **[Roadmap](./ROADMAP.md)**: Our plans for future features and enhancements.
