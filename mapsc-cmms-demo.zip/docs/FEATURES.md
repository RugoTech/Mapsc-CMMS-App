
# Implemented Features

This document provides a comprehensive list of all features currently available in the Mapsc CMMS application.

## Core Application Features

-   **User Authentication**: Demo-based login system with multiple user roles.
-   **Role-Based Access Control (RBAC)**: UI and functionality are tailored based on the logged-in user's role and group permissions.
-   **Global Search**: A powerful search bar in the header to quickly find Assets, Work Orders, Parts, and Vendors.
-   **Theming**: Light and Dark mode support, with an option to follow the system theme. User preference is saved in local storage.
-   **Responsive Design**: The application is designed to be usable on both desktop and mobile devices, with a collapsible sidebar.

## Modules

### 1. Dashboard
-   KPI cards for at-a-glance metrics (Open WOs, Downtime, Low Stock, etc.).
-   Charts for Maintenance Costs vs. Budget and Workload by Work Center.
-   Lists for Asset Meters by Zone and Active Users.

### 2. Asset Management
-   **Asset Register**: View, filter, and add company assets.
-   **Asset Detail View**: Comprehensive view of a single asset, including properties, health score, and history.
-   **Bill of Materials (BOM)**: Hierarchical view of components for an asset.
-   **Asset Meters**: Log and view meter readings for assets.
-   **Asset Documentation**: Attach and view documents like manuals and schematics.
-   **Asset History**: View a complete maintenance and cost history for an asset.
-   **Asset Location Management**: Define and manage the physical hierarchy (Plants, Zones, Areas).

### 3. Maintenance Management
-   **Work Requests**: Users can submit maintenance requests, which can be approved, rejected, or converted to Work Orders by planners.
-   **Work Orders**: Create, view, and manage all types of work orders (Preventive, Corrective, Breakdown, Project).
-   **Work Order Detail View**: A multi-tab interface to manage all aspects of a WO, including resource planning, procedures, parts, and labor logging.
-   **AI-Powered Troubleshooting**: Gemini-powered suggestions for troubleshooting based on the WO description and asset type.
-   **Labor Allocation**: A capacity planning view showing the workload of technicians against their weekly capacity.
-   **Procedures**: Create and manage Safety Instructions, Work Instructions, and Standard Operating Procedures (SOPs).
-   **Preventive Maintenance (PM)**: Schedule PMs based on calendar frequency or meter readings. Automatically or manually generate WOs from PM schedules.
-   **Projects**: Manage larger maintenance projects, create project-based WOs, and track budgets.

### 4. Inventory Management
-   **Parts Catalog**: A complete list of all inventory parts, with details on location, quantity, cost, and vendor.
-   **Inventory Transactions**: A log of all stock movements (issues, receipts, adjustments).
-   **Purchase Requisitions (PR)**: Create manual PRs for items/services or have the system generate them for low-stock items.
-   **Request for Quotation (RFQ)**: Create RFQs from approved PRs to send to vendors.
-   **Purchase Orders (PO)**: Create POs from RFQs, with a multi-level approval workflow for high-value orders.
-   **Goods Receiving**: Log the receipt of items against a purchase order.
-   **Invoice Reconciliation**: Match vendor invoices against received goods, with a workflow for approving with exceptions.
-   **Vendor Management**: Maintain a list of approved vendors and view their history.
-   **Inventory Alerts**: A dedicated view for low-stock items with quick actions to generate PRs.
-   **Cycle Counting**: Schedule and perform physical inventory counts, view variances, and post adjustments.

### 5. Personnel & Budgeting
-   **Personnel Management**: Manage users and their group assignments.
-   **Group Management**: Create and manage user groups (Work Centers, Controller Groups, etc.).
-   **Budgeting**: View budgets defined for different cost centers.
-   **Cost Centers**: View the hierarchical structure of cost centers.

### 6. Reporting & Analytics
A dedicated module with two tabs:
-   **Standard Reports**: A library of pre-built reports.
-   **Custom Reports**: A user-configurable dashboard for quick access to favorite reports.

**Available Reports:**
-   Work Order Summary
-   Maintenance Cost Report
-   Inventory Valuation
-   Stock Movement
-   Labor Utilization
-   PM Compliance
-   Asset Downtime
-   Work Request Status
-   Procedure Usage
-   Project Status
-   Machine Availability
-   MTBF (Mean Time Between Failures)
-   MTTR (Mean Time To Repair)
-   Asset Health Score
-   Maintenance Mix
-   Purchase Requisition Report
-   Purchase Order Report
-   Cycle Count Report

### 7. Admin & Settings
-   **System Settings**: Configure global settings like currency, date format, default priorities, and notification preferences.
-   **Audit Trails**: A comprehensive log of all create, update, and delete actions performed in the system.
-   **Data Import/Export**: Tools to bulk import data (Assets, Parts, Users, etc.) from CSV and export system data to CSV.
-   **User Rights & Permissions**: A detailed matrix view to audit user roles, group memberships, and effective permissions.
