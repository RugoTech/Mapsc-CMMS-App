
import type { View, User } from '../types';

// All views available in the application.
export const allViews: View[] = [
  'Dashboard', 'Messages', 'Assets', 'Asset Detail', 'Asset Location',
  'Asset Meters', 'Asset Documentation', 'Asset History', 'Work Requests',
  'Work Orders', 'Work Order Detail', 'Labor Allocation', 'Procedures', 'Preventive Maintenance',
  'Projects', 'Warehousing', 'Parts Catalog', 'Inventory Transactions', 'Purchase Requisitions',
  'RFQs', 'Purchase Orders', 'Vendors', 'Vendor Detail', 'Inventory Alerts', 'Cycle Counting',
  'Invoice Reconciliation', 'Personnel Management',
  'Reporting & Analytics', 'Asset Health Score', 'Report: Purchase Requisitions', 'Report: Purchase Orders', 'Report: Cycle Counts',
  'Admin & Settings', 'System Settings', 'Audit Trails', 'User Rights & Permissions'
];

// Views strictly reserved for system administrators
const adminViews: View[] = [
  'Admin & Settings', 
  'System Settings', 
  'Audit Trails', 
  'User Rights & Permissions'
];

/**
 * Defines permissions for specific user roles that are not tied to a group structure,
 * such as system-wide administrators or basic requesters.
 */
export const standaloneRolePermissions: Partial<Record<User['role'], View[]>> = {
  Administrator: allViews,
  Requester: [
    'Dashboard', 'Messages', 'Work Requests'
  ],
  Operator: [
    'Dashboard', 'Messages', 'Work Requests', 'Assets', 'Asset Detail', 'Work Orders', 'Work Order Detail'
  ],
  'Manager': [
    'Dashboard', 'Messages', 'Assets', 'Asset Detail', 'Asset Location',
    'Asset Meters', 'Asset Documentation', 'Asset History', 'Work Requests',
    'Work Orders', 'Work Order Detail', 'Labor Allocation', 'Procedures', 'Preventive Maintenance',
    'Projects', 'Warehousing', 'Parts Catalog', 'Personnel Management',
    'Reporting & Analytics', 'Asset Health Score', 'Report: Purchase Requisitions', 'Report: Purchase Orders', 'Report: Cycle Counts',
    'Purchase Requisitions', 'RFQs', 'Purchase Orders', 'Vendors', 'Vendor Detail'
  ],
  'Supervisor': [
    'Dashboard',
    'Messages',
    'Work Requests',
    'Warehousing',
    'Parts Catalog',
    'Inventory Transactions',
    'Purchase Requisitions',
    'RFQs',
    'Purchase Orders',
    'Invoice Reconciliation',
    'Vendors',
    'Vendor Detail',
    'Inventory Alerts',
    'Cycle Counting',
    'Reporting & Analytics',
    'Report: Purchase Requisitions', 'Report: Purchase Orders', 'Report: Cycle Counts',
  ],
  'Engineer': [
    'Dashboard', 'Messages', 'Assets', 'Asset Detail', 'Asset Location', 'Asset Meters', 'Asset Documentation', 'Asset History',
    'Work Requests',
    'Work Orders', 'Work Order Detail', 'Labor Allocation', 'Procedures', 'Preventive Maintenance', 'Parts Catalog',
    'Inventory Transactions', 'Purchase Requisitions', 'Reporting & Analytics', 'Asset Health Score',
    'Report: Purchase Requisitions', 'Report: Purchase Orders', 'Report: Cycle Counts',
  ],
  'Planner': [
    'Dashboard', 'Messages', 'Assets', 'Asset Detail', 'Asset Location', 'Asset Meters', 'Asset Documentation', 'Asset History',
    'Work Orders', 'Work Order Detail', 'Labor Allocation', 'Procedures', 'Preventive Maintenance',
    'Projects', 'Parts Catalog', 'Purchase Requisitions', 'Vendors', 'Vendor Detail', 'Reporting & Analytics', 'Asset Health Score',
    'Report: Purchase Orders', 'Report: Purchase Requisitions',
    'Work Requests'
  ],
};

/**
 * Specific permissions for Maintenance Clerks.
 * They need to see Asset/Maintenance info and basic inventory/PRs,
 * but not the full procurement chain like RFQs/POs.
 */
export const maintenanceClerkPermissions: View[] = [
  'Dashboard', 'Messages',
  // Asset Views
  'Assets', 'Asset Detail', 'Asset Meters',
  // Maintenance Views
  'Work Requests',
  'Work Orders', 'Work Order Detail',
  // Inventory Views for Maintenance Support
  'Parts Catalog'
];

/**
 * Defines which views each group type can access. A user's total permissions
 * will be the union of all permissions from all groups they are a member of.
 */
export const groupPermissions: Record<string, View[]> = {
  // Top Management gets everything EXCEPT restricted Admin configuration pages
  TopManagementGroup: allViews.filter(v => !adminViews.includes(v)),
  AssetManagers: allViews.filter(v => !adminViews.includes(v)),
  LogisticsManagers: allViews.filter(v => !adminViews.includes(v)),
  
  Engineers: [
    'Dashboard', 'Messages', 'Assets', 'Asset Detail', 'Asset Location', 'Asset Meters', 'Asset Documentation', 'Asset History',
    'Work Requests',
    'Work Orders', 'Work Order Detail', 'Labor Allocation', 'Procedures', 'Parts Catalog',
    'Inventory Transactions', 'Purchase Requisitions', 'Reporting & Analytics', 'Asset Health Score',
    'Report: Purchase Requisitions', 'Report: Purchase Orders', 'Report: Cycle Counts', 'Preventive Maintenance'
  ],
  PlannerGroup: [
    'Dashboard', 'Messages', 'Assets', 'Asset Detail', 'Asset Location', 'Asset Meters',
    'Asset Documentation', 'Asset History', 'Work Orders',
    'Work Order Detail', 'Labor Allocation', 'Procedures', 'Preventive Maintenance', 'Projects',
    'Parts Catalog', 'Purchase Requisitions', 'Vendors', 'Vendor Detail', 'Reporting & Analytics', 'Asset Health Score',
    'Report: Purchase Orders', 'Report: Purchase Requisitions',
    'Work Requests'
  ],
  MaintenanceControllers: [
    'Dashboard', 'Messages', 'Assets', 'Asset Detail', 'Work Requests',
    'Work Orders', 'Work Order Detail', 'Labor Allocation', 'Procedures', 'Preventive Maintenance',
    'Personnel Management', 'Reporting & Analytics', 'Asset Health Score'
  ],
  LogisticsControllers: [
    'Dashboard', 'Messages', 'Warehousing', 'Parts Catalog', 'Inventory Transactions',
    'Purchase Requisitions', 'RFQs', 'Purchase Orders', 'Invoice Reconciliation',
    'Vendors', 'Vendor Detail', 'Inventory Alerts', 'Cycle Counting', 'Reporting & Analytics',
    'Report: Purchase Requisitions', 'Report: Purchase Orders', 'Report: Cycle Counts',
    'Work Requests',
  ],
  LogisticsClerks: [
    'Dashboard', 'Messages', 
    'Assets', 'Asset Detail', 'Asset Location', 'Asset Meters', 'Asset Documentation', 'Asset History',
    'Warehousing', 'Parts Catalog', 'Inventory Transactions',
    'Purchase Requisitions', 'RFQs', 'Purchase Orders', 'Invoice Reconciliation',
    'Vendors', 'Vendor Detail', 'Inventory Alerts', 'Cycle Counting',
    'Report: Purchase Requisitions', 'Report: Purchase Orders', 'Report: Cycle Counts',
    'Work Requests',
  ],
  MaintenanceClerks: maintenanceClerkPermissions,
  WorkCenter: [
    'Dashboard', 'Messages', 'Assets', 'Asset Detail', 'Asset Documentation', 'Asset History',
    'Work Orders', 'Work Order Detail', 'Procedures', 'Parts Catalog',
    'Inventory Transactions',
    'Work Requests',
  ]
};
