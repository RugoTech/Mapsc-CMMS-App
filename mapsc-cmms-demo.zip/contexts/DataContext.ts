import React, { createContext } from 'react';
import type { MockData } from '../types';

interface DataContextType {
  data: MockData;
  setData: React.Dispatch<React.SetStateAction<MockData>>;
}

export const DataContext = createContext<DataContextType | undefined>(undefined);